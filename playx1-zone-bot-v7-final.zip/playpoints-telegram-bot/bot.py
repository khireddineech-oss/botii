import os
import re
import math
import time
import socket
import asyncio
import logging
from datetime import datetime
from typing import Dict, Any, Optional, List, Tuple, Union
from concurrent.futures import ThreadPoolExecutor

import aiohttp
import gpsoauth
from aiogram import Bot, Dispatcher, F, types, BaseMiddleware
from aiogram.types import (
    InlineKeyboardMarkup,
    InlineKeyboardButton,
    FSInputFile,
    LabeledPrice,
    PreCheckoutQuery,
    ReplyKeyboardRemove,
)
from aiogram.filters import CommandStart, Command, StateFilter, CommandObject
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiogram.client.session.aiohttp import AiohttpSession

import database as db
from games_catalog import GAMES_CATALOG
from google_auth import GoogleAuthenticator, EMBEDDED_SETUP_URL
from autopixel_auth import AutoPixelAuthenticator
from gpgs_unlocker import GPGSUnlocker
from services.weekly_reward import claim_weekly_perk, fast_claim_weekly_perk
from services.device_simulator import create_device_profile
from services.google_automation_core.driver_factory import build_driver

QUEST_SEMAPHORE = asyncio.Semaphore(10)
QUEST_EXECUTOR = ThreadPoolExecutor(max_workers=14)
PAGE_SIZE_ACCOUNTS = 6
_BOT_USERNAME_CACHE: Optional[str] = None

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

BOT_TOKEN = os.getenv("BOT_TOKEN")

if not BOT_TOKEN:
    env_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env")
    if os.path.exists(env_file):
        with open(env_file, encoding="utf-8") as f:
            for line in f:
                line_str = line.strip()
                if not line_str or line_str.startswith("#"):
                    continue
                if line_str.startswith("BOT_TOKEN=") and not BOT_TOKEN:
                    BOT_TOKEN = line_str.split("=", 1)[1].strip()

if not BOT_TOKEN:
    raise RuntimeError("BOT_TOKEN is not set in environment or .env file.")

session = AiohttpSession()
session._connector_init["family"] = socket.AF_INET
bot = Bot(token=BOT_TOKEN, session=session)

dp = Dispatcher(storage=MemoryStorage())

ADMIN_IDS = [
    int(x) for x in os.getenv("ADMIN_IDS", "9093744527").split(",")
    if x.strip().isdigit()
]

CHANNEL_URL = "https://t.me/PLAYX1_ZONE"
CHANNEL_HANDLE = "@PLAYX1_ZONE"
BRAND_NAME = "PLAYX1 ZONE"
CHEST_COST = 2.0

STARS_PACKS = [
    (1, 2),
    (2, 4),
    (3, 6),
    (6, 13),
    (12, 25),
    (26, 50),
    (54, 100),
    (112, 200),
    (350, 600),
    (700, 1000),
]

INTRO_GIF_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "intro.gif")

_SUB_CACHE: Dict[int, Tuple[float, bool, List[Dict[str, Any]]]] = {}
_SUB_CACHE_TTL = 120.0
_SUB_CACHE_MAX_SIZE = 2000


def _prune_sub_cache():
    if len(_SUB_CACHE) > _SUB_CACHE_MAX_SIZE:
        now = time.time()
        expired = [k for k, v in _SUB_CACHE.items() if now - v[0] > _SUB_CACHE_TTL]
        for k in expired:
            _SUB_CACHE.pop(k, None)
        if len(_SUB_CACHE) > _SUB_CACHE_MAX_SIZE:
            for k in list(_SUB_CACHE.keys())[: len(_SUB_CACHE) - (_SUB_CACHE_MAX_SIZE // 2)]:
                _SUB_CACHE.pop(k, None)


async def _get_bot_username(bot_instance: Bot) -> str:
    global _BOT_USERNAME_CACHE
    if _BOT_USERNAME_CACHE:
        return _BOT_USERNAME_CACHE
    me = await bot_instance.get_me()
    _BOT_USERNAME_CACHE = me.username or ""
    return _BOT_USERNAME_CACHE


def fmt_tok(val: Union[int, float, str]) -> str:
    try:
        v = round(float(val), 4)
        if v == int(v):
            return str(int(v))
        return f"{v:g}"
    except Exception:
        return str(val)


def parse_float_val(raw: str) -> Optional[float]:
    try:
        cleaned = raw.strip().replace(",", ".")
        val = float(cleaned)
        if math.isnan(val) or math.isinf(val) or val < 0:
            return None
        return round(val, 4)
    except Exception:
        return None


def get_chest_cost() -> float:
    val = db.get_setting_float("chest_cost", CHEST_COST)
    return val if val >= 0 else CHEST_COST


def get_weekly_base_cost() -> float:
    val = db.get_setting_float("weekly_prize_cost", 1.0)
    return val if val >= 0 else 1.0


def get_weekly_cost_for_user(user_id: int) -> float:
    if db.get_setting_bool("weekly_free_first_time", False) and not db.has_user_used_weekly_before(user_id):
        return 0.0
    return get_weekly_base_cost()


def get_welcome_bonus() -> float:
    val = db.get_setting_float("welcome_bonus", 8.0)
    return val if val >= 0 else 8.0


def get_admin_lang() -> str:
    lang = db.get_setting("admin_lang", "ar")
    return lang if lang in ("ar", "en", "fr") else "ar"


def cleanup_file(filepath: Optional[str]):
    if filepath and os.path.exists(filepath):
        try:
            os.remove(filepath)
        except Exception:
            pass


def parse_channels_input(raw_text: str) -> List[str]:
    tokens = raw_text.strip().replace(",", " ").split()
    results = []
    for item in tokens:
        item = item.strip()
        if not item:
            continue
        item = re.sub(r"^https?://(?:www\.)?t\.m(?:e)?/", "", item)
        item = item.split("/")[0].split("?")[0]
        item = item.lstrip("@").strip()
        if item:
            results.append(f"@{item}")
    return list(dict.fromkeys(results))


async def safe_show(
    target: Union[types.Message, types.CallbackQuery],
    text: str,
    reply_markup: Optional[InlineKeyboardMarkup] = None,
    prefer_edit: bool = True,
    disable_web_page_preview: bool = True,
):
    if isinstance(target, types.CallbackQuery):
        msg = target.message
        if prefer_edit and msg and msg.text is not None:
            try:
                await msg.edit_text(
                    text,
                    reply_markup=reply_markup,
                    parse_mode="HTML",
                    disable_web_page_preview=disable_web_page_preview,
                )
                return msg
            except Exception as e:
                if "message is not modified" in str(e).lower():
                    return msg
        return await msg.answer(
            text,
            reply_markup=reply_markup,
            parse_mode="HTML",
            disable_web_page_preview=disable_web_page_preview,
        )
    return await target.answer(
        text,
        reply_markup=reply_markup,
        parse_mode="HTML",
        disable_web_page_preview=disable_web_page_preview,
    )


async def send_welcome_message(chat_id: int, user_id: int, text: str, reply_markup):
    if os.path.exists(INTRO_GIF_PATH):
        try:
            return await bot.send_animation(
                chat_id=chat_id,
                animation=FSInputFile(INTRO_GIF_PATH),
                caption=text,
                reply_markup=reply_markup,
                parse_mode="HTML",
            )
        except Exception as e:
            logger.warning("Failed to send intro gif: %s", e)
    return await bot.send_message(
        chat_id=chat_id,
        text=text,
        reply_markup=reply_markup,
        parse_mode="HTML",
        disable_web_page_preview=True,
    )


async def check_single_channel_membership(bot_instance: Bot, channel_username: str, user_id: int) -> bool:
    ch = channel_username.strip()
    if not ch.startswith("@"):
        ch = f"@{ch}"
    try:
        member = await bot_instance.get_chat_member(chat_id=ch, user_id=user_id)
        return member.status in ("creator", "administrator", "member", "restricted")
    except Exception as e:
        logger.warning("Membership check error for %s user %s: %s", ch, user_id, e)
        return False


async def check_all_channels_subscription(
    bot_instance: Bot, user_id: int, use_cache: bool = True
) -> Tuple[bool, List[Dict[str, Any]]]:
    if not db.get_setting_bool("force_sub_enabled", True):
        return (True, [])
    now = time.time()
    if use_cache and user_id in _SUB_CACHE:
        ts, is_sub, missing = _SUB_CACHE[user_id]
        if now - ts < _SUB_CACHE_TTL:
            return is_sub, missing

    channels = db.get_mandatory_channels()
    if not channels:
        return (True, [])

    missing = []
    for ch in channels:
        ch_uname = ch["channel_username"]
        ok = await check_single_channel_membership(bot_instance, ch_uname, user_id)
        if not ok:
            missing.append(ch)

    is_subscribed = len(missing) == 0
    _prune_sub_cache()
    _SUB_CACHE[user_id] = (now, is_subscribed, missing)
    return (is_subscribed, missing)


async def _notify_inviter_reward(inviter_id: int, invited_user_id: int, invited_username: Optional[str], reward_amt: float):
    if reward_amt <= 0:
        return
    inv_lang = db.get_user_language(inviter_id) or "ar"
    r_str = fmt_tok(reward_amt)
    uname_disp = f"@{invited_username}" if invited_username else str(invited_user_id)
    try:
        if inv_lang == "en":
            inv_msg = (
                "🎊 <b>Referral Reward Credited!</b>\n"
                f"Your invited member {uname_disp} joined & verified.\n"
                f"💳 <b>+{r_str} Tokens</b> have been added to your wallet!"
            )
        elif inv_lang == "fr":
            inv_msg = (
                "🎊 <b>Prime de Parrainage Créditée !</b>\n"
                f"Votre filleul {uname_disp} a rejoint nos chaînes.\n"
                f"💳 <b>+{r_str} Tokens</b> ajoutés à votre solde !"
            )
        else:
            inv_msg = (
                "🎊 <b>مكافأة إحالة جديدة!</b>\n"
                f"انضم صديقك {uname_disp} وأكمل الاشتراك بنجاح.\n"
                f"💳 تم شحن <b>+{r_str} توكن</b> إلى محفظتك!"
            )
        await bot.send_message(inviter_id, inv_msg, parse_mode="HTML")
    except Exception:
        pass


STRINGS = {
    "ar": {
        "quest": "🚀 فتح الصناديق",
        "weekly": "👑 الجائزة الأسبوعية",
        "services_store": "🛍️ متجر العروض والخدمات",
        "balance": "💳 محفظتي والشحن",
        "profile": "👤 ملفي الشخصي",
        "rewards": "🎉 مركز الهدايا والربح",
        "checkin": "📅 تسجيل الدخول اليومي",
        "leaderboard": "🥇 نخبة الداعمين",
        "help": "📘 دليل الاستخدام",
        "lang": "🌐 اللغة",
        "channel": "📡 PLAYX1 ZONE",
        "admin": "🛡️ لوحة الإدارة",
        "home": "🏠 القائمة الرئيسية",
        "cancel": "✖️ إلغاء",
        "back": "↩️ رجوع",
        "welcome": (
            "⚡ <b>مرحباً بك في منصة PLAYX1 ZONE الذكية</b> ⚡\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "مساعدك الذكي لإنجاز مهام ومكافآت <b>Google Play Points</b> بسرعة وأمان.\n\n"
            "🎁 <b>رصيد ترحيبي فوري:</b> <code>{welcome_bonus}</code> توكن مجاناً\n"
            "⚡ <b>إنجاز فوري ومباشر:</b> إتمام المهام واستلام النقاط خلال ثوانٍ\n"
            "🎉 <b>طرق ربح مجانية:</b> تسجيل دخول يومي، إحالات، قنوات، وأكواد هدايا\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "💳 <b>رصيدك الحالي:</b> <code>{balance}</code> توكن\n"
            "📦 <b>تكلفة الصندوق:</b> <code>{chest_cost}</code> توكن\n"
            "👑 <b>تكلفة الجائزة الأسبوعية:</b> <code>{weekly_cost}</code> توكن\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "🧭 <i>اختر القسم المطلوب من الأزرار أدناه للبدء:</i>"
        ),
        "sub_req": (
            "🔐 <b>بوابة الدخول — PLAYX1 ZONE</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "للاستفادة من خدمات البوت المجانية والفورية، يرجى الانضمام أولاً إلى قنواتنا الرسمية أدناه.\n\n"
            "👇 <i>اشترك في القنوات ثم اضغط على زر التحقق:</i>"
        ),
        "sub_alert": "🔒 يرجى الاشتراك في جميع القنوات المطلوبة أولاً.",
        "sub_btn_check": "✅ تحقّق من اشتراكي الآن",
        "sub_ok": "🎉 تم تأكيد اشتراكك بنجاح! أهلاً بك في PLAYX1 ZONE.",
        "sub_fail": "⚠️ لم نرصد اشتراكك في كل القنوات بعد، تأكد وحاول مجدداً.",
        "banned": (
            "🚫 <b>تم تقييد وصولك إلى البوت</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "حسابك موقوف حالياً من قبل الإدارة."
        ),
        "maint": (
            "🛠️ <b>البوت في وضع الصيانة المؤقتة</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "نعمل حالياً على تحديث الأنظمة لتحسين السرعة والأداء.\n"
            "📡 تابع آخر الأخبار عبر قناتنا: https://t.me/PLAYX1_ZONE"
        ),
    },
    "en": {
        "quest": "🚀 Quest Vault",
        "weekly": "👑 Weekly Prize",
        "services_store": "🛍️ Offers & Services",
        "balance": "💳 Wallet & Top-Up",
        "profile": "👤 My Profile",
        "rewards": "🎉 Earn & Bonus Center",
        "checkin": "📅 Daily Check-In",
        "leaderboard": "🥇 Top Supporters",
        "help": "📘 User Guide",
        "lang": "🌐 Language",
        "channel": "📡 PLAYX1 ZONE",
        "admin": "🛡️ Admin Control",
        "home": "🏠 Main Menu",
        "cancel": "✖️ Cancel",
        "back": "↩️ Back",
        "welcome": (
            "⚡ <b>Welcome to PLAYX1 ZONE Smart Hub</b> ⚡\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "Your fast smart assistant to complete <b>Google Play Points</b> chests & weekly rewards.\n\n"
            "🎁 <b>Welcome Gift:</b> <code>{welcome_bonus}</code> free tokens on startup\n"
            "⚡ <b>Instant Execution:</b> Fast task sync in seconds\n"
            "🎉 <b>Free Rewards:</b> Daily Check-In streak, referrals, channels & gift codes\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "💳 <b>Your Wallet:</b> <code>{balance}</code> Tokens\n"
            "📦 <b>Chest Cost:</b> <code>{chest_cost}</code> Tokens\n"
            "👑 <b>Weekly Prize Cost:</b> <code>{weekly_cost}</code> Tokens\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "🧭 <i>Select an option from the menu below to get started:</i>"
        ),
        "sub_req": (
            "🔐 <b>Access Gate — PLAYX1 ZONE</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "To unlock all bot services, please join our official channel(s) below first.\n\n"
            "👇 <i>Join the channels and tap Verify below:</i>"
        ),
        "sub_alert": "🔒 Please join all required channels first.",
        "sub_btn_check": "✅ Verify My Membership",
        "sub_ok": "🎉 Membership verified! Welcome to PLAYX1 ZONE.",
        "sub_fail": "⚠️ Subscription not detected yet. Join all channels and retry.",
        "banned": (
            "🚫 <b>Access Restricted</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "Your account is currently suspended by administration."
        ),
        "maint": (
            "🛠️ <b>Scheduled Maintenance Mode</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "We are upgrading our servers for faster performance.\n"
            "📡 Stay updated on our channel: https://t.me/PLAYX1_ZONE"
        ),
    },
    "fr": {
        "quest": "🚀 Coffres & Quêtes",
        "weekly": "👑 Prix Hebdomadaire",
        "services_store": "🛍️ Boutique Services & Offres",
        "balance": "💳 Solde & Recharge",
        "profile": "👤 Mon Profil",
        "rewards": "🎉 Centre Cadeaux & Gains",
        "checkin": "📅 Connexion Quotidienne",
        "leaderboard": "🥇 Top Membres",
        "help": "📘 Guide Rapide",
        "lang": "🌐 Langue",
        "channel": "📡 PLAYX1 ZONE",
        "admin": "🛡️ Panneau Admin",
        "home": "🏠 Menu Principal",
        "cancel": "✖️ Annuler",
        "back": "↩️ Retour",
        "welcome": (
            "⚡ <b>Bienvenue sur PLAYX1 ZONE</b> ⚡\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "Votre assistant rapide pour valider vos coffres et prix hebdomadaires <b>Google Play Points</b>.\n\n"
            "🎁 <b>Cadeau de Bienvenue :</b> <code>{welcome_bonus}</code> tokens offerts\n"
            "⚡ <b>Validation Express :</b> Synchronisation rapide en quelques secondes\n"
            "🎉 <b>Gains Gratuits :</b> Bonus quotidien, parrainage, chaînes & codes cadeaux\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "💳 <b>Votre Solde :</b> <code>{balance}</code> Tokens\n"
            "📦 <b>Coût du Coffre :</b> <code>{chest_cost}</code> Tokens\n"
            "👑 <b>Coût Prix Hebdo :</b> <code>{weekly_cost}</code> Tokens\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "🧭 <i>Choisissez une action dans le menu ci-dessous :</i>"
        ),
        "sub_req": (
            "🔐 <b>Accès Requis — PLAYX1 ZONE</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "Pour utiliser les services du bot, veuillez rejoindre nos chaînes officielles ci-dessous.\n\n"
            "👇 <i>Rejoignez les chaînes puis cliquez sur Vérifier :</i>"
        ),
        "sub_alert": "🔒 Veuillez d'abord rejoindre toutes les chaînes requises.",
        "sub_btn_check": "✅ Vérifier mon Abonnement",
        "sub_ok": "🎉 Abonnement confirmé ! Bienvenue sur PLAYX1 ZONE.",
        "sub_fail": "⚠️ Abonnement non détecté. Rejoignez toutes les chaînes puis réessayez.",
        "banned": (
            "🚫 <b>Accès Restreint</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "Votre compte est actuellement suspendu par l'administration."
        ),
        "maint": (
            "🛠️ <b>Maintenance en Cours</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "Nos serveurs sont en cours de mise à jour.\n"
            "📡 Suivez les actualités sur : https://t.me/PLAYX1_ZONE"
        ),
    },
}


ADMIN_STRINGS = {
    "ar": {
        "title": "🛡️ <b>مركز التحكم الإداري المتكامل — PLAYX1 ZONE</b>",
        "subtitle": (
            "━━━━━━━━━━━━━━━━━━━━\n"
            "⚙️ <b>النظام:</b> {maint} | 📡 <b>الاشتراك:</b> {fsub}\n"
            "📦 <b>الصندوق:</b> <code>{cost}</code> 🪙 | 👑 <b>الأسبوعية:</b> <code>{wcost}</code> 🪙 | 🎁 <b>الترحيب:</b> <code>{wbonus}</code> 🪙\n"
            "🤝 <b>الإحالة:</b> {ref_st} (<code>{ref_r}</code> 🪙) | 📅 <b>اليومي:</b> {ci_st}\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "اختر القسم أو الأداة الإدارية المطلوبة:"
        ),
        "on": "🟢 مفعّل",
        "off": "🔴 متوقف",
        "maint_on": "🟠 صيانة",
        "maint_off": "🟢 يعمل",
        "btn_stats": "📊 الإحصائيات",
        "btn_lookup": "🔎 بحث عن عضو",
        "btn_users_top": "👥 الأعضاء والنخبة",
        "btn_add": "➕ شحن توكنات",
        "btn_sub": "➖ خصم توكنات",
        "btn_gift_all": "🎁 هدية للجميع",
        "btn_bans": "🚫 المحظورون",
        "btn_weekly_cfg": "👑 الجائزة الأسبوعية",
        "btn_services_cfg": "🛍️ متجر العروض والخدمات",
        "btn_ref_cfg": "🤝 نظام الإحالة",
        "btn_checkin_cfg": "📅 الدخول اليومي",
        "btn_ch_rewards": "💎 ربح القنوات",
        "btn_mand": "📡 القنوات الإجبارية",
        "btn_promo_ch": "🌟 القنوات الشريكة",
        "btn_promos": "🎫 أكواد الهدايا",
        "btn_bcast": "📣 إذاعة شاملة",
        "btn_dm": "📩 رسالة لعضو",
        "btn_settings": "⚙️ إعدادات متقدمة",
        "btn_logs": "📜 سجل الإدارة",
        "btn_backup": "💾 نسخة احتياطية",
        "btn_lang": "🌐 لغة اللوحة: العربية",
        "btn_home": "🏠 واجهة البوت",
        "btn_close": "✖️ إغلاق",
        "btn_back_admin": "↩️ لوحة الإدارة",
        "btn_cancel": "✖️ إلغاء",
        "closed": "تم إغلاق لوحة الإدارة.",
        "lang_title": "🌐 <b>اختر لغة لوحة التحكم الإدارية:</b>",
        "lang_updated": "✅ تم تغيير لغة لوحة الإدارة إلى العربية.",
        "stats_body": (
            "📊 <b>التقرير الإحصائي الشامل — PLAYX1 ZONE</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "👥 <b>إجمالي الأعضاء:</b> <code>{total_users}</code>\n"
            "🆕 <b>أعضاء اليوم:</b> <code>{new_users_today}</code>\n"
            "🚫 <b>الحسابات المحظورة:</b> <code>{banned_users}</code>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "💳 <b>التوكنات المتداولة:</b> <code>{total_balance}</code>\n"
            "🛍️ <b>التوكنات المشتراة:</b> <code>{tokens_purchased}</code>\n"
            "⭐ <b>إجمالي النجوم:</b> <code>{stars_spent}</code>\n"
            "📅 <b>إجمالي تسجيلات الدخول اليومي:</b> <code>{total_checkins}</code>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "🚀 <b>صناديق مكتملة:</b> <code>{completed_quests}</code>\n"
            "⚠️ <b>محاولات فاشلة:</b> <code>{failed_quests}</code>\n"
            "👑 <b>مطالبات الجائزة الأسبوعية:</b> <code>{weekly_claims}</code>\n"
            "🔑 <b>حسابات محفوظة:</b> <code>{saved_accs}</code>\n"
            "🤝 <b>إحالات ناجحة:</b> <code>{total_referrals}</code>\n"
            "📡 <b>قنوات إجبارية / شريكة:</b> <code>{mandatory_channels} / {promo_channels}</code>\n"
            "🎫 <b>أكواد هدايا نشطة:</b> <code>{active_promos}</code>"
        ),
        "lookup_prompt": "🔎 <b>البحث عن عضو:</b>\n\nأرسل معرّف التليجرام (ID) أو اليوزرنيم (<code>@username</code>):\n<i>(أو أرسل /cancel للإلغاء)</i>",
        "user_not_found": "⚠️ لم يتم العثور على هذا العضو في قاعدة البيانات.",
        "user_card": (
            "👤 <b>بطاقة العضو</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "🆔 <b>المعرّف:</b> <code>{uid}</code>\n"
            "🔖 <b>اليوزر:</b> {uname}\n"
            "💳 <b>الرصيد:</b> <code>{bal}</code> توكن\n"
            "🌐 <b>اللغة:</b> <code>{ulang}</code>\n"
            "🛡️ <b>الحالة:</b> {status}\n"
            "🔥 <b>سلسلة الدخول اليومي:</b> <code>{streak}/7</code> ({total_ci} مرة)\n"
            "🚀 <b>الصناديق المنجزة:</b> <code>{qcount}</code>\n"
            "🔑 <b>الحسابات المحفوظة:</b> <code>{acount}</code>\n"
            "🤝 <b>الإحالات النشطة:</b> <code>{rcount}</code>\n"
            "⭐ <b>النجوم المنفقة:</b> <code>{stars}</code>\n"
            "📅 <b>تاريخ الانضمام:</b> <code>{created}</code>"
        ),
        "status_active": "🟢 نشط",
        "status_banned": "🔴 محظور",
        "u_btn_add": "➕ شحن لهذا العضو",
        "u_btn_sub": "➖ خصم من هذا العضو",
        "u_btn_ban": "🚫 حظر العضو",
        "u_btn_unban": "✅ فك الحظر",
        "u_btn_dm": "📩 مراسلة العضو",
        "u_btn_reset_ci": "🔄 تصفير سلسلتهم",
        "add_prompt": "➕ <b>شحن توكنات لعضو (يدعم الكسور مثل 0.25 و 0.5):</b>\n\nأرسل المعرّف أو اليوزر متبوعاً بالكمية:\nمثال: <code>@username 2.5</code> أو <code>123456789 0.25</code>",
        "add_one_prompt": "➕ <b>أرسل عدد التوكنات المراد إضافتها للعضو</b> <code>{uid}</code> (مثال <code>2</code> أو <code>0.5</code>):",
        "sub_prompt": "➖ <b>خصم توكنات من عضو (يدعم الكسور مثل 0.25):</b>\n\nأرسل المعرّف أو اليوزر متبوعاً بالكمية:\nمثال: <code>@username 1.5</code> أو <code>123456789 0.25</code>",
        "sub_one_prompt": "➖ <b>أرسل عدد التوكنات المراد خصمها من العضو</b> <code>{uid}</code>:",
        "bad_format": "⚠️ صيغة غير صحيحة! يرجى التأكد والمحاولة مجدداً.",
        "added_ok": "✅ <b>تم شحن {amount} توكن للعضو {target} بنجاح!</b>\n💳 الرصيد الجديد: <code>{bal}</code> توكن",
        "sub_ok": "✅ <b>تم خصم {amount} توكن من العضو {target}.</b>\n💳 الرصيد الجديد: <code>{bal}</code> توكن",
        "gift_prompt": "🎁 <b>توزيع هدية جماعية لكل الأعضاء:</b>\n\nأرسل عدد التوكنات المراد إضافتها لكل عضو نشط (يدعم الكسور مثل <code>0.5</code> أو <code>5</code>):",
        "gift_done": "🎉 <b>تم توزيع هدية جماعية بنجاح!</b>\n\n🎁 <b>القيمة:</b> +{amount} توكن\n👥 <b>المستفيدون:</b> {count} عضو\n📨 <b>تم إشعارهم:</b> {sent} | ❌ <b>فشل الإشعار:</b> {failed}",
        "bans_title": "🚫 <b>إدارة الأعضاء المحظورين:</b>\n\n",
        "bans_empty": "<i>لا يوجد أي أعضاء محظورين حالياً.</i>",
        "btn_ban_new": "➕ حظر عضو جديد",
        "ban_prompt": "🚫 <b>حظر عضو:</b>\n\nأرسل معرّف العضو (ID) أو اليوزر (<code>@username</code>):",
        "cannot_ban_admin": "⚠️ لا يمكن حظر حساب الأدمن!",
        "banned_ok": "🚫 تم حظر العضو <code>{uid}</code> بنجاح.",
        "unbanned_ok": "✅ تم فك الحظر عن العضو <code>{uid}</code> بنجاح.",
        "mand_title": "📡 <b>القنوات الإجبارية للاشتراك:</b>\n\n",
        "mand_empty": "<i>لا توجد قنوات إجبارية حالياً.</i>\n",
        "btn_add_mand": "➕ إضافة قناة إجبارية",
        "btn_toggle_fsub": "🔄 الاشتراك الإجباري: {state}",
        "add_mand_prompt": (
            "📡 <b>إضافة قنوات إجبارية:</b>\n\n"
            "أرسل معرّفات أو روابط القنوات (سطر لكل قناة):\n"
            "<code>@PLAYX1_ZONE\nhttps://t.me/channel2</code>\n\n"
            "⚠️ <i>تأكد من رفع البوت @{bot_uname} مشرفاً داخل كل قناة!</i>"
        ),
        "mand_added": "✅ <b>تمت إضافة {n} قناة إجبارية بنجاح:</b>\n\n",
        "ch_deleted": "✅ تم حذف القناة {ch}.",
        "promo_ch_title": "🌟 <b>القنوات الشريكة والإعلانية:</b>\n\n",
        "promo_ch_empty": "<i>لا توجد قنوات شريكة مضافة بعد.</i>\n",
        "btn_add_promo_ch": "➕ إضافة قناة شريكة",
        "add_promo_ch_prompt": (
            "🌟 <b>إضافة قنوات شريكة:</b>\n\n"
            "أرسل روابط أو معرّفات القنوات (سطر لكل قناة):\n"
            "<code>https://t.me/channel1\n@channel2</code>"
        ),
        "promo_ch_added": "✅ <b>تمت إضافة {n} قناة شريكة بنجاح:</b>\n\n",
        "promos_title": "🎫 <b>إدارة أكواد الهدايا:</b>\n\n",
        "promos_empty": "<i>لا توجد أكواد هدايا نشطة حالياً.</i>\n",
        "btn_new_promo": "➕ إنشاء كود جديد",
        "new_promo_prompt": (
            "🎫 <b>إنشاء كود هدية جديد (يدعم الكسور):</b>\n\n"
            "أرسل البيانات بالصيغة التالية:\n"
            "<code>CODE TOKENS MAX_USES</code>\n\n"
            "مثال: <code>PLAYX10 2.5 100</code> أو <code>VIP05 0.5 50</code>"
        ),
        "promo_created": (
            "✅ <b>تم إنشاء كود الهدية بنجاح!</b>\n\n"
            "🎫 <b>الكود:</b> <code>{code}</code>\n"
            "🎁 <b>المكافأة:</b> +{tokens} توكن\n"
            "👥 <b>الحد الأقصى:</b> {max_uses} مستخدم"
        ),
        "promo_bcast_btn": "📣 إذاعة الكود للجميع",
        "promo_deleted": "✅ تم حذف الكود {code}.",
        "bcast_prompt": "📣 <b>إذاعة شاملة لجميع الأعضاء:</b>\n\nأرسل الآن رسالتك (نص، صورة، فيديو، أو ملف) وسيتم نسخها وإرسالها للجميع:",
        "bcast_running": "⏳ جاري الإرسال إلى <b>{n}</b> عضو...",
        "bcast_done": "📣 <b>اكتملت الإذاعة بنجاح!</b>\n\n✅ <b>نجح الإرسال:</b> {ok}\n❌ <b>فشل/محظور:</b> {fail}",
        "dm_prompt_user": "📩 <b>إرسال رسالة خاصة لعضو:</b>\n\nأرسل معرّف العضو (ID) أو اليوزر (<code>@username</code>):",
        "dm_prompt_msg": "✍️ <b>أرسل الآن الرسالة المطلوب إيصالها للعضو</b> <code>{uid}</code>:",
        "dm_sent": "✅ تم إيصال رسالتك إلى العضو <code>{uid}</code> بنجاح.",
        "dm_fail": "❌ تعذر إرسال الرسالة للعضو (ربما قام بحظر البوت).",
        "settings_title": (
            "⚙️ <b>إعدادات نظام PLAYX1 ZONE المتقدمة</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "🛠️ <b>وضع الصيانة:</b> {maint}\n"
            "📡 <b>الاشتراك الإجباري:</b> {fsub}\n"
            "🚀 <b>نظام فتح الصناديق:</b> {quests_st}\n"
            "⭐ <b>متجر النجوم:</b> {shop_st}\n"
            "🎫 <b>أكواد الهدايا:</b> {promos_st}\n"
            "💾 <b>الحفظ التلقائي للحسابات:</b> {autosave_st}\n"
            "📦 <b>تكلفة الصندوق:</b> <code>{cost}</code> توكن\n"
            "🎁 <b>رصيد الترحيب:</b> <code>{wbonus}</code> توكن"
        ),
        "btn_maint": "🛠️ الصيانة: {state}",
        "btn_fsub": "📡 الاشتراك: {state}",
        "btn_edit_cost": "📦 تعديل تكلفة الصندوق",
        "btn_edit_welcome": "🎁 تعديل رصيد الترحيب",
        "cost_prompt": "📦 <b>تعديل تكلفة الصندوق (يدعم الكسور مثل 0.25 و 1.5):</b>\n\nأرسل العدد الجديد للتوكنات المطلوبة لكل صندوق:",
        "welcome_prompt": "🎁 <b>تعديل رصيد الترحيب للأعضاء الجدد (يدعم الكسور مثل 2.5 أو 8):</b>\n\nأرسل العدد الجديد للتوكنات المجانية عند التسجيل:",
        "setting_saved": "✅ تم حفظ الإعداد الجديد بنجاح!",
        "backup_caption": "💾 <b>نسخة احتياطية لقاعدة بيانات PLAYX1 ZONE</b>\n🕒 {ts}",
        "backup_err": "❌ تعذر العثور على ملف قاعدة البيانات.",
    },
    "en": {
        "title": "🛡️ <b>Master Admin Control Center — PLAYX1 ZONE</b>",
        "subtitle": (
            "━━━━━━━━━━━━━━━━━━━━\n"
            "⚙️ <b>System:</b> {maint} | 📡 <b>Force Sub:</b> {fsub}\n"
            "📦 <b>Chest:</b> <code>{cost}</code> 🪙 | 👑 <b>Weekly:</b> <code>{wcost}</code> 🪙 | 🎁 <b>Welcome:</b> <code>{wbonus}</code> 🪙\n"
            "🤝 <b>Referrals:</b> {ref_st} (<code>{ref_r}</code> 🪙) | 📅 <b>Daily:</b> {ci_st}\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "Select an administrative module below:"
        ),
        "on": "🟢 Enabled",
        "off": "🔴 Disabled",
        "maint_on": "🟠 Maintenance",
        "maint_off": "🟢 Online",
        "btn_stats": "📊 Analytics",
        "btn_lookup": "🔎 User Lookup",
        "btn_users_top": "👥 Users & Top",
        "btn_add": "➕ Credit Tokens",
        "btn_sub": "➖ Deduct Tokens",
        "btn_gift_all": "🎁 Gift Everyone",
        "btn_bans": "🚫 Banned Users",
        "btn_weekly_cfg": "👑 Weekly Prize Ctrl",
        "btn_services_cfg": "🛍️ Offers & Services",
        "btn_ref_cfg": "🤝 Referral Ctrl",
        "btn_checkin_cfg": "📅 Daily Check-In",
        "btn_ch_rewards": "💎 Channel Rewards",
        "btn_mand": "📡 Mandatory Channels",
        "btn_promo_ch": "🌟 Partner Channels",
        "btn_promos": "🎫 Gift Codes",
        "btn_bcast": "📣 Broadcast",
        "btn_dm": "📩 Message User",
        "btn_settings": "⚙️ Advanced Settings",
        "btn_logs": "📜 Admin Logs",
        "btn_backup": "💾 DB Backup",
        "btn_lang": "🌐 Panel Lang: English",
        "btn_home": "🏠 Bot Home",
        "btn_close": "✖️ Close",
        "btn_back_admin": "↩️ Admin Panel",
        "btn_cancel": "✖️ Cancel",
        "closed": "Admin panel closed.",
        "lang_title": "🌐 <b>Select Admin Panel Language:</b>",
        "lang_updated": "✅ Admin panel language switched to English.",
        "stats_body": (
            "📊 <b>Platform Analytics — PLAYX1 ZONE</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "👥 <b>Total Users:</b> <code>{total_users}</code>\n"
            "🆕 <b>Joined Today:</b> <code>{new_users_today}</code>\n"
            "🚫 <b>Banned Users:</b> <code>{banned_users}</code>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "💳 <b>Tokens in Wallets:</b> <code>{total_balance}</code>\n"
            "🛍️ <b>Tokens Purchased:</b> <code>{tokens_purchased}</code>\n"
            "⭐ <b>Total Stars Spent:</b> <code>{stars_spent}</code>\n"
            "📅 <b>Total Daily Check-Ins:</b> <code>{total_checkins}</code>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "🚀 <b>Completed Quests:</b> <code>{completed_quests}</code>\n"
            "⚠️ <b>Failed Attempts:</b> <code>{failed_quests}</code>\n"
            "👑 <b>Weekly Prize Claims:</b> <code>{weekly_claims}</code>\n"
            "🔑 <b>Saved Accounts:</b> <code>{saved_accs}</code>\n"
            "🤝 <b>Active Referrals:</b> <code>{total_referrals}</code>\n"
            "📡 <b>Mandatory / Partner Ch:</b> <code>{mandatory_channels} / {promo_channels}</code>\n"
            "🎫 <b>Active Gift Codes:</b> <code>{active_promos}</code>"
        ),
        "lookup_prompt": "🔎 <b>User Lookup:</b>\n\nSend Telegram ID or username (<code>@username</code>):\n<i>(or send /cancel)</i>",
        "user_not_found": "⚠️ User not found in database.",
        "user_card": (
            "👤 <b>User Profile</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "🆔 <b>ID:</b> <code>{uid}</code>\n"
            "🔖 <b>Username:</b> {uname}\n"
            "💳 <b>Balance:</b> <code>{bal}</code> Tokens\n"
            "🌐 <b>Language:</b> <code>{ulang}</code>\n"
            "🛡️ <b>Status:</b> {status}\n"
            "🔥 <b>Check-In Streak:</b> <code>{streak}/7</code> ({total_ci} total)\n"
            "🚀 <b>Completed Quests:</b> <code>{qcount}</code>\n"
            "🔑 <b>Saved Accounts:</b> <code>{acount}</code>\n"
            "🤝 <b>Referrals:</b> <code>{rcount}</code>\n"
            "⭐ <b>Stars Spent:</b> <code>{stars}</code>\n"
            "📅 <b>Joined:</b> <code>{created}</code>"
        ),
        "status_active": "🟢 Active",
        "status_banned": "🔴 Banned",
        "u_btn_add": "➕ Credit User",
        "u_btn_sub": "➖ Deduct User",
        "u_btn_ban": "🚫 Ban User",
        "u_btn_unban": "✅ Unban User",
        "u_btn_dm": "📩 Message User",
        "u_btn_reset_ci": "🔄 Reset Streak",
        "add_prompt": "➕ <b>Credit Tokens (supports decimals like 0.25):</b>\n\nSend username/ID and amount:\nExample: <code>@username 2.5</code> or <code>123456789 0.25</code>",
        "add_one_prompt": "➕ <b>Enter token amount to credit user</b> <code>{uid}</code> (e.g. <code>2</code> or <code>0.5</code>):",
        "sub_prompt": "➖ <b>Deduct Tokens (supports decimals like 0.25):</b>\n\nSend username/ID and amount:\nExample: <code>@username 1.5</code> or <code>123456789 0.25</code>",
        "sub_one_prompt": "➖ <b>Enter token amount to deduct from user</b> <code>{uid}</code>:",
        "bad_format": "⚠️ Invalid format! Please check and try again.",
        "added_ok": "✅ <b>Credited {amount} tokens to {target}!</b>\n💳 New Balance: <code>{bal}</code> Tokens",
        "sub_ok": "✅ <b>Deducted {amount} tokens from {target}.</b>\n💳 New Balance: <code>{bal}</code> Tokens",
        "gift_prompt": "🎁 <b>Global Token Gift:</b>\n\nEnter token amount to grant every active user (supports decimals like <code>0.5</code> or <code>5</code>):",
        "gift_done": "🎉 <b>Global Gift Distributed!</b>\n\n🎁 <b>Amount:</b> +{amount} Tokens\n👥 <b>Credited Users:</b> {count}\n📨 <b>Notified:</b> {sent} | ❌ <b>Failed:</b> {failed}",
        "bans_title": "🚫 <b>Banned Users Management:</b>\n\n",
        "bans_empty": "<i>No banned users currently.</i>",
        "btn_ban_new": "➕ Ban a User",
        "ban_prompt": "🚫 <b>Ban User:</b>\n\nSend user ID or <code>@username</code>:",
        "cannot_ban_admin": "⚠️ Cannot ban an administrator!",
        "banned_ok": "🚫 User <code>{uid}</code> has been banned.",
        "unbanned_ok": "✅ User <code>{uid}</code> has been unbanned.",
        "mand_title": "📡 <b>Mandatory Channels (Force Sub):</b>\n\n",
        "mand_empty": "<i>No mandatory channels configured.</i>\n",
        "btn_add_mand": "➕ Add Mandatory Channel",
        "btn_toggle_fsub": "🔄 Force Sub: {state}",
        "add_mand_prompt": (
            "📡 <b>Add Mandatory Channels:</b>\n\n"
            "Send channel handles or links (one per line):\n"
            "<code>@PLAYX1_ZONE\nhttps://t.me/channel2</code>\n\n"
            "⚠️ <i>Make sure @{bot_uname} is added as Admin in each channel!</i>"
        ),
        "mand_added": "✅ <b>Added {n} mandatory channel(s):</b>\n\n",
        "ch_deleted": "✅ Channel {ch} removed.",
        "promo_ch_title": "🌟 <b>Partner & Sponsored Channels:</b>\n\n",
        "promo_ch_empty": "<i>No partner channels configured yet.</i>\n",
        "btn_add_promo_ch": "➕ Add Partner Channel",
        "add_promo_ch_prompt": (
            "🌟 <b>Add Partner Channels:</b>\n\n"
            "Send channel links or handles (one per line):\n"
            "<code>https://t.me/channel1\n@channel2</code>"
        ),
        "promo_ch_added": "✅ <b>Added {n} partner channel(s):</b>\n\n",
        "promos_title": "🎫 <b>Gift Codes Management:</b>\n\n",
        "promos_empty": "<i>No active gift codes.</i>\n",
        "btn_new_promo": "➕ Create Gift Code",
        "new_promo_prompt": (
            "🎫 <b>Create New Gift Code (supports decimals):</b>\n\n"
            "Send using format:\n"
            "<code>CODE TOKENS MAX_USES</code>\n\n"
            "Example: <code>PLAYX10 2.5 100</code>"
        ),
        "promo_created": (
            "✅ <b>Gift Code Created!</b>\n\n"
            "🎫 <b>Code:</b> <code>{code}</code>\n"
            "🎁 <b>Reward:</b> +{tokens} Tokens\n"
            "👥 <b>Max Uses:</b> {max_uses} users"
        ),
        "promo_bcast_btn": "📣 Broadcast Code to All",
        "promo_deleted": "✅ Code {code} deleted.",
        "bcast_prompt": "📣 <b>Global Broadcast:</b>\n\nSend any message (text, photo, video, or document) to broadcast to all users:",
        "bcast_running": "⏳ Broadcasting to <b>{n}</b> users...",
        "bcast_done": "📣 <b>Broadcast Finished!</b>\n\n✅ <b>Delivered:</b> {ok}\n❌ <b>Failed/Blocked:</b> {fail}",
        "dm_prompt_user": "📩 <b>Direct Message User:</b>\n\nSend user ID or <code>@username</code>:",
        "dm_prompt_msg": "✍️ <b>Send the message to deliver to</b> <code>{uid}</code>:",
        "dm_sent": "✅ Message delivered to <code>{uid}</code>.",
        "dm_fail": "❌ Could not send message (user may have blocked the bot).",
        "settings_title": (
            "⚙️ <b>PLAYX1 ZONE Advanced Settings</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "🛠️ <b>Maintenance Mode:</b> {maint}\n"
            "📡 <b>Force Subscription:</b> {fsub}\n"
            "🚀 <b>Quest Vault:</b> {quests_st}\n"
            "⭐ <b>Stars Store:</b> {shop_st}\n"
            "🎫 <b>Gift Codes:</b> {promos_st}\n"
            "💾 <b>Auto-Save Accounts:</b> {autosave_st}\n"
            "📦 <b>Quest Cost:</b> <code>{cost}</code> Tokens\n"
            "🎁 <b>Welcome Gift:</b> <code>{wbonus}</code> Tokens"
        ),
        "btn_maint": "🛠️ Maintenance: {state}",
        "btn_fsub": "📡 Force Sub: {state}",
        "btn_edit_cost": "📦 Edit Quest Cost",
        "btn_edit_welcome": "🎁 Edit Welcome Gift",
        "cost_prompt": "📦 <b>Edit Quest Cost (supports decimals like 0.25):</b>\n\nEnter the new token cost per chest:",
        "welcome_prompt": "🎁 <b>Edit Welcome Bonus (supports decimals like 2.5):</b>\n\nEnter free tokens granted to new users:",
        "setting_saved": "✅ Setting updated successfully!",
        "backup_caption": "💾 <b>PLAYX1 ZONE Database Backup</b>\n🕒 {ts}",
        "backup_err": "❌ Database file not found.",
    },
    "fr": {
        "title": "🛡️ <b>Centre de Contrôle Admin — PLAYX1 ZONE</b>",
        "subtitle": (
            "━━━━━━━━━━━━━━━━━━━━\n"
            "⚙️ <b>Système :</b> {maint} | 📡 <b>Abonnement :</b> {fsub}\n"
            "📦 <b>Coffre :</b> <code>{cost}</code> 🪙 | 👑 <b>Hebdo :</b> <code>{wcost}</code> 🪙 | 🎁 <b>Départ :</b> <code>{wbonus}</code> 🪙\n"
            "🤝 <b>Parrainage :</b> {ref_st} (<code>{ref_r}</code> 🪙) | 📅 <b>Quotidien :</b> {ci_st}\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "Choisissez un module d'administration :"
        ),
        "on": "🟢 Activé",
        "off": "🔴 Désactivé",
        "maint_on": "🟠 Maintenance",
        "maint_off": "🟢 En Ligne",
        "btn_stats": "📊 Statistiques",
        "btn_lookup": "🔎 Chercher Membre",
        "btn_users_top": "👥 Membres & Top",
        "btn_add": "➕ Créditer Tokens",
        "btn_sub": "➖ Déduire Tokens",
        "btn_gift_all": "🎁 Cadeau Global",
        "btn_bans": "🚫 Bannis",
        "btn_weekly_cfg": "👑 Prix Hebdomadaire",
        "btn_services_cfg": "🛍️ Boutique Services",
        "btn_ref_cfg": "🤝 Parrainage",
        "btn_checkin_cfg": "📅 Connexion Quotidienne",
        "btn_ch_rewards": "💎 Gains Chaînes",
        "btn_mand": "📡 Chaînes Obligatoires",
        "btn_promo_ch": "🌟 Chaînes Partenaires",
        "btn_promos": "🎫 Codes Cadeaux",
        "btn_bcast": "📣 Diffusion Globale",
        "btn_dm": "📩 Message Privé",
        "btn_settings": "⚙️ Paramètres Avancés",
        "btn_logs": "📜 Journaux Admin",
        "btn_backup": "💾 Sauvegarde BDD",
        "btn_lang": "🌐 Langue : Français",
        "btn_home": "🏠 Accueil Bot",
        "btn_close": "✖️ Fermer",
        "btn_back_admin": "↩️ Panneau Admin",
        "btn_cancel": "✖️ Annuler",
        "closed": "Panneau admin fermé.",
        "lang_title": "🌐 <b>Choisissez la langue du Panneau Admin :</b>",
        "lang_updated": "✅ Langue du panneau définie sur Français.",
        "stats_body": (
            "📊 <b>Statistiques Globales — PLAYX1 ZONE</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "👥 <b>Total Membres :</b> <code>{total_users}</code>\n"
            "🆕 <b>Nouveaux Aujourd'hui :</b> <code>{new_users_today}</code>\n"
            "🚫 <b>Membres Bannis :</b> <code>{banned_users}</code>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "💳 <b>Tokens en Circulation :</b> <code>{total_balance}</code>\n"
            "🛍️ <b>Tokens Achetés :</b> <code>{tokens_purchased}</code>\n"
            "⭐ <b>Total Stars Dépensées :</b> <code>{stars_spent}</code>\n"
            "📅 <b>Connexions Quotidiennes :</b> <code>{total_checkins}</code>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "🚀 <b>Quêtes Validées :</b> <code>{completed_quests}</code>\n"
            "⚠️ <b>Échecs :</b> <code>{failed_quests}</code>\n"
            "👑 <b>Prix Hebdo Réclamés :</b> <code>{weekly_claims}</code>\n"
            "🔑 <b>Comptes Sauvegardés :</b> <code>{saved_accs}</code>\n"
            "🤝 <b>Parrainages Actifs :</b> <code>{total_referrals}</code>\n"
            "📡 <b>Chaînes Oblig. / Part. :</b> <code>{mandatory_channels} / {promo_channels}</code>\n"
            "🎫 <b>Codes Actifs :</b> <code>{active_promos}</code>"
        ),
        "lookup_prompt": "🔎 <b>Recherche Membre :</b>\n\nEnvoyez l'ID Telegram ou le pseudo (<code>@username</code>) :",
        "user_not_found": "⚠️ Utilisateur introuvable dans la base.",
        "user_card": (
            "👤 <b>Fiche Membre</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "🆔 <b>ID :</b> <code>{uid}</code>\n"
            "🔖 <b>Pseudo :</b> {uname}\n"
            "💳 <b>Solde :</b> <code>{bal}</code> Tokens\n"
            "🌐 <b>Langue :</b> <code>{ulang}</code>\n"
            "🛡️ <b>Statut :</b> {status}\n"
            "🔥 <b>Série Quotidienne :</b> <code>{streak}/7</code> ({total_ci} fois)\n"
            "🚀 <b>Quêtes Validées :</b> <code>{qcount}</code>\n"
            "🔑 <b>Comptes Sauvegardés :</b> <code>{acount}</code>\n"
            "🤝 <b>Parrainages :</b> <code>{rcount}</code>\n"
            "⭐ <b>Stars Dépensées :</b> <code>{stars}</code>\n"
            "📅 <b>Inscrit le :</b> <code>{created}</code>"
        ),
        "status_active": "🟢 Actif",
        "status_banned": "🔴 Banni",
        "u_btn_add": "➕ Créditer",
        "u_btn_sub": "➖ Déduire",
        "u_btn_ban": "🚫 Bannir",
        "u_btn_unban": "✅ Débannir",
        "u_btn_dm": "📩 Envoyer MP",
        "u_btn_reset_ci": "🔄 Réinit. Série",
        "add_prompt": "➕ <b>Créditer des Tokens (décimaux supportés ex: 0.25) :</b>\n\nFormat : <code>@username 2.5</code> ou <code>123456789 0.25</code>",
        "add_one_prompt": "➕ <b>Entrez le montant à créditer à</b> <code>{uid}</code> :",
        "sub_prompt": "➖ <b>Déduire des Tokens (décimaux supportés) :</b>\n\nFormat : <code>@username 1.5</code> ou <code>123456789 0.25</code>",
        "sub_one_prompt": "➖ <b>Entrez le montant à déduire de</b> <code>{uid}</code> :",
        "bad_format": "⚠️ Format invalide ! Veuillez réessayer.",
        "added_ok": "✅ <b>+{amount} tokens crédités à {target} !</b>\n💳 Nouveau solde : <code>{bal}</code> Tokens",
        "sub_ok": "✅ <b>-{amount} tokens déduits de {target}.</b>\n💳 Nouveau solde : <code>{bal}</code> Tokens",
        "gift_prompt": "🎁 <b>Cadeau Global :</b>\n\nEntrez le nombre de tokens à offrir à tous les membres actifs (ex : <code>0.5</code> ou <code>5</code>) :",
        "gift_done": "🎉 <b>Cadeau Global Distribué !</b>\n\n🎁 <b>Montant :</b> +{amount} Tokens\n👥 <b>Bénéficiaires :</b> {count}\n📨 <b>Notifiés :</b> {sent} | ❌ <b>Échecs :</b> {failed}",
        "bans_title": "🚫 <b>Gestion des Membres Bannis :</b>\n\n",
        "bans_empty": "<i>Aucun membre banni actuellement.</i>",
        "btn_ban_new": "➕ Bannir un Membre",
        "ban_prompt": "🚫 <b>Bannir un Membre :</b>\n\nEnvoyez son ID ou <code>@username</code> :",
        "cannot_ban_admin": "⚠️ Impossible de bannir un administrateur !",
        "banned_ok": "🚫 L'utilisateur <code>{uid}</code> a été banni.",
        "unbanned_ok": "✅ L'utilisateur <code>{uid}</code> a été débanni.",
        "mand_title": "📡 <b>Chaînes Obligatoires :</b>\n\n",
        "mand_empty": "<i>Aucune chaîne obligatoire configurée.</i>\n",
        "btn_add_mand": "➕ Ajouter Chaîne Obligatoire",
        "btn_toggle_fsub": "🔄 Abonnement Forcé : {state}",
        "add_mand_prompt": (
            "📡 <b>Ajouter des Chaînes Obligatoires :</b>\n\n"
            "Envoyez les pseudos ou liens (un par ligne) :\n"
            "<code>@PLAYX1_ZONE\nhttps://t.me/channel2</code>\n\n"
            "⚠️ <i>Assurez-vous que @{bot_uname} soit Admin dans chaque chaîne !</i>"
        ),
        "mand_added": "✅ <b>{n} chaîne(s) obligatoire(s) ajoutée(s) :</b>\n\n",
        "ch_deleted": "✅ Chaîne {ch} supprimée.",
        "promo_ch_title": "🌟 <b>Chaînes Partenaires :</b>\n\n",
        "promo_ch_empty": "<i>Aucune chaîne partenaire configurée.</i>\n",
        "btn_add_promo_ch": "➕ Ajouter Chaîne Partenaire",
        "add_promo_ch_prompt": (
            "🌟 <b>Ajouter des Chaînes Partenaires :</b>\n\n"
            "Envoyez les liens ou pseudos (un par ligne) :\n"
            "<code>https://t.me/channel1\n@channel2</code>"
        ),
        "promo_ch_added": "✅ <b>{n} chaîne(s) partenaire(s) ajoutée(s) :</b>\n\n",
        "promos_title": "🎫 <b>Gestion des Codes Cadeaux :</b>\n\n",
        "promos_empty": "<i>Aucun code cadeau actif.</i>\n",
        "btn_new_promo": "➕ Créer un Code",
        "new_promo_prompt": (
            "🎫 <b>Créer un Code Cadeau (décimaux supportés) :</b>\n\n"
            "Format : <code>CODE TOKENS MAX_USES</code>\n\n"
            "Exemple : <code>PLAYX10 2.5 100</code>"
        ),
        "promo_created": (
            "✅ <b>Code Cadeau Créé !</b>\n\n"
            "🎫 <b>Code :</b> <code>{code}</code>\n"
            "🎁 <b>Récompense :</b> +{tokens} Tokens\n"
            "👥 <b>Limite :</b> {max_uses} membres"
        ),
        "promo_bcast_btn": "📣 Diffuser ce Code",
        "promo_deleted": "✅ Code {code} supprimé.",
        "bcast_prompt": "📣 <b>Diffusion Globale :</b>\n\nEnvoyez le message (texte, photo, vidéo ou fichier) à diffuser :",
        "bcast_running": "⏳ Envoi en cours à <b>{n}</b> membres...",
        "bcast_done": "📣 <b>Diffusion Terminée !</b>\n\n✅ <b>Envoyés :</b> {ok}\n❌ <b>Échecs/Bloqués :</b> {fail}",
        "dm_prompt_user": "📩 <b>Message Privé :</b>\n\nEnvoyez l'ID ou <code>@username</code> :",
        "dm_prompt_msg": "✍️ <b>Envoyez maintenant le message pour</b> <code>{uid}</code> :",
        "dm_sent": "✅ Message envoyé à <code>{uid}</code>.",
        "dm_fail": "❌ Échec d'envoi (l'utilisateur a peut-être bloqué le bot).",
        "settings_title": (
            "⚙️ <b>Paramètres Avancés PLAYX1 ZONE</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "🛠️ <b>Mode Maintenance :</b> {maint}\n"
            "📡 <b>Abonnement Forcé :</b> {fsub}\n"
            "🚀 <b>Coffres & Quêtes :</b> {quests_st}\n"
            "⭐ <b>Boutique Stars :</b> {shop_st}\n"
            "🎫 <b>Codes Cadeaux :</b> {promos_st}\n"
            "💾 <b>Sauvegarde Auto Comptes :</b> {autosave_st}\n"
            "📦 <b>Coût par Coffre :</b> <code>{cost}</code> Tokens\n"
            "🎁 <b>Bonus Départ :</b> <code>{wbonus}</code> Tokens"
        ),
        "btn_maint": "🛠️ Maintenance : {state}",
        "btn_fsub": "📡 Abonnement Forcé : {state}",
        "btn_edit_cost": "📦 Modifier Coût Coffre",
        "btn_edit_welcome": "🎁 Modifier Bonus Départ",
        "cost_prompt": "📦 <b>Modifier le Coût par Coffre (décimaux supportés) :</b>\n\nEntrez le nouveau coût en tokens :",
        "welcome_prompt": "🎁 <b>Modifier le Bonus de Bienvenue (décimaux supportés) :</b>\n\nEntrez le montant offert :",
        "setting_saved": "✅ Paramètre enregistré !",
        "backup_caption": "💾 <b>Sauvegarde Base de Données PLAYX1 ZONE</b>\n🕒 {ts}",
        "backup_err": "❌ Fichier de base de données introuvable.",
    },
}


class AdminForm(StatesGroup):
    waiting_for_add_tokens = State()
    waiting_for_sub_tokens = State()
    waiting_for_add_tokens_target = State()
    waiting_for_sub_tokens_target = State()
    waiting_for_lookup = State()
    waiting_for_broadcast = State()
    waiting_for_add_mandatory = State()
    waiting_for_add_promo_ch = State()
    waiting_for_add_promo = State()
    waiting_for_gift_all = State()
    waiting_for_ban_user = State()
    waiting_for_dm_user = State()
    waiting_for_dm_message = State()
    waiting_for_edit_cost = State()
    waiting_for_edit_welcome = State()
    waiting_for_edit_weekly_cost = State()
    waiting_for_edit_ref_reward = State()
    waiting_for_edit_ref_invited = State()
    waiting_for_edit_checkin_day = State()
    waiting_for_edit_ch_reward = State()
    waiting_for_new_service = State()
    waiting_for_edit_service_price = State()
    waiting_for_edit_service_info = State()
    waiting_for_new_category = State()
    waiting_for_bulk_ch_reward = State()


class UserForm(StatesGroup):
    waiting_for_promo_code = State()


class QuestForm(StatesGroup):
    waiting_for_credentials = State()
    confirm_credentials = State()
    waiting_for_oauth_token = State()


class WeeklyForm(StatesGroup):
    waiting_for_account_selection = State()
    waiting_for_credentials = State()
    confirm_credentials = State()


def get_missing_sub_keyboard(missing_channels: Optional[List[Dict[str, Any]]] = None, lang: str = "ar"):
    channels_to_show = db.get_mandatory_channels()
    builder = InlineKeyboardBuilder()
    styles = ["primary", "success"]
    for i, ch in enumerate(channels_to_show):
        raw_name = ch.get("title") or ch.get("channel_username") or ""
        clean_name = raw_name.strip().lstrip("@").strip()
        if not clean_name:
            clean_name = ch.get("channel_username", "").lstrip("@").strip()
        link = ch.get("invite_link") or f"https://t.me/{ch['channel_username'].lstrip('@')}"
        builder.button(text=f"📡 {clean_name}", url=link, style=styles[i % len(styles)])
    t = STRINGS.get(lang, STRINGS["ar"])
    builder.button(text=t["sub_btn_check"], callback_data="check_sub", style="success")
    builder.adjust(1)
    return builder.as_markup()


class ForceSubMiddleware(BaseMiddleware):
    async def __call__(self, handler, event: types.TelegramObject, data: Dict[str, Any]):
        user = getattr(event, "from_user", None)
        if not user or user.is_bot:
            return await handler(event, data)

        db.get_or_create_user(user.id, user.username)
        logger.info("User interaction: id=%s, username=@%s", user.id, user.username)

        if user.id in ADMIN_IDS:
            return await handler(event, data)

        user_lang = db.get_user_language(user.id) or "ar"
        t = STRINGS.get(user_lang, STRINGS["ar"])

        if db.is_user_banned(user.id):
            if isinstance(event, types.Message):
                await event.answer(t["banned"], parse_mode="HTML")
            elif isinstance(event, types.CallbackQuery):
                await event.answer(t["banned"].replace("<b>", "").replace("</b>", "")[:180], show_alert=True)
            return

        if db.get_setting_bool("maintenance_mode", False):
            if isinstance(event, types.Message):
                await event.answer(t["maint"], parse_mode="HTML", disable_web_page_preview=True)
            elif isinstance(event, types.CallbackQuery):
                await event.answer("🛠️ Maintenance Mode", show_alert=True)
            return

        if isinstance(event, types.Message) and event.text:
            text_val = event.text.strip()
            if text_val.startswith("/start"):
                parts = text_val.split()
                if len(parts) > 1 and parts[1].startswith("ref_"):
                    inviter_str = parts[1].replace("ref_", "").strip()
                    if inviter_str.isdigit():
                        db.record_referral(int(inviter_str), user.id)

        if isinstance(event, types.CallbackQuery) and event.data == "check_sub":
            return await handler(event, data)

        bot_instance: Bot = data.get("bot") or bot
        is_sub, missing = await check_all_channels_subscription(bot_instance, user.id)
        if not is_sub:
            if isinstance(event, types.Message):
                await event.answer(
                    t["sub_req"],
                    reply_markup=get_missing_sub_keyboard(missing, lang=user_lang),
                    parse_mode="HTML",
                )
            elif isinstance(event, types.CallbackQuery):
                await event.answer(t["sub_alert"], show_alert=True)
                try:
                    await event.message.answer(
                        t["sub_req"],
                        reply_markup=get_missing_sub_keyboard(missing, lang=user_lang),
                        parse_mode="HTML",
                    )
                except Exception:
                    pass
            return

        return await handler(event, data)


dp.message.outer_middleware(ForceSubMiddleware())
dp.callback_query.outer_middleware(ForceSubMiddleware())


def get_main_menu(user_id: Optional[int] = None, lang: Optional[str] = None) -> InlineKeyboardMarkup:
    if not lang and user_id:
        lang = db.get_user_language(user_id)
    if not lang or lang not in STRINGS:
        lang = "ar"
    t = STRINGS[lang]
    store_on = db.get_setting_bool("services_store_enabled", True)
    builder = InlineKeyboardBuilder()

    # المجموعة 1: الخدمات الرئيسية والمتجر
    builder.button(text=t["quest"], callback_data="nav_quests", style="primary")
    builder.button(text=t["weekly"], callback_data="nav_weekly", style="success")
    if store_on:
        builder.button(text=t["services_store"], callback_data="nav_services_store", style="success")

    # المجموعة 2: الحساب والمحفظة
    builder.button(text=t["balance"], callback_data="nav_wallet", style="primary")
    builder.button(text=t["profile"], callback_data="nav_profile", style="primary")

    # المجموعة 3: المكافآت اليومية والربح والترتيب
    builder.button(text=t["rewards"], callback_data="nav_rewards", style="success")
    builder.button(text=t["checkin"], callback_data="nav_checkin", style="success")
    builder.button(text=t["leaderboard"], callback_data="nav_top", style="primary")

    # المجموعة 4: المساعدة واللغة والقناة
    builder.button(text=t["help"], callback_data="nav_guide", style="primary")
    builder.button(text=t["lang"], callback_data="nav_lang", style="primary")
    builder.button(text=t["channel"], url=CHANNEL_URL, style="success")

    if user_id and user_id in ADMIN_IDS:
        builder.button(text=t["admin"], callback_data="admin_menu", style="danger")

    if store_on:
        builder.adjust(2, 1, 2, 2, 1, 2, 1, 1)
    else:
        builder.adjust(2, 2, 2, 1, 2, 1, 1)
    return builder.as_markup()


def get_admin_menu_keyboard(alang: Optional[str] = None) -> InlineKeyboardMarkup:
    lang = alang or get_admin_lang()
    a = ADMIN_STRINGS.get(lang, ADMIN_STRINGS["ar"])
    builder = InlineKeyboardBuilder()

    # قسم 1: الإحصائيات وإدارة الأعضاء والأرصدة
    builder.button(text=a["btn_stats"], callback_data="admin_stats", style="primary")
    builder.button(text=a["btn_lookup"], callback_data="admin_lookup", style="primary")
    builder.button(text=a["btn_users_top"], callback_data="admin_users_top", style="primary")
    builder.button(text=a["btn_bans"], callback_data="admin_bans", style="danger")
    builder.button(text=a["btn_add"], callback_data="admin_add_tokens", style="success")
    builder.button(text=a["btn_sub"], callback_data="admin_sub_tokens", style="danger")
    builder.button(text=a["btn_gift_all"], callback_data="admin_gift_all", style="success")

    # قسم 2: المتجر والخدمات والجوائز
    builder.button(text=a["btn_services_cfg"], callback_data="admin_services_cfg", style="success")
    builder.button(text=a["btn_weekly_cfg"], callback_data="admin_weekly_cfg", style="success")

    # قسم 3: أنظمة الربح والقنوات والأكواد
    builder.button(text=a["btn_ch_rewards"], callback_data="admin_ch_rewards", style="primary")
    builder.button(text=a["btn_ref_cfg"], callback_data="admin_ref_cfg", style="primary")
    builder.button(text=a["btn_checkin_cfg"], callback_data="admin_checkin_cfg", style="success")
    builder.button(text=a["btn_mand"], callback_data="admin_mandatory_channels", style="primary")
    builder.button(text=a["btn_promo_ch"], callback_data="admin_promo_channels", style="primary")
    builder.button(text=a["btn_promos"], callback_data="admin_promos", style="success")

    # قسم 4: التواصل والإعدادات والسجلات والنسخ الاحتياطي
    builder.button(text=a["btn_bcast"], callback_data="admin_broadcast", style="primary")
    builder.button(text=a["btn_dm"], callback_data="admin_dm_user", style="primary")
    builder.button(text=a["btn_settings"], callback_data="admin_settings", style="primary")
    builder.button(text=a["btn_logs"], callback_data="admin_logs", style="primary")
    builder.button(text=a["btn_backup"], callback_data="admin_backup", style="success")
    builder.button(text=a["btn_lang"], callback_data="admin_lang_menu", style="primary")

    # قسم 5: التنقل والإغلاق
    builder.button(text=a["btn_home"], callback_data="nav_home", style="primary")
    builder.button(text=a["btn_close"], callback_data="admin_close", style="danger")
    builder.adjust(2)
    return builder.as_markup()


def get_admin_panel_text(alang: Optional[str] = None) -> str:
    lang = alang or get_admin_lang()
    a = ADMIN_STRINGS.get(lang, ADMIN_STRINGS["ar"])
    maint = a["maint_on"] if db.get_setting_bool("maintenance_mode", False) else a["maint_off"]
    fsub = a["on"] if db.get_setting_bool("force_sub_enabled", True) else a["off"]
    ref_on = db.get_setting_bool("referral_enabled", True)
    ci_on = db.get_setting_bool("checkin_enabled", True)
    return a["title"] + "\n" + a["subtitle"].format(
        maint=maint,
        fsub=fsub,
        cost=fmt_tok(get_chest_cost()),
        wcost=fmt_tok(get_weekly_base_cost()),
        wbonus=fmt_tok(get_welcome_bonus()),
        ref_st=a["on"] if ref_on else a["off"],
        ref_r=fmt_tok(db.get_setting_float("referral_inviter_reward", 3.0)),
        ci_st=a["on"] if ci_on else a["off"],
    )


def get_games_keyboard(lang: str = "ar") -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    styles = ["primary", "success"]
    for i, (key, data) in enumerate(GAMES_CATALOG.items()):
        builder.button(text=data["name"], callback_data=f"game_{key}", style=styles[i % len(styles)])
    builder.adjust(2)
    t = STRINGS.get(lang, STRINGS["ar"])
    nav = InlineKeyboardBuilder()
    nav.button(text=t["home"], callback_data="nav_home", style="danger")
    nav.adjust(1)
    builder.attach(nav)
    return builder.as_markup()


def get_confirmation_keyboard(lang: str = "ar") -> InlineKeyboardMarkup:
    cost = fmt_tok(get_chest_cost())
    builder = InlineKeyboardBuilder()
    if lang == "fr":
        builder.button(text=f"⚡ Lancer Maintenant ({cost} 🪙)", callback_data="pay_confirm", style="success")
        builder.button(text="📝 Changer Compte", callback_data="pay_edit", style="primary")
        builder.button(text="✖️ Annuler", callback_data="pay_cancel", style="danger")
    elif lang == "en":
        builder.button(text=f"⚡ Launch Now ({cost} 🪙)", callback_data="pay_confirm", style="success")
        builder.button(text="📝 Edit Account", callback_data="pay_edit", style="primary")
        builder.button(text="✖️ Cancel", callback_data="pay_cancel", style="danger")
    else:
        builder.button(text=f"⚡ تأكيد والبدء الآن ({cost} 🪙)", callback_data="pay_confirm", style="success")
        builder.button(text="📝 تعديل الحساب", callback_data="pay_edit", style="primary")
        builder.button(text="✖️ إلغاء", callback_data="pay_cancel", style="danger")
    builder.adjust(1, 2)
    return builder.as_markup()


def _welcome_text_for(user_id: int, lang: Optional[str] = None) -> str:
    user = db.get_or_create_user(user_id)
    use_lang = lang or db.get_user_language(user_id) or "ar"
    t = STRINGS.get(use_lang, STRINGS["ar"])
    return t["welcome"].format(
        balance=fmt_tok(user.get("balance", 0)),
        chest_cost=fmt_tok(get_chest_cost()),
        weekly_cost=fmt_tok(get_weekly_cost_for_user(user_id)),
        welcome_bonus=fmt_tok(get_welcome_bonus()),
    )


@dp.message(CommandStart(), StateFilter("*"))
async def cmd_start(message: types.Message, state: FSMContext, command: Optional[CommandObject] = None):
    await state.clear()
    user_id = message.from_user.id
    username = message.from_user.username
    db.get_or_create_user(user_id, username)

    if command and command.args:
        ref_arg = command.args.strip()
        inviter_str = ref_arg.replace("ref_", "")
        if inviter_str.isdigit():
            db.record_referral(int(inviter_str), user_id)

    req_sub = db.get_setting_bool("referral_require_sub", True)
    is_sub, _ = await check_all_channels_subscription(bot, user_id)
    if (is_sub or not req_sub) or user_id in ADMIN_IDS:
        rewarded_tuple = db.reward_referral_if_pending(user_id)
        if rewarded_tuple:
            inviter_id, inv_amt, _ = rewarded_tuple
            await _notify_inviter_reward(inviter_id, user_id, username, inv_amt)

    lang = db.get_user_language(user_id) or "ar"
    try:
        rm = await message.answer("⚡", reply_markup=ReplyKeyboardRemove())
        await rm.delete()
    except Exception:
        pass
    await send_welcome_message(message.chat.id, user_id, _welcome_text_for(user_id, lang), get_main_menu(user_id, lang))


@dp.callback_query(F.data == "nav_home", StateFilter("*"))
async def cb_nav_home(callback: types.CallbackQuery, state: FSMContext):
    await state.clear()
    user_id = callback.from_user.id
    lang = db.get_user_language(user_id) or "ar"
    text = _welcome_text_for(user_id, lang)
    kb = get_main_menu(user_id, lang)
    if callback.message and callback.message.text is not None:
        try:
            await callback.message.edit_text(text, reply_markup=kb, parse_mode="HTML", disable_web_page_preview=True)
            await callback.answer()
            return
        except Exception:
            pass
    await send_welcome_message(callback.message.chat.id, user_id, text, kb)
    await callback.answer()


@dp.message(Command("cancel"), StateFilter("*"))
async def cmd_cancel(message: types.Message, state: FSMContext):
    await state.clear()
    user_id = message.from_user.id
    lang = db.get_user_language(user_id) or "ar"
    cancel_msg = {
        "en": "✖️ <b>Operation cancelled.</b> Choose an action below:",
        "fr": "✖️ <b>Opération annulée.</b> Choisissez une option ci-dessous :",
        "ar": "✖️ <b>تم إلغاء العملية الحالية.</b> اختر من القائمة أدناه:",
    }.get(lang, "✖️ <b>تم إلغاء العملية الحالية.</b>")
    await message.answer(cancel_msg, reply_markup=get_main_menu(user_id, lang), parse_mode="HTML")


async def _show_quests_menu(target: Union[types.Message, types.CallbackQuery], user_id: int, state: FSMContext):
    await state.clear()
    lang = db.get_user_language(user_id) or "ar"
    if not db.get_setting_bool("quests_enabled", True):
        msg = {
            "en": "🔒 <b>Quest Vault is currently disabled by Admin.</b>",
            "fr": "🔒 <b>Le Coffre des Quêtes est désactivé par l'Admin.</b>",
            "ar": "🔒 <b>نظام فتح الصناديق متوقف مؤقتاً من قبل الإدارة.</b>",
        }.get(lang)
        await safe_show(target, msg, reply_markup=get_main_menu(user_id, lang), prefer_edit=True)
        if isinstance(target, types.CallbackQuery):
            await target.answer()
        return

    if lang == "en":
        q_text = (
            "🚀 <b>PLAYX1 ZONE — Quest Vault</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "Pick the active chest game you want to complete automatically:\n"
            "📌 <i>Verify that this game quest is visible inside your Google Play Points tab first.</i>"
        )
    elif lang == "fr":
        q_text = (
            "🚀 <b>PLAYX1 ZONE — Coffres & Quêtes</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "Sélectionnez le jeu correspondant au coffre à valider :\n"
            "📌 <i>Assurez-vous que la mission apparaît bien dans votre onglet Google Play Points.</i>"
        )
    else:
        q_text = (
            "🚀 <b>خزنة الصناديق — PLAYX1 ZONE</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "اختر اللعبة الخاصة بالصندوق الذي تريد إنجازه الآن:\n"
            "📌 <i>تأكد أولاً أن مهمة هذا الصندوق ظاهرة لديك داخل قسم Google Play Points.</i>"
        )
    await safe_show(target, q_text, reply_markup=get_games_keyboard(lang), prefer_edit=True)
    if isinstance(target, types.CallbackQuery):
        await target.answer()


@dp.message(Command("goal"), StateFilter("*"))
@dp.message(Command("goals"), StateFilter("*"))
@dp.message(Command("quest"), StateFilter("*"))
@dp.message(Command("quests"), StateFilter("*"))
@dp.message(Command("boost"), StateFilter("*"))
async def select_quest(message: types.Message, state: FSMContext):
    await _show_quests_menu(message, message.from_user.id, state)


@dp.callback_query(F.data.in_({"nav_quests", "menu_select_quest"}), StateFilter("*"))
async def menu_select_quest_cb(callback: types.CallbackQuery, state: FSMContext):
    await _show_quests_menu(callback, callback.from_user.id, state)


async def _render_weekly_menu(
    target_event: Union[types.Message, types.CallbackQuery],
    user_id: int,
    state: FSMContext,
    page: int = 0,
    edit: bool = False,
):
    lang = db.get_user_language(user_id) or "ar"
    t = STRINGS.get(lang, STRINGS["ar"])

    if not db.get_setting_bool("weekly_prize_enabled", True):
        dis_msg = {
            "en": "👑 <b>Weekly Prize System</b>\n━━━━━━━━━━━━━━━━━━━━\n🔒 <i>Currently disabled by administrator.</i>",
            "fr": "👑 <b>Prix Hebdomadaire</b>\n━━━━━━━━━━━━━━━━━━━━\n🔒 <i>Actuellement désactivé par l'administrateur.</i>",
            "ar": "👑 <b>نظام الجائزة الأسبوعية</b>\n━━━━━━━━━━━━━━━━━━━━\n🔒 <i>متوقف حالياً من قبل الإدارة.</i>",
        }.get(lang)
        kb = InlineKeyboardBuilder()
        kb.button(text=t["home"], callback_data="nav_home", style="primary")
        await safe_show(target_event, dis_msg, reply_markup=kb.as_markup(), prefer_edit=edit)
        if isinstance(target_event, types.CallbackQuery):
            await target_event.answer()
        return

    w_cost = get_weekly_cost_for_user(user_id)
    w_cost_str = fmt_tok(w_cost)
    bal_str = fmt_tok(db.get_user_balance(user_id))
    cost_line_ar = f"💳 <b>رصيدك الحالي:</b> <code>{bal_str}</code> توكن\n🪙 <b>تكلفة التفعيل:</b> <code>{w_cost_str}</code> توكن" if w_cost > 0 else f"💳 <b>رصيدك الحالي:</b> <code>{bal_str}</code> توكن\n🪙 <b>تكلفة التفعيل:</b> <b>مجاني 🎁</b>"
    cost_line_en = f"💳 <b>Current Wallet:</b> <code>{bal_str}</code> Tokens\n🪙 <b>Activation Cost:</b> <code>{w_cost_str}</code> Tokens" if w_cost > 0 else f"💳 <b>Current Wallet:</b> <code>{bal_str}</code> Tokens\n🪙 <b>Activation Cost:</b> <b>FREE 🎁</b>"
    cost_line_fr = f"💳 <b>Solde Actuel :</b> <code>{bal_str}</code> Tokens\n🪙 <b>Coût d'Activation :</b> <code>{w_cost_str}</code> Tokens" if w_cost > 0 else f"💳 <b>Solde Actuel :</b> <code>{bal_str}</code> Tokens\n🪙 <b>Coût d'Activation :</b> <b>GRATUIT 🎁</b>"

    saved = db.get_saved_accounts(user_id)
    saved = [acc for acc in saved if acc.get("email") and acc.get("password")]

    if not saved:
        await state.set_state(WeeklyForm.waiting_for_credentials)
        if lang == "en":
            empty_text = (
                "👑 <b>Weekly Prize Claimer</b>\n"
                "━━━━━━━━━━━━━━━━━━━━\n"
                f"{cost_line_en}\n"
                "━━━━━━━━━━━━━━━━━━━━\n"
                "Send your Google account credentials to collect this week's Play Points prize:\n\n"
                "📥 Format: <code>email:password</code>\n\n"
                "⚡ <i>Saved automatically for instant 1-tap weekly claims.</i>"
            )
        elif lang == "fr":
            empty_text = (
                "👑 <b>Récupérateur Prix Hebdomadaire</b>\n"
                "━━━━━━━━━━━━━━━━━━━━\n"
                f"{cost_line_fr}\n"
                "━━━━━━━━━━━━━━━━━━━━\n"
                "Envoyez vos identifiants Google pour réclamer votre prix hebdomadaire :\n\n"
                "📥 Format : <code>email:password</code>\n\n"
                "⚡ <i>Sauvegardé automatiquement pour vos prochaines réclamations.</i>"
            )
        else:
            empty_text = (
                "👑 <b>استلام الجائزة الأسبوعية</b>\n"
                "━━━━━━━━━━━━━━━━━━━━\n"
                f"{cost_line_ar}\n"
                "━━━━━━━━━━━━━━━━━━━━\n"
                "أرسل بيانات حساب Google الخاص بك للمطالبة بجائزة نقاط Play لهذا الأسبوع:\n\n"
                "📥 الصيغة: <code>email:password</code>\n\n"
                "⚡ <i>سيتم حفظ الحساب تلقائياً لاستلام الجائزة الأسبوعية بنقرة واحدة.</i>"
            )
        kb = InlineKeyboardBuilder()
        kb.button(text=t["home"], callback_data="nav_home", style="danger")
        await safe_show(target_event, empty_text, reply_markup=kb.as_markup(), prefer_edit=edit)
        if isinstance(target_event, types.CallbackQuery):
            await target_event.answer()
        return

    total_accounts = len(saved)
    total_pages = max(1, math.ceil(total_accounts / PAGE_SIZE_ACCOUNTS))
    page = max(0, min(page, total_pages - 1))

    start_idx = page * PAGE_SIZE_ACCOUNTS
    end_idx = min(start_idx + PAGE_SIZE_ACCOUNTS, total_accounts)
    page_accounts = saved[start_idx:end_idx]

    builder = InlineKeyboardBuilder()
    for offset_i, acc in enumerate(page_accounts):
        global_idx = start_idx + offset_i
        acc_id = acc.get("id")
        cb_val = str(acc_id) if acc_id is not None else str(global_idx)
        builder.button(text=f"📨 {acc['email']}", callback_data=f"weekly_acc_{cb_val}", style="primary")
    builder.adjust(1)

    if total_pages > 1:
        nav_builder = InlineKeyboardBuilder()
        btn_prev = "◀️ Prev" if lang == "en" else ("◀️ Préc." if lang == "fr" else "◀️ السابق")
        btn_next = "Next ▶️" if lang == "en" else ("Suiv. ▶️" if lang == "fr" else "التالي ▶️")
        if page > 0:
            nav_builder.button(text=btn_prev, callback_data=f"weekly_page_{page - 1}")
        nav_builder.button(text=f"📑 {page + 1}/{total_pages}", callback_data=f"weekly_page_info_{page + 1}_{total_pages}")
        if page < total_pages - 1:
            nav_builder.button(text=btn_next, callback_data=f"weekly_page_{page + 1}")
        nav_builder.adjust(3 if (page > 0 and page < total_pages - 1) else 2)
        builder.attach(nav_builder)

    action_builder = InlineKeyboardBuilder()
    if lang == "en":
        action_builder.button(text="➕ Add New Account", callback_data="weekly_acc_new", style="success")
        action_builder.button(text=t["home"], callback_data="nav_home", style="danger")
        page_info = f"\n📑 <i>Page {page + 1}/{total_pages} • {total_accounts} saved accounts</i>" if total_pages > 1 else ""
        msg_text = (
            "👑 <b>Weekly Prize Claimer</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"{cost_line_en}\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"Choose an account to claim this week's Play Points prize:{page_info}\n\n"
            "✨ <i>Available weekly for Silver, Gold, Platinum & Diamond tiers.</i>"
        )
    elif lang == "fr":
        action_builder.button(text="➕ Nouveau Compte", callback_data="weekly_acc_new", style="success")
        action_builder.button(text=t["home"], callback_data="nav_home", style="danger")
        page_info = f"\n📑 <i>Page {page + 1}/{total_pages} • {total_accounts} comptes</i>" if total_pages > 1 else ""
        msg_text = (
            "👑 <b>Récupérateur Prix Hebdomadaire</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"{cost_line_fr}\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"Sélectionnez un compte pour réclamer votre prix hebdomadaire :{page_info}\n\n"
            "✨ <i>Disponible chaque semaine pour les niveaux Argent, Or, Platine et Diamant.</i>"
        )
    else:
        action_builder.button(text="➕ إضافة حساب جديد", callback_data="weekly_acc_new", style="success")
        action_builder.button(text=t["home"], callback_data="nav_home", style="danger")
        page_info = f"\n📑 <i>الصفحة {page + 1} من {total_pages} • الإجمالي: {total_accounts} حساب</i>" if total_pages > 1 else ""
        msg_text = (
            "👑 <b>استلام الجائزة الأسبوعية</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"{cost_line_ar}\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"اختر أحد حساباتك المحفوظة لاستلام الجائزة الأسبوعية:{page_info}\n\n"
            "✨ <i>تتوفر الجائزة الأسبوعية للمستويات الفضي والذهبي والبلاتيني والماسي.</i>"
        )
    action_builder.adjust(1)
    builder.attach(action_builder)

    await state.update_data(saved_accounts=saved, weekly_page=page)
    await state.set_state(WeeklyForm.waiting_for_account_selection)

    await safe_show(target_event, msg_text, reply_markup=builder.as_markup(), prefer_edit=edit)
    if isinstance(target_event, types.CallbackQuery):
        await target_event.answer()


@dp.message(Command("weekly"), StateFilter("*"))
async def weekly_prize_menu(message: types.Message, state: FSMContext):
    await state.clear()
    await _render_weekly_menu(message, message.from_user.id, state, page=0, edit=False)


@dp.callback_query(F.data == "nav_weekly", StateFilter("*"))
async def cb_nav_weekly(callback: types.CallbackQuery, state: FSMContext):
    await state.clear()
    await _render_weekly_menu(callback, callback.from_user.id, state, page=0, edit=True)


@dp.callback_query(F.data.startswith("weekly_page_info_"))
async def weekly_page_info_handler(callback: types.CallbackQuery):
    parts = callback.data.split("_")
    if len(parts) >= 5:
        await callback.answer(f"📑 {parts[3]} / {parts[4]}")
    else:
        await callback.answer()


@dp.callback_query(WeeklyForm.waiting_for_account_selection, F.data.startswith("weekly_page_"))
@dp.callback_query(F.data.startswith("weekly_page_"))
async def weekly_page_handler(callback: types.CallbackQuery, state: FSMContext):
    try:
        page = int(callback.data.split("weekly_page_")[1])
    except ValueError:
        await callback.answer()
        return
    await _render_weekly_menu(callback, callback.from_user.id, state, page=page, edit=True)


@dp.callback_query(WeeklyForm.waiting_for_account_selection, F.data.startswith("weekly_acc_"))
@dp.callback_query(F.data.startswith("weekly_acc_"))
async def weekly_acc_selected(callback: types.CallbackQuery, state: FSMContext):
    data = callback.data.split("weekly_acc_")[1]
    user_id = callback.from_user.id
    lang = db.get_user_language(user_id) or "ar"
    t = STRINGS.get(lang, STRINGS["ar"])

    if not db.get_setting_bool("weekly_prize_enabled", True):
        await callback.answer("🔒 Weekly Prize is disabled.", show_alert=True)
        return

    if data == "new":
        await state.set_state(WeeklyForm.waiting_for_credentials)
        if lang == "en":
            prompt = "👑 <b>Link New Google Account</b>\n━━━━━━━━━━━━━━━━━━━━\nSend credentials in format:\n<code>email:password</code>"
        elif lang == "fr":
            prompt = "👑 <b>Ajouter un Compte Google</b>\n━━━━━━━━━━━━━━━━━━━━\nEnvoyez vos identifiants au format :\n<code>email:password</code>"
        else:
            prompt = "👑 <b>إضافة حساب Google جديد</b>\n━━━━━━━━━━━━━━━━━━━━\nأرسل البيانات بالصيغة التالية:\n<code>email:password</code>"
        kb = InlineKeyboardBuilder()
        kb.button(text=t["back"], callback_data="nav_weekly", style="danger")
        await safe_show(callback, prompt, reply_markup=kb.as_markup(), prefer_edit=True)
        await callback.answer()
        return

    w_cost = get_weekly_cost_for_user(user_id)
    bal = db.get_user_balance(user_id)
    if w_cost > 0 and bal < w_cost:
        low_txt = {
            "en": f"⚠️ Insufficient tokens! Required: {fmt_tok(w_cost)} | Wallet: {fmt_tok(bal)}",
            "fr": f"⚠️ Tokens insuffisants ! Requis : {fmt_tok(w_cost)} | Solde : {fmt_tok(bal)}",
            "ar": f"⚠️ رصيدك غير كافٍ! التكلفة: {fmt_tok(w_cost)} توكن | رصيدك: {fmt_tok(bal)} توكن",
        }.get(lang)
        await callback.answer(low_txt, show_alert=True)
        return

    acc = None
    if data.isdigit():
        acc = db.get_saved_account_by_id(user_id, int(data))
    if not acc and data.isdigit():
        try:
            idx = int(data)
            state_data = await state.get_data()
            saved = state_data.get("saved_accounts", [])
            if not saved or idx >= len(saved):
                saved = db.get_saved_accounts(user_id)
                saved = [a for a in saved if a.get("email") and a.get("password")]
            if idx < len(saved):
                acc = saved[idx]
        except (ValueError, IndexError):
            pass
    if not acc:
        acc = db.get_saved_account_by_email(user_id, data)

    if not acc or not acc.get("password"):
        await callback.answer("⚠️ Account not found!", show_alert=True)
        return

    email = acc["email"]
    password = acc["password"]
    await callback.answer()

    connecting_txt = {
        "en": f"👑 <b>Processing Weekly Prize...</b>\n\n📨 <b>Account:</b> <code>{email}</code>\n⚡ <i>Connecting to Google Play Points...</i>",
        "fr": f"👑 <b>Traitement du Prix Hebdomadaire...</b>\n\n📨 <b>Compte :</b> <code>{email}</code>\n⚡ <i>Connexion à Google Play Points...</i>",
        "ar": f"👑 <b>جاري فحص واستلام الجائزة الأسبوعية...</b>\n\n📨 <b>الحساب:</b> <code>{email}</code>\n⚡ <i>جاري الاتصال بخوادم Google Play Points...</i>",
    }.get(lang)
    status_msg = await safe_show(callback, connecting_txt, prefer_edit=True)
    await _execute_weekly_claim(user_id, email, password, status_msg, state, charged_cost=w_cost)


@dp.message(WeeklyForm.waiting_for_credentials)
async def weekly_credentials_entered(message: types.Message, state: FSMContext):
    text = (message.text or "").strip()
    user_id = message.from_user.id
    lang = db.get_user_language(user_id) or "ar"

    if not db.get_setting_bool("weekly_prize_enabled", True):
        await message.answer("🔒 Weekly Prize is currently disabled.", parse_mode="HTML")
        await state.clear()
        return

    if ":" not in text:
        err_fmt = {
            "en": "⚠️ <b>Invalid Format</b>\nUse: <code>email:password</code>\nExample: <code>player@gmail.com:Pass1234</code>",
            "fr": "⚠️ <b>Format Invalide</b>\nUtilisez : <code>email:password</code>\nExemple : <code>player@gmail.com:Pass1234</code>",
            "ar": "⚠️ <b>صيغة غير صحيحة!</b>\nاستخدم: <code>email:password</code>\nمثال: <code>player@gmail.com:Pass1234</code>",
        }.get(lang)
        await message.answer(err_fmt, parse_mode="HTML")
        return

    w_cost = get_weekly_cost_for_user(user_id)
    bal = db.get_user_balance(user_id)
    if w_cost > 0 and bal < w_cost:
        low_msg = {
            "en": f"⚠️ Insufficient balance! Need <code>{fmt_tok(w_cost)}</code> tokens (Current: <code>{fmt_tok(bal)}</code>).",
            "fr": f"⚠️ Solde insuffisant ! Il faut <code>{fmt_tok(w_cost)}</code> tokens (Actuel : <code>{fmt_tok(bal)}</code>).",
            "ar": f"⚠️ رصيدك غير كافٍ! تحتاج إلى <code>{fmt_tok(w_cost)}</code> توكن (رصيدك: <code>{fmt_tok(bal)}</code>).",
        }.get(lang)
        await message.answer(low_msg, reply_markup=get_main_menu(user_id, lang), parse_mode="HTML")
        await state.clear()
        return

    email, password = text.split(":", 1)
    email = email.strip()
    password = password.strip()

    try:
        await message.delete()
    except Exception:
        pass

    db.save_account(user_id, email, password)

    connecting_txt = {
        "en": f"👑 <b>Processing Weekly Prize...</b>\n\n📨 <b>Account:</b> <code>{email}</code>\n⚡ <i>Connecting to Google Play Points...</i>",
        "fr": f"👑 <b>Traitement du Prix Hebdomadaire...</b>\n\n📨 <b>Compte :</b> <code>{email}</code>\n⚡ <i>Connexion à Google Play Points...</i>",
        "ar": f"👑 <b>جاري فحص واستلام الجائزة الأسبوعية...</b>\n\n📨 <b>الحساب:</b> <code>{email}</code>\n⚡ <i>جاري الاتصال بخوادم Google Play Points...</i>",
    }.get(lang)
    status_msg = await message.answer(connecting_txt, parse_mode="HTML")
    await _execute_weekly_claim(user_id, email, password, status_msg, state, charged_cost=w_cost)


async def _execute_weekly_claim(
    user_id: int,
    email: str,
    password: str,
    status_msg: types.Message,
    state: FSMContext,
    charged_cost: Optional[float] = None,
):
    sc_prefix = f"/tmp/weekly_{user_id}"
    claim_res = None
    lang = db.get_user_language(user_id) or "ar"
    cost = get_weekly_cost_for_user(user_id) if charged_cost is None else charged_cost
    deducted = False

    if cost > 0:
        cur_bal = db.get_user_balance(user_id)
        if cur_bal < cost:
            await status_msg.edit_text(
                f"⚠️ <b>Insufficient Tokens:</b> Need <code>{fmt_tok(cost)}</code> 🪙 (Wallet: <code>{fmt_tok(cur_bal)}</code> 🪙).",
                reply_markup=get_main_menu(user_id, lang),
                parse_mode="HTML",
            )
            await state.clear()
            return
        db.update_balance(user_id, -cost)
        deducted = True

    mt_info = db.get_master_token(user_id, email)
    if mt_info and mt_info.get("master_token"):
        loading_text = {
            "en": f"👑 <b>Checking Play Points Perks...</b>\n\n📨 <b>Account:</b> <code>{email}</code>\n⚡ <i>Saved session active. Scanning weekly prize...</i>",
            "fr": f"👑 <b>Vérification des Avantages...</b>\n\n📨 <b>Compte :</b> <code>{email}</code>\n⚡ <i>Session enregistrée active. Analyse...</i>",
            "ar": f"👑 <b>جاري الدخول إلى مزايا Play Points...</b>\n\n📨 <b>الحساب:</b> <code>{email}</code>\n⚡ <i>الجلسة المحفوظة جاهزة. جاري فحص الجائزة الأسبوعية...</i>",
        }.get(lang)
        await status_msg.edit_text(loading_text, parse_mode="HTML")

        try:
            claim_res = await asyncio.to_thread(
                fast_claim_weekly_perk,
                email,
                mt_info["master_token"],
                mt_info["android_id"],
                None,
                sc_prefix,
            )
        except Exception as e:
            logger.warning("Fast weekly claim failed, falling back to full login: %s", e)

    if not claim_res or claim_res.get("status") == "AUTH_REQUIRED":
        ap_auth = AutoPixelAuthenticator(email, password)
        status, result = await asyncio.to_thread(ap_auth.start_auth)

        if status in ("NEEDS_NUMBER", "NEEDS_TAP_YES"):
            if lang == "en":
                if status == "NEEDS_NUMBER":
                    prompt_text = (
                        "📲 <b>Phone Approval Needed</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                        f"👉 <b>Tap number <code>{result}</code> on your phone</b>\n\n"
                        f"<i>Approve the Google security prompt and choose <b>{result}</b>.</i>\n"
                        "⏳ <i>Waiting up to 2 minutes...</i>"
                    )
                else:
                    prompt_text = (
                        "📲 <b>Phone Approval Needed</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                        "👉 <b>Tap 'Yes, it's me' on your phone</b>\n\n"
                        "<i>Open the Google notification on your device to approve sign-in.</i>\n"
                        "⏳ <i>Waiting up to 2 minutes...</i>"
                    )
                timeout_msg = "⌛ <b>Verification expired.</b> No response was received on your device."
                confirmed_msg = "✅ <b>Device approval received!</b>\n⚡ <i>Collecting your weekly prize...</i>"
            elif lang == "fr":
                if status == "NEEDS_NUMBER":
                    prompt_text = (
                        "📲 <b>Validation sur Téléphone Requise</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                        f"👉 <b>Appuyez sur le chiffre <code>{result}</code> sur votre appareil</b>\n\n"
                        f"<i>Validez l'alerte Google et choisissez <b>{result}</b>.</i>\n"
                        "⏳ <i>En attente (2 minutes max)...</i>"
                    )
                else:
                    prompt_text = (
                        "📲 <b>Validation sur Téléphone Requise</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                        "👉 <b>Appuyez sur 'Oui, c'est moi' sur votre appareil</b>\n\n"
                        "<i>Ouvrez la notification Google pour confirmer.</i>\n"
                        "⏳ <i>En attente (2 minutes max)...</i>"
                    )
                timeout_msg = "⌛ <b>Délai expiré.</b> Confirmation non validée à temps."
                confirmed_msg = "✅ <b>Connexion validée !</b>\n⚡ <i>Récupération du prix hebdomadaire...</i>"
            else:
                if status == "NEEDS_NUMBER":
                    prompt_text = (
                        "📲 <b>مطلوب الموافقة من هاتفك</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                        f"👉 <b>اختر الرقم <code>{result}</code> في إشعار Google على هاتفك</b>\n\n"
                        f"<i>اضغط «نعم، إنه أنا» ثم حدد الرقم <b>{result}</b> لإكمال الدخول.</i>\n"
                        "💡 <i>يظهر التنبيه في شاشة الهاتف أو تطبيق Gmail (ليس رسالة SMS).</i>\n"
                        "⏳ <i>بانتظار موافقتك (مهلة دقيقتين)...</i>"
                    )
                else:
                    prompt_text = (
                        "📲 <b>مطلوب الموافقة من هاتفك</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                        "👉 <b>اضغط «نعم، إنه أنا» في إشعار Google على هاتفك</b>\n\n"
                        "<i>افتح إشعار الأمان من شريط الإشعارات أو تطبيق Gmail للمتابعة.</i>\n"
                        "⏳ <i>بانتظار موافقتك (مهلة دقيقتين)...</i>"
                    )
                timeout_msg = "⌛ <b>انتهت مهلة الموافقة!</b> لم يتم تأكيد الإشعار في الوقت المحدد."
                confirmed_msg = "✅ <b>تمت الموافقة من هاتفك بنجاح!</b>\n⚡ <i>جاري استلام الجائزة الأسبوعية...</i>"

            await status_msg.edit_text(prompt_text, parse_mode="HTML")
            approved = await asyncio.to_thread(ap_auth.wait_for_approval, 120)
            if not approved:
                ap_auth.close()
                refund_note = ""
                if deducted and cost > 0:
                    db.update_balance(user_id, cost)
                    refund_note = f"\n💳 <i>Refunded +{fmt_tok(cost)} 🪙.</i>"
                await status_msg.edit_text(timeout_msg + refund_note, reply_markup=get_main_menu(user_id, lang), parse_mode="HTML")
                await state.clear()
                return
            await status_msg.edit_text(confirmed_msg, parse_mode="HTML")

        elif status != "SUCCESS":
            ap_auth.close()
            refund_note = ""
            if deducted and cost > 0:
                db.update_balance(user_id, cost)
                refund_note = f"\n💳 <i>Refunded +{fmt_tok(cost)} 🪙.</i>"
            await status_msg.edit_text(
                f"❌ <b>Google Sign-In Failed:</b>\n\n<code>{result}</code>{refund_note}",
                reply_markup=get_main_menu(user_id, lang),
                parse_mode="HTML",
            )
            await state.clear()
            return

        await asyncio.to_thread(ap_auth.extract_tokens)
        ap_auth.close()
        if ap_auth.master_token:
            db.save_master_token(user_id, email, ap_auth.master_token, ap_auth.android_id)
            claim_res = await asyncio.to_thread(
                fast_claim_weekly_perk,
                email,
                ap_auth.master_token,
                ap_auth.android_id,
                None,
                sc_prefix,
            )
        else:
            claim_res = {"status": "ERROR", "message": "Failed to extract Google session tokens."}

    await state.clear()
    st = claim_res.get("status")
    sc_file = claim_res.get("screenshot")
    menu_kb = get_main_menu(user_id, lang)

    refunded = False
    if deducted and cost > 0:
        if st == "NOT_ELIGIBLE" and db.get_setting_bool("weekly_refund_on_ineligible", True):
            db.update_balance(user_id, cost)
            refunded = True
        elif st == "ALREADY_CLAIMED" and db.get_setting_bool("weekly_refund_on_already_claimed", True):
            db.update_balance(user_id, cost)
            refunded = True
        elif st not in ("CLAIMED", "APP_REQUIRED", "ALREADY_CLAIMED", "NOT_ELIGIBLE"):
            db.update_balance(user_id, cost)
            refunded = True

    actual_charged = 0.0 if refunded else (cost if deducted else 0.0)
    db.log_weekly_claim(user_id, email, str(st), str(claim_res.get("points") or ""), actual_charged)

    rem_str = fmt_tok(db.get_user_balance(user_id))
    cost_info_ar = f"\n💳 <i>تم استرجاع +{fmt_tok(cost)} توكن إلى رصيدك (الرصيد: <code>{rem_str}</code> 🪙).</i>" if refunded else (f"\n💳 <i>الرصيد المتبقي: <code>{rem_str}</code> 🪙.</i>" if deducted else "")
    cost_info_en = f"\n💳 <i>Refunded +{fmt_tok(cost)} tokens (Wallet: <code>{rem_str}</code> 🪙).</i>" if refunded else (f"\n💳 <i>Remaining Wallet: <code>{rem_str}</code> 🪙.</i>" if deducted else "")
    cost_info_fr = f"\n💳 <i>+{fmt_tok(cost)} tokens remboursés (Solde : <code>{rem_str}</code> 🪙).</i>" if refunded else (f"\n💳 <i>Solde restant : <code>{rem_str}</code> 🪙.</i>" if deducted else "")

    try:
        if st == "CLAIMED":
            pts = claim_res.get("points", "+Points")
            caption = {
                "en": (
                    "🎊 <b>Weekly Prize Collected!</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                    f"🏆 <b>Points Won:</b> <code>{pts}</code> Play Points\n"
                    f"📨 <b>Account:</b> <code>{email}</code>\n\n"
                    f"✨ <i>Credited directly to your Google Play balance.</i>{cost_info_en}"
                ),
                "fr": (
                    "🎊 <b>Prix Hebdomadaire Récupéré !</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                    f"🏆 <b>Gain :</b> <code>{pts}</code> Play Points\n"
                    f"📨 <b>Compte :</b> <code>{email}</code>\n\n"
                    f"✨ <i>Crédité directement sur votre solde Google Play.</i>{cost_info_fr}"
                ),
                "ar": (
                    "🎊 <b>تم استلام الجائزة الأسبوعية بنجاح!</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                    f"🏆 <b>الجائزة:</b> <code>{pts}</code> Play Points\n"
                    f"📨 <b>الحساب:</b> <code>{email}</code>\n\n"
                    f"✨ <i>أُضيفت النقاط مباشرة إلى رصيدك في Google Play.</i>{cost_info_ar}"
                ),
            }.get(lang)
        elif st == "APP_REQUIRED":
            caption = {
                "en": (
                    "📱 <b>Mobile / PC App Required</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                    f"📨 <b>Account:</b> <code>{email}</code>\n\n"
                    "Google requires claiming this account's prize directly in the Play Store app or Play Games PC.\n"
                    f"👉 Go to: <b>Play Points → Perks → Claim Weekly Prize</b>.{cost_info_en}"
                ),
                "fr": (
                    "📱 <b>Réclamation via l'Application Requise</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                    f"📨 <b>Compte :</b> <code>{email}</code>\n\n"
                    "Google demande de réclamer ce bonus depuis l'app Play Store ou Play Jeux PC.\n"
                    f"👉 Allez dans : <b>Play Points → Avantages → Prix hebdomadaire</b>.{cost_info_fr}"
                ),
                "ar": (
                    "📱 <b>يتطلب الاستلام من تطبيق المتجر</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                    f"📨 <b>الحساب:</b> <code>{email}</code>\n\n"
                    "تفرض Google استلام جائزة هذا الحساب مباشرة عبر تطبيق Google Play في هاتفك أو Play Games على الكمبيوتر.\n"
                    f"👉 افتح: <b>Play Points ← المزايا ← المطالبة بالجائزة الأسبوعية</b>.{cost_info_ar}"
                ),
            }.get(lang)
        elif st == "ALREADY_CLAIMED":
            next_d = claim_res.get("next_date", "Next Week")
            caption = {
                "en": (
                    "ℹ️ <b>Already Collected This Week</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                    f"📨 <b>Account:</b> <code>{email}</code>\n"
                    f"🗓️ <b>Next Drop:</b> <b>{next_d}</b>{cost_info_en}"
                ),
                "fr": (
                    "ℹ️ <b>Bonus Déjà Réclamé Cette Semaine</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                    f"📨 <b>Compte :</b> <code>{email}</code>\n"
                    f"🗓️ <b>Prochaine date :</b> <b>{next_d}</b>{cost_info_fr}"
                ),
                "ar": (
                    "ℹ️ <b>تم استلام جائزة هذا الأسبوع مسبقاً</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                    f"📨 <b>الحساب:</b> <code>{email}</code>\n"
                    f"🗓️ <b>موعد الجائزة القادمة:</b> <b>{next_d}</b>{cost_info_ar}"
                ),
            }.get(lang)
        elif st == "NOT_ELIGIBLE":
            caption = {
                "en": (
                    "⚠️ <b>Account Not Eligible Yet</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                    f"📨 <b>Account:</b> <code>{email}</code>\n\n"
                    f"🥉 Currently on <b>Bronze Tier</b>. Weekly prizes unlock at <b>Silver Tier</b> or higher.{cost_info_en}"
                ),
                "fr": (
                    "⚠️ <b>Compte Non Éligible</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                    f"📨 <b>Compte :</b> <code>{email}</code>\n\n"
                    f"🥉 Niveau actuel : <b>Bronze</b>. Les prix s'activent à partir du niveau <b>Argent</b>.{cost_info_fr}"
                ),
                "ar": (
                    "⚠️ <b>الحساب غير مؤهل حالياً</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                    f"📨 <b>الحساب:</b> <code>{email}</code>\n\n"
                    f"🥉 الحساب في <b>المستوى البرونزي</b> حالياً، وتُفتح الجائزة الأسبوعية بدءاً من <b>المستوى الفضي</b> فأعلى.{cost_info_ar}"
                ),
            }.get(lang)
            await status_msg.edit_text(caption, reply_markup=menu_kb, parse_mode="HTML")
            return
        else:
            err_msg = claim_res.get("message", "Unknown error")
            caption = f"❌ <b>Weekly Prize Notice</b>\n━━━━━━━━━━━━━━━━━━━━\n{err_msg}\n\n📨 <b>Account:</b> <code>{email}</code>{cost_info_ar}"

        if sc_file and os.path.exists(sc_file):
            try:
                await status_msg.answer_photo(
                    photo=FSInputFile(sc_file),
                    caption=caption[:1024],
                    reply_markup=menu_kb,
                    parse_mode="HTML",
                )
                await status_msg.delete()
                return
            except Exception:
                pass
        await status_msg.edit_text(caption, reply_markup=menu_kb, parse_mode="HTML")
    except Exception as e:
        logger.exception("Error rendering weekly claim response: %s", e)
    finally:
        cleanup_file(sc_file)


@dp.callback_query(F.data == "check_sub")
async def cb_check_sub(callback: types.CallbackQuery, state: FSMContext):
    user_id = callback.from_user.id
    _SUB_CACHE.pop(user_id, None)
    is_sub, _ = await check_all_channels_subscription(bot, user_id, use_cache=False)
    lang = db.get_user_language(user_id) or "ar"
    t = STRINGS.get(lang, STRINGS["ar"])
    if is_sub:
        await callback.answer(t["sub_ok"], show_alert=False)
        try:
            await callback.message.delete()
        except Exception:
            pass
        db.get_or_create_user(user_id, callback.from_user.username)
        rewarded_tuple = db.reward_referral_if_pending(user_id)
        if rewarded_tuple:
            inviter_id, inv_amt, _ = rewarded_tuple
            await _notify_inviter_reward(inviter_id, user_id, callback.from_user.username, inv_amt)
        await send_welcome_message(callback.message.chat.id, user_id, _welcome_text_for(user_id, lang), get_main_menu(user_id, lang))
    else:
        await callback.answer(t["sub_fail"], show_alert=True)


@dp.callback_query(F.data.startswith("game_"))
async def game_selected(callback: types.CallbackQuery, state: FSMContext):
    if not db.get_setting_bool("quests_enabled", True):
        await callback.answer("🔒 Quests are disabled by Admin.", show_alert=True)
        return
    game_key = callback.data.split("game_")[1]
    if game_key not in GAMES_CATALOG:
        await callback.answer("Game not found!", show_alert=True)
        return

    game = GAMES_CATALOG[game_key]
    await state.update_data(game_key=game_key, game_name=game["name"])
    await state.set_state(QuestForm.waiting_for_credentials)

    user_id = callback.from_user.id
    lang = db.get_user_language(user_id) or "ar"

    if lang == "en":
        text = (
            f"🚀 <b>Selected Quest:</b> {game['name']}\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "📥 <b>Send your Google credentials:</b>\n"
            "<code>email---password</code>\n\n"
            "✨ <i>You can also send the email first, followed by the password in the next message.</i>\n"
            "📲 <b>Note:</b> Keep your phone ready in case Google displays a confirmation number."
        )
        btn_quick = "⚡ Saved Accounts"
        btn_info = "🔐 Verification Guide"
        btn_back = "↩️ All Quests"
        btn_cancel = "✖️ Cancel"
    elif lang == "fr":
        text = (
            f"🚀 <b>Coffre Choisi :</b> {game['name']}\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "📥 <b>Envoyez vos identifiants Google :</b>\n"
            "<code>email---password</code>\n\n"
            "✨ <i>Ou envoyez l'email d'abord, puis le mot de passe dans le message suivant.</i>\n"
            "📲 <b>Astuce :</b> Gardez votre téléphone à portée de main pour valider le chiffre Google."
        )
        btn_quick = "⚡ Comptes Sauvegardés"
        btn_info = "🔐 Guide de Vérification"
        btn_back = "↩️ Tous les Coffres"
        btn_cancel = "✖️ Annuler"
    else:
        text = (
            f"🚀 <b>الصندوق المحدد:</b> {game['name']}\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "📥 <b>أرسل بيانات حساب Google الخاص بك:</b>\n"
            "<code>email---password</code>\n\n"
            "✨ <i>يمكنك أيضاً إرسال الإيميل أولاً ثم كلمة المرور في رسالة منفصلة.</i>\n"
            "📲 <b>تذكير:</b> أبقِ هاتفك بجانبك للضغط على رقم التأكيد إن طُلب منك."
        )
        btn_quick = "⚡ اختيار من حساباتي المحفوظة"
        btn_info = "🔐 شرح آلية التحقق"
        btn_back = "↩️ قائمة الصناديق"
        btn_cancel = "✖️ إلغاء"

    builder = InlineKeyboardBuilder()
    builder.button(text=btn_quick, callback_data=f"quick_select_{game_key}", style="success")
    builder.button(text=btn_info, callback_data="verification_info", style="primary")
    builder.button(text=btn_back, callback_data="nav_quests", style="primary")
    builder.button(text=btn_cancel, callback_data="pay_cancel", style="danger")
    builder.adjust(1, 1, 2)

    await safe_show(callback, text, reply_markup=builder.as_markup(), prefer_edit=True)
    await callback.answer()


async def _render_quick_select(
    callback: types.CallbackQuery,
    state: FSMContext,
    page: int = 0,
    edit: bool = False,
):
    user_id = callback.from_user.id
    lang = db.get_user_language(user_id) or "ar"
    accounts = db.get_saved_accounts(user_id)
    valid_accounts = [acc for acc in accounts if acc.get("email") and acc.get("password")]

    if not valid_accounts:
        err_msg = (
            "No saved accounts found! Enter your credentials manually."
            if lang == "en" else
            ("Aucun compte sauvegardé ! Entrez vos identifiants manuellement." if lang == "fr" else "لا توجد حسابات محفوظة بعد! أرسل بياناتك يدوياً.")
        )
        await callback.answer(err_msg, show_alert=True)
        return

    total_accounts = len(valid_accounts)
    total_pages = max(1, math.ceil(total_accounts / PAGE_SIZE_ACCOUNTS))
    page = max(0, min(page, total_pages - 1))

    start_idx = page * PAGE_SIZE_ACCOUNTS
    end_idx = min(start_idx + PAGE_SIZE_ACCOUNTS, total_accounts)
    page_accounts = valid_accounts[start_idx:end_idx]

    builder = InlineKeyboardBuilder()
    for acc in page_accounts:
        acc_id = acc.get("id")
        cb_val = str(acc_id) if acc_id is not None else acc["email"]
        builder.button(text=f"📨 {acc['email']}", callback_data=f"use_acc_{cb_val}", style="primary")
    builder.adjust(1)

    if total_pages > 1:
        nav_builder = InlineKeyboardBuilder()
        btn_prev = "◀️ Prev" if lang == "en" else ("◀️ Préc." if lang == "fr" else "◀️ السابق")
        btn_next = "Next ▶️" if lang == "en" else ("Suiv. ▶️" if lang == "fr" else "التالي ▶️")
        if page > 0:
            nav_builder.button(text=btn_prev, callback_data=f"quick_page_{page - 1}")
        nav_builder.button(text=f"📑 {page + 1}/{total_pages}", callback_data=f"quick_page_info_{page + 1}_{total_pages}")
        if page < total_pages - 1:
            nav_builder.button(text=btn_next, callback_data=f"quick_page_{page + 1}")
        nav_builder.adjust(3 if (page > 0 and page < total_pages - 1) else 2)
        builder.attach(nav_builder)

    cancel_text = "✖️ Cancel" if lang == "en" else ("✖️ Annuler" if lang == "fr" else "✖️ إلغاء")
    action_builder = InlineKeyboardBuilder()
    action_builder.button(text=cancel_text, callback_data="pay_cancel", style="danger")
    action_builder.adjust(1)
    builder.attach(action_builder)

    if lang == "en":
        page_info = f"\n<i>Page {page + 1}/{total_pages} • {total_accounts} accounts</i>" if total_pages > 1 else ""
        prompt_title = f"⚡ <b>Saved Accounts Vault</b>{page_info}"
    elif lang == "fr":
        page_info = f"\n<i>Page {page + 1}/{total_pages} • {total_accounts} comptes</i>" if total_pages > 1 else ""
        prompt_title = f"⚡ <b>Comptes Sauvegardés</b>{page_info}"
    else:
        page_info = f"\n<i>الصفحة {page + 1} من {total_pages} • الإجمالي: {total_accounts} حساب</i>" if total_pages > 1 else ""
        prompt_title = f"⚡ <b>اختر حساباً من خزنتك المحفوظة:</b>{page_info}"

    await safe_show(callback, prompt_title, reply_markup=builder.as_markup(), prefer_edit=edit)
    await callback.answer()


@dp.callback_query(F.data == "quick_select")
@dp.callback_query(F.data.startswith("quick_select_"))
async def quick_select(callback: types.CallbackQuery, state: FSMContext):
    if callback.data.startswith("quick_select_"):
        gk = callback.data.split("quick_select_")[1]
        if gk in GAMES_CATALOG:
            await state.update_data(game_key=gk, game_name=GAMES_CATALOG[gk]["name"])
            await state.set_state(QuestForm.waiting_for_credentials)
    await _render_quick_select(callback, state, page=0, edit=True)


@dp.callback_query(F.data.startswith("quick_page_info_"))
async def quick_page_info_handler(callback: types.CallbackQuery):
    parts = callback.data.split("_")
    if len(parts) >= 5:
        await callback.answer(f"📑 {parts[3]} / {parts[4]}")
    else:
        await callback.answer()


@dp.callback_query(F.data.startswith("quick_page_"))
async def quick_page_handler(callback: types.CallbackQuery, state: FSMContext):
    try:
        page = int(callback.data.split("quick_page_")[1])
    except ValueError:
        await callback.answer()
        return
    await _render_quick_select(callback, state, page=page, edit=True)


def _format_confirm_text(lang: str, game_name: str, email: str, masked_pw: str, balance: float) -> str:
    cost_str = fmt_tok(get_chest_cost())
    bal_str = fmt_tok(balance)
    if lang == "fr":
        return (
            "🧾 <b>Récapitulatif & Lancement</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"🚀 <b>Coffre :</b> {game_name}\n"
            f"📨 <b>Compte :</b> <code>{email}</code>\n"
            f"🔑 <b>Mot de passe :</b> <code>{masked_pw}</code>\n"
            f"💳 <b>Frais :</b> {cost_str} Tokens (Solde : {bal_str} 🪙)\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "📲 <i>Gardez votre téléphone déverrouillé si Google demande une confirmation.</i>"
        )
    if lang == "en":
        return (
            "🧾 <b>Order Summary & Launch</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"🚀 <b>Quest:</b> {game_name}\n"
            f"📨 <b>Account:</b> <code>{email}</code>\n"
            f"🔑 <b>Password:</b> <code>{masked_pw}</code>\n"
            f"💳 <b>Cost:</b> {cost_str} Tokens (Wallet: {bal_str} 🪙)\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "📲 <i>Keep your phone unlocked in case Google sends a confirmation prompt.</i>"
        )
    return (
        "🧾 <b>مراجعة الطلب وتأكيد التشغيل</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"🚀 <b>الصندوق:</b> {game_name}\n"
        f"📨 <b>الحساب:</b> <code>{email}</code>\n"
        f"🔑 <b>كلمة المرور:</b> <code>{masked_pw}</code>\n"
        f"💳 <b>التكلفة:</b> {cost_str} توكن (محفظتك: {bal_str} 🪙)\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "📲 <i>أبقِ هاتفك مفتوحاً تحسباً لوصول إشعار تأكيد من Google.</i>"
    )


@dp.callback_query(F.data.startswith("use_acc_"))
async def use_saved_account(callback: types.CallbackQuery, state: FSMContext):
    target = callback.data.split("use_acc_")[1]
    user_id = callback.from_user.id
    acc = None
    if target.isdigit():
        acc = db.get_saved_account_by_id(user_id, int(target))
    if not acc:
        acc = db.get_saved_account_by_email(user_id, target)
    if not acc:
        accounts = db.get_saved_accounts(user_id)
        acc = next((a for a in accounts if str(a.get("id")) == target or a.get("email") == target), None)

    if not acc or not acc.get("password"):
        await callback.answer("⚠️ Account not found!", show_alert=True)
        return

    email = acc["email"]
    pwd = acc["password"]
    data = await state.get_data()
    game_name = data.get("game_name", "Selected Quest")
    await state.update_data(email=email, password=pwd)
    await state.set_state(QuestForm.confirm_credentials)

    balance = db.get_user_balance(user_id)
    masked_pw = pwd[:4] + "••••" + pwd[-4:] if len(pwd) > 8 else pwd[:2] + "••••" + pwd[-2:]
    lang = db.get_user_language(user_id) or "ar"

    confirm_text = _format_confirm_text(lang, game_name, email, masked_pw, balance)
    await safe_show(callback, confirm_text, reply_markup=get_confirmation_keyboard(lang), prefer_edit=True)
    await callback.answer()


@dp.message(QuestForm.waiting_for_credentials)
async def process_credentials(message: types.Message, state: FSMContext):
    text = (message.text or "").strip()
    email, password = None, None

    if "---" in text:
        parts = text.split("---", 1)
        email, password = parts[0].strip(), parts[1].strip()
    elif "\n" in text:
        parts = text.split("\n", 1)
        email, password = parts[0].strip(), parts[1].strip()

    user_id = message.from_user.id
    lang = db.get_user_language(user_id) or "ar"

    if not email or not password:
        if "@" in text:
            await state.update_data(email=text.strip())
            pw_prompt = {
                "en": f"📨 <b>Account:</b> <code>{text.strip()}</code>\n\n🔑 <b>Now send the password:</b>\n🔒 <i>Encrypted during transmission.</i>",
                "fr": f"📨 <b>Compte :</b> <code>{text.strip()}</code>\n\n🔑 <b>Envoyez maintenant le mot de passe :</b>\n🔒 <i>Transmission chiffrée.</i>",
                "ar": f"📨 <b>الحساب:</b> <code>{text.strip()}</code>\n\n🔑 <b>أرسل الآن كلمة المرور في رسالة منفصلة:</b>\n🔒 <i>يتم حذف رسالتك تلقائياً بعد الاستلام.</i>",
            }.get(lang)
            await message.answer(pw_prompt, parse_mode="HTML")
            return
        data = await state.get_data()
        if data.get("email") and not data.get("password"):
            password = text.strip()
            email = data["email"]
        else:
            fmt_err = {
                "en": "⚠️ Send credentials as: <code>email---password</code>",
                "fr": "⚠️ Envoyez vos identifiants sous la forme : <code>email---password</code>",
                "ar": "⚠️ يرجى إرسال البيانات بالصيغة: <code>email---password</code>",
            }.get(lang)
            await message.answer(fmt_err, parse_mode="HTML")
            return

    try:
        await message.delete()
    except Exception:
        pass

    data = await state.get_data()
    game_name = data.get("game_name", "Selected Quest")
    await state.update_data(email=email, password=password)
    await state.set_state(QuestForm.confirm_credentials)

    balance = db.get_user_balance(user_id)
    masked_pw = password[:4] + "••••" + password[-4:] if len(password) > 8 else password[:2] + "••••" + password[-2:]
    confirm_text = _format_confirm_text(lang, game_name, email, masked_pw, balance)
    await message.answer(confirm_text, reply_markup=get_confirmation_keyboard(lang), parse_mode="HTML")


@dp.callback_query(F.data == "verification_info")
async def verification_info(callback: types.CallbackQuery):
    lang = db.get_user_language(callback.from_user.id) or "ar"
    if lang == "en":
        text = (
            "🔐 <b>How PLAYX1 ZONE Verification Works</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            "<b>1. Smart Session Login:</b>\n"
            "Saved accounts reconnect immediately using secure saved sessions without repeating security prompts.\n\n"
            "<b>2. Live Device Approval:</b>\n"
            "For new logins, approve the Google prompt on your phone when notified.\n\n"
            "<b>3. High-Security / Passkey Accounts:</b>\n"
            "Use a 16-character Google App Password for seamless authentication."
        )
    elif lang == "fr":
        text = (
            "🔐 <b>Fonctionnement de la Vérification PLAYX1 ZONE</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            "<b>1. Session Rapide :</b>\n"
            "Les comptes déjà vérifiés se reconnectent instantanément via un jeton sécurisé.\n\n"
            "<b>2. Validation Téléphone :</b>\n"
            "Pour une première connexion, confirmez simplement l'alerte Google sur votre téléphone.\n\n"
            "<b>3. Comptes Haute Sécurité / Passkey :</b>\n"
            "Utilisez un mot de passe d'application Google (16 caractères)."
        )
    else:
        text = (
            "🔐 <b>آلية التحقق والأمان في PLAYX1 ZONE</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            "<b>1. الدخول الفوري بالجلسة المحفوظة:</b>\n"
            "بعد أول تسجيل ناجح، يتم حفظ الجلسة الآمنة لتنفيذ المهام لاحقاً خلال ثوانٍ دون تكرار التأكيد.\n\n"
            "<b>2. تأكيد الهاتف المباشر:</b>\n"
            "عند تسجيل الدخول الأول، يظهر لك رقم التأكيد وتوافق عليه من هاتفك مباشرة.\n\n"
            "<b>3. حسابات الحماية العالية (Passkey / 2FA):</b>\n"
            "يمكنك استخدام كلمة مرور التطبيقات (App Password) المكونة من 16 حرفاً لتسجيل دخول فوري."
        )
    kb = InlineKeyboardBuilder()
    kb.button(text=STRINGS[lang]["home"], callback_data="nav_home", style="primary")
    await callback.message.answer(text, reply_markup=kb.as_markup(), parse_mode="HTML")
    await callback.answer()


@dp.callback_query(F.data == "pay_edit")
async def pay_edit(callback: types.CallbackQuery, state: FSMContext):
    lang = db.get_user_language(callback.from_user.id) or "ar"
    await state.set_state(QuestForm.waiting_for_credentials)
    msg = {
        "en": "📝 <b>Enter updated credentials:</b>\n<code>email---password</code>",
        "fr": "📝 <b>Envoyez les nouveaux identifiants :</b>\n<code>email---password</code>",
        "ar": "📝 <b>أرسل بيانات الحساب الجديدة:</b>\n<code>email---password</code>",
    }.get(lang)
    await safe_show(callback, msg, prefer_edit=True)
    await callback.answer()


@dp.callback_query(F.data == "pay_confirm")
async def execute_quest(callback: types.CallbackQuery, state: FSMContext):
    user_id = callback.from_user.id
    lang = db.get_user_language(user_id) or "ar"
    cost = get_chest_cost()
    balance = db.get_user_balance(user_id)

    data = await state.get_data()
    email = data.get("email")
    password = data.get("password")
    game_key = data.get("game_key", "triple_match")
    game = GAMES_CATALOG.get(game_key, GAMES_CATALOG["triple_match"])

    if not email or not password:
        await callback.answer("⚠️ Session expired! Start again.", show_alert=True)
        return

    if balance < cost:
        low_bal = {
            "en": f"⚠️ Insufficient wallet balance! You need {fmt_tok(cost)} tokens.",
            "fr": f"⚠️ Solde insuffisant ! Il vous faut {fmt_tok(cost)} tokens.",
            "ar": f"⚠️ رصيدك غير كافٍ! تحتاج إلى {fmt_tok(cost)} توكن على الأقل.",
        }.get(lang)
        await callback.answer(low_bal, show_alert=True)
        return

    db.update_balance(user_id, -cost)
    db.save_account(user_id, email, password)

    init_txt = {
        "en": "⚡ <b>Starting PLAYX1 Smart Assistant...</b>\n🔐 <i>Connecting securely to Google Services...</i>",
        "fr": "⚡ <b>Démarrage de l'Assistant PLAYX1...</b>\n🔐 <i>Connexion sécurisée aux services Google...</i>",
        "ar": "⚡ <b>جاري تجهيز المساعد الذكي PLAYX1...</b>\n🔐 <i>جاري الاتصال الآمن بحساب Google...</i>",
    }.get(lang)
    status_msg = await safe_show(callback, init_txt, prefer_edit=True)
    await callback.answer()

    ap_auth = None
    try:
        saved = db.get_master_token(user_id, email)
        if saved:
            logger.info("Trying saved master token for %s...", email)
            auth_fast = GoogleAuthenticator(email, android_id=saved["android_id"])
            st_fast, _ = auth_fast.login_with_master_token(saved["master_token"])
            if st_fast == "SUCCESS":
                fast_txt = {
                    "en": f"⚡ <b>Instant Session Restored!</b>\n📨 <code>{email}</code>\n🚀 <i>Syncing game achievements...</i>",
                    "fr": f"⚡ <b>Session Restaurée Instantanément !</b>\n📨 <code>{email}</code>\n🚀 <i>Validation des succès en cours...</i>",
                    "ar": f"⚡ <b>تم استرجاع الجلسة فوراً!</b>\n📨 <code>{email}</code>\n🚀 <i>جاري فتح إنجازات اللعبة...</i>",
                }.get(lang)
                await status_msg.edit_text(fast_txt, parse_mode="HTML")
                await _run_quest_unlocking(auth_fast, game, game_key, email, user_id, status_msg, state, cost)
                return

        ap_auth = AutoPixelAuthenticator(email, password)
        status, result = await asyncio.to_thread(ap_auth.start_auth)
        logger.info("Auth start for %s: %s", email, status)

        if status in ("NEEDS_NUMBER", "NEEDS_TAP_YES"):
            if status == "NEEDS_NUMBER":
                prompt_text = {
                    "en": (
                        "📲 <b>Phone Security Check</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                        f"👉 <b>Tap number <code>{result}</code> on your phone</b>\n\n"
                        f"<i>Approve Google's notification and pick <b>{result}</b>.</i>\n"
                        "⏳ <i>Waiting up to 2 minutes...</i>"
                    ),
                    "fr": (
                        "📲 <b>Vérification sur Téléphone</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                        f"👉 <b>Appuyez sur <code>{result}</code> sur votre appareil</b>\n\n"
                        f"<i>Acceptez la demande Google puis choisissez <b>{result}</b>.</i>\n"
                        "⏳ <i>En attente (2 minutes)...</i>"
                    ),
                    "ar": (
                        "📲 <b>تأكيد الدخول من هاتفك</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                        f"👉 <b>اضغط على الرقم <code>{result}</code> في إشعار Google</b>\n\n"
                        f"<i>اختر «نعم، إنه أنا» ثم الرقم <b>{result}</b> على شاشة هاتفك أو Gmail.</i>\n"
                        "⏳ <i>بانتظار التأكيد (دقيقتان)...</i>"
                    ),
                }.get(lang)
            else:
                prompt_text = {
                    "en": (
                        "📲 <b>Phone Security Check</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                        "👉 <b>Tap 'Yes, it's me' on your phone</b>\n\n"
                        "⏳ <i>Waiting up to 2 minutes...</i>"
                    ),
                    "fr": (
                        "📲 <b>Vérification sur Téléphone</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                        "👉 <b>Appuyez sur 'Oui, c'est moi' sur votre appareil</b>\n\n"
                        "⏳ <i>En attente (2 minutes)...</i>"
                    ),
                    "ar": (
                        "📲 <b>تأكيد الدخول من هاتفك</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                        "👉 <b>اضغط «نعم، إنه أنا» في إشعار Google على هاتفك</b>\n\n"
                        "⏳ <i>بانتظار التأكيد (دقيقتان)...</i>"
                    ),
                }.get(lang)

            await status_msg.edit_text(prompt_text, parse_mode="HTML")
            approved = await asyncio.to_thread(ap_auth.wait_for_approval, 120)
            if not approved:
                ap_auth.close()
                db.update_balance(user_id, cost)
                t_out = {
                    "en": f"⌛ <b>Approval timed out.</b> Refunded +{fmt_tok(cost)} tokens to your wallet.",
                    "fr": f"⌛ <b>Délai expiré.</b> +{fmt_tok(cost)} tokens remboursés sur votre solde.",
                    "ar": f"⌛ <b>انتهت مهلة التأكيد!</b> تم إرجاع +{fmt_tok(cost)} توكن إلى محفظتك تلقائياً.",
                }.get(lang)
                await status_msg.edit_text(t_out, reply_markup=get_main_menu(user_id, lang), parse_mode="HTML")
                await state.clear()
                return

            t_ok = {
                "en": "✅ <b>Device Approved!</b>\n🚀 <i>Preparing Google Play Games session...</i>",
                "fr": "✅ <b>Appareil Validé !</b>\n🚀 <i>Préparation de la session Google Play Jeux...</i>",
                "ar": "✅ <b>تم التأكيد بنجاح!</b>\n🚀 <i>جاري تجهيز جلسة Google Play Games...</i>",
            }.get(lang)
            await status_msg.edit_text(t_ok, parse_mode="HTML")

        elif status == "SUCCESS":
            s_ok = {
                "en": "✅ <b>Signed In!</b>\n🚀 <i>Extracting Google Play session...</i>",
                "fr": "✅ <b>Connecté !</b>\n🚀 <i>Extraction de la session Google Play...</i>",
                "ar": "✅ <b>تم تسجيل الدخول!</b>\n🚀 <i>جاري استخراج الجلسة الآمنة...</i>",
            }.get(lang)
            await status_msg.edit_text(s_ok, parse_mode="HTML")

        else:
            ap_auth.close()
            db.update_balance(user_id, cost)
            help_tip = ""
            if result and any(w in result.lower() for w in ["security key", "two-step", "app password", "verification"]):
                help_tip = (
                    "\n\n💡 <b>حل سريع لحسابات الحماية العالية (Passkey / 2FA):</b>\n"
                    "1. افتح: <a href='https://myaccount.google.com/apppasswords'>myaccount.google.com/apppasswords</a>\n"
                    "2. أنشئ <b>كلمة مرور تطبيق (App Password)</b> من 16 حرفاً.\n"
                    "3. استخدمها مع إيميلك في البوت لتسجيل دخول فوري."
                )
            await status_msg.edit_text(
                f"❌ <b>فشل تسجيل الدخول / Sign-In Failed:</b>\n\n<code>{result}</code>"
                f"{help_tip}\n\n"
                f"💳 <i>تم استرجاع التوكنات إلى محفظتك (+{fmt_tok(cost)} 🪙).</i>",
                reply_markup=get_main_menu(user_id, lang),
                parse_mode="HTML",
                disable_web_page_preview=True,
            )
            await state.clear()
            return

        tokens_ok, token_msg = await asyncio.to_thread(ap_auth.extract_tokens)
        if not tokens_ok:
            db.update_balance(user_id, cost)
            await status_msg.edit_text(
                f"❌ <b>Session Error:</b> <code>{token_msg}</code>\n\n💳 <i>Refunded +{fmt_tok(cost)} 🪙.</i>",
                reply_markup=get_main_menu(user_id, lang),
                parse_mode="HTML",
            )
            await state.clear()
            return

        if ap_auth.master_token:
            db.save_master_token(user_id, email, ap_auth.master_token, ap_auth.android_id)

        await _run_quest_unlocking(ap_auth, game, game_key, email, user_id, status_msg, state, cost)

    except Exception as e:
        logger.exception("Unexpected error during quest execution for %s: %s", email, e)
        if ap_auth:
            try:
                ap_auth.close()
            except Exception:
                pass
        db.update_balance(user_id, cost)
        try:
            await status_msg.edit_text(
                f"❌ <b>Execution Error:</b> <code>{str(e)[:150]}</code>\n\n💳 <i>Refunded +{fmt_tok(cost)} 🪙.</i>",
                reply_markup=get_main_menu(user_id, lang),
                parse_mode="HTML",
            )
        except Exception:
            pass
        await state.clear()


@dp.callback_query(F.data == "token_help")
async def token_help(callback: types.CallbackQuery):
    text = (
        "📋 <b>OAuth Token Extraction Guide</b>\n━━━━━━━━━━━━━━━━━━━━\n"
        "<b>Mobile (Chrome):</b>\n"
        "1. Open the Google login link in Chrome & sign in.\n"
        "2. Tap 'I agree' on the consent screen.\n"
        "3. Open <code>chrome://cookies</code> and locate <code>oauth_token</code>.\n"
        "4. Copy its value and send it here.\n\n"
        "<b>Desktop (Chrome / Edge):</b>\n"
        "1. Sign in via the link and click 'I agree'.\n"
        "2. Press <b>F12</b> → Application → Cookies → accounts.google.com.\n"
        "3. Copy <code>oauth_token</code> and paste it here within 2 minutes."
    )
    await callback.message.answer(text, parse_mode="HTML")
    await callback.answer()


@dp.callback_query(F.data == "cancel_token_flow")
async def cancel_token_flow(callback: types.CallbackQuery, state: FSMContext):
    user_id = callback.from_user.id
    cost = get_chest_cost()
    lang = db.get_user_language(user_id) or "ar"
    db.update_balance(user_id, cost)
    await state.clear()
    await safe_show(
        callback,
        f"✖️ <b>Process cancelled.</b>\n💳 <i>Refunded +{fmt_tok(cost)} tokens to your wallet.</i>",
        reply_markup=get_main_menu(user_id, lang),
        prefer_edit=True,
    )
    await callback.answer()


@dp.message(QuestForm.waiting_for_oauth_token)
async def process_oauth_token(message: types.Message, state: FSMContext):
    oauth_token = (message.text or "").strip()
    try:
        await message.delete()
    except Exception:
        pass

    user_id = message.from_user.id
    lang = db.get_user_language(user_id) or "ar"
    cost = get_chest_cost()

    if len(oauth_token) < 10:
        await message.answer(
            "⚠️ Invalid <code>oauth_token</code> format. Send the full value starting with <code>oauth2_4/</code> or /cancel.",
            parse_mode="HTML",
        )
        return

    data = await state.get_data()
    email = data.get("email")
    android_id = data.get("auth_android_id")
    game_key = data.get("game_key", "triple_match")
    game = GAMES_CATALOG.get(game_key, GAMES_CATALOG["triple_match"])

    status_msg = await message.answer(
        "🔄 <b>Exchanging OAuth Token...</b>\n⚡ <i>Validating with Google MTP...</i>",
        parse_mode="HTML",
    )

    auth = GoogleAuthenticator(email, android_id=android_id)
    auth_status, details = auth.login_with_token(oauth_token)
    logger.info("Token exchange for %s: status=%s", email, auth_status)

    if auth_status == "SUCCESS":
        master_token = details.get("master_token")
        if master_token:
            db.save_master_token(user_id, email, master_token, auth.android_id)

        await status_msg.edit_text(
            f"✅ <b>Account Session Verified!</b>\n📨 <code>{email}</code>\n🚀 <i>Unlocking quest achievements...</i>",
            parse_mode="HTML",
        )
        await _run_quest_unlocking(auth, game, game_key, email, user_id, status_msg, state, cost)
        return

    if auth_status == "TOKEN_INVALID":
        await status_msg.edit_text(
            "⚠️ <b>Token Invalid or Expired.</b>\nGenerate a fresh token and send it again, or send /cancel.",
            parse_mode="HTML",
        )
        return

    db.update_balance(user_id, cost)
    error_msg = details.get("error", "Unknown error")
    await status_msg.edit_text(
        f"❌ <b>Token Exchange Failed</b>\n<code>{error_msg}</code>\n\n💳 <i>Refunded +{fmt_tok(cost)} tokens.</i>",
        reply_markup=get_main_menu(user_id, lang),
        parse_mode="HTML",
    )
    await state.clear()


def _execute_single_task(unlocker: GPGSUnlocker, task: dict, package: Optional[str]) -> Tuple[str, bool]:
    title = task.get("title", "Task")
    ach_id = task.get("achievement_id")
    event_name = task.get("event_name")
    task_type = task.get("type", "")
    success = False

    if task_type in ["session", "signin"] or "sign into" in title.lower():
        success = unlocker.sign_in_game()

    if ach_id:
        steps = task.get("steps", 5)
        ach_ok = unlocker.unlock_achievement(ach_id, steps=steps)
        success = success or ach_ok

    if event_name:
        amount = task.get("amount", 1)
        prop = task.get("property_name", "amount")
        ev_ok = unlocker.record_event(package_name=package, event_name=event_name, amount=amount, property_name=prop)
        success = success or ev_ok

    return (title, success)


def _sync_unlock_all(
    email: str,
    master_token: Optional[str],
    android_id: Optional[str],
    access_token: str,
    game: dict,
) -> Tuple[Optional[dict], List[Tuple[str, bool]], bool]:
    target_token = access_token
    if game.get("package") and game.get("client_sig") and master_token and android_id:
        try:
            game_res = gpsoauth.perform_oauth(
                email,
                master_token,
                android_id,
                service="oauth2:https://www.googleapis.com/auth/games",
                app=game["package"],
                client_sig=game["client_sig"],
            )
            if "Auth" in game_res:
                target_token = game_res["Auth"]
            else:
                logger.warning("Failed to get app-scoped token: %s", game_res.get("Error"))
        except Exception as e:
            logger.warning("Error getting app-scoped GPGS token: %s", e)

    unlocker = GPGSUnlocker(target_token)
    profile = unlocker.get_player_profile()
    if unlocker.player_not_found:
        return (None, [], True)

    unlocker.sign_in_game()
    tasks = game.get("tasks", [])
    package = game.get("package")

    num_workers = max(1, min(len(tasks), 5)) if tasks else 1
    with ThreadPoolExecutor(max_workers=num_workers) as pool:
        futures = [pool.submit(_execute_single_task, unlocker, t, package) for t in tasks]
        results = [f.result() for f in futures]

    return (profile, results, False)


async def _run_quest_unlocking(
    auth: GoogleAuthenticator,
    game: dict,
    game_key: str,
    email: str,
    user_id: int,
    status_msg: types.Message,
    state: FSMContext,
    cost: Optional[float] = None,
):
    quest_cost = get_chest_cost() if cost is None else cost
    lang = db.get_user_language(user_id) or "ar"

    if not auth.access_token:
        db.update_balance(user_id, quest_cost)
        await status_msg.edit_text(
            f"❌ <b>Authentication Error:</b> Could not verify game session.\n💳 <i>Refunded +{fmt_tok(quest_cost)} tokens.</i>",
            reply_markup=get_main_menu(user_id, lang),
            parse_mode="HTML",
        )
        await state.clear()
        return

    tasks = game.get("tasks", [])
    total_tasks = len(tasks)

    sync_txt = {
        "en": f"⚡ <b>Running Quest Sync: {game['name']}</b>\n📨 <code>{email}</code>\n🚀 <i>Processing {total_tasks} tasks in parallel...</i>",
        "fr": f"⚡ <b>Synchronisation Express : {game['name']}</b>\n📨 <code>{email}</code>\n🚀 <i>Traitement parallèle de {total_tasks} tâches...</i>",
        "ar": f"⚡ <b>جاري التنفيذ المتوازي: {game['name']}</b>\n📨 <code>{email}</code>\n🚀 <i>مزامنة {total_tasks} مهام دفعة واحدة مع Google Play Games...</i>",
    }.get(lang)
    await status_msg.edit_text(sync_txt, parse_mode="HTML")

    async with QUEST_SEMAPHORE:
        loop = asyncio.get_running_loop()
        profile, unlock_results, player_not_found = await loop.run_in_executor(
            QUEST_EXECUTOR,
            _sync_unlock_all,
            email,
            auth.master_token,
            auth.android_id,
            auth.access_token,
            game,
        )

    if player_not_found:
        db.update_balance(user_id, quest_cost)
        rem = fmt_tok(db.get_user_balance(user_id))
        if lang == "en":
            pnf_text = (
                "⚠️ <b>No Play Games Gamer Profile Found</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                f"📨 <b>Account:</b> <code>{email}</code>\n\n"
                "Google API returned <code>404 Player Not Found</code>.\n\n"
                "👉 <b>Fix in 5 seconds:</b>\n"
                "1. Open <b>Google Play Games</b> on your phone with this account.\n"
                "2. Create any Gamer Tag.\n"
                "3. Come back and run the quest again.\n\n"
                f"💳 <i>Refunded +{fmt_tok(quest_cost)} tokens (Wallet: {rem} 🪙).</i>"
            )
        elif lang == "fr":
            pnf_text = (
                "⚠️ <b>Profil Google Play Jeux Manquant</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                f"📨 <b>Compte :</b> <code>{email}</code>\n\n"
                "Réponse API : <code>404 Player Not Found</code>.\n\n"
                "👉 <b>Activation rapide :</b>\n"
                "1. Ouvrez <b>Google Play Jeux</b> avec ce compte.\n"
                "2. Créez un pseudo joueur.\n"
                "3. Relancez ensuite la quête sur le bot.\n\n"
                f"💳 <i>+{fmt_tok(quest_cost)} tokens remboursés (Solde : {rem} 🪙).</i>"
            )
        else:
            pnf_text = (
                "⚠️ <b>الحساب لا يملك ملف لاعب في ألعاب Google Play</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                f"📨 <b>الحساب:</b> <code>{email}</code>\n\n"
                "استجابة Google: <code>404 Player Not Found</code>.\n\n"
                "👉 <b>التفعيل في ثوانٍ:</b>\n"
                "1. افتح تطبيق <b>ألعاب Google Play</b> على هاتفك بهذا الحساب.\n"
                "2. اختر أي اسم لاعب (Gamer Tag) لتفعيل الملف.\n"
                "3. عُد للبوت وأعد تشغيل المهمة بنجاح.\n\n"
                f"💳 <i>تم إرجاع +{fmt_tok(quest_cost)} توكن إلى محفظتك (رصيدك: {rem} 🪙).</i>"
            )
        await status_msg.edit_text(pnf_text, reply_markup=get_main_menu(user_id, lang), parse_mode="HTML")
        await state.clear()
        return

    profile_name = profile["displayName"] if profile else "Play Points Member"
    profile_level = profile["level"] if profile else 1
    raw_xp = profile.get("xp", 0) if profile else 0
    try:
        profile_xp = f"{int(raw_xp):,}"
    except (ValueError, TypeError):
        profile_xp = str(raw_xp)

    any_success = any(s for _, s in unlock_results)
    if any_success:
        db.log_quest(user_id, email, game_key, "COMPLETED")
    else:
        db.log_quest(user_id, email, game_key, "FAILED")
        db.update_balance(user_id, quest_cost)
    await state.clear()

    done_count = sum(1 for _, s in unlock_results if s)
    completed_list = "\n".join([
        f"{'🟢' if s else '🔴'} {t} — {'Unlocked' if s else 'Rejected'}"
        for t, s in unlock_results
    ])
    rem_bal = fmt_tok(db.get_user_balance(user_id))
    home_lbl = STRINGS[lang]["home"]

    claim_btn_text = {
        "ar": "🎁 افتح متجر Play واستلم النقاط",
        "fr": "🎁 Ouvrir Play Store & Réclamer",
        "en": "🎁 Open Play Store & Claim Points",
    }.get(lang)

    retry_btn_text = {
        "ar": "🚀 إنجاز صندوق آخر",
        "fr": "🚀 Lancer un Autre Coffre",
        "en": "🚀 Complete Another Quest",
    }.get(lang)

    tip_claim_text = {
        "ar": "✨ <b>اضغط على زر الاستلام أدناه لفتح الصندوق وإضافة نقاطك فوراً!</b>",
        "fr": "✨ <b>Cliquez ci-dessous pour ouvrir le coffre et récupérer vos points !</b>",
        "en": "✨ <b>Tap the button below to open your chest and collect your points!</b>",
    }.get(lang)

    if any_success:
        final_kb = InlineKeyboardMarkup(
            inline_keyboard=[
                [InlineKeyboardButton(
                    text=("✅ " if s else "⚠️ ") + t,
                    callback_data="noop",
                )] for t, s in unlock_results
            ] + [
                [InlineKeyboardButton(text=claim_btn_text, url="https://play.google.com/store/points")],
                [
                    InlineKeyboardButton(text=retry_btn_text, callback_data="nav_quests"),
                    InlineKeyboardButton(text=home_lbl, callback_data="nav_home"),
                ],
            ]
        )
        final_text = (
            f"🏆 <b>{profile_name}</b> • Lv.{profile_level} ({profile_xp} XP)\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"⚡ <b>Synced Tasks ({done_count}/{total_tasks}):</b>\n"
            f"{completed_list}\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"💳 <b>Remaining Wallet:</b> <code>{rem_bal}</code> 🪙\n\n"
            f"{tip_claim_text}"
        )
    else:
        final_kb = InlineKeyboardMarkup(
            inline_keyboard=[
                [InlineKeyboardButton(text=retry_btn_text, callback_data="nav_quests")],
                [InlineKeyboardButton(text=home_lbl, callback_data="nav_home")],
            ]
        )
        final_text = (
            "❌ <b>Achievement Sync Unsuccessful</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"🚀 <b>Game:</b> {game['name']}\n"
            f"📨 <b>Account:</b> <code>{email}</code>\n\n"
            f"{completed_list}\n\n"
            f"💳 <i>Refunded +{fmt_tok(quest_cost)} tokens (Wallet: {rem_bal} 🪙).</i>"
        )
    await status_msg.edit_text(final_text, reply_markup=final_kb, parse_mode="HTML")


@dp.callback_query(F.data == "pay_cancel", StateFilter("*"))
async def cancel_process(callback: types.CallbackQuery, state: FSMContext):
    await state.clear()
    user_id = callback.from_user.id
    lang = db.get_user_language(user_id) or "ar"
    msg = {
        "en": "✖️ <b>Action cancelled.</b>",
        "fr": "✖️ <b>Action annulée.</b>",
        "ar": "✖️ <b>تم إلغاء العملية.</b>",
    }.get(lang)
    await safe_show(callback, msg, reply_markup=get_main_menu(user_id, lang), prefer_edit=True)
    await callback.answer()


@dp.callback_query(F.data == "noop")
async def noop_handler(callback: types.CallbackQuery):
    await callback.answer()


@dp.callback_query(F.data == "nav_wallet", StateFilter("*"))
async def cb_nav_wallet(callback: types.CallbackQuery, state: FSMContext):
    await state.clear()
    user_id = callback.from_user.id
    bal_str = fmt_tok(db.get_user_balance(user_id))
    cost_str = fmt_tok(get_chest_cost())
    wcost_str = fmt_tok(get_weekly_cost_for_user(user_id))
    lang = db.get_user_language(user_id) or "ar"
    t = STRINGS.get(lang, STRINGS["ar"])

    if lang == "en":
        text = (
            "💳 <b>PLAYX1 ZONE — Your Wallet</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"🪙 <b>Available Balance:</b> <code>{bal_str}</code> Tokens\n"
            f"📦 <b>Chest Cost:</b> <code>{cost_str}</code> Tokens\n"
            f"👑 <b>Weekly Prize Cost:</b> <code>{wcost_str}</code> Tokens\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "✨ <i>Every completed chest grants 50 Google Play Points!</i>\n\n"
            "⭐ <b>Instant Telegram Stars Top-Up:</b>\n"
            "Automated delivery straight into your wallet seconds after payment."
        )
        btn_shop = "⭐ Open Stars Store"
    elif lang == "fr":
        text = (
            "💳 <b>PLAYX1 ZONE — Votre Portefeuille</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"🪙 <b>Solde Disponible :</b> <code>{bal_str}</code> Tokens\n"
            f"📦 <b>Coût du Coffre :</b> <code>{cost_str}</code> Tokens\n"
            f"👑 <b>Coût Prix Hebdo :</b> <code>{wcost_str}</code> Tokens\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "✨ <i>Chaque coffre complété rapporte 50 Google Play Points !</i>\n\n"
            "⭐ <b>Recharge Express Telegram Stars :</b>\n"
            "Livraison automatique et immédiate sur votre compte."
        )
        btn_shop = "⭐ Boutique Telegram Stars"
    else:
        text = (
            "💳 <b>محفظتي — PLAYX1 ZONE</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"🪙 <b>الرصيد المتاح:</b> <code>{bal_str}</code> توكن\n"
            f"📦 <b>تكلفة الصندوق:</b> <code>{cost_str}</code> توكن\n"
            f"👑 <b>تكلفة الجائزة الأسبوعية:</b> <code>{wcost_str}</code> توكن\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "✨ <i>كل صندوق مكتمل يمنحك 50 نقطة داخل Google Play Points!</i>\n\n"
            "⭐ <b>الشحن الفوري بنجوم تليجرام:</b>\n"
            "شحن آلي ومؤمّن يُضاف إلى محفظتك في اللحظة نفسها."
        )
        btn_shop = "⭐ الدخول لمتجر النجوم"

    builder = InlineKeyboardBuilder()
    builder.button(text=btn_shop, callback_data="stars_shop", style="success")
    builder.button(text=t["home"], callback_data="nav_home", style="primary")
    builder.adjust(1)
    await safe_show(callback, text, reply_markup=builder.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.callback_query(F.data == "stars_shop")
async def cb_stars_shop(callback: types.CallbackQuery):
    user_id = callback.from_user.id
    lang = db.get_user_language(user_id) or "ar"
    t = STRINGS.get(lang, STRINGS["ar"])

    if not db.get_setting_bool("stars_shop_enabled", True):
        await callback.answer("🔒 Stars Store is disabled by Admin.", show_alert=True)
        return

    if lang == "en":
        text = (
            "⭐ <b>PLAYX1 ZONE — Stars Token Store</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "⚡ <i>Select your package below for instant automated delivery:</i>"
        )
    elif lang == "fr":
        text = (
            "⭐ <b>PLAYX1 ZONE — Boutique Stars</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "⚡ <i>Sélectionnez votre pack pour un crédit instantané :</i>"
        )
    else:
        text = (
            "⭐ <b>متجر التوكنات — نجوم تليجرام</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "⚡ <i>اختر الباقة المناسبة لك ليتم الشحن الفوري والآمن:</i>"
        )

    builder = InlineKeyboardBuilder()
    styles = ["primary", "success"]
    for i, (tokens, stars) in enumerate(STARS_PACKS):
        builder.button(text=f"🪙 {tokens}  •  {stars} ⭐", callback_data=f"buy_stars_{tokens}_{stars}", style=styles[i % len(styles)])
    builder.adjust(2)
    nav = InlineKeyboardBuilder()
    nav.button(text=t["home"], callback_data="nav_home", style="danger")
    nav.adjust(1)
    builder.attach(nav)
    await safe_show(callback, text, reply_markup=builder.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.callback_query(F.data.startswith("buy_stars_"))
async def cb_buy_stars(callback: types.CallbackQuery):
    user_id = callback.from_user.id
    lang = db.get_user_language(user_id) or "ar"

    if not db.get_setting_bool("stars_shop_enabled", True):
        await callback.answer("🔒 Stars Store is disabled by Admin.", show_alert=True)
        return

    parts = callback.data.split("_")
    try:
        tokens = int(parts[2])
        stars = int(parts[3])
    except (IndexError, ValueError):
        await callback.answer("⚠️ Invalid package selection.", show_alert=True)
        return

    await callback.bot.send_invoice(
        chat_id=user_id,
        title=f"🪙 {tokens} PLAYX1 ZONE Tokens",
        description=f"Instant top-up of {tokens} tokens for PLAYX1 ZONE.",
        payload=f"stars_pack_{user_id}_{tokens}_{stars}",
        currency="XTR",
        prices=[LabeledPrice(label=f"{tokens} Tokens", amount=stars)],
        provider_token="",
    )
    await callback.answer()


@dp.pre_checkout_query()
async def process_pre_checkout(pre_checkout_query: PreCheckoutQuery):
    try:
        await pre_checkout_query.answer(ok=True)
    except Exception as e:
        logger.warning("pre_checkout_query answer failed: %s", e)


@dp.message(F.successful_payment)
async def process_successful_payment(message: types.Message):
    payment = message.successful_payment
    if not payment:
        return

    payload = payment.invoice_payload or ""
    parts = payload.split("_")

    payer_id = message.from_user.id if message.from_user else 0
    payer_uname = f"@{message.from_user.username}" if (message.from_user and message.from_user.username) else str(payer_id)

    if payload.startswith("srv_buy_"):
        try:
            buyer_id = int(parts[2]) if len(parts) >= 3 and parts[2].isdigit() else payer_id
            srv_id = int(parts[3]) if len(parts) >= 4 and parts[3].isdigit() else 0
            stars_paid = int(parts[4]) if len(parts) >= 5 and parts[4].isdigit() else (payment.total_amount or 1)
        except Exception:
            buyer_id, srv_id, stars_paid = payer_id, 0, (payment.total_amount or 1)

        srv = db.get_store_service_by_id(srv_id) if srv_id else None
        srv_title = srv["title"] if srv else f"Service #{srv_id}"
        is_bundle = bool(srv and int(srv.get("bundle_mode") or 0) == 1)
        extra_tok = round(float(srv.get("price_tokens") or 0), 4) if (is_bundle and srv) else 0.0
        if extra_tok > 0:
            cur_bal_b = db.get_user_balance(buyer_id)
            if cur_bal_b < extra_tok:
                # Refund stars if user lacks required bundle tokens
                try:
                    await bot.refund_star_payment(user_id=buyer_id, telegram_payment_charge_id=payment.telegram_payment_charge_id)
                except Exception:
                    pass
                await bot.send_message(
                    buyer_id,
                    f"⚠️ <b>تعذر إتمام الباقة الثنائية</b>\n━━━━━━━━━━━━━━━━━━━━\nهذا العرض يتطلب <code>{stars_paid}</code> نجمة مع خصم <code>{fmt_tok(extra_tok)}</code> توكن، ورصيدك الحالي <code>{fmt_tok(cur_bal_b)}</code> توكن. تم إرجاع النجوم تلقائياً.",
                    parse_mode="HTML"
                )
                return
        order_code = db.record_service_star_order(
            buyer_id,
            srv_id,
            srv_title,
            stars_paid,
            extra_tokens_deducted=extra_tok,
            payment_method="STARS+TOKENS" if extra_tok > 0 else "STARS",
        )
        u_lang = db.get_user_language(buyer_id) or "ar"

        if u_lang == "en":
            user_receipt = (
                "🧾 <b>Service Purchase Receipt — PLAYX1 ZONE</b>\n"
                "━━━━━━━━━━━━━━━━━━━━\n"
                f"🔢 <b>Invoice ID:</b> <code>{order_code}</code>\n"
                f"🎁 <b>Service:</b> {srv_title}\n"
                f"⭐ <b>Stars Paid:</b> <code>{stars_paid}</code> ⭐\n"
                "━━━━━━━━━━━━━━━━━━━━\n"
                "✅ <i>Your invoice has been delivered to administration. We will contact you shortly!</i>"
            )
        elif u_lang == "fr":
            user_receipt = (
                "🧾 <b>Reçu d'Achat de Service — PLAYX1 ZONE</b>\n"
                "━━━━━━━━━━━━━━━━━━━━\n"
                f"🔢 <b>Facture N° :</b> <code>{order_code}</code>\n"
                f"🎁 <b>Service :</b> {srv_title}\n"
                f"⭐ <b>Stars Payées :</b> <code>{stars_paid}</code> ⭐\n"
                "━━━━━━━━━━━━━━━━━━━━\n"
                "✅ <i>Votre commande a été transmise à l'administration. Nous vous contacterons très vite !</i>"
            )
        else:
            user_receipt = (
                "🧾 <b>فاتورة شراء خدمة — PLAYX1 ZONE</b>\n"
                "━━━━━━━━━━━━━━━━━━━━\n"
                f"🔢 <b>رقم الفاتورة:</b> <code>{order_code}</code>\n"
                f"🎁 <b>الخدمة المطلوبة:</b> {srv_title}\n"
                f"⭐ <b>المبلغ المدفوع:</b> <code>{stars_paid}</code> نجمة ⭐\n"
                "━━━━━━━━━━━━━━━━━━━━\n"
                "✅ <i>تم إرسال فاتورة طلبك إلى الإدارة بنجاح، سيتم التواصل معك قريباً لتنفيذ طلبك!</i>"
            )

        try:
            await bot.send_message(buyer_id, user_receipt, reply_markup=get_main_menu(buyer_id, u_lang), parse_mode="HTML")
        except Exception:
            await message.answer(user_receipt, reply_markup=get_main_menu(buyer_id, u_lang), parse_mode="HTML")

        full_name = message.from_user.full_name if message.from_user else str(buyer_id)
        admin_invoice = (
            "⭐🧾 <b>فاتورة طلب خدمة جديدة (دفع بالنجوم)</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"🔢 <b>رقم الفاتورة:</b> <code>{order_code}</code>\n"
            f"🎁 <b>العرض / الخدمة:</b> {srv_title}\n"
            f"⭐ <b>النجوم المستلمة:</b> <code>{stars_paid}</code> ⭐\n"
            f"👤 <b>العميل:</b> {full_name} ({payer_uname})\n"
            f"🆔 <b>معرّف العميل:</b> <code>{buyer_id}</code>"
        )
        adm_kb = InlineKeyboardBuilder()
        adm_kb.button(text="💬 مراسلة العميل عبر البوت", callback_data=f"admin_u_dm_{buyer_id}", style="success")
        adm_kb.button(text="👤 فتح ملف العميل", callback_data=f"admin_inspect_{buyer_id}", style="primary")
        adm_kb.adjust(1)
        for adm_id in ADMIN_IDS:
            try:
                await bot.send_message(adm_id, admin_invoice, reply_markup=adm_kb.as_markup(), parse_mode="HTML")
            except Exception:
                pass
        return

    user_id = payer_id
    tokens = 1
    stars = payment.total_amount or 1

    try:
        if len(parts) >= 5:
            if parts[2].isdigit():
                user_id = int(parts[2])
            tokens = int(float(parts[3]))
            stars = int(float(parts[4]))
        elif len(parts) >= 4:
            tokens = int(float(parts[2]))
            stars = int(float(parts[3]))
    except Exception as parse_err:
        logger.warning("Payload parse fallback (%s): %s", payload, parse_err)

    if tokens <= 0:
        tokens = max(1, int(stars))

    charge_id = payment.telegram_payment_charge_id or f"xtr_{user_id}_{int(time.time())}"
    db.record_star_purchase(user_id, float(tokens), int(stars), charge_id)
    new_bal_str = fmt_tok(db.get_user_balance(user_id))
    lang = db.get_user_language(user_id) or "ar"

    logger.info(
        "Stars payment credited: user_id=%s, tokens=%s, stars=%s, charge_id=%s",
        user_id, tokens, stars, charge_id
    )

    if lang == "en":
        text = (
            "🎊 <b>Top-Up Completed!</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            f"⭐ <b>Stars Paid:</b> {stars} ⭐\n"
            f"🪙 <b>Tokens Credited:</b> +{tokens} 🪙\n"
            f"💳 <b>Updated Wallet:</b> <code>{new_bal_str}</code> Tokens\n\n"
            "Thank you for choosing <b>PLAYX1 ZONE</b>!"
        )
    elif lang == "fr":
        text = (
            "🎊 <b>Recharge Validée !</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            f"⭐ <b>Stars Payées :</b> {stars} ⭐\n"
            f"🪙 <b>Tokens Ajoutés :</b> +{tokens} 🪙\n"
            f"💳 <b>Nouveau Solde :</b> <code>{new_bal_str}</code> Tokens\n\n"
            "Merci de votre confiance envers <b>PLAYX1 ZONE</b> !"
        )
    else:
        text = (
            "🎊 <b>تم الشحن بنجاح!</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            f"⭐ <b>النجوم المدفوعة:</b> {stars} ⭐\n"
            f"🪙 <b>التوكنات المضافة:</b> +{tokens} 🪙\n"
            f"💳 <b>محفظتك الآن:</b> <code>{new_bal_str}</code> توكن\n\n"
            "شكراً لثقتك بمنصة <b>PLAYX1 ZONE</b>!"
        )

    text = text.replace("\\n", "\n")
    try:
        await bot.send_message(chat_id=user_id, text=text, reply_markup=get_main_menu(user_id, lang), parse_mode="HTML")
    except Exception as e:
        logger.warning("Could not send payment confirmation via bot.send_message: %s", e)
        try:
            await message.answer(text, reply_markup=get_main_menu(user_id, lang), parse_mode="HTML")
        except Exception:
            pass

    admin_alert = (
        "⭐ <b>عملية شراء نجوم جديدة — PLAYX1 ZONE</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"👤 <b>المشتري:</b> {payer_uname} (<code>{user_id}</code>)\n"
        f"⭐ <b>النجوم المستلمة:</b> <code>{stars}</code> ⭐\n"
        f"🪙 <b>التوكنات المضافة:</b> <code>+{tokens}</code> 🪙\n"
        f"💳 <b>رصيده الحالي:</b> <code>{new_bal_str}</code> 🪙"
    ).replace("\\n", "\n")
    for adm_id in ADMIN_IDS:
        try:
            await bot.send_message(chat_id=adm_id, text=admin_alert, parse_mode="HTML")
        except Exception:
            pass


# =========================================================
# DAILY CHECK-IN HANDLERS
# =========================================================

def _build_checkin_text(user_id: int, lang: str) -> Tuple[str, bool]:
    st = db.get_checkin_status(user_id)
    bal_str = fmt_tok(st["balance"])
    streak = st["effective_streak"]
    next_day = st["next_day_num"]
    claimed_today = st["claimed_today"]
    sched = st["schedule"]
    enabled = db.get_setting_bool("checkin_enabled", True)

    if lang == "en":
        rows = []
        for idx, val in enumerate(sched, start=1):
            v_str = fmt_tok(val)
            if idx <= streak:
                badge = "✅"
            elif idx == next_day and not claimed_today and enabled:
                badge = "🎁 [Available Now!]"
            else:
                badge = "🔒"
            lbl = f"• Day {idx} 🏆 (Grand Prize)" if idx == 7 else f"• Day {idx}"
            rows.append(f"{lbl}: +{v_str} Tokens {badge}")

        dis_note = "\n⚠️ <i>Daily Check-In is currently paused by Admin.</i>" if not enabled else ""
        text = (
            "📅 <b>DAILY CHECK-IN • تسجيل الدخول اليومي</b>\n"
            "━━━━━━━━━━━━━━━━━━━━━━\n"
            f"💳 <b>Current Balance:</b> <code>{bal_str}</code> Tokens\n"
            f"🔥 <b>Current Streak:</b> <code>{streak}</code> of 7 days\n"
            "━━━━━━━━━━━━━━━━━━━━━━\n"
            "💡 <b>Reward Rules:</b>\n"
            "Check in every day to collect increasing free tokens!\n"
            "Missing a day resets streak to Day 1; completing Day 7 starts a fresh cycle from Day 1.\n\n"
            "📋 <b>Weekly Reward Schedule:</b>\n"
            + "\n".join(rows)
            + dis_note
        )
    elif lang == "fr":
        rows = []
        for idx, val in enumerate(sched, start=1):
            v_str = fmt_tok(val)
            if idx <= streak:
                badge = "✅"
            elif idx == next_day and not claimed_today and enabled:
                badge = "🎁 [Disponible !]"
            else:
                badge = "🔒"
            lbl = f"• Jour {idx} 🏆 (Grand Prix)" if idx == 7 else f"• Jour {idx}"
            rows.append(f"{lbl} : +{v_str} Tokens {badge}")

        dis_note = "\n⚠️ <i>La connexion quotidienne est suspendue par l'Admin.</i>" if not enabled else ""
        text = (
            "📅 <b>CONNEXION QUOTIDIENNE • DAILY CHECK-IN</b>\n"
            "━━━━━━━━━━━━━━━━━━━━━━\n"
            f"💳 <b>Solde Actuel :</b> <code>{bal_str}</code> Tokens\n"
            f"🔥 <b>Série Actuelle :</b> <code>{streak}</code> sur 7 jours\n"
            "━━━━━━━━━━━━━━━━━━━━━━\n"
            "💡 <b>Règles :</b>\n"
            "Connectez-vous chaque jour pour gagner des tokens croissants !\n"
            "Un jour manqué remet au Jour 1 ; le Jour 7 terminé lance un nouveau cycle.\n\n"
            "📋 <b>Tableau de la Semaine :</b>\n"
            + "\n".join(rows)
            + dis_note
        )
    else:
        rows = []
        for idx, val in enumerate(sched, start=1):
            v_str = fmt_tok(val)
            if idx <= streak:
                badge = "✅"
            elif idx == next_day and not claimed_today and enabled:
                badge = "🎁 [متاح الآن!]"
            else:
                badge = "🔒"
            lbl = f"• اليوم {idx} 🏆 (الجائزة الكبرى)" if idx == 7 else f"• اليوم {idx}"
            rows.append(f"{lbl}: +{v_str} نقطة {badge}")

        dis_note = "\n⚠️ <i>تسجيل الدخول اليومي متوقف حالياً من قبل الإدارة.</i>" if not enabled else ""
        text = (
            "📅 <b>تسجيل الدخول اليومي • DAILY CHECK-IN</b>\n"
            "━━━━━━━━━━━━━━━━━━━━━━\n"
            f"💳 <b>رصيدك الحالي:</b> <code>{bal_str}</code> نقطة\n"
            f"🔥 <b>سلسلة الأيام الحالية:</b> <code>{streak}</code> من 7 أيام\n"
            "━━━━━━━━━━━━━━━━━━━━━━\n"
            "💡 <b>قواعد المكافأة:</b>\n"
            "سجل دخولك كل يوم لتحصل على نقاط مجانية تتزايد يومياً!\n"
            "إذا فاتك تسجيل الدخول ليوم واحد يتم تصفير الأيام إلى اليوم الأول، وعند إتمام اليوم السابع تبدأ دورة جديدة من اليوم الأول.\n\n"
            "📋 <b>جدول مكافآت الأسبوع:</b>\n"
            + "\n".join(rows)
            + dis_note
        )
    can_claim = enabled and (not claimed_today)
    return text, can_claim


@dp.callback_query(F.data == "nav_checkin", StateFilter("*"))
async def cb_nav_checkin(callback: types.CallbackQuery, state: FSMContext):
    await state.clear()
    user_id = callback.from_user.id
    lang = db.get_user_language(user_id) or "ar"
    t = STRINGS.get(lang, STRINGS["ar"])
    text, can_claim = _build_checkin_text(user_id, lang)

    btn_claim_lbl = {
        "en": "🎁 Claim Today's Reward",
        "fr": "🎁 Réclamer le Bonus du Jour",
        "ar": "🎁 استلام مكافأة اليوم الآن",
    }.get(lang)
    btn_rewards_lbl = {
        "en": "🎉 More Ways to Earn",
        "fr": "🎉 Plus de Moyens de Gagner",
        "ar": "🎉 طرق ربح أخرى",
    }.get(lang)

    builder = InlineKeyboardBuilder()
    if can_claim:
        builder.button(text=btn_claim_lbl, callback_data="claim_daily_checkin", style="success")
    builder.button(text=btn_rewards_lbl, callback_data="nav_rewards", style="primary")
    builder.button(text=t["home"], callback_data="nav_home", style="danger")
    builder.adjust(1)
    await safe_show(callback, text, reply_markup=builder.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.callback_query(F.data == "claim_daily_checkin")
async def cb_claim_daily_checkin(callback: types.CallbackQuery, state: FSMContext):
    user_id = callback.from_user.id
    lang = db.get_user_language(user_id) or "ar"
    t = STRINGS.get(lang, STRINGS["ar"])
    ok, status_code, reward, new_streak, new_bal = db.perform_daily_checkin(user_id)

    if not ok:
        if status_code == "DISABLED":
            await callback.answer("🔒 Daily Check-In is disabled.", show_alert=True)
        else:
            msg_al = {
                "en": "ℹ️ You already claimed today's check-in reward! Come back tomorrow.",
                "fr": "ℹ️ Bonus du jour déjà réclamé ! Revenez demain.",
                "ar": "ℹ️ لقد استلمت مكافأة اليوم مسبقاً! عد غداً لمتابعة السلسلة.",
            }.get(lang)
            await callback.answer(msg_al, show_alert=True)
        text, can_claim = _build_checkin_text(user_id, lang)
        builder = InlineKeyboardBuilder()
        builder.button(text=t["home"], callback_data="nav_home", style="primary")
        await safe_show(callback, text, reply_markup=builder.as_markup(), prefer_edit=True)
        return

    r_str = fmt_tok(reward)
    b_str = fmt_tok(new_bal)
    alert_txt = {
        "en": f"🎉 +{r_str} Tokens claimed! Streak: {new_streak}/7",
        "fr": f"🎉 +{r_str} Tokens reçus ! Série : {new_streak}/7",
        "ar": f"🎉 تم استلام +{r_str} نقطة! السلسلة: {new_streak}/7",
    }.get(lang)
    await callback.answer(alert_txt, show_alert=True)

    text, can_claim = _build_checkin_text(user_id, lang)
    done_banner = {
        "en": f"\n━━━━━━━━━━━━━━━━━━━━━━\n✅ <b>Claimed +{r_str} Tokens!</b> 🔥 Streak: <code>{new_streak}/7</code> | 💳 Wallet: <code>{b_str}</code>",
        "fr": f"\n━━━━━━━━━━━━━━━━━━━━━━\n✅ <b>+{r_str} Tokens reçus !</b> 🔥 Série : <code>{new_streak}/7</code> | 💳 Solde : <code>{b_str}</code>",
        "ar": f"\n━━━━━━━━━━━━━━━━━━━━━━\n✅ <b>تمت إضافة +{r_str} نقطة بنجاح!</b> 🔥 السلسلة: <code>{new_streak}/7</code> | 💳 الرصيد: <code>{b_str}</code>",
    }.get(lang)
    builder = InlineKeyboardBuilder()
    builder.button(text=t["home"], callback_data="nav_home", style="primary")
    await safe_show(callback, text + done_banner, reply_markup=builder.as_markup(), prefer_edit=True)


@dp.callback_query(F.data == "nav_rewards", StateFilter("*"))
async def cb_nav_rewards(callback: types.CallbackQuery, state: FSMContext):
    await state.clear()
    user_id = callback.from_user.id
    ref_info = db.get_referral_info(user_id)
    bot_user = await bot.get_me()
    ref_link = f"https://t.me/{bot_user.username}?start=ref_{user_id}"
    lang = db.get_user_language(user_id) or "ar"
    t = STRINGS.get(lang, STRINGS["ar"])

    ref_enabled = db.get_setting_bool("referral_enabled", True)
    ref_rate_str = fmt_tok(db.get_setting_float("referral_inviter_reward", 3.0))
    ref_earned_str = fmt_tok(ref_info["tokens_earned"])

    ch_rew_enabled = db.get_setting_bool("channel_reward_enabled", True)
    all_ch_list = db.get_mandatory_channels() + db.get_promo_channels()
    active_earn_chs = [c for c in all_ch_list if int(c.get("is_active", 1)) == 1 and float(c.get("reward_tokens", 0)) > 0]
    claimed_set = {x.lower().lstrip("@") for x in db.get_user_claimed_channels(user_id)}
    unclaimed_chs = [c for c in active_earn_chs if c["channel_username"].lower().lstrip("@") not in claimed_set]
    unclaimed_total_str = fmt_tok(sum(float(c.get("reward_tokens", 0)) for c in unclaimed_chs))
    default_ch_r_str = fmt_tok(db.get_setting_float("channel_reward_default", 2.0))

    ci_st = db.get_checkin_status(user_id)
    ci_enabled = db.get_setting_bool("checkin_enabled", True)
    ci_next_reward_str = fmt_tok(ci_st["schedule"][ci_st["next_day_num"] - 1])

    if lang == "en":
        ref_sec = (
            f"<b>1. Share Link & Earn (+{ref_rate_str} 🪙 / friend):</b>\n"
            f"👥 Invited: <code>{ref_info['total_invited']}</code> | ✅ Active: <code>{ref_info['completed_invited']}</code>\n"
            f"💰 Earned: <code>{ref_earned_str}</code> Tokens\n"
            f"🔗 <code>{ref_link}</code>"
            if ref_enabled else
            "<b>1. Referral Program:</b> <i>Paused by Admin</i>"
        )
        if not ch_rew_enabled:
            ch_sec = "<b>2. Channel Rewards:</b> <i>Paused by Admin</i>"
        elif unclaimed_chs:
            ch_lines = "\n".join([f"  • {c.get('title') or c['channel_username']}: <b>+{fmt_tok(c.get('reward_tokens', 0))} 🪙</b>" for c in unclaimed_chs])
            ch_sec = f"<b>2. Earn Tokens from Channels ({len(unclaimed_chs)} available — +{unclaimed_total_str} 🪙):</b>\n{ch_lines}"
        else:
            ch_sec = "<b>2. Earn Tokens from Channels:</b> ✅ All available channel rewards claimed!"

        ci_sec = (
            f"<b>3. Daily Check-In (Streak {ci_st['effective_streak']}/7):</b>\n"
            + (f"• Today's reward: <b>+{ci_next_reward_str} Tokens</b> {'✅ Claimed' if ci_st['claimed_today'] else '🎁 Ready!'}" if ci_enabled else "• <i>Paused by Admin</i>")
        )
        text = (
            "🎉 <b>PLAYX1 ZONE — Earn & Bonus Center</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            f"{ref_sec}\n━━━━━━━━━━━━━━━━━━━━\n"
            f"{ch_sec}\n━━━━━━━━━━━━━━━━━━━━\n"
            f"{ci_sec}\n━━━━━━━━━━━━━━━━━━━━\n"
            "<b>4. Gift Codes:</b>\n"
            "• Activate exclusive codes posted on @PLAYX1_ZONE!"
        )
        btn_share = "📤 Share Invite Link"
        btn_claim = f"🎁 Claim Channel Rewards (+{unclaimed_total_str} 🪙)"
        btn_checkin_b = "📅 Daily Check-In"
        btn_promo = "🎫 Activate Gift Code"
        partner_hdr = "\n━━━━━━━━━━━━━━━━━━━━\n🌟 <b>Featured Partner Channels:</b>"
        share_msg = "Join PLAYX1 ZONE Bot for free Google Play Points tokens!"
    elif lang == "fr":
        ref_sec = (
            f"<b>1. Parrainage (+{ref_rate_str} 🪙 / ami) :</b>\n"
            f"👥 Invités : <code>{ref_info['total_invited']}</code> | ✅ Validés : <code>{ref_info['completed_invited']}</code>\n"
            f"💰 Gagnés : <code>{ref_earned_str}</code> Tokens\n"
            f"🔗 <code>{ref_link}</code>"
            if ref_enabled else
            "<b>1. Parrainage :</b> <i>En pause</i>"
        )
        if not ch_rew_enabled:
            ch_sec = "<b>2. Gains par Chaînes :</b> <i>En pause</i>"
        elif unclaimed_chs:
            ch_lines = "\n".join([f"  • {c.get('title') or c['channel_username']} : <b>+{fmt_tok(c.get('reward_tokens', 0))} 🪙</b>" for c in unclaimed_chs])
            ch_sec = f"<b>2. Gagner par Chaînes ({len(unclaimed_chs)} dispo — +{unclaimed_total_str} 🪙) :</b>\n{ch_lines}"
        else:
            ch_sec = "<b>2. Gagner par Chaînes :</b> ✅ Toutes les chaînes réclamées !"

        ci_sec = (
            f"<b>3. Connexion Quotidienne (Série {ci_st['effective_streak']}/7) :</b>\n"
            + (f"• Gain du jour : <b>+{ci_next_reward_str} Tokens</b> {'✅ Réclamé' if ci_st['claimed_today'] else '🎁 Prêt !'}" if ci_enabled else "• <i>En pause</i>")
        )
        text = (
            "🎉 <b>PLAYX1 ZONE — Centre Cadeaux & Gains</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            f"{ref_sec}\n━━━━━━━━━━━━━━━━━━━━\n"
            f"{ch_sec}\n━━━━━━━━━━━━━━━━━━━━\n"
            f"{ci_sec}\n━━━━━━━━━━━━━━━━━━━━\n"
            "<b>4. Codes Cadeaux :</b>\n"
            "• Utilisez les codes exclusifs publiés sur @PLAYX1_ZONE !"
        )
        btn_share = "📤 Partager mon Lien"
        btn_claim = f"🎁 Réclamer Chaînes (+{unclaimed_total_str} 🪙)"
        btn_checkin_b = "📅 Connexion Quotidienne"
        btn_promo = "🎫 Activer un Code Cadeau"
        partner_hdr = "\n━━━━━━━━━━━━━━━━━━━━\n🌟 <b>Chaînes Partenaires :</b>"
        share_msg = "Rejoignez le bot PLAYX1 ZONE pour gagner des tokens Google Play Points!"
    else:
        ref_sec = (
            f"<b>1. الربح من مشاركة الرابط (+{ref_rate_str} 🪙 لكل صديق):</b>\n"
            f"👥 المدعوون: <code>{ref_info['total_invited']}</code> | ✅ المؤكدون: <code>{ref_info['completed_invited']}</code>\n"
            f"💰 أرباحك: <code>{ref_earned_str}</code> توكن\n"
            f"🔗 <code>{ref_link}</code>"
            if ref_enabled else
            "<b>1. برنامج الإحالة:</b> <i>متوقف مؤقتاً من قبل الإدارة</i>"
        )
        if not ch_rew_enabled:
            ch_sec = "<b>2. الربح من الاشتراك في القنوات:</b> <i>متوقف مؤقتاً من قبل الإدارة</i>"
        elif unclaimed_chs:
            ch_lines = "\n".join([f"  • {c.get('title') or c['channel_username']}: <b>+{fmt_tok(c.get('reward_tokens', default_ch_r_str))} 🪙</b>" for c in unclaimed_chs])
            ch_sec = f"<b>2. الربح من الاشتراك في القنوات ({len(unclaimed_chs)} متاحة — +{unclaimed_total_str} 🪙):</b>\n{ch_lines}"
        else:
            ch_sec = "<b>2. الربح من الاشتراك في القنوات:</b> ✅ تم استلام مكافآت جميع القنوات المتاحة!"

        ci_sec = (
            f"<b>3. تسجيل الدخول اليومي (السلسلة {ci_st['effective_streak']}/7):</b>\n"
            + (f"• مكافأة اليوم: <b>+{ci_next_reward_str} نقطة</b> {'✅ مستلمة' if ci_st['claimed_today'] else '🎁 متاحة الآن!'}" if ci_enabled else "• <i>متوقف مؤقتاً من قبل الإدارة</i>")
        )
        text = (
            "🎉 <b>مركز الهدايا والربح — PLAYX1 ZONE</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            f"{ref_sec}\n━━━━━━━━━━━━━━━━━━━━\n"
            f"{ch_sec}\n━━━━━━━━━━━━━━━━━━━━\n"
            f"{ci_sec}\n━━━━━━━━━━━━━━━━━━━━\n"
            "<b>4. أكواد الهدايا الحصرية:</b>\n"
            "• فعّل الأكواد التي نوزعها باستمرار في قناة @PLAYX1_ZONE!"
        )
        btn_share = "📤 مشاركة رابط الإحالة"
        btn_claim = f"🎁 استلام مكافأة القنوات (+{unclaimed_total_str} 🪙)"
        btn_checkin_b = "📅 تسجيل الدخول اليومي"
        btn_promo = "🎫 تفعيل كود هدية"
        partner_hdr = "\n━━━━━━━━━━━━━━━━━━━━\n🌟 <b>قنوات شريكة ومميزة:</b>"
        share_msg = "انضم لبوت PLAYX1 ZONE لإنجاز مهام Google Play Points مجاناً!"

    builder = InlineKeyboardBuilder()
    if ref_enabled:
        builder.button(
            text=btn_share,
            url=f"https://t.me/share/url?url={ref_link}&text={share_msg.replace(' ', '%20')}",
            style="primary",
        )
    if ch_rew_enabled and unclaimed_chs:
        builder.button(text=btn_claim, callback_data="claim_channel_bonus", style="success")
    builder.button(text=btn_checkin_b, callback_data="nav_checkin", style="success")
    builder.button(text=btn_promo, callback_data="user_enter_promo", style="primary")

    promo_channels = db.get_promo_channels()
    if promo_channels:
        text += partner_hdr
        styles = ["primary", "success"]
        for i, pch in enumerate(promo_channels):
            raw_title = pch.get("title") or pch.get("channel_username") or ""
            clean_title = raw_title.strip().lstrip("@").strip() or pch.get("channel_username", "").lstrip("@").strip()
            r_tok = fmt_tok(pch.get("reward_tokens", 0))
            r_tag = f" (+{r_tok} 🪙)" if float(pch.get("reward_tokens", 0)) > 0 and int(pch.get("is_active", 1)) == 1 else ""
            builder.button(text=f"🌟 {clean_title}{r_tag}", url=pch["invite_link"], style=styles[i % len(styles)])

    builder.button(text=t["home"], callback_data="nav_home", style="danger")
    builder.adjust(1)
    await safe_show(callback, text, reply_markup=builder.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.callback_query(F.data == "claim_channel_bonus")
async def cb_claim_channel_bonus(callback: types.CallbackQuery, state: FSMContext):
    user_id = callback.from_user.id
    lang = db.get_user_language(user_id) or "ar"

    if not db.get_setting_bool("channel_reward_enabled", True):
        await callback.answer("🔒 Channel rewards are disabled by Admin.", show_alert=True)
        return

    all_chs = db.get_mandatory_channels() + db.get_promo_channels()
    active_chs = [c for c in all_chs if int(c.get("is_active", 1)) == 1 and float(c.get("reward_tokens", 0)) > 0]
    claimed_set = {x.lower().lstrip("@") for x in db.get_user_claimed_channels(user_id)}
    pending_chs = [c for c in active_chs if c["channel_username"].lower().lstrip("@") not in claimed_set]

    if not pending_chs:
        already = "ℹ️ All channel rewards already collected!" if lang == "en" else ("ℹ️ Récompenses déjà récupérées !" if lang == "fr" else "ℹ️ لقد استلمت مكافآت جميع القنوات المتاحة مسبقاً!")
        await callback.answer(already, show_alert=True)
        return

    verify_live = db.get_setting_bool("channel_verify_live", True)
    verified_chs = []
    unverified_chs = []
    for ch_obj in pending_chs:
        uname = ch_obj["channel_username"]
        if verify_live:
            ok = await check_single_channel_membership(bot, uname, user_id)
            if ok:
                verified_chs.append(ch_obj)
            else:
                unverified_chs.append(ch_obj)
        else:
            verified_chs.append(ch_obj)

    if not verified_chs:
        err = "🔒 Join the reward channels first, then tap Claim!" if lang == "en" else ("🔒 Rejoignez d'abord les chaînes !" if lang == "fr" else "🔒 يرجى الاشتراك في القنوات أولاً ثم الضغط على الاستلام!")
        await callback.answer(err, show_alert=True)
        return

    awarded, count = db.claim_channel_bonus_per_channel(user_id, verified_chs, reward_per_channel=db.get_setting_float("channel_reward_default", 2.0))
    if awarded > 0:
        a_str = fmt_tok(awarded)
        b_str = fmt_tok(db.get_user_balance(user_id))
        miss_note = ""
        if unverified_chs:
            miss_list = ", ".join([c["channel_username"] for c in unverified_chs])
            miss_note = f"\n⚠️ <i>Not yet joined: {miss_list}</i>" if lang == "en" else f"\n⚠️ <i>لم يتم رصد اشتراكك بعد في: {miss_list}</i>"

        if lang == "en":
            succ = f"🎉 +{a_str} Tokens added ({count} channels)!"
            msg = f"✅ Credited <b>+{a_str} Tokens</b> across <b>{count}</b> channel(s)! Wallet: <code>{b_str}</code> 🪙{miss_note}"
        elif lang == "fr":
            succ = f"🎉 +{a_str} Tokens ajoutés ({count} chaînes) !"
            msg = f"✅ <b>+{a_str} Tokens</b> crédités ({count} chaîne(s)) ! Solde : <code>{b_str}</code> 🪙{miss_note}"
        else:
            succ = f"🎉 تمت إضافة +{a_str} توكن ({count} قناة)!"
            msg = f"✅ تم شحن <b>+{a_str} توكن</b> مقابل <b>{count}</b> قناة! رصيدك: <code>{b_str}</code> 🪙{miss_note}"
        await callback.answer(succ, show_alert=True)
        await callback.message.answer(msg, reply_markup=get_main_menu(user_id, lang), parse_mode="HTML")
    else:
        already = "ℹ️ Channel bonus already collected!" if lang == "en" else ("ℹ️ Bonus déjà récupéré !" if lang == "fr" else "ℹ️ لقد استلمت مكافأة القنوات مسبقاً!")
        await callback.answer(already, show_alert=True)


@dp.callback_query(F.data == "user_enter_promo")
async def cb_user_enter_promo(callback: types.CallbackQuery, state: FSMContext):
    user_id = callback.from_user.id
    lang = db.get_user_language(user_id) or "ar"
    t = STRINGS.get(lang, STRINGS["ar"])
    if not db.get_setting_bool("promo_codes_enabled", True):
        await callback.answer("🔒 Gift codes are currently disabled.", show_alert=True)
        return
    await state.set_state(UserForm.waiting_for_promo_code)

    text = {
        "en": "🎫 <b>Activate Gift Code</b>\n━━━━━━━━━━━━━━━━━━━━\nSend your gift code below to claim free tokens:",
        "fr": "🎫 <b>Activer un Code Cadeau</b>\n━━━━━━━━━━━━━━━━━━━━\nEnvoyez votre code ci-dessous pour recevoir vos tokens :",
        "ar": "🎫 <b>تفعيل كود هدية</b>\n━━━━━━━━━━━━━━━━━━━━\nأرسل الكود الترويجي الآن لاستلام التوكنات فوراً:",
    }.get(lang)
    builder = InlineKeyboardBuilder()
    builder.button(text=t["cancel"], callback_data="pay_cancel", style="danger")
    await safe_show(callback, text, reply_markup=builder.as_markup(), prefer_edit=True)
    await callback.answer()


async def _handle_promo_redemption(message: types.Message, code_text: str):
    user_id = message.from_user.id
    lang = db.get_user_language(user_id) or "ar"
    success, status, reward = db.redeem_promo_code(user_id, code_text)
    if success:
        r_str = fmt_tok(reward)
        b_str = fmt_tok(db.get_user_balance(user_id))
        ok_msg = {
            "en": f"🎊 <b>Gift Code Activated!</b>\n━━━━━━━━━━━━━━━━━━━━\n🎫 <b>Code:</b> <code>{code_text}</code>\n🪙 <b>Reward:</b> +{r_str} Tokens\n💳 <b>Wallet:</b> <code>{b_str}</code> 🪙",
            "fr": f"🎊 <b>Code Cadeau Activé !</b>\n━━━━━━━━━━━━━━━━━━━━\n🎫 <b>Code :</b> <code>{code_text}</code>\n🪙 <b>Gain :</b> +{r_str} Tokens\n💳 <b>Solde :</b> <code>{b_str}</code> 🪙",
            "ar": f"🎊 <b>تم تفعيل كود الهدية بنجاح!</b>\n━━━━━━━━━━━━━━━━━━━━\n🎫 <b>الكود:</b> <code>{code_text}</code>\n🪙 <b>المكافأة:</b> +{r_str} توكن\n💳 <b>محفظتك الآن:</b> <code>{b_str}</code> 🪙",
        }.get(lang)
        await message.answer(ok_msg, reply_markup=get_main_menu(user_id, lang), parse_mode="HTML")
        return

    err_map = {
        "DISABLED": {
            "en": "🔒 <b>Gift codes are currently disabled by Admin.</b>",
            "fr": "🔒 <b>Les codes cadeaux sont désactivés.</b>",
            "ar": "🔒 <b>أكواد الهدايا متوقفة حالياً من قبل الإدارة.</b>",
        },
        "NOT_FOUND": {
            "en": "❌ <b>Invalid gift code!</b>",
            "fr": "❌ <b>Code cadeau introuvable !</b>",
            "ar": "❌ <b>الكود غير صحيح أو غير موجود!</b>",
        },
        "EXPIRED": {
            "en": "⌛ <b>This gift code has reached its redemption limit.</b>",
            "fr": "⌛ <b>Ce code cadeau a atteint sa limite d'utilisation.</b>",
            "ar": "⌛ <b>انتهت صلاحية هذا الكود أو اكتمل الحد الأقصى للمستفيدين.</b>",
        },
        "ALREADY_USED": {
            "en": "⚠️ <b>You already redeemed this gift code!</b>",
            "fr": "⚠️ <b>Vous avez déjà utilisé ce code cadeau !</b>",
            "ar": "⚠️ <b>لقد استخدمت هذا الكود مسبقاً!</b>",
        },
    }
    err_txt = err_map.get(status, {}).get(lang, "❌ <b>Error redeeming code.</b>")
    await message.answer(err_txt, reply_markup=get_main_menu(user_id, lang), parse_mode="HTML")


@dp.message(UserForm.waiting_for_promo_code)
async def process_user_promo_code(message: types.Message, state: FSMContext):
    await state.clear()
    await _handle_promo_redemption(message, (message.text or "").strip().upper())


@dp.message(Command("promo"), StateFilter("*"))
@dp.message(Command("redeem"), StateFilter("*"))
async def cmd_promo(message: types.Message, state: FSMContext, command: Optional[CommandObject] = None):
    lang = db.get_user_language(message.from_user.id) or "ar"
    if command and command.args:
        await state.clear()
        await _handle_promo_redemption(message, command.args.strip().upper())
    else:
        await state.set_state(UserForm.waiting_for_promo_code)
        builder = InlineKeyboardBuilder()
        builder.button(text=STRINGS[lang]["cancel"], callback_data="pay_cancel", style="danger")
        prompt = {
            "en": "🎫 <b>Activate Gift Code</b>\nSend your code now (or use <code>/promo CODE</code>):",
            "fr": "🎫 <b>Activer un Code Cadeau</b>\nEnvoyez votre code (ou utilisez <code>/promo CODE</code>) :",
            "ar": "🎫 <b>تفعيل كود هدية</b>\nأرسل الكود الآن (أو استخدم <code>/promo CODE</code>):",
        }.get(lang)
        await message.answer(prompt, reply_markup=builder.as_markup(), parse_mode="HTML")


@dp.callback_query(F.data == "nav_top", StateFilter("*"))
async def cb_nav_top(callback: types.CallbackQuery, state: FSMContext):
    await state.clear()
    user_id = callback.from_user.id
    lang = db.get_user_language(user_id) or "ar"
    t = STRINGS.get(lang, STRINGS["ar"])
    top_buyers = db.get_top_buyers(10)

    medals = ["🥇", "🥈", "🥉", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣", "🔟"]
    prizes = ["50 🪙", "30 🪙", "20 🪙"] + ["10 🪙"] * 7
    empty_lbl = {"en": "Open slot", "fr": "Place libre", "ar": "مقعد متاح"}.get(lang)

    board_lines = []
    for idx in range(10):
        if idx < len(top_buyers):
            u = top_buyers[idx]
            uname = f"@{u['username']}" if u.get("username") else f"ID {str(u['user_id'])[:4]}***"
            board_lines.append(f"{medals[idx]} <b>{uname}</b> • {fmt_tok(u['tokens_purchased'])} 🪙 ({u['stars_spent']} ⭐) [{prizes[idx]}]")
        else:
            board_lines.append(f"{medals[idx]} <i>{empty_lbl}</i> [{prizes[idx]}]")

    if lang == "en":
        text = (
            "🥇 <b>PLAYX1 ZONE — Top Supporters</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            + "\n".join(board_lines)
            + "\n━━━━━━━━━━━━━━━━━━━━\n"
            "🎁 <b>Weekly Supporter Rewards:</b>\n"
            "• 🥇 #1: 50 Tokens | 🥈 #2: 30 Tokens | 🥉 #3: 20 Tokens\n"
            "• #4 to #10: 10 Tokens each"
        )
        btn_shop = "⭐ Top-Up & Climb the Ranks"
    elif lang == "fr":
        text = (
            "🥇 <b>PLAYX1 ZONE — Top Membres</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            + "\n".join(board_lines)
            + "\n━━━━━━━━━━━━━━━━━━━━\n"
            "🎁 <b>Récompenses Hebdomadaires :</b>\n"
            "• 🥇 1er : 50 Tokens | 🥈 2e : 30 Tokens | 🥉 3e : 20 Tokens\n"
            "• 4e au 10e : 10 Tokens chacun"
        )
        btn_shop = "⭐ Recharger & Monter au Classement"
    else:
        text = (
            "🥇 <b>نخبة الداعمين — PLAYX1 ZONE</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            + "\n".join(board_lines)
            + "\n━━━━━━━━━━━━━━━━━━━━\n"
            "🎁 <b>جوائز الصدارة الأسبوعية:</b>\n"
            "• 🥇 الأول: 50 توكن | 🥈 الثاني: 30 توكن | 🥉 الثالث: 20 توكن\n"
            "• المراكز 4 إلى 10: 10 توكن لكل متصدر"
        )
        btn_shop = "⭐ اشحن وتصدّر القائمة الآن"

    builder = InlineKeyboardBuilder()
    builder.button(text=btn_shop, callback_data="stars_shop", style="success")
    builder.button(text=t["home"], callback_data="nav_home", style="primary")
    builder.adjust(1)
    await safe_show(callback, text, reply_markup=builder.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.callback_query(F.data == "nav_lang", StateFilter("*"))
async def cb_nav_lang(callback: types.CallbackQuery, state: FSMContext):
    await state.clear()
    lang = db.get_user_language(callback.from_user.id) or "ar"
    text = (
        "🌐 <b>Language Settings / إعدادات اللغة / Langue</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "Choose your preferred interface language:"
    )
    builder = InlineKeyboardBuilder()
    builder.button(text="🇩🇿 العربية", callback_data="set_lang_ar", style="success" if lang == "ar" else "primary")
    builder.button(text="🇬🇧 English", callback_data="set_lang_en", style="success" if lang == "en" else "primary")
    builder.button(text="🇫🇷 Français", callback_data="set_lang_fr", style="success" if lang == "fr" else "primary")
    builder.button(text=STRINGS[lang]["home"], callback_data="nav_home", style="danger")
    builder.adjust(1)
    await safe_show(callback, text, reply_markup=builder.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.callback_query(F.data.startswith("set_lang_"))
async def process_set_language(callback: types.CallbackQuery):
    lang = callback.data.split("set_lang_")[1]
    if lang not in STRINGS:
        lang = "ar"
    user_id = callback.from_user.id
    db.set_user_language(user_id, lang)

    msg_map = {
        "ar": "✅ تم تفعيل اللغة العربية بنجاح!",
        "en": "✅ Interface language switched to English!",
        "fr": "✅ Langue de l'interface définie sur Français !",
    }
    await callback.answer(msg_map[lang], show_alert=False)
    await safe_show(
        callback,
        _welcome_text_for(user_id, lang),
        reply_markup=get_main_menu(user_id, lang),
        prefer_edit=True,
    )




@dp.callback_query(F.data == "nav_profile", StateFilter("*"))
async def cb_nav_profile(callback: types.CallbackQuery, state: FSMContext):
    await state.clear()
    user = callback.from_user
    user_id = user.id
    lang = db.get_user_language(user_id) or "ar"
    t = STRINGS.get(lang, STRINGS["ar"])

    u_rec = db.get_or_create_user(user_id, user.username)
    bal_str = fmt_tok(u_rec.get("balance", 0))
    ref_info = db.get_referral_info(user_id)
    ref_count = int(ref_info.get("completed_invited", 0))
    ref_earned_str = fmt_tok(ref_info.get("tokens_earned", 0))
    quests_done = db.get_user_quests_count(user_id)
    saved_emails = db.count_saved_accounts(user_id)
    active_sessions = db.count_active_sessions(user_id)
    total_xp_earned = quests_done * 50
    streak_days = int(u_rec.get("checkin_streak") or 0)
    stars_used = int(u_rec.get("stars_spent") or 0)
    joined_date = str(u_rec.get("created_at") or "")[:10]

    full_name = (user.full_name or "").strip() or (u_rec.get("username") or "Member")
    uname_display = f"@{user.username}" if user.username else (f"@{u_rec['username']}" if u_rec.get("username") else "—")

    if lang == "en":
        text = (
            "🪪 <b>PLAYER ACCOUNT OVERVIEW • PLAYX1 ZONE</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"👤 <b>Display Name:</b> {full_name}\n"
            f"🆔 <b>Account ID:</b> <code>{user_id}</code>\n"
            f"🔖 <b>Handle:</b> {uname_display}\n"
            f"📅 <b>Member Since:</b> <code>{joined_date}</code>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"💳 <b>Wallet Balance:</b> <code>{bal_str}</code> Tokens\n"
            f"⭐ <b>Stars Invested:</b> <code>{stars_used}</code> Stars\n"
            f"🔥 <b>Daily Streak:</b> <code>{streak_days}/7</code> Days\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"🏆 <b>Estimated Play XP:</b> <code>+{total_xp_earned:,}</code> XP\n"
            f"🚀 <b>Chests Completed:</b> <code>{quests_done}</code>\n"
            f"🤝 <b>Verified Referrals:</b> <code>{ref_count}</code> (+{ref_earned_str} 🪙)\n"
            f"📧 <b>Saved Accounts:</b> <code>{saved_emails}</code>\n"
            f"⚡ <b>Ready Sessions:</b> <code>{active_sessions}</code>"
        )
        btn_wallet = "💳 Wallet & Top-Up"
        btn_rewards = "🎉 Earn & Bonus Center"
    elif lang == "fr":
        text = (
            "🪪 <b>APERÇU DU COMPTE JOUEUR • PLAYX1 ZONE</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"👤 <b>Nom Affiché :</b> {full_name}\n"
            f"🆔 <b>Identifiant :</b> <code>{user_id}</code>\n"
            f"🔖 <b>Pseudo :</b> {uname_display}\n"
            f"📅 <b>Inscrit le :</b> <code>{joined_date}</code>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"💳 <b>Solde Tokens :</b> <code>{bal_str}</code> Tokens\n"
            f"⭐ <b>Stars Utilisées :</b> <code>{stars_used}</code> Stars\n"
            f"🔥 <b>Série Quotidienne :</b> <code>{streak_days}/7</code> Jours\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"🏆 <b>XP Estimée :</b> <code>+{total_xp_earned:,}</code> XP\n"
            f"🚀 <b>Coffres Validés :</b> <code>{quests_done}</code>\n"
            f"🤝 <b>Parrainages Validés :</b> <code>{ref_count}</code> (+{ref_earned_str} 🪙)\n"
            f"📧 <b>Comptes Enregistrés :</b> <code>{saved_emails}</code>\n"
            f"⚡ <b>Sessions Actives :</b> <code>{active_sessions}</code>"
        )
        btn_wallet = "💳 Solde & Recharge"
        btn_rewards = "🎉 Centre Cadeaux & Gains"
    else:
        text = (
            "🪪 <b>ملفك الشخصي وحالة الحساب • PLAYX1 ZONE</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"👤 <b>الاسم الكامل:</b> {full_name}\n"
            f"🆔 <b>رقم المعرّف:</b> <code>{user_id}</code>\n"
            f"🔖 <b>اسم المستخدم:</b> {uname_display}\n"
            f"📅 <b>تاريخ الانضمام:</b> <code>{joined_date}</code>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"💳 <b>رصيد التوكن:</b> <code>{bal_str}</code> توكن\n"
            f"⭐ <b>النجوم المستثمرة:</b> <code>{stars_used}</code> نجمة\n"
            f"🔥 <b>سلسلة الدخول اليومي:</b> <code>{streak_days}/7</code> أيام\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"🏆 <b>نقاط الخبرة التقديرية:</b> <code>+{total_xp_earned:,}</code> XP\n"
            f"🚀 <b>الصناديق المنجزة:</b> <code>{quests_done}</code>\n"
            f"🤝 <b>الدعوات المؤكدة:</b> <code>{ref_count}</code> (+{ref_earned_str} 🪙)\n"
            f"📧 <b>الحسابات المحفوظة:</b> <code>{saved_emails}</code>\n"
            f"⚡ <b>الجلسات الجاهزة:</b> <code>{active_sessions}</code>"
        )
        btn_wallet = "💳 محفظتي والشحن"
        btn_rewards = "🎉 مركز الهدايا والربح"

    builder = InlineKeyboardBuilder()
    builder.button(text=btn_wallet, callback_data="nav_wallet", style="primary")
    builder.button(text=btn_rewards, callback_data="nav_rewards", style="success")
    builder.button(text=t["home"], callback_data="nav_home", style="danger")
    builder.adjust(2, 1)
    await safe_show(callback, text, reply_markup=builder.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.callback_query(F.data == "nav_guide", StateFilter("*"))
async def cb_nav_guide(callback: types.CallbackQuery, state: FSMContext):
    await state.clear()
    lang = db.get_user_language(callback.from_user.id) or "ar"
    t = STRINGS.get(lang, STRINGS["ar"])
    if lang == "en":
        text = (
            "📘 <b>PLAYX1 ZONE — Quick Guide</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            "<b>⚡ Steps to Complete a Quest:</b>\n"
            "1. Open Google Play Store → Play Points → Earn.\n"
            "2. Confirm the chest quest is visible on your account.\n"
            "3. Tap <b>🚀 Quest Vault</b> and select the game.\n"
            "4. Send your credentials (or pick a saved account) & launch.\n"
            "5. Open Play Store and collect your 50 Play Points!\n\n"
            "<b>🎁 Free Earning Methods:</b>\n"
            "• 📅 Daily Check-In (7-day streak up to +1 Token/day)\n"
            "• 🤝 Referral Link sharing & Channel Subscriptions & Gift Codes\n\n"
            f"📡 <b>Official Channel:</b> {CHANNEL_URL}"
        )
    elif lang == "fr":
        text = (
            "📘 <b>PLAYX1 ZONE — Guide Rapide</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            "<b>⚡ Étapes de Validation :</b>\n"
            "1. Ouvrez Google Play Store → Play Points → Gagner.\n"
            "2. Vérifiez que la quête du coffre est affichée.\n"
            "3. Appuyez sur <b>🚀 Coffres & Quêtes</b> et choisissez le jeu.\n"
            "4. Entrez vos identifiants (ou choisissez un compte sauvegardé).\n"
            "5. Ouvrez le Play Store pour récupérer vos 50 Play Points !\n\n"
            "<b>🎁 Moyens Gratuits de Gagner :</b>\n"
            "• 📅 Connexion Quotidienne (série de 7 jours)\n"
            "• 🤝 Parrainage, Abonnements Chaînes & Codes Cadeaux\n\n"
            f"📡 <b>Chaîne Officielle :</b> {CHANNEL_URL}"
        )
    else:
        text = (
            "📘 <b>دليل الاستخدام السريع — PLAYX1 ZONE</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            "<b>⚡ خطوات إنهاء أي صندوق:</b>\n"
            "1. افتح متجر Google Play ← نقاط Play ← كسب (Earn).\n"
            "2. تأكد من ظهور مهمة الصندوق على حسابك.\n"
            "3. اضغط <b>🚀 فتح الصناديق</b> واختر اللعبة المطلوبة.\n"
            "4. أرسل بيانات الحساب (أو اختر حساباً محفوظاً) واضغط تأكيد.\n"
            "5. افتح المتجر لاستلام 50 نقطة مباشرة في حسابك!\n\n"
            "<b>🎁 طرق الربح المجانية للتوكن / النقاط:</b>\n"
            "• 📅 تسجيل الدخول اليومي المتسلسل (7 أيام)\n"
            "• 🤝 مشاركة رابط الإحالة، الاشتراك بالقنوات، وأكواد الهدايا\n\n"
            f"📡 <b>قناتنا الرسمية:</b> {CHANNEL_URL}"
        )
    builder = InlineKeyboardBuilder()
    builder.button(text=t["channel"], url=CHANNEL_URL, style="success")
    builder.button(text=t["home"], callback_data="nav_home", style="primary")
    builder.adjust(1)
    await safe_show(callback, text, reply_markup=builder.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.message(Command("admin"), StateFilter("*"))
async def admin_panel(message: types.Message, state: FSMContext):
    if message.from_user.id not in ADMIN_IDS:
        return
    await state.clear()
    alang = get_admin_lang()
    await message.answer(get_admin_panel_text(alang), reply_markup=get_admin_menu_keyboard(alang), parse_mode="HTML")


@dp.callback_query(F.data == "admin_menu", StateFilter("*"))
async def cb_admin_menu(callback: types.CallbackQuery, state: FSMContext):
    if callback.from_user.id not in ADMIN_IDS:
        return
    await state.clear()
    alang = get_admin_lang()
    await safe_show(callback, get_admin_panel_text(alang), reply_markup=get_admin_menu_keyboard(alang), prefer_edit=True)
    await callback.answer()


@dp.callback_query(F.data == "admin_close", StateFilter("*"))
async def cb_admin_close(callback: types.CallbackQuery, state: FSMContext):
    if callback.from_user.id not in ADMIN_IDS:
        return
    await state.clear()
    a = ADMIN_STRINGS[get_admin_lang()]
    try:
        await callback.message.delete()
    except Exception:
        pass
    await callback.answer(a["closed"])


@dp.callback_query(F.data == "admin_lang_menu")
async def cb_admin_lang_menu(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    alang = get_admin_lang()
    a = ADMIN_STRINGS[alang]
    builder = InlineKeyboardBuilder()
    builder.button(text="🇩🇿 العربية", callback_data="set_admin_lang_ar", style="success" if alang == "ar" else "primary")
    builder.button(text="🇬🇧 English", callback_data="set_admin_lang_en", style="success" if alang == "en" else "primary")
    builder.button(text="🇫🇷 Français", callback_data="set_admin_lang_fr", style="success" if alang == "fr" else "primary")
    builder.button(text="🧹 تنظيف الكاش وتخفيف الرام", callback_data="adm_set_clear_cache", style="success")
    builder.button(text=a["btn_back_admin"], callback_data="admin_menu", style="danger")
    builder.adjust(1)
    await safe_show(callback, a["lang_title"], reply_markup=builder.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.callback_query(F.data.startswith("set_admin_lang_"))
async def cb_set_admin_lang(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    new_lang = callback.data.split("set_admin_lang_")[1]
    if new_lang not in ADMIN_STRINGS:
        new_lang = "ar"
    db.set_setting("admin_lang", new_lang)
    await callback.answer(ADMIN_STRINGS[new_lang]["lang_updated"], show_alert=False)
    await safe_show(callback, get_admin_panel_text(new_lang), reply_markup=get_admin_menu_keyboard(new_lang), prefer_edit=True)


@dp.callback_query(F.data == "admin_stats")
async def cb_admin_stats(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    stats = db.get_admin_stats()
    text = a["stats_body"].format(**stats)
    builder = InlineKeyboardBuilder()
    builder.button(text=a["btn_back_admin"], callback_data="admin_menu", style="primary")
    await safe_show(callback, text, reply_markup=builder.as_markup(), prefer_edit=True)
    await callback.answer()


def _render_user_card(user: Dict[str, Any], alang: str) -> Tuple[str, InlineKeyboardMarkup]:
    a = ADMIN_STRINGS[alang]
    uid = user["user_id"]
    uname = f"@{user['username']}" if user.get("username") else "—"
    banned = bool(user.get("is_banned"))
    ref_info = db.get_referral_info(uid)
    text = a["user_card"].format(
        uid=uid,
        uname=uname,
        bal=fmt_tok(user.get("balance", 0)),
        ulang=user.get("language", "ar"),
        status=a["status_banned"] if banned else a["status_active"],
        streak=int(user.get("checkin_streak") or 0),
        total_ci=int(user.get("total_checkins") or 0),
        qcount=db.get_user_quests_count(uid),
        acount=db.count_saved_accounts(uid),
        rcount=ref_info["completed_invited"],
        stars=user.get("stars_spent", 0),
        created=user.get("created_at", "N/A"),
    )
    builder = InlineKeyboardBuilder()
    builder.button(text=a["u_btn_add"], callback_data=f"admin_u_add_{uid}", style="success")
    builder.button(text=a["u_btn_sub"], callback_data=f"admin_u_sub_{uid}", style="danger")
    if banned:
        builder.button(text=a["u_btn_unban"], callback_data=f"admin_u_unban_{uid}", style="success")
    else:
        builder.button(text=a["u_btn_ban"], callback_data=f"admin_u_ban_{uid}", style="danger")
    builder.button(text=a["u_btn_dm"], callback_data=f"admin_u_dm_{uid}", style="primary")
    builder.button(text=a["u_btn_reset_ci"], callback_data=f"admin_u_resetci_{uid}", style="primary")
    builder.button(text=a["btn_back_admin"], callback_data="admin_menu", style="primary")
    builder.adjust(2, 2, 2, 1)
    return text, builder.as_markup()


@dp.callback_query(F.data.startswith("admin_u_resetci_"))
async def cb_admin_u_resetci(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    uid = int(callback.data.split("admin_u_resetci_")[1])
    db.reset_user_checkin_streak(uid)
    db.log_admin_action(callback.from_user.id, "RESET_CHECKIN", f"uid={uid}")
    await callback.answer("🔄 Streak reset to 0.", show_alert=True)
    user = db.get_user_by_query(str(uid))
    if user:
        card_txt, card_kb = _render_user_card(user, get_admin_lang())
        await safe_show(callback, card_txt, reply_markup=card_kb, prefer_edit=True)


@dp.callback_query(F.data == "admin_users_top")
async def cb_admin_users_top(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    alang = get_admin_lang()
    a = ADMIN_STRINGS[alang]
    recent = db.get_recent_users(8)
    richest = db.get_richest_users(8)

    rec_lines = [f"• <code>{u['user_id']}</code> (@{u.get('username') or '—'}) • <b>{fmt_tok(u.get('balance', 0))}</b> 🪙" for u in recent]
    rich_lines = [f"• <code>{u['user_id']}</code> (@{u.get('username') or '—'}) • <b>{fmt_tok(u.get('balance', 0))}</b> 🪙" for u in richest]

    text = (
        "👥 <b>دليل الأعضاء والأرصدة — PLAYX1 ZONE</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "🆕 <b>أحدث الأعضاء:</b>\n" + ("\n".join(rec_lines) if rec_lines else "<i>لا يوجد</i>") + "\n\n"
        "💎 <b>أعلى الأرصدة:</b>\n" + ("\n".join(rich_lines) if rich_lines else "<i>لا يوجد</i>")
    )
    builder = InlineKeyboardBuilder()
    for u in richest[:5]:
        builder.button(text=f"👤 {u['user_id']} ({fmt_tok(u.get('balance', 0))} 🪙)", callback_data=f"admin_inspect_{u['user_id']}", style="primary")
    builder.button(text=a["btn_back_admin"], callback_data="admin_menu", style="danger")
    builder.adjust(1)
    await safe_show(callback, text, reply_markup=builder.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.callback_query(F.data.startswith("admin_inspect_"))
async def cb_admin_inspect(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    uid = int(callback.data.split("admin_inspect_")[1])
    user = db.get_user_by_query(str(uid))
    if not user:
        await callback.answer("User not found", show_alert=True)
        return
    card_txt, card_kb = _render_user_card(user, get_admin_lang())
    await safe_show(callback, card_txt, reply_markup=card_kb, prefer_edit=True)
    await callback.answer()


@dp.callback_query(F.data == "admin_lookup")
async def cb_admin_lookup(callback: types.CallbackQuery, state: FSMContext):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    await state.set_state(AdminForm.waiting_for_lookup)
    builder = InlineKeyboardBuilder()
    builder.button(text=a["btn_cancel"], callback_data="admin_menu", style="danger")
    await safe_show(callback, a["lookup_prompt"], reply_markup=builder.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.message(AdminForm.waiting_for_lookup)
async def process_admin_lookup(message: types.Message, state: FSMContext):
    if message.from_user.id not in ADMIN_IDS:
        return
    alang = get_admin_lang()
    a = ADMIN_STRINGS[alang]
    user = db.get_user_by_query((message.text or "").strip())
    await state.clear()
    if not user:
        kb = InlineKeyboardBuilder()
        kb.button(text=a["btn_back_admin"], callback_data="admin_menu", style="primary")
        await message.answer(a["user_not_found"], reply_markup=kb.as_markup(), parse_mode="HTML")
        return
    card_txt, card_kb = _render_user_card(user, alang)
    await message.answer(card_txt, reply_markup=card_kb, parse_mode="HTML")


@dp.callback_query(F.data.startswith("admin_u_add_"))
async def cb_admin_u_add(callback: types.CallbackQuery, state: FSMContext):
    if callback.from_user.id not in ADMIN_IDS:
        return
    uid = int(callback.data.split("admin_u_add_")[1])
    a = ADMIN_STRINGS[get_admin_lang()]
    await state.update_data(target_uid=uid)
    await state.set_state(AdminForm.waiting_for_add_tokens_target)
    kb = InlineKeyboardBuilder()
    kb.button(text=a["btn_cancel"], callback_data="admin_menu", style="danger")
    await safe_show(callback, a["add_one_prompt"].format(uid=uid), reply_markup=kb.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.message(AdminForm.waiting_for_add_tokens_target)
async def process_admin_u_add(message: types.Message, state: FSMContext):
    if message.from_user.id not in ADMIN_IDS:
        return
    alang = get_admin_lang()
    a = ADMIN_STRINGS[alang]
    amount = parse_float_val(message.text or "")
    if amount is None or amount <= 0:
        await message.answer(a["bad_format"], parse_mode="HTML")
        return
    data = await state.get_data()
    uid = data.get("target_uid")
    await state.clear()
    new_bal = db.update_balance(uid, amount)
    db.log_admin_action(message.from_user.id, "ADD_TOKENS_UID", f"uid={uid} amt={amount}")
    amt_s = fmt_tok(amount)
    bal_s = fmt_tok(new_bal)
    try:
        u_lang = db.get_user_language(uid) or "ar"
        ntf = {
            "en": f"🎁 <b>+{amt_s} Tokens credited by PLAYX1 ZONE Admin!</b>\n💳 New Wallet: <code>{bal_s}</code> 🪙",
            "fr": f"🎁 <b>+{amt_s} Tokens ajoutés par l'Admin PLAYX1 ZONE !</b>\n💳 Solde : <code>{bal_s}</code> 🪙",
            "ar": f"🎁 <b>تم شحن +{amt_s} توكن لحسابك من إدارة PLAYX1 ZONE!</b>\n💳 رصيدك الجديد: <code>{bal_s}</code> 🪙",
        }.get(u_lang)
        await bot.send_message(uid, ntf, parse_mode="HTML")
    except Exception:
        pass
    kb = InlineKeyboardBuilder()
    kb.button(text=a["btn_back_admin"], callback_data="admin_menu", style="primary")
    await message.answer(a["added_ok"].format(amount=amt_s, target=uid, bal=bal_s), reply_markup=kb.as_markup(), parse_mode="HTML")


@dp.callback_query(F.data.startswith("admin_u_sub_"))
async def cb_admin_u_sub(callback: types.CallbackQuery, state: FSMContext):
    if callback.from_user.id not in ADMIN_IDS:
        return
    uid = int(callback.data.split("admin_u_sub_")[1])
    a = ADMIN_STRINGS[get_admin_lang()]
    await state.update_data(target_uid=uid)
    await state.set_state(AdminForm.waiting_for_sub_tokens_target)
    kb = InlineKeyboardBuilder()
    kb.button(text=a["btn_cancel"], callback_data="admin_menu", style="danger")
    await safe_show(callback, a["sub_one_prompt"].format(uid=uid), reply_markup=kb.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.message(AdminForm.waiting_for_sub_tokens_target)
async def process_admin_u_sub(message: types.Message, state: FSMContext):
    if message.from_user.id not in ADMIN_IDS:
        return
    alang = get_admin_lang()
    a = ADMIN_STRINGS[alang]
    amount = parse_float_val(message.text or "")
    if amount is None or amount <= 0:
        await message.answer(a["bad_format"], parse_mode="HTML")
        return
    data = await state.get_data()
    uid = data.get("target_uid")
    await state.clear()
    new_bal = db.update_balance(uid, -amount)
    db.log_admin_action(message.from_user.id, "SUB_TOKENS_UID", f"uid={uid} amt={amount}")
    kb = InlineKeyboardBuilder()
    kb.button(text=a["btn_back_admin"], callback_data="admin_menu", style="primary")
    await message.answer(a["sub_ok"].format(amount=fmt_tok(amount), target=uid, bal=fmt_tok(new_bal)), reply_markup=kb.as_markup(), parse_mode="HTML")


@dp.callback_query(F.data.startswith("admin_u_ban_"))
async def cb_admin_u_ban(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    uid = int(callback.data.split("admin_u_ban_")[1])
    alang = get_admin_lang()
    a = ADMIN_STRINGS[alang]
    if uid in ADMIN_IDS:
        await callback.answer(a["cannot_ban_admin"], show_alert=True)
        return
    db.set_user_banned(uid, True)
    db.log_admin_action(callback.from_user.id, "BAN_USER", f"uid={uid}")
    await callback.answer(a["banned_ok"].format(uid=uid).replace("<code>", "").replace("</code>", ""), show_alert=True)
    user = db.get_user_by_query(str(uid))
    if user:
        card_txt, card_kb = _render_user_card(user, alang)
        await safe_show(callback, card_txt, reply_markup=card_kb, prefer_edit=True)


@dp.callback_query(F.data.startswith("admin_u_unban_"))
async def cb_admin_u_unban(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    uid = int(callback.data.split("admin_u_unban_")[1])
    alang = get_admin_lang()
    a = ADMIN_STRINGS[alang]
    db.set_user_banned(uid, False)
    db.log_admin_action(callback.from_user.id, "UNBAN_USER", f"uid={uid}")
    await callback.answer(a["unbanned_ok"].format(uid=uid).replace("<code>", "").replace("</code>", ""), show_alert=True)
    user = db.get_user_by_query(str(uid))
    if user:
        card_txt, card_kb = _render_user_card(user, alang)
        await safe_show(callback, card_txt, reply_markup=card_kb, prefer_edit=True)


@dp.callback_query(F.data.startswith("admin_u_dm_"))
async def cb_admin_u_dm(callback: types.CallbackQuery, state: FSMContext):
    if callback.from_user.id not in ADMIN_IDS:
        return
    uid = int(callback.data.split("admin_u_dm_")[1])
    a = ADMIN_STRINGS[get_admin_lang()]
    await state.update_data(dm_uid=uid)
    await state.set_state(AdminForm.waiting_for_dm_message)
    kb = InlineKeyboardBuilder()
    kb.button(text=a["btn_cancel"], callback_data="admin_menu", style="danger")
    await safe_show(callback, a["dm_prompt_msg"].format(uid=uid), reply_markup=kb.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.callback_query(F.data == "admin_add_tokens")
async def cb_admin_add_tokens(callback: types.CallbackQuery, state: FSMContext):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    await state.set_state(AdminForm.waiting_for_add_tokens)
    kb = InlineKeyboardBuilder()
    kb.button(text=a["btn_cancel"], callback_data="admin_menu", style="danger")
    await safe_show(callback, a["add_prompt"], reply_markup=kb.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.message(AdminForm.waiting_for_add_tokens)
async def process_admin_add_tokens(message: types.Message, state: FSMContext):
    if message.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    parts = (message.text or "").strip().split()
    if len(parts) < 2:
        await message.answer(a["bad_format"], parse_mode="HTML")
        return
    amount = parse_float_val(parts[1])
    if amount is None or amount <= 0:
        await message.answer(a["bad_format"], parse_mode="HTML")
        return
    target = parts[0]
    user = db.get_user_by_query(target)
    await state.clear()
    kb = InlineKeyboardBuilder()
    kb.button(text=a["btn_back_admin"], callback_data="admin_menu", style="primary")
    if not user:
        await message.answer(a["user_not_found"], reply_markup=kb.as_markup(), parse_mode="HTML")
        return
    new_bal = db.update_balance(user["user_id"], amount)
    db.log_admin_action(message.from_user.id, "ADD_TOKENS", f"target={target} amt={amount}")
    amt_s = fmt_tok(amount)
    bal_s = fmt_tok(new_bal)
    try:
        u_lang = db.get_user_language(user["user_id"]) or "ar"
        ntf = {
            "en": f"🎁 <b>+{amt_s} Tokens credited to your wallet!</b>\n💳 New Balance: <code>{bal_s}</code> 🪙",
            "fr": f"🎁 <b>+{amt_s} Tokens crédités sur votre solde !</b>\n💳 Nouveau Solde : <code>{bal_s}</code> 🪙",
            "ar": f"🎁 <b>تمت إضافة +{amt_s} توكن إلى محفظتك!</b>\n💳 الرصيد الجديد: <code>{bal_s}</code> 🪙",
        }.get(u_lang)
        await bot.send_message(user["user_id"], ntf, parse_mode="HTML")
    except Exception:
        pass
    uname = f"@{user['username']}" if user.get("username") else str(user["user_id"])
    await message.answer(a["added_ok"].format(amount=amt_s, target=uname, bal=bal_s), reply_markup=kb.as_markup(), parse_mode="HTML")


@dp.callback_query(F.data == "admin_sub_tokens")
async def cb_admin_sub_tokens(callback: types.CallbackQuery, state: FSMContext):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    await state.set_state(AdminForm.waiting_for_sub_tokens)
    kb = InlineKeyboardBuilder()
    kb.button(text=a["btn_cancel"], callback_data="admin_menu", style="danger")
    await safe_show(callback, a["sub_prompt"], reply_markup=kb.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.message(AdminForm.waiting_for_sub_tokens)
async def process_admin_sub_tokens(message: types.Message, state: FSMContext):
    if message.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    parts = (message.text or "").strip().split()
    if len(parts) < 2:
        await message.answer(a["bad_format"], parse_mode="HTML")
        return
    amount = parse_float_val(parts[1])
    if amount is None or amount <= 0:
        await message.answer(a["bad_format"], parse_mode="HTML")
        return
    target = parts[0]
    user = db.get_user_by_query(target)
    await state.clear()
    kb = InlineKeyboardBuilder()
    kb.button(text=a["btn_back_admin"], callback_data="admin_menu", style="primary")
    if not user:
        await message.answer(a["user_not_found"], reply_markup=kb.as_markup(), parse_mode="HTML")
        return
    new_bal = db.update_balance(user["user_id"], -amount)
    db.log_admin_action(message.from_user.id, "SUB_TOKENS", f"target={target} amt={amount}")
    uname = f"@{user['username']}" if user.get("username") else str(user["user_id"])
    await message.answer(a["sub_ok"].format(amount=fmt_tok(amount), target=uname, bal=fmt_tok(new_bal)), reply_markup=kb.as_markup(), parse_mode="HTML")


@dp.callback_query(F.data == "admin_gift_all")
async def cb_admin_gift_all(callback: types.CallbackQuery, state: FSMContext):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    await state.set_state(AdminForm.waiting_for_gift_all)
    kb = InlineKeyboardBuilder()
    kb.button(text=a["btn_cancel"], callback_data="admin_menu", style="danger")
    await safe_show(callback, a["gift_prompt"], reply_markup=kb.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.message(AdminForm.waiting_for_gift_all)
async def process_admin_gift_all(message: types.Message, state: FSMContext):
    if message.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    amount = parse_float_val(message.text or "")
    if amount is None or amount <= 0:
        await message.answer(a["bad_format"], parse_mode="HTML")
        return
    await state.clear()
    credited = db.gift_tokens_to_all(amount)
    db.log_admin_action(message.from_user.id, "GIFT_ALL", f"amt={amount} count={credited}")
    amt_s = fmt_tok(amount)
    active_ids = db.get_active_user_ids()
    sent, failed = 0, 0
    for uid in active_ids:
        u_lang = db.get_user_language(uid) or "ar"
        gift_txt = {
            "en": f"🎉 <b>PLAYX1 ZONE Gift!</b>\nEveryone just received <b>+{amt_s} Free Tokens</b> in their wallet! 🪙",
            "fr": f"🎉 <b>Cadeau PLAYX1 ZONE !</b>\nVous venez de recevoir <b>+{amt_s} Tokens Gratuits</b> dans votre solde ! 🪙",
            "ar": f"🎉 <b>هدية جماعية من PLAYX1 ZONE!</b>\nتم توزيع <b>+{amt_s} توكن مجاني</b> على محفظتك الآن! 🪙",
        }.get(u_lang)
        try:
            await bot.send_message(uid, gift_txt, parse_mode="HTML")
            sent += 1
            await asyncio.sleep(0.04)
        except Exception:
            failed += 1
    kb = InlineKeyboardBuilder()
    kb.button(text=a["btn_back_admin"], callback_data="admin_menu", style="primary")
    await message.answer(
        a["gift_done"].format(amount=amt_s, count=credited, sent=sent, failed=failed),
        reply_markup=kb.as_markup(),
        parse_mode="HTML",
    )


@dp.callback_query(F.data == "admin_bans")
async def cb_admin_bans(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    banned = db.get_banned_users()
    text = a["bans_title"]
    builder = InlineKeyboardBuilder()
    if banned:
        for u in banned:
            uname = f"@{u['username']}" if u.get("username") else str(u["user_id"])
            text += f"• <code>{u['user_id']}</code> ({uname})\n"
            builder.button(text=f"✅ Unban {u['user_id']}", callback_data=f"admin_fast_unban_{u['user_id']}", style="success")
    else:
        text += a["bans_empty"]
    builder.button(text=a["btn_ban_new"], callback_data="admin_ban_new", style="danger")
    builder.button(text=a["btn_back_admin"], callback_data="admin_menu", style="primary")
    builder.adjust(1)
    await safe_show(callback, text, reply_markup=builder.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.callback_query(F.data.startswith("admin_fast_unban_"))
async def cb_admin_fast_unban(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    uid = int(callback.data.split("admin_fast_unban_")[1])
    a = ADMIN_STRINGS[get_admin_lang()]
    db.set_user_banned(uid, False)
    await callback.answer(a["unbanned_ok"].format(uid=uid).replace("<code>", "").replace("</code>", ""), show_alert=True)
    await cb_admin_bans(callback)


@dp.callback_query(F.data == "admin_ban_new")
async def cb_admin_ban_new(callback: types.CallbackQuery, state: FSMContext):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    await state.set_state(AdminForm.waiting_for_ban_user)
    kb = InlineKeyboardBuilder()
    kb.button(text=a["btn_cancel"], callback_data="admin_bans", style="danger")
    await safe_show(callback, a["ban_prompt"], reply_markup=kb.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.message(AdminForm.waiting_for_ban_user)
async def process_admin_ban_user(message: types.Message, state: FSMContext):
    if message.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    user = db.get_user_by_query((message.text or "").strip())
    await state.clear()
    kb = InlineKeyboardBuilder()
    kb.button(text=a["btn_bans"], callback_data="admin_bans", style="primary")
    if not user:
        await message.answer(a["user_not_found"], reply_markup=kb.as_markup(), parse_mode="HTML")
        return
    if user["user_id"] in ADMIN_IDS:
        await message.answer(a["cannot_ban_admin"], reply_markup=kb.as_markup(), parse_mode="HTML")
        return
    db.set_user_banned(user["user_id"], True)
    await message.answer(a["banned_ok"].format(uid=user["user_id"]), reply_markup=kb.as_markup(), parse_mode="HTML")


# =========================================================
# WEEKLY PRIZE ADMIN CONTROL (Token Cost, Toggles, Refunds)
# =========================================================

@dp.callback_query(F.data == "admin_weekly_cfg")
async def cb_admin_weekly_cfg(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    w_en = db.get_setting_bool("weekly_prize_enabled", True)
    w_cost = fmt_tok(get_weekly_base_cost())
    w_free1 = db.get_setting_bool("weekly_free_first_time", False)
    w_ref_inel = db.get_setting_bool("weekly_refund_on_ineligible", True)
    w_ref_clm = db.get_setting_bool("weekly_refund_on_already_claimed", True)

    text = (
        "👑 <b>إعدادات نظام الجائزة الأسبوعية — PLAYX1 ZONE</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"⚡ <b>حالة النظام:</b> {a['on'] if w_en else a['off']}\n"
        f"🪙 <b>سعر التفعيل بالتوكن:</b> <code>{w_cost}</code> توكن (يدعم الكسور مثل 0.25 أو 0 للمجاني)\n"
        f"🎁 <b>أول مطالبة مجانية:</b> {a['on'] if w_free1 else a['off']}\n"
        f"↩️ <b>استرجاع التوكن عند عدم الأهلية (Bronze):</b> {a['on'] if w_ref_inel else a['off']}\n"
        f"↩️ <b>استرجاع التوكن عند الاستلام المسبق:</b> {a['on'] if w_ref_clm else a['off']}"
    )
    builder = InlineKeyboardBuilder()
    builder.button(text=f"⚡ النظام: {a['on'] if w_en else a['off']}", callback_data="adm_w_toggle_en", style="success" if w_en else "danger")
    builder.button(text=f"🪙 تعديل سعر التفعيل ({w_cost} 🪙)", callback_data="adm_w_edit_cost", style="primary")
    builder.button(text=f"🎁 أول مرة مجاناً: {a['on'] if w_free1 else a['off']}", callback_data="adm_w_toggle_free1", style="primary")
    builder.button(text=f"↩️ إرجاع (برونزي): {a['on'] if w_ref_inel else a['off']}", callback_data="adm_w_toggle_ref_inel", style="primary")
    builder.button(text=f"↩️ إرجاع (مستلمة): {a['on'] if w_ref_clm else a['off']}", callback_data="adm_w_toggle_ref_clm", style="primary")
    builder.button(text=a["btn_back_admin"], callback_data="admin_menu", style="danger")
    builder.adjust(1)
    await safe_show(callback, text, reply_markup=builder.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.callback_query(F.data == "adm_w_toggle_en")
async def cb_adm_w_toggle_en(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    cur = db.get_setting_bool("weekly_prize_enabled", True)
    db.set_setting("weekly_prize_enabled", "0" if cur else "1")
    db.log_admin_action(callback.from_user.id, "TOGGLE_WEEKLY", f"val={0 if cur else 1}")
    await cb_admin_weekly_cfg(callback)


@dp.callback_query(F.data == "adm_w_toggle_free1")
async def cb_adm_w_toggle_free1(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    cur = db.get_setting_bool("weekly_free_first_time", False)
    db.set_setting("weekly_free_first_time", "0" if cur else "1")
    await cb_admin_weekly_cfg(callback)


@dp.callback_query(F.data == "adm_w_toggle_ref_inel")
async def cb_adm_w_toggle_ref_inel(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    cur = db.get_setting_bool("weekly_refund_on_ineligible", True)
    db.set_setting("weekly_refund_on_ineligible", "0" if cur else "1")
    await cb_admin_weekly_cfg(callback)


@dp.callback_query(F.data == "adm_w_toggle_ref_clm")
async def cb_adm_w_toggle_ref_clm(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    cur = db.get_setting_bool("weekly_refund_on_already_claimed", True)
    db.set_setting("weekly_refund_on_already_claimed", "0" if cur else "1")
    await cb_admin_weekly_cfg(callback)


@dp.callback_query(F.data == "adm_w_edit_cost")
async def cb_adm_w_edit_cost(callback: types.CallbackQuery, state: FSMContext):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    await state.set_state(AdminForm.waiting_for_edit_weekly_cost)
    kb = InlineKeyboardBuilder()
    kb.button(text=a["btn_cancel"], callback_data="admin_weekly_cfg", style="danger")
    prompt = (
        "👑 <b>تعديل سعر تفعيل الجائزة الأسبوعية</b>\n\n"
        "أرسل التكلفة الجديدة بالتوكن (يدعم الكسور مثل <code>0.25</code> أو <code>0.5</code> أو <code>1</code> أو <code>0</code> للمجاني):"
    )
    await safe_show(callback, prompt, reply_markup=kb.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.message(AdminForm.waiting_for_edit_weekly_cost)
async def process_adm_w_edit_cost(message: types.Message, state: FSMContext):
    if message.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    val = parse_float_val(message.text or "")
    if val is None:
        await message.answer(a["bad_format"], parse_mode="HTML")
        return
    db.set_setting("weekly_prize_cost", fmt_tok(val))
    db.log_admin_action(message.from_user.id, "SET_WEEKLY_COST", f"cost={val}")
    await state.clear()
    kb = InlineKeyboardBuilder()
    kb.button(text="↩️ إعدادات الجائزة الأسبوعية", callback_data="admin_weekly_cfg", style="primary")
    await message.answer(f"✅ تم حفظ سعر تفعيل الجائزة الأسبوعية: <code>{fmt_tok(val)}</code> توكن!", reply_markup=kb.as_markup(), parse_mode="HTML")


# =========================================================
# REFERRAL PROGRAM ADMIN CONTROL
# =========================================================

@dp.callback_query(F.data == "admin_ref_cfg")
async def cb_admin_ref_cfg(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    ref_en = db.get_setting_bool("referral_enabled", True)
    inv_r = fmt_tok(db.get_setting_float("referral_inviter_reward", 3.0))
    new_b = fmt_tok(db.get_setting_float("referral_invited_bonus", 0.0))
    req_sub = db.get_setting_bool("referral_require_sub", True)
    top_refs = db.get_top_referrers(5)

    top_txt = ""
    if top_refs:
        lines = [f"• <code>{r['user_id']}</code> (@{r.get('username') or '—'}) : <b>{r['refs']}</b> إحالة ({fmt_tok(r.get('earned', 0))} 🪙)" for r in top_refs]
        top_txt = "\n━━━━━━━━━━━━━━━━━━━━\n🏆 <b>أكثر الأعضاء دعوةً:</b>\n" + "\n".join(lines)

    text = (
        "🤝 <b>إعدادات برنامج الإحالة — PLAYX1 ZONE</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"⚡ <b>حالة البرنامج:</b> {a['on'] if ref_en else a['off']}\n"
        f"🎁 <b>مكافأة الداعي لكل إحالة:</b> <code>{inv_r}</code> توكن\n"
        f"✨ <b>هدية إضافية للمدعو:</b> <code>{new_b}</code> توكن\n"
        f"📡 <b>اشتراط تأكيد الاشتراك:</b> {a['on'] if req_sub else a['off']}"
        + top_txt
    )
    builder = InlineKeyboardBuilder()
    builder.button(text=f"⚡ الإحالة: {a['on'] if ref_en else a['off']}", callback_data="adm_ref_toggle_en", style="success" if ref_en else "danger")
    builder.button(text=f"🎁 تعديل مكافأة الداعي ({inv_r} 🪙)", callback_data="adm_ref_edit_inviter", style="primary")
    builder.button(text=f"✨ تعديل هدية المدعو ({new_b} 🪙)", callback_data="adm_ref_edit_invited", style="primary")
    builder.button(text=f"📡 اشتراط الاشتراك: {a['on'] if req_sub else a['off']}", callback_data="adm_ref_toggle_sub", style="primary")
    builder.button(text=a["btn_back_admin"], callback_data="admin_menu", style="danger")
    builder.adjust(1)
    await safe_show(callback, text, reply_markup=builder.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.callback_query(F.data == "adm_ref_toggle_en")
async def cb_adm_ref_toggle_en(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    cur = db.get_setting_bool("referral_enabled", True)
    db.set_setting("referral_enabled", "0" if cur else "1")
    db.log_admin_action(callback.from_user.id, "TOGGLE_REFERRAL", f"val={0 if cur else 1}")
    await cb_admin_ref_cfg(callback)


@dp.callback_query(F.data == "adm_ref_toggle_sub")
async def cb_adm_ref_toggle_sub(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    cur = db.get_setting_bool("referral_require_sub", True)
    db.set_setting("referral_require_sub", "0" if cur else "1")
    await cb_admin_ref_cfg(callback)


@dp.callback_query(F.data == "adm_ref_edit_inviter")
async def cb_adm_ref_edit_inviter(callback: types.CallbackQuery, state: FSMContext):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    await state.set_state(AdminForm.waiting_for_edit_ref_reward)
    kb = InlineKeyboardBuilder()
    kb.button(text=a["btn_cancel"], callback_data="admin_ref_cfg", style="danger")
    await safe_show(callback, "🎁 <b>أرسل مكافأة الداعي لكل إحالة مؤكدة (يدعم الكسور مثل 0.5 أو 2.5 أو 3):</b>", reply_markup=kb.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.message(AdminForm.waiting_for_edit_ref_reward)
async def process_adm_ref_edit_inviter(message: types.Message, state: FSMContext):
    if message.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    val = parse_float_val(message.text or "")
    if val is None:
        await message.answer(a["bad_format"], parse_mode="HTML")
        return
    db.set_setting("referral_inviter_reward", fmt_tok(val))
    db.log_admin_action(message.from_user.id, "SET_REF_REWARD", f"val={val}")
    await state.clear()
    kb = InlineKeyboardBuilder()
    kb.button(text="↩️ إعدادات الإحالة", callback_data="admin_ref_cfg", style="primary")
    await message.answer(f"✅ تم حفظ مكافأة الإحالة: <code>{fmt_tok(val)}</code> توكن!", reply_markup=kb.as_markup(), parse_mode="HTML")


@dp.callback_query(F.data == "adm_ref_edit_invited")
async def cb_adm_ref_edit_invited(callback: types.CallbackQuery, state: FSMContext):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    await state.set_state(AdminForm.waiting_for_edit_ref_invited)
    kb = InlineKeyboardBuilder()
    kb.button(text=a["btn_cancel"], callback_data="admin_ref_cfg", style="danger")
    await safe_show(callback, "✨ <b>أرسل الهدية الترحيبية الإضافية للمدعو (يدعم الكسور مثل 0.25 أو 0):</b>", reply_markup=kb.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.message(AdminForm.waiting_for_edit_ref_invited)
async def process_adm_ref_edit_invited(message: types.Message, state: FSMContext):
    if message.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    val = parse_float_val(message.text or "")
    if val is None:
        await message.answer(a["bad_format"], parse_mode="HTML")
        return
    db.set_setting("referral_invited_bonus", fmt_tok(val))
    await state.clear()
    kb = InlineKeyboardBuilder()
    kb.button(text="↩️ إعدادات الإحالة", callback_data="admin_ref_cfg", style="primary")
    await message.answer(f"✅ تم حفظ هدية المدعو: <code>{fmt_tok(val)}</code> توكن!", reply_markup=kb.as_markup(), parse_mode="HTML")


# =========================================================
# DAILY CHECK-IN ADMIN CONTROL (7 Days & Toggle)
# =========================================================

@dp.callback_query(F.data == "admin_checkin_cfg")
async def cb_admin_checkin_cfg(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    ci_en = db.get_setting_bool("checkin_enabled", True)
    sched = db.get_checkin_schedule()
    lines = [f"• اليوم {i}: <b>+{fmt_tok(v)}</b> نقطة" for i, v in enumerate(sched, start=1)]

    text = (
        "📅 <b>إعدادات تسجيل الدخول اليومي — PLAYX1 ZONE</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"⚡ <b>حالة النظام:</b> {a['on'] if ci_en else a['off']}\n"
        "📋 <b>مكافآت الأيام السبعة (اضغط على اليوم لتعديل قيمته):</b>\n"
        + "\n".join(lines)
    )
    builder = InlineKeyboardBuilder()
    builder.button(text=f"⚡ تسجيل الدخول اليومي: {a['on'] if ci_en else a['off']}", callback_data="adm_ci_toggle", style="success" if ci_en else "danger")
    for day_i in range(1, 8):
        builder.button(text=f"✏️ اليوم {day_i} (+{fmt_tok(sched[day_i - 1])})", callback_data=f"adm_ci_day_{day_i}", style="primary")
    builder.button(text=a["btn_back_admin"], callback_data="admin_menu", style="danger")
    builder.adjust(1, 2, 2, 2, 1, 1)
    await safe_show(callback, text, reply_markup=builder.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.callback_query(F.data == "adm_ci_toggle")
async def cb_adm_ci_toggle(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    cur = db.get_setting_bool("checkin_enabled", True)
    db.set_setting("checkin_enabled", "0" if cur else "1")
    db.log_admin_action(callback.from_user.id, "TOGGLE_CHECKIN", f"val={0 if cur else 1}")
    await cb_admin_checkin_cfg(callback)


@dp.callback_query(F.data.startswith("adm_ci_day_"))
async def cb_adm_ci_day(callback: types.CallbackQuery, state: FSMContext):
    if callback.from_user.id not in ADMIN_IDS:
        return
    day_num = int(callback.data.split("adm_ci_day_")[1])
    a = ADMIN_STRINGS[get_admin_lang()]
    await state.update_data(ci_day=day_num)
    await state.set_state(AdminForm.waiting_for_edit_checkin_day)
    kb = InlineKeyboardBuilder()
    kb.button(text=a["btn_cancel"], callback_data="admin_checkin_cfg", style="danger")
    prompt = f"📅 <b>تعديل مكافأة اليوم {day_num}</b>\n\nأرسل قيمة المكافأة الجديدة (يدعم الكسور مثل <code>0.25</code> أو <code>0.5</code> أو <code>1</code>):"
    await safe_show(callback, prompt, reply_markup=kb.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.message(AdminForm.waiting_for_edit_checkin_day)
async def process_adm_ci_day(message: types.Message, state: FSMContext):
    if message.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    val = parse_float_val(message.text or "")
    if val is None:
        await message.answer(a["bad_format"], parse_mode="HTML")
        return
    data = await state.get_data()
    day_num = data.get("ci_day", 1)
    db.set_setting(f"checkin_day_{day_num}", fmt_tok(val))
    db.log_admin_action(message.from_user.id, "SET_CHECKIN_DAY", f"day={day_num} val={val}")
    await state.clear()
    kb = InlineKeyboardBuilder()
    kb.button(text="↩️ جدول تسجيل الدخول اليومي", callback_data="admin_checkin_cfg", style="primary")
    await message.answer(f"✅ تم تحديث مكافأة <b>اليوم {day_num}</b> إلى <code>+{fmt_tok(val)}</code> نقطة!", reply_markup=kb.as_markup(), parse_mode="HTML")


# =========================================================
# CHANNEL REWARDS CONTROL (Per-channel tokens & active state)
# =========================================================

@dp.callback_query(F.data == "admin_ch_rewards")
async def cb_admin_ch_rewards(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    rew_en = db.get_setting_bool("channel_reward_enabled", True)
    def_r = fmt_tok(db.get_setting_float("channel_reward_default", 2.0))
    all_chs = db.get_mandatory_channels() + db.get_promo_channels()

    lines = []
    builder = InlineKeyboardBuilder()
    builder.button(
        text=f"⚡ ربح القنوات: {a['on'] if rew_en else a['off']}",
        callback_data="adm_chr_toggle",
        style="success" if rew_en else "danger"
    )
    builder.button(
        text=f"🌐 تعديل نقاط كل القنوات ({def_r} 🪙)",
        callback_data="adm_chr_bulk_set",
        style="success"
    )

    for ch in all_chs:
        uname = ch["channel_username"]
        r_val = fmt_tok(ch.get("reward_tokens", 2))
        is_act = int(ch.get("is_active", 1)) == 1
        st_ico = "🟢" if is_act else "🔴"
        ch_kind = "إجبارية" if ch.get("channel_type") == "mandatory" else "شريكة"
        lines.append(f"{st_ico} <code>{uname}</code> • <b>+{r_val} 🪙</b> ({ch_kind})")
        builder.button(text=f"✏️ {uname} ({r_val} 🪙)", callback_data=f"adm_chr_set_{uname}", style="primary")
        builder.button(
            text=f"{'⏸️ إيقاف' if is_act else '▶️ تشغيل'} {uname}",
            callback_data=f"adm_chr_act_{uname}",
            style="danger" if is_act else "success"
        )

    text = (
        "💎 <b>التحكم بربح التوكن من القنوات — PLAYX1 ZONE</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"⚡ <b>حالة النظام:</b> {a['on'] if rew_en else a['off']}\n"
        f"🪙 <b>النقاط الافتراضية للقنوات:</b> <code>{def_r}</code> توكن\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "📋 <b>القنوات ومكافآتها الفردية:</b>\n"
        + ("\n".join(lines) if lines else "<i>لا توجد قنوات مضافة بعد.</i>")
    )
    builder.button(text=a["btn_back_admin"], callback_data="admin_menu", style="danger")
    builder.adjust(1, 1, *([2] * len(all_chs)), 1)
    await safe_show(callback, text, reply_markup=builder.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.callback_query(F.data == "adm_chr_bulk_set")
async def cb_adm_chr_bulk_set(callback: types.CallbackQuery, state: FSMContext):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    await state.set_state(AdminForm.waiting_for_bulk_ch_reward)
    kb = InlineKeyboardBuilder()
    kb.button(text=a["btn_cancel"], callback_data="admin_ch_rewards", style="danger")
    prompt = (
        "🌐 <b>تعديل نقاط الاشتراك لجميع القنوات دفعة واحدة</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "أرسل عدد التوكنات الجديد ليُطبق على كل القنوات المضافة والقنوات الجديدة القادمة (يدعم الكسور مثل <code>0.5</code> أو <code>2.5</code> أو <code>5</code>):"
    )
    await safe_show(callback, prompt, reply_markup=kb.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.message(AdminForm.waiting_for_bulk_ch_reward)
async def process_adm_chr_bulk_set(message: types.Message, state: FSMContext):
    if message.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    val = parse_float_val(message.text or "")
    if val is None:
        await message.answer(a["bad_format"], parse_mode="HTML")
        return
    updated_cnt = db.bulk_update_all_channels_reward(val)
    db.log_admin_action(message.from_user.id, "BULK_SET_CH_REWARD", f"val={val} count={updated_cnt}")
    await state.clear()
    kb = InlineKeyboardBuilder()
    kb.button(text="↩️ ربح القنوات", callback_data="admin_ch_rewards", style="primary")
    await message.answer(
        f"✅ تم تحديث مكافأة <b>{updated_cnt}</b> قناة إلى <code>+{fmt_tok(val)}</code> توكن بنجاح!",
        reply_markup=kb.as_markup(),
        parse_mode="HTML"
    )


@dp.callback_query(F.data == "adm_chr_toggle")
async def cb_adm_chr_toggle(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    cur = db.get_setting_bool("channel_reward_enabled", True)
    db.set_setting("channel_reward_enabled", "0" if cur else "1")
    db.log_admin_action(callback.from_user.id, "TOGGLE_CH_REWARDS", f"val={0 if cur else 1}")
    await cb_admin_ch_rewards(callback)


@dp.callback_query(F.data.startswith("adm_chr_act_"))
async def cb_adm_chr_act(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    ch_name = callback.data.split("adm_chr_act_")[1]
    db.toggle_channel_active(ch_name)
    await cb_admin_ch_rewards(callback)


@dp.callback_query(F.data.startswith("adm_chr_set_"))
async def cb_adm_chr_set(callback: types.CallbackQuery, state: FSMContext):
    if callback.from_user.id not in ADMIN_IDS:
        return
    ch_name = callback.data.split("adm_chr_set_")[1]
    a = ADMIN_STRINGS[get_admin_lang()]
    await state.update_data(target_ch=ch_name)
    await state.set_state(AdminForm.waiting_for_edit_ch_reward)
    kb = InlineKeyboardBuilder()
    kb.button(text=a["btn_cancel"], callback_data="admin_ch_rewards", style="danger")
    prompt = (
        f"💎 <b>تحديد مكافأة القناة</b> <code>{ch_name}</code>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "أرسل عدد التوكنات الممنوحة عند الاشتراك في هذه القناة (يدعم الكسور مثل <code>0.25</code> أو <code>0.5</code> أو <code>2</code> أو <code>0</code> لإلغاء مكافأتها):"
    )
    await safe_show(callback, prompt, reply_markup=kb.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.message(AdminForm.waiting_for_edit_ch_reward)
async def process_adm_chr_set(message: types.Message, state: FSMContext):
    if message.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    val = parse_float_val(message.text or "")
    if val is None:
        await message.answer(a["bad_format"], parse_mode="HTML")
        return
    data = await state.get_data()
    ch_name = data.get("target_ch", "")
    db.update_channel_reward(ch_name, val)
    db.log_admin_action(message.from_user.id, "SET_CH_REWARD", f"ch={ch_name} val={val}")
    await state.clear()
    kb = InlineKeyboardBuilder()
    kb.button(text="↩️ ربح القنوات", callback_data="admin_ch_rewards", style="primary")
    await message.answer(f"✅ تم تحديث مكافأة القناة <code>{ch_name}</code> إلى <code>+{fmt_tok(val)}</code> توكن!", reply_markup=kb.as_markup(), parse_mode="HTML")


# =========================================================
# MANDATORY & PARTNER CHANNELS, PROMOS, BROADCAST, DM
# =========================================================

@dp.callback_query(F.data == "admin_mandatory_channels")
async def cb_admin_mandatory_channels(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    channels = db.get_mandatory_channels()
    fsub_on = db.get_setting_bool("force_sub_enabled", True)
    text = a["mand_title"]
    builder = InlineKeyboardBuilder()
    if channels:
        for ch in channels:
            ch_name = ch["channel_username"]
            title = ch.get("title") or ch_name
            r_s = fmt_tok(ch.get("reward_tokens", 2))
            text += f"• <b>{title}:</b> <code>{ch_name}</code> (+{r_s} 🪙)\n"
            builder.button(text=f"🗑️ {ch_name}", callback_data=f"del_mand_{ch_name}", style="danger")
    else:
        text += a["mand_empty"]
    builder.button(text=a["btn_add_mand"], callback_data="admin_add_mandatory", style="success")
    builder.button(text=a["btn_toggle_fsub"].format(state=a["on"] if fsub_on else a["off"]), callback_data="admin_toggle_fsub_ch", style="primary")
    builder.button(text=a["btn_back_admin"], callback_data="admin_menu", style="primary")
    builder.adjust(1)
    await safe_show(callback, text, reply_markup=builder.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.callback_query(F.data == "admin_toggle_fsub_ch")
async def cb_admin_toggle_fsub_ch(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    cur = db.get_setting_bool("force_sub_enabled", True)
    db.set_setting("force_sub_enabled", "0" if cur else "1")
    _SUB_CACHE.clear()
    await cb_admin_mandatory_channels(callback)


@dp.callback_query(F.data.startswith("del_mand_"))
async def cb_del_mand(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    ch_name = callback.data.split("del_mand_")[1]
    db.remove_sponsored_channel(ch_name)
    _SUB_CACHE.clear()
    await callback.answer(a["ch_deleted"].format(ch=ch_name), show_alert=True)
    await cb_admin_mandatory_channels(callback)


@dp.callback_query(F.data == "admin_add_mandatory")
async def cb_admin_add_mandatory(callback: types.CallbackQuery, state: FSMContext):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    me = await bot.get_me()
    await state.set_state(AdminForm.waiting_for_add_mandatory)
    builder = InlineKeyboardBuilder()
    builder.button(text=a["btn_cancel"], callback_data="admin_mandatory_channels", style="danger")
    await safe_show(callback, a["add_mand_prompt"].format(bot_uname=me.username), reply_markup=builder.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.message(AdminForm.waiting_for_add_mandatory)
async def process_admin_add_mandatory(message: types.Message, state: FSMContext):
    if message.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    channel_list = parse_channels_input(message.text or "")
    if not channel_list:
        await message.answer(a["bad_format"], parse_mode="HTML")
        return

    added = []
    for ch_name in channel_list:
        clean_fallback = ch_name.lstrip("@").strip()
        title = clean_fallback
        invite_link = f"https://t.me/{clean_fallback}"
        try:
            chat = await bot.get_chat(ch_name)
            title = (chat.title or clean_fallback).strip().lstrip("@").strip()
        except Exception:
            pass
        db.add_sponsored_channel(ch_name, title, invite_link, channel_type="mandatory")
        added.append(f"• <b>{title}:</b> {ch_name}")

    _SUB_CACHE.clear()
    await state.clear()
    builder = InlineKeyboardBuilder()
    builder.button(text=a["btn_mand"], callback_data="admin_mandatory_channels", style="primary")
    await message.answer(a["mand_added"].format(n=len(added)) + "\n".join(added), reply_markup=builder.as_markup(), parse_mode="HTML")


@dp.callback_query(F.data == "admin_promo_channels")
async def cb_admin_promo_channels(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    channels = db.get_promo_channels()
    text = a["promo_ch_title"]
    builder = InlineKeyboardBuilder()
    if channels:
        for ch in channels:
            ch_name = ch["channel_username"]
            title = ch.get("title") or ch_name
            r_s = fmt_tok(ch.get("reward_tokens", 2))
            text += f"• <b>{title}:</b> <code>{ch_name}</code> (+{r_s} 🪙)\n"
            builder.button(text=f"🗑️ {ch_name}", callback_data=f"del_promo_ch_{ch_name}", style="danger")
    else:
        text += a["promo_ch_empty"]
    builder.button(text=a["btn_add_promo_ch"], callback_data="admin_add_promo_ch", style="success")
    builder.button(text=a["btn_back_admin"], callback_data="admin_menu", style="primary")
    builder.adjust(1)
    await safe_show(callback, text, reply_markup=builder.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.callback_query(F.data.startswith("del_promo_ch_"))
async def cb_del_promo_ch(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    ch_name = callback.data.split("del_promo_ch_")[1]
    db.remove_sponsored_channel(ch_name)
    await callback.answer(a["ch_deleted"].format(ch=ch_name), show_alert=True)
    await cb_admin_promo_channels(callback)


@dp.callback_query(F.data == "admin_add_promo_ch")
async def cb_admin_add_promo_ch(callback: types.CallbackQuery, state: FSMContext):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    await state.set_state(AdminForm.waiting_for_add_promo_ch)
    builder = InlineKeyboardBuilder()
    builder.button(text=a["btn_cancel"], callback_data="admin_promo_channels", style="danger")
    await safe_show(callback, a["add_promo_ch_prompt"], reply_markup=builder.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.message(AdminForm.waiting_for_add_promo_ch)
async def process_admin_add_promo_ch(message: types.Message, state: FSMContext):
    if message.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    channel_list = parse_channels_input(message.text or "")
    if not channel_list:
        await message.answer(a["bad_format"], parse_mode="HTML")
        return

    added = []
    for ch_name in channel_list:
        clean_fallback = ch_name.lstrip("@").strip()
        title = clean_fallback
        invite_link = f"https://t.me/{clean_fallback}"
        try:
            chat = await bot.get_chat(ch_name)
            title = (chat.title or clean_fallback).strip().lstrip("@").strip()
        except Exception:
            pass
        db.add_sponsored_channel(ch_name, title, invite_link, channel_type="promo")
        added.append(f"• <b>{title}:</b> {ch_name}")

    await state.clear()
    builder = InlineKeyboardBuilder()
    builder.button(text=a["btn_promo_ch"], callback_data="admin_promo_channels", style="primary")
    await message.answer(a["promo_ch_added"].format(n=len(added)) + "\n".join(added), reply_markup=builder.as_markup(), parse_mode="HTML")


@dp.callback_query(F.data == "admin_promos")
async def cb_admin_promos(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    promos = db.get_all_promo_codes()
    text = a["promos_title"]
    builder = InlineKeyboardBuilder()
    if promos:
        for p in promos:
            text += f"• <code>{p['code']}</code> ➜ <b>+{fmt_tok(p['reward_tokens'])} 🪙</b> ({p['current_uses']}/{p['max_uses']})\n"
            builder.button(text=f"📣 {p['code']}", callback_data=f"bcast_promo_{p['code']}", style="primary")
            builder.button(text=f"🗑️ {p['code']}", callback_data=f"del_promo_{p['code']}", style="danger")
    else:
        text += a["promos_empty"]
    builder.button(text=a["btn_new_promo"], callback_data="admin_add_promo", style="success")
    builder.button(text=a["btn_back_admin"], callback_data="admin_menu", style="primary")
    builder.adjust(2)
    await safe_show(callback, text, reply_markup=builder.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.callback_query(F.data == "admin_add_promo")
async def cb_admin_add_promo(callback: types.CallbackQuery, state: FSMContext):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    await state.set_state(AdminForm.waiting_for_add_promo)
    builder = InlineKeyboardBuilder()
    builder.button(text=a["btn_cancel"], callback_data="admin_promos", style="danger")
    await safe_show(callback, a["new_promo_prompt"], reply_markup=builder.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.message(AdminForm.waiting_for_add_promo)
async def process_admin_add_promo(message: types.Message, state: FSMContext):
    if message.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    parts = (message.text or "").strip().split()
    if len(parts) < 3:
        await message.answer(a["bad_format"], parse_mode="HTML")
        return
    tokens_val = parse_float_val(parts[1])
    if tokens_val is None or tokens_val <= 0 or not parts[2].isdigit():
        await message.answer(a["bad_format"], parse_mode="HTML")
        return
    code, max_uses = parts[0].upper(), int(parts[2])
    db.create_promo_code(code, tokens_val, max_uses)
    db.log_admin_action(message.from_user.id, "CREATE_PROMO", f"code={code} tok={tokens_val} uses={max_uses}")
    await state.clear()

    builder = InlineKeyboardBuilder()
    builder.button(text=a["promo_bcast_btn"], callback_data=f"bcast_promo_{code}", style="success")
    builder.button(text=a["btn_promos"], callback_data="admin_promos", style="primary")
    builder.adjust(1)
    await message.answer(
        a["promo_created"].format(code=code, tokens=fmt_tok(tokens_val), max_uses=max_uses),
        reply_markup=builder.as_markup(),
        parse_mode="HTML",
    )


@dp.callback_query(F.data.startswith("del_promo_"))
async def cb_del_promo(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    code = callback.data.split("del_promo_")[1]
    db.delete_promo_code(code)
    await callback.answer(a["promo_deleted"].format(code=code), show_alert=True)
    await cb_admin_promos(callback)


@dp.callback_query(F.data.startswith("bcast_promo_"))
async def cb_bcast_promo(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    code = callback.data.split("bcast_promo_")[1]
    promos = db.get_all_promo_codes()
    promo = next((p for p in promos if p["code"] == code), None)
    if not promo:
        await callback.answer("Code not found!", show_alert=True)
        return

    tok_s = fmt_tok(promo["reward_tokens"])
    max_uses = promo["max_uses"]
    await callback.answer("⏳...", show_alert=False)

    user_ids = db.get_active_user_ids()
    ok, fail = 0, 0
    for uid in user_ids:
        u_lang = db.get_user_language(uid) or "ar"
        if u_lang == "en":
            bcast_text = (
                "🎁 <b>New PLAYX1 ZONE Gift Code!</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                f"🎫 <b>Code:</b> <code>{code}</code>\n"
                f"🪙 <b>Reward:</b> +{tok_s} Free Tokens\n"
                f"👥 <b>Limit:</b> First {max_uses} members\n\n"
                f"Tap below or send <code>/promo {code}</code>"
            )
            btn_redeem = "🎫 Activate Now"
        elif u_lang == "fr":
            bcast_text = (
                "🎁 <b>Nouveau Code Cadeau PLAYX1 ZONE !</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                f"🎫 <b>Code :</b> <code>{code}</code>\n"
                f"🪙 <b>Gain :</b> +{tok_s} Tokens Gratuits\n"
                f"👥 <b>Limite :</b> {max_uses} premiers membres\n\n"
                f"Cliquez ci-dessous ou envoyez <code>/promo {code}</code>"
            )
            btn_redeem = "🎫 Activer Maintenant"
        else:
            bcast_text = (
                "🎁 <b>كود هدية جديد من PLAYX1 ZONE!</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                f"🎫 <b>الكود:</b> <code>{code}</code>\n"
                f"🪙 <b>المكافأة:</b> +{tok_s} توكن مجاني\n"
                f"👥 <b>الحد الأقصى:</b> لأول {max_uses} مستخدم\n\n"
                f"فعّله الآن بالزر أدناه أو عبر <code>/promo {code}</code>"
            )
            btn_redeem = "🎫 تفعيل الكود الآن"

        builder = InlineKeyboardBuilder()
        builder.button(text=btn_redeem, callback_data="user_enter_promo", style="success")
        try:
            await bot.send_message(uid, bcast_text, reply_markup=builder.as_markup(), parse_mode="HTML")
            ok += 1
            await asyncio.sleep(0.04)
        except Exception:
            fail += 1

    kb = InlineKeyboardBuilder()
    kb.button(text=a["btn_back_admin"], callback_data="admin_menu", style="primary")
    await callback.message.answer(a["bcast_done"].format(ok=ok, fail=fail), reply_markup=kb.as_markup(), parse_mode="HTML")


@dp.callback_query(F.data == "admin_broadcast")
async def cb_admin_broadcast(callback: types.CallbackQuery, state: FSMContext):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    await state.set_state(AdminForm.waiting_for_broadcast)
    kb = InlineKeyboardBuilder()
    kb.button(text=a["btn_cancel"], callback_data="admin_menu", style="danger")
    await safe_show(callback, a["bcast_prompt"], reply_markup=kb.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.message(AdminForm.waiting_for_broadcast)
async def process_admin_broadcast(message: types.Message, state: FSMContext):
    if message.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    await state.clear()
    user_ids = db.get_all_user_ids()
    status_msg = await message.answer(a["bcast_running"].format(n=len(user_ids)), parse_mode="HTML")
    ok, fail = 0, 0
    for uid in user_ids:
        try:
            await bot.copy_message(chat_id=uid, from_chat_id=message.chat.id, message_id=message.message_id)
            ok += 1
            await asyncio.sleep(0.04)
        except Exception:
            fail += 1
    kb = InlineKeyboardBuilder()
    kb.button(text=a["btn_back_admin"], callback_data="admin_menu", style="primary")
    await status_msg.edit_text(a["bcast_done"].format(ok=ok, fail=fail), reply_markup=kb.as_markup(), parse_mode="HTML")


@dp.callback_query(F.data == "admin_dm_user")
async def cb_admin_dm_user(callback: types.CallbackQuery, state: FSMContext):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    await state.set_state(AdminForm.waiting_for_dm_user)
    kb = InlineKeyboardBuilder()
    kb.button(text=a["btn_cancel"], callback_data="admin_menu", style="danger")
    await safe_show(callback, a["dm_prompt_user"], reply_markup=kb.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.message(AdminForm.waiting_for_dm_user)
async def process_admin_dm_user(message: types.Message, state: FSMContext):
    if message.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    user = db.get_user_by_query((message.text or "").strip())
    if not user:
        await state.clear()
        kb = InlineKeyboardBuilder()
        kb.button(text=a["btn_back_admin"], callback_data="admin_menu", style="primary")
        await message.answer(a["user_not_found"], reply_markup=kb.as_markup(), parse_mode="HTML")
        return
    await state.update_data(dm_uid=user["user_id"])
    await state.set_state(AdminForm.waiting_for_dm_message)
    kb = InlineKeyboardBuilder()
    kb.button(text=a["btn_cancel"], callback_data="admin_menu", style="danger")
    await message.answer(a["dm_prompt_msg"].format(uid=user["user_id"]), reply_markup=kb.as_markup(), parse_mode="HTML")


@dp.message(AdminForm.waiting_for_dm_message)
async def process_admin_dm_message(message: types.Message, state: FSMContext):
    if message.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    data = await state.get_data()
    uid = data.get("dm_uid")
    await state.clear()
    kb = InlineKeyboardBuilder()
    kb.button(text=a["btn_back_admin"], callback_data="admin_menu", style="primary")
    try:
        await bot.copy_message(chat_id=uid, from_chat_id=message.chat.id, message_id=message.message_id)
        await message.answer(a["dm_sent"].format(uid=uid), reply_markup=kb.as_markup(), parse_mode="HTML")
    except Exception:
        await message.answer(a["dm_fail"], reply_markup=kb.as_markup(), parse_mode="HTML")


# =========================================================
# ADVANCED SETTINGS, ADMIN LOGS & BACKUP
# =========================================================

@dp.callback_query(F.data == "admin_settings")
async def cb_admin_settings(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    maint = db.get_setting_bool("maintenance_mode", False)
    fsub = db.get_setting_bool("force_sub_enabled", True)
    quests_en = db.get_setting_bool("quests_enabled", True)
    shop_en = db.get_setting_bool("stars_shop_enabled", True)
    promos_en = db.get_setting_bool("promo_codes_enabled", True)
    autosave_en = db.get_setting_bool("auto_save_accounts", True)
    cost = fmt_tok(get_chest_cost())
    wbonus = fmt_tok(get_welcome_bonus())

    text = a["settings_title"].format(
        maint=a["maint_on"] if maint else a["maint_off"],
        fsub=a["on"] if fsub else a["off"],
        quests_st=a["on"] if quests_en else a["off"],
        shop_st=a["on"] if shop_en else a["off"],
        promos_st=a["on"] if promos_en else a["off"],
        autosave_st=a["on"] if autosave_en else a["off"],
        cost=cost,
        wbonus=wbonus,
    )
    builder = InlineKeyboardBuilder()
    builder.button(text=a["btn_maint"].format(state=a["on"] if maint else a["off"]), callback_data="admin_toggle_maint", style="danger" if maint else "success")
    builder.button(text=a["btn_fsub"].format(state=a["on"] if fsub else a["off"]), callback_data="admin_toggle_fsub", style="success" if fsub else "danger")
    builder.button(text=f"🚀 فتح الصناديق: {a['on'] if quests_en else a['off']}", callback_data="adm_set_toggle_quests", style="primary")
    builder.button(text=f"⭐ متجر النجوم: {a['on'] if shop_en else a['off']}", callback_data="adm_set_toggle_shop", style="primary")
    builder.button(text=f"🎫 أكواد الهدايا: {a['on'] if promos_en else a['off']}", callback_data="adm_set_toggle_promos", style="primary")
    builder.button(text=f"💾 حفظ الحسابات: {a['on'] if autosave_en else a['off']}", callback_data="adm_set_toggle_autosave", style="primary")
    builder.button(text=a["btn_edit_cost"], callback_data="admin_edit_cost", style="success")
    builder.button(text=a["btn_edit_welcome"], callback_data="admin_edit_welcome", style="success")
    builder.button(text=a["btn_back_admin"], callback_data="admin_menu", style="danger")
    builder.adjust(2)
    await safe_show(callback, text, reply_markup=builder.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.callback_query(F.data == "adm_set_toggle_quests")
async def cb_adm_set_toggle_quests(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    cur = db.get_setting_bool("quests_enabled", True)
    db.set_setting("quests_enabled", "0" if cur else "1")
    await cb_admin_settings(callback)


@dp.callback_query(F.data == "adm_set_toggle_shop")
async def cb_adm_set_toggle_shop(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    cur = db.get_setting_bool("stars_shop_enabled", True)
    db.set_setting("stars_shop_enabled", "0" if cur else "1")
    await cb_admin_settings(callback)


@dp.callback_query(F.data == "adm_set_toggle_promos")
async def cb_adm_set_toggle_promos(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    cur = db.get_setting_bool("promo_codes_enabled", True)
    db.set_setting("promo_codes_enabled", "0" if cur else "1")
    await cb_admin_settings(callback)


@dp.callback_query(F.data == "adm_set_toggle_autosave")
async def cb_adm_set_toggle_autosave(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    cur = db.get_setting_bool("auto_save_accounts", True)
    db.set_setting("auto_save_accounts", "0" if cur else "1")
    await cb_admin_settings(callback)


@dp.callback_query(F.data == "admin_toggle_maint")
async def cb_admin_toggle_maint(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    cur = db.get_setting_bool("maintenance_mode", False)
    db.set_setting("maintenance_mode", "0" if cur else "1")
    await cb_admin_settings(callback)


@dp.callback_query(F.data == "admin_toggle_fsub")
async def cb_admin_toggle_fsub(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    cur = db.get_setting_bool("force_sub_enabled", True)
    db.set_setting("force_sub_enabled", "0" if cur else "1")
    _SUB_CACHE.clear()
    await cb_admin_settings(callback)


@dp.callback_query(F.data == "admin_edit_cost")
async def cb_admin_edit_cost(callback: types.CallbackQuery, state: FSMContext):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    await state.set_state(AdminForm.waiting_for_edit_cost)
    kb = InlineKeyboardBuilder()
    kb.button(text=a["btn_cancel"], callback_data="admin_settings", style="danger")
    await safe_show(callback, a["cost_prompt"], reply_markup=kb.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.message(AdminForm.waiting_for_edit_cost)
async def process_admin_edit_cost(message: types.Message, state: FSMContext):
    if message.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    val = parse_float_val(message.text or "")
    if val is None:
        await message.answer(a["bad_format"], parse_mode="HTML")
        return
    db.set_setting("chest_cost", fmt_tok(val))
    db.log_admin_action(message.from_user.id, "SET_CHEST_COST", f"val={val}")
    await state.clear()
    kb = InlineKeyboardBuilder()
    kb.button(text=a["btn_settings"], callback_data="admin_settings", style="primary")
    await message.answer(a["setting_saved"], reply_markup=kb.as_markup(), parse_mode="HTML")


@dp.callback_query(F.data == "admin_edit_welcome")
async def cb_admin_edit_welcome(callback: types.CallbackQuery, state: FSMContext):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    await state.set_state(AdminForm.waiting_for_edit_welcome)
    kb = InlineKeyboardBuilder()
    kb.button(text=a["btn_cancel"], callback_data="admin_settings", style="danger")
    await safe_show(callback, a["welcome_prompt"], reply_markup=kb.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.message(AdminForm.waiting_for_edit_welcome)
async def process_admin_edit_welcome(message: types.Message, state: FSMContext):
    if message.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    val = parse_float_val(message.text or "")
    if val is None:
        await message.answer(a["bad_format"], parse_mode="HTML")
        return
    db.set_setting("welcome_bonus", fmt_tok(val))
    db.log_admin_action(message.from_user.id, "SET_WELCOME_BONUS", f"val={val}")
    await state.clear()
    kb = InlineKeyboardBuilder()
    kb.button(text=a["btn_settings"], callback_data="admin_settings", style="primary")
    await message.answer(a["setting_saved"], reply_markup=kb.as_markup(), parse_mode="HTML")


@dp.callback_query(F.data == "admin_logs")
async def cb_admin_logs(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    logs = db.get_recent_admin_logs(15)
    if logs:
        lines = [f"• <code>{l['action']}</code> ({l.get('details') or ''}) — <i>{l.get('created_at') or ''}</i>" for l in logs]
        body = "\n".join(lines)
    else:
        body = "<i>لا توجد عمليات مسجلة بعد.</i>"
    text = f"📜 <b>سجل عمليات الإدارة — PLAYX1 ZONE</b>\n━━━━━━━━━━━━━━━━━━━━\n{body}"
    builder = InlineKeyboardBuilder()
    if logs:
        builder.button(text="🗑️ حذف وتفريغ السجل بالكامل", callback_data="admin_clear_logs", style="danger")
    builder.button(text=a["btn_back_admin"], callback_data="admin_menu", style="primary")
    builder.adjust(1)
    await safe_show(callback, text, reply_markup=builder.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.callback_query(F.data == "admin_clear_logs")
async def cb_admin_clear_logs(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    deleted_cnt = db.clear_admin_logs()
    await callback.answer(f"🗑️ تم حذف {deleted_cnt} سجل وتوفير مساحة التخزين.", show_alert=True)
    await cb_admin_logs(callback)


@dp.callback_query(F.data == "admin_backup")
async def cb_admin_backup(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    if not os.path.exists(db.DB_PATH):
        await callback.answer(a["backup_err"], show_alert=True)
        return
    ts = datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC")
    await callback.message.answer_document(
        document=FSInputFile(str(db.DB_PATH)),
        caption=a["backup_caption"].format(ts=ts),
        parse_mode="HTML",
    )
    await callback.answer("✅", show_alert=False)


@dp.message(Command("id"), StateFilter("*"))
@dp.message(Command("myid"), StateFilter("*"))
async def cmd_myid(message: types.Message):
    uid = message.from_user.id
    uname = f"@{message.from_user.username}" if message.from_user.username else "—"
    await message.answer(f"🆔 <b>ID:</b> <code>{uid}</code>\n🔖 <b>Username:</b> {uname}", parse_mode="HTML")


@dp.message(Command("add"), StateFilter("*"))
async def cmd_quick_add(message: types.Message):
    if message.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    parts = (message.text or "").strip().split()
    if len(parts) < 3:
        await message.answer("<code>/add @username 2.5</code>", parse_mode="HTML")
        return
    amount = parse_float_val(parts[2])
    if amount is None:
        await message.answer("<code>/add @username 2.5</code>", parse_mode="HTML")
        return
    target = parts[1]
    user = db.get_user_by_query(target)
    if not user:
        await message.answer(a["user_not_found"], parse_mode="HTML")
        return
    new_bal = db.update_balance(user["user_id"], amount)
    amt_s = fmt_tok(amount)
    bal_s = fmt_tok(new_bal)
    try:
        u_lang = db.get_user_language(user["user_id"]) or "ar"
        ntf = {
            "en": f"🎁 <b>+{amt_s} Tokens credited!</b>\n💳 Wallet: <code>{bal_s}</code> 🪙",
            "fr": f"🎁 <b>+{amt_s} Tokens crédités !</b>\n💳 Solde : <code>{bal_s}</code> 🪙",
            "ar": f"🎁 <b>تم شحن +{amt_s} توكن في محفظتك!</b>\n💳 الرصيد: <code>{bal_s}</code> 🪙",
        }.get(u_lang)
        await bot.send_message(user["user_id"], ntf, parse_mode="HTML")
    except Exception:
        pass
    await message.answer(a["added_ok"].format(amount=amt_s, target=target, bal=bal_s), parse_mode="HTML")


@dp.message(Command("stats"), StateFilter("*"))
async def cmd_quick_stats(message: types.Message):
    if message.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    stats = db.get_admin_stats()
    await message.answer(a["stats_body"].format(**stats), parse_mode="HTML")




# =========================================================
# OFFERS, CATEGORIES & SERVICES STORE (STARS / TOKENS / DUAL / BUNDLE / USDT)
# =========================================================

def _format_service_price_summary(srv: Dict[str, Any]) -> str:
    p_stars = int(srv.get("price_stars") or 0)
    p_tok = round(float(srv.get("price_tokens") or 0), 4)
    p_usdt = str(srv.get("price_usdt") or "").strip()
    is_bundle = bool(int(srv.get("bundle_mode") or 0))

    parts = []
    if is_bundle and p_stars > 0 and p_tok > 0:
        parts.append(f"{p_stars} ⭐ + {fmt_tok(p_tok)} 🪙 (مدمج)")
    else:
        if p_stars > 0:
            parts.append(f"{p_stars} ⭐")
        if p_tok > 0:
            parts.append(f"{fmt_tok(p_tok)} 🪙")
    if p_usdt:
        parts.append(f"{p_usdt} USDT")
    return " أو ".join(parts) if parts else "مجاني"


@dp.callback_query(F.data == "nav_services_store", StateFilter("*"))
async def cb_nav_services_store(callback: types.CallbackQuery, state: FSMContext):
    await state.clear()
    user_id = callback.from_user.id
    lang = db.get_user_language(user_id) or "ar"
    t = STRINGS.get(lang, STRINGS["ar"])

    if not db.get_setting_bool("services_store_enabled", True):
        dis_msg = {
            "en": "🔒 Offers & Services Store is currently paused by Admin.",
            "fr": "🔒 La Boutique Services est temporairement désactivée.",
            "ar": "🔒 متجر العروض والخدمات متوقف مؤقتاً من قبل الإدارة.",
        }.get(lang)
        await callback.answer(dis_msg, show_alert=True)
        return

    categories = db.get_store_categories(only_active=True)
    root_services = db.get_store_services(only_active=True, category_id=0)
    bal_str = fmt_tok(db.get_user_balance(user_id))

    if not categories and not root_services:
        empty_txt = {
            "en": (
                "🛍️ <b>Offers & Services Store — PLAYX1 ZONE</b>\n"
                "━━━━━━━━━━━━━━━━━━━━\n"
                "📭 <i>No active offers or categories available right now. Check back soon!</i>"
            ),
            "fr": (
                "🛍️ <b>Boutique Services & Offres — PLAYX1 ZONE</b>\n"
                "━━━━━━━━━━━━━━━━━━━━\n"
                "📭 <i>Aucune offre disponible pour le moment. Revenez bientôt !</i>"
            ),
            "ar": (
                "🛍️ <b>متجر العروض والخدمات — PLAYX1 ZONE</b>\n"
                "━━━━━━━━━━━━━━━━━━━━\n"
                "📭 <i>لا توجد فئات أو عروض متاحة حالياً، ترقّب العروض الحصرية قريباً!</i>"
            ),
        }.get(lang)
        kb = InlineKeyboardBuilder()
        kb.button(text=t["home"], callback_data="nav_home", style="primary")
        await safe_show(callback, empty_txt, reply_markup=kb.as_markup(), prefer_edit=True)
        await callback.answer()
        return

    if lang == "en":
        text = (
            "🛍️ <b>Offers & Services Store — PLAYX1 ZONE</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"💳 <b>Your Wallet:</b> <code>{bal_str}</code> Tokens\n"
            "📂 <i>Browse categories or select a direct offer below:</i>"
        )
    elif lang == "fr":
        text = (
            "🛍️ <b>Boutique Services & Offres — PLAYX1 ZONE</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"💳 <b>Votre Solde :</b> <code>{bal_str}</code> Tokens\n"
            "📂 <i>Choisissez une catégorie ou une offre directe ci-dessous :</i>"
        )
    else:
        text = (
            "🛍️ <b>متجر العروض والخدمات — PLAYX1 ZONE</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"💳 <b>رصيد محفظتك:</b> <code>{bal_str}</code> توكن\n"
            "📂 <i>اختر فئة لاستعراض العروض بداخلها أو اختر عرضاً مباشراً من القائمة:</i>"
        )

    builder = InlineKeyboardBuilder()
    for cat in categories:
        cnt_in_cat = len(db.get_store_services(only_active=True, category_id=cat["id"]))
        builder.button(
            text=f"📁 {cat['name']} ({cnt_in_cat})",
            callback_data=f"srv_cat_{cat['id']}",
            style="success"
        )
    for srv in root_services:
        price_tag = _format_service_price_summary(srv)
        builder.button(
            text=f"🎁 {srv['title']} ({price_tag})",
            callback_data=f"srv_view_{srv['id']}",
            style="primary"
        )
    builder.button(text=t["home"], callback_data="nav_home", style="danger")
    builder.adjust(1)
    await safe_show(callback, text, reply_markup=builder.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.callback_query(F.data.startswith("srv_cat_"))
async def cb_srv_category(callback: types.CallbackQuery):
    user_id = callback.from_user.id
    lang = db.get_user_language(user_id) or "ar"
    t = STRINGS.get(lang, STRINGS["ar"])

    if not db.get_setting_bool("services_store_enabled", True):
        await callback.answer("🔒 Store is currently disabled.", show_alert=True)
        return

    try:
        cat_id = int(callback.data.split("srv_cat_")[1])
    except ValueError:
        await callback.answer()
        return

    cat = db.get_store_category_by_id(cat_id)
    if not cat or not cat.get("is_active"):
        await callback.answer("⚠️ Category not found or disabled.", show_alert=True)
        return

    services = db.get_store_services(only_active=True, category_id=cat_id)
    bal_str = fmt_tok(db.get_user_balance(user_id))

    desc_block = f"📝 {cat['description']}\n━━━━━━━━━━━━━━━━━━━━\n" if cat.get("description") else ""
    text = (
        f"📁 <b>{cat['name']} — PLAYX1 ZONE</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"{desc_block}"
        f"💳 <b>رصيد محفظتك:</b> <code>{bal_str}</code> توكن\n"
        "✨ <i>اختر العرض المطلوب من هذه الفئة:</i>"
    )

    builder = InlineKeyboardBuilder()
    for srv in services:
        price_tag = _format_service_price_summary(srv)
        builder.button(
            text=f"🎁 {srv['title']} ({price_tag})",
            callback_data=f"srv_view_{srv['id']}",
            style="primary"
        )
    builder.button(text=t["back"], callback_data="nav_services_store", style="danger")
    builder.adjust(1)
    await safe_show(callback, text, reply_markup=builder.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.callback_query(F.data.startswith("srv_view_"))
async def cb_srv_view(callback: types.CallbackQuery):
    user_id = callback.from_user.id
    lang = db.get_user_language(user_id) or "ar"
    t = STRINGS.get(lang, STRINGS["ar"])

    if not db.get_setting_bool("services_store_enabled", True):
        await callback.answer("🔒 Store is currently disabled.", show_alert=True)
        return

    try:
        srv_id = int(callback.data.split("srv_view_")[1])
    except ValueError:
        await callback.answer()
        return

    srv = db.get_store_service_by_id(srv_id)
    if not srv or not srv.get("is_active"):
        await callback.answer("⚠️ Offer is no longer available.", show_alert=True)
        return

    p_stars = int(srv.get("price_stars") or 0)
    p_tok = round(float(srv.get("price_tokens") or 0), 4)
    p_usdt = str(srv.get("price_usdt") or "").strip()
    is_bundle = bool(int(srv.get("bundle_mode") or 0))
    bal_str = fmt_tok(db.get_user_balance(user_id))
    cat_id = int(srv.get("category_id") or 0)
    back_cb = f"srv_cat_{cat_id}" if cat_id > 0 else "nav_services_store"

    price_lines = []
    builder = InlineKeyboardBuilder()

    if is_bundle and p_stars > 0 and p_tok > 0:
        price_lines.append(f"🔗 <b>سعر العرض المدمج:</b> <code>{p_stars}</code> نجمة + خصم <code>{fmt_tok(p_tok)}</code> توكن معاً")
        builder.button(
            text=f"⚡ شراء العرض المدمج ({p_stars} ⭐ + {fmt_tok(p_tok)} 🪙)",
            callback_data=f"srv_buybundle_{srv_id}",
            style="success"
        )
    else:
        if p_stars > 0:
            price_lines.append(f"⭐ <b>السعر بالنجوم:</b> <code>{p_stars}</code> نجمة تليجرام")
            builder.button(text=f"⭐ شراء بالنجوم ({p_stars} ⭐)", callback_data=f"srv_buystar_{srv_id}", style="success")
        if p_tok > 0:
            price_lines.append(f"🪙 <b>السعر بالتوكن:</b> <code>{fmt_tok(p_tok)}</code> توكن")
            builder.button(text=f"🪙 شراء بالتوكن ({fmt_tok(p_tok)} 🪙)", callback_data=f"srv_buytok_{srv_id}", style="primary")

    if p_usdt:
        price_lines.append(f"💵 <b>السعر عبر USDT:</b> <code>{p_usdt}</code>")
        builder.button(text=f"💵 دفع عبر USDT ({p_usdt})", callback_data=f"srv_buyusdt_{srv_id}", style="success")

    if not price_lines:
        price_lines.append("🎁 <b>العرض:</b> متاح للتواصل وطلب التنفيذ")
        builder.button(text="📩 طلب العرض والتواصل مع الإدارة", callback_data=f"srv_buyusdt_{srv_id}", style="success")

    text = (
        f"🎁 <b>{srv['title']}</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"📝 <b>تفاصيل العرض والخدمة:</b>\n{srv.get('description') or 'خدمة حصرية ومضمونة من فريق PLAYX1 ZONE.'}\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        + "\n".join(price_lines) + "\n"
        f"💳 <b>رصيدك الحالي:</b> <code>{bal_str}</code> توكن"
    )

    builder.button(text=t["back"], callback_data=back_cb, style="danger")
    builder.adjust(1)
    await safe_show(callback, text, reply_markup=builder.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.callback_query(F.data.startswith("srv_buystar_"))
async def cb_srv_buy_star(callback: types.CallbackQuery):
    user_id = callback.from_user.id
    if not db.get_setting_bool("services_store_enabled", True):
        await callback.answer("🔒 Store is disabled.", show_alert=True)
        return

    try:
        srv_id = int(callback.data.split("srv_buystar_")[1])
    except ValueError:
        await callback.answer()
        return

    srv = db.get_store_service_by_id(srv_id)
    if not srv or not srv.get("is_active") or int(srv.get("price_stars") or 0) <= 0:
        await callback.answer("⚠️ Stars payment is not available for this offer.", show_alert=True)
        return

    stars = int(srv["price_stars"])
    await callback.bot.send_invoice(
        chat_id=user_id,
        title=f"🎁 {srv['title']}"[:32],
        description=(srv.get("description") or f"Service order: {srv['title']}")[:250],
        payload=f"srv_buy_{user_id}_{srv_id}_{stars}",
        currency="XTR",
        prices=[LabeledPrice(label=srv["title"][:32], amount=stars)],
        provider_token="",
    )
    await callback.answer()


@dp.callback_query(F.data.startswith("srv_buybundle_"))
async def cb_srv_buy_bundle(callback: types.CallbackQuery):
    user_id = callback.from_user.id
    if not db.get_setting_bool("services_store_enabled", True):
        await callback.answer("🔒 Store is disabled.", show_alert=True)
        return

    try:
        srv_id = int(callback.data.split("srv_buybundle_")[1])
    except ValueError:
        await callback.answer()
        return

    srv = db.get_store_service_by_id(srv_id)
    if not srv or not srv.get("is_active"):
        await callback.answer("⚠️ Offer is not available.", show_alert=True)
        return

    stars = int(srv.get("price_stars") or 0)
    req_tok = round(float(srv.get("price_tokens") or 0), 4)
    cur_bal = db.get_user_balance(user_id)
    if req_tok > 0 and cur_bal < req_tok:
        await callback.answer(f"⚠️ رصيد التوكن غير كافٍ للعرض المدمج! المطلوب {fmt_tok(req_tok)} توكن ورصيدك {fmt_tok(cur_bal)}.", show_alert=True)
        return

    await callback.bot.send_invoice(
        chat_id=user_id,
        title=f"⚡ {srv['title']}"[:32],
        description=f"{srv['title']} (+ {fmt_tok(req_tok)} Tokens bundle)"[:250],
        payload=f"srv_buy_{user_id}_{srv_id}_{stars}",
        currency="XTR",
        prices=[LabeledPrice(label=srv["title"][:32], amount=stars)],
        provider_token="",
    )
    await callback.answer()


@dp.callback_query(F.data.startswith("srv_buytok_"))
async def cb_srv_buy_tok(callback: types.CallbackQuery):
    user_id = callback.from_user.id
    lang = db.get_user_language(user_id) or "ar"
    t = STRINGS.get(lang, STRINGS["ar"])

    if not db.get_setting_bool("services_store_enabled", True):
        await callback.answer("🔒 Store is disabled.", show_alert=True)
        return

    try:
        srv_id = int(callback.data.split("srv_buytok_")[1])
    except ValueError:
        await callback.answer()
        return

    ok, code, info = db.purchase_service_with_tokens(user_id, srv_id)
    if not ok:
        if code == "INSUFFICIENT":
            await callback.answer("⚠️ رصيدك من التوكن غير كافٍ لشراء هذا العرض!", show_alert=True)
        else:
            await callback.answer("⚠️ تعذر إتمام العملية حالياً.", show_alert=True)
        return

    order_code = info["order_code"]
    srv_title = info["service_title"]
    paid_str = fmt_tok(info["amount_paid"])
    rem_str = fmt_tok(info["new_balance"])
    payer_uname = f"@{callback.from_user.username}" if callback.from_user.username else "بدون يوزر"

    user_receipt = (
        "🧾 <b>فاتورة شراء خدمة — PLAYX1 ZONE</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"🔢 <b>رقم الفاتورة:</b> <code>{order_code}</code>\n"
        f"🎁 <b>الخدمة المطلوبة:</b> {srv_title}\n"
        f"🪙 <b>المبلغ المخصوم:</b> <code>{paid_str}</code> توكن\n"
        f"💳 <b>رصيدك المتبقي:</b> <code>{rem_str}</code> توكن\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "✅ <i>تم إرسال فاتورة طلبك للإدارة بنجاح، سيتم التواصل معك قريباً لتنفيذ الخدمة!</i>"
    )
    kb = InlineKeyboardBuilder()
    kb.button(text=t["home"], callback_data="nav_home", style="primary")
    await safe_show(callback, user_receipt, reply_markup=kb.as_markup(), prefer_edit=True)
    await callback.answer("✅")

    admin_invoice = (
        "🧾 <b>فاتورة طلب خدمة جديدة (دفع بالتوكن)</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"🔢 <b>رقم الفاتورة:</b> <code>{order_code}</code>\n"
        f"🎁 <b>العرض / الخدمة:</b> {srv_title}\n"
        f"🪙 <b>القيمة المدفوعة:</b> <code>{paid_str}</code> توكن\n"
        f"👤 <b>العميل:</b> {callback.from_user.full_name} ({payer_uname})\n"
        f"🆔 <b>معرّف العميل:</b> <code>{user_id}</code>"
    )
    adm_kb = InlineKeyboardBuilder()
    adm_kb.button(text="💬 مراسلة العميل عبر البوت", callback_data=f"admin_u_dm_{user_id}", style="success")
    adm_kb.button(text="👤 فتح ملف العميل", callback_data=f"admin_inspect_{user_id}", style="primary")
    adm_kb.adjust(1)
    for adm_id in ADMIN_IDS:
        try:
            await bot.send_message(adm_id, admin_invoice, reply_markup=adm_kb.as_markup(), parse_mode="HTML")
        except Exception:
            pass


@dp.callback_query(F.data.startswith("srv_buyusdt_"))
async def cb_srv_buy_usdt(callback: types.CallbackQuery):
    user_id = callback.from_user.id
    lang = db.get_user_language(user_id) or "ar"
    t = STRINGS.get(lang, STRINGS["ar"])

    if not db.get_setting_bool("services_store_enabled", True):
        await callback.answer("🔒 Store is disabled.", show_alert=True)
        return

    try:
        srv_id = int(callback.data.split("srv_buyusdt_")[1])
    except ValueError:
        await callback.answer()
        return

    srv = db.get_store_service_by_id(srv_id)
    if not srv or not srv.get("is_active"):
        await callback.answer("⚠️ Offer is not available.", show_alert=True)
        return

    usdt_price = str(srv.get("price_usdt") or "حسب الاتفاق").strip()
    order_code = db.record_service_usdt_order(user_id, srv_id, srv["title"], usdt_price)
    payer_uname = f"@{callback.from_user.username}" if callback.from_user.username else "بدون يوزر"

    user_receipt = (
        "💵 <b>طلب دفع عبر USDT — PLAYX1 ZONE</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"🔢 <b>رقم الفاتورة:</b> <code>{order_code}</code>\n"
        f"🎁 <b>العرض المطلوب:</b> {srv['title']}\n"
        f"💵 <b>قيمة العرض (USDT):</b> <code>{usdt_price}</code>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "📩 <i>تم إرسال طلبك مباشرة إلى الإدارة؛ سيتواصل معك الأدمن لتزويدك بعنوان المحفظة/الشبكة وتأكيد الطلب.</i>"
    )
    kb = InlineKeyboardBuilder()
    kb.button(text=t["home"], callback_data="nav_home", style="primary")
    await safe_show(callback, user_receipt, reply_markup=kb.as_markup(), prefer_edit=True)
    await callback.answer("💵 تم إرسال طلب الدفع بـ USDT للإدارة!")

    admin_invoice = (
        "💵🧾 <b>طلب شراء جديد عبر USDT (تواصل مباشر)</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"🔢 <b>رقم الفاتورة:</b> <code>{order_code}</code>\n"
        f"🎁 <b>العرض / الخدمة:</b> {srv['title']}\n"
        f"💵 <b>السعر المطلوب بـ USDT:</b> <code>{usdt_price}</code>\n"
        f"👤 <b>العميل:</b> {callback.from_user.full_name} ({payer_uname})\n"
        f"🆔 <b>معرّف العميل:</b> <code>{user_id}</code>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "💡 <i>اضغط على زر المراسلة لإرسال عنوان المحفظة والشبكة للعميل وإتمام العملية.</i>"
    )
    adm_kb = InlineKeyboardBuilder()
    adm_kb.button(text="💬 مراسلة العميل وإرسال عنوان USDT", callback_data=f"admin_u_dm_{user_id}", style="success")
    adm_kb.button(text="👤 فتح ملف العميل", callback_data=f"admin_inspect_{user_id}", style="primary")
    adm_kb.adjust(1)
    for adm_id in ADMIN_IDS:
        try:
            await bot.send_message(adm_id, admin_invoice, reply_markup=adm_kb.as_markup(), parse_mode="HTML")
        except Exception:
            pass


@dp.callback_query(F.data == "admin_services_cfg")
async def cb_admin_services_cfg(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    st_en = db.get_setting_bool("services_store_enabled", True)
    categories = db.get_store_categories(only_active=False)
    services = db.get_store_services(only_active=False)

    cat_lines = []
    builder = InlineKeyboardBuilder()
    builder.button(
        text=f"🛍️ زر المتجر: {a['on'] if st_en else a['off']}",
        callback_data="adm_srv_toggle_store",
        style="success" if st_en else "danger"
    )
    builder.button(text="📁 إضافة فئة جديدة", callback_data="adm_cat_add", style="success")
    builder.button(text="➕ إضافة عرض / خدمة", callback_data="adm_srv_add", style="success")
    builder.button(text="🧾 سجل الفواتير", callback_data="adm_srv_orders", style="primary")

    for c in categories:
        c_ico = "🟢" if c["is_active"] else "🔴"
        c_cnt = len(db.get_store_services(only_active=False, category_id=c["id"]))
        cat_lines.append(f"{c_ico} 📁 <b>{c['name']}</b> ({c_cnt} عرض)")
        builder.button(text=f"📁 {c['name'][:14]}", callback_data=f"adm_cat_tog_{c['id']}", style="primary")
        builder.button(text="🗑️ فئة", callback_data=f"adm_cat_del_{c['id']}", style="danger")

    srv_lines = []
    for s in services:
        ico = "🟢" if s["is_active"] else "🔴"
        p_info = _format_service_price_summary(s)
        cat_id = int(s.get("category_id") or 0)
        cat_obj = db.get_store_category_by_id(cat_id) if cat_id > 0 else None
        loc_tag = f"📁 {cat_obj['name']}" if cat_obj else "🏠 مباشر"
        srv_lines.append(f"{ico} <b>{s['title']}</b> [{loc_tag}] — <code>{p_info}</code>")
        builder.button(text=f"💰 {s['title'][:12]}", callback_data=f"adm_srv_price_{s['id']}", style="primary")
        builder.button(text="🔗 مدمج" if int(s.get("bundle_mode") or 0) else "🔀 خيار", callback_data=f"adm_srv_bundle_{s['id']}", style="success")
        builder.button(text="⏸️" if s["is_active"] else "▶️", callback_data=f"adm_srv_tog_{s['id']}", style="primary")
        builder.button(text="🗑️", callback_data=f"adm_srv_del_{s['id']}", style="danger")

    text = (
        "🛍️ <b>إدارة متجر العروض والفئات والخدمات — PLAYX1 ZONE</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"⚡ <b>حالة المتجر:</b> {a['on'] if st_en else a['off']}\n"
        "📁 <b>الفئات:</b>\n"
        + ("\n".join(cat_lines) if cat_lines else "<i>لا توجد فئات مضافة بعد.</i>") + "\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "🎁 <b>العروض والخدمات:</b>\n"
        + ("\n".join(srv_lines) if srv_lines else "<i>لا توجد عروض مضافة بعد.</i>")
    )
    builder.button(text=a["btn_back_admin"], callback_data="admin_menu", style="danger")
    row_pattern = [2, 2] + ([2] * len(categories)) + ([4] * len(services)) + [1]
    builder.adjust(*row_pattern)
    await safe_show(callback, text, reply_markup=builder.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.callback_query(F.data == "adm_srv_toggle_store")
async def cb_adm_srv_toggle_store(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    cur = db.get_setting_bool("services_store_enabled", True)
    db.set_setting("services_store_enabled", "0" if cur else "1")
    db.log_admin_action(callback.from_user.id, "TOGGLE_SERVICES_STORE", f"val={0 if cur else 1}")
    await cb_admin_services_cfg(callback)


@dp.callback_query(F.data == "adm_cat_add")
async def cb_adm_cat_add(callback: types.CallbackQuery, state: FSMContext):
    if callback.from_user.id not in ADMIN_IDS:
        return
    await state.set_state(AdminForm.waiting_for_new_category)
    kb = InlineKeyboardBuilder()
    kb.button(text="✖️ إلغاء", callback_data="admin_services_cfg", style="danger")
    prompt = (
        "📁 <b>إضافة فئة جديدة داخل المتجر</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "أرسل اسم الفئة (أو الاسم مع الوصف مفصولين بـ <code>|</code>):\n"
        "مثال: <code>الإلكترونيات | عروض وأجهزة مختارة</code>\n"
        "أو فقط: <code>الحسابات المميزة</code>"
    )
    await safe_show(callback, prompt, reply_markup=kb.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.message(AdminForm.waiting_for_new_category)
async def process_adm_cat_add(message: types.Message, state: FSMContext):
    if message.from_user.id not in ADMIN_IDS:
        return
    raw = (message.text or "").strip()
    if not raw:
        await message.answer("⚠️ يرجى إرسال اسم الفئة.", parse_mode="HTML")
        return
    if "|" in raw:
        c_name, c_desc = [x.strip() for x in raw.split("|", 1)]
    else:
        c_name, c_desc = raw, ""
    if not c_name:
        await message.answer("⚠️ اسم الفئة لا يمكن أن يكون فارغاً.", parse_mode="HTML")
        return

    db.create_store_category(c_name, c_desc)
    db.log_admin_action(message.from_user.id, "ADD_STORE_CATEGORY", c_name)
    await state.clear()
    kb = InlineKeyboardBuilder()
    kb.button(text="🛍️ العودة لإدارة المتجر", callback_data="admin_services_cfg", style="primary")
    await message.answer(f"✅ تم إنشاء الفئة <b>{c_name}</b> بنجاح! يمكنك الآن إضافة عروض بداخلها.", reply_markup=kb.as_markup(), parse_mode="HTML")


@dp.callback_query(F.data.startswith("adm_cat_tog_"))
async def cb_adm_cat_tog(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    cat_id = int(callback.data.split("adm_cat_tog_")[1])
    db.toggle_store_category_active(cat_id)
    await cb_admin_services_cfg(callback)


@dp.callback_query(F.data.startswith("adm_cat_del_"))
async def cb_adm_cat_del(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    cat_id = int(callback.data.split("adm_cat_del_")[1])
    db.delete_store_category(cat_id, move_services_to_root=True)
    await callback.answer("🗑️ تم حذف الفئة ونقل عروضها إلى المتجر المباشر.", show_alert=True)
    await cb_admin_services_cfg(callback)


@dp.callback_query(F.data == "adm_srv_orders")
async def cb_adm_srv_orders(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    orders = db.get_recent_service_orders(12)
    lines = []
    builder = InlineKeyboardBuilder()
    for o in orders:
        uname = f"@{o['username']}" if o.get("username") else str(o["user_id"])
        pm = o.get("payment_method") or "STARS"
        unit = "⭐" if "STARS" in pm else ("💵 USDT" if pm == "USDT" else "🪙")
        lines.append(f"• <code>{o['order_code']}</code> | <b>{o['service_title']}</b> ({fmt_tok(o['amount_paid'])} {unit}) — {uname}")
        builder.button(text=f"💬 {uname} ({o['order_code'][-4:]})", callback_data=f"admin_u_dm_{o['user_id']}", style="primary")

    text = (
        "🧾 <b>أحدث فواتير متجر العروض والخدمات</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        + ("\n".join(lines) if lines else "<i>لا توجد طلبات مسجلة بعد.</i>")
    )
    builder.button(text="↩️ إدارة المتجر", callback_data="admin_services_cfg", style="danger")
    builder.adjust(1)
    await safe_show(callback, text, reply_markup=builder.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.callback_query(F.data == "adm_srv_add")
async def cb_adm_srv_add(callback: types.CallbackQuery, state: FSMContext):
    if callback.from_user.id not in ADMIN_IDS:
        return
    categories = db.get_store_categories(only_active=False)
    await state.set_state(AdminForm.waiting_for_new_service)

    cat_hint = "0 (مباشر في المتجر)"
    if categories:
        cat_hint = "0 (مباشر) أو رقم الفئة: " + " ، ".join([f"<code>{c['id']}</code>={c['name']}" for c in categories])

    kb = InlineKeyboardBuilder()
    kb.button(text="✖️ إلغاء", callback_data="admin_services_cfg", style="danger")
    prompt = (
        "➕ <b>إضافة عرض أو خدمة جديدة</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "أرسل بيانات العرض مفصولة بعلامة <code>|</code> بالصيغة:\n"
        "<code>الاسم | الوصف | النجوم | التوكن | USDT | رقم_الفئة | مدمج(0/1)</code>\n\n"
        f"📁 <b>الفئات:</b> {cat_hint}\n"
        "🔗 <b>مدمج(0/1):</b> <code>0</code> للاختيار بين النجوم أو التوكن ، <code>1</code> لخصم النجوم والتوكن معاً!\n\n"
        "📌 <b>أمثلة:</b>\n"
        "• نجوم فقط (30 نجمة، مباشر):\n"
        "<code>حل مشكلة البند | حل كامل وسريع | 30 | 0 | - | 0 | 0</code>\n"
        "• نجوم + خصم توكن معاً (30 نجمة + 5 توكن):\n"
        "<code>باقة VIP | تفعيل فوري | 30 | 5 | - | 0 | 1</code>\n"
        "• دفع عبر USDT فقط داخل فئة رقم 1:\n"
        "<code>هاتف ذكي | عرض خاص | 0 | 0 | 120$ | 1 | 0</code>"
    )
    await safe_show(callback, prompt, reply_markup=kb.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.message(AdminForm.waiting_for_new_service)
async def process_adm_srv_add(message: types.Message, state: FSMContext):
    if message.from_user.id not in ADMIN_IDS:
        return
    parts = [p.strip() for p in (message.text or "").split("|")]
    if len(parts) < 4 or not parts[0]:
        await message.answer("⚠️ صيغة غير صحيحة! يرجى مراجعة المثال وإرسال البيانات بشكل صحيح.", parse_mode="HTML")
        return

    title = parts[0]
    desc = parts[1] if len(parts) > 1 else ""
    stars_raw = (parts[2] if len(parts) > 2 else "0").replace(",", ".")
    try:
        stars_val = int(float(stars_raw)) if stars_raw not in ("", "-", "0") else 0
    except ValueError:
        stars_val = -1

    tok_raw = parts[3] if len(parts) > 3 and parts[3] not in ("", "-") else "0"
    tok_val = parse_float_val(tok_raw)

    usdt_raw = parts[4].strip() if len(parts) > 4 and parts[4].strip() not in ("", "-", "0") else ""
    cat_id = int(parts[5]) if len(parts) > 5 and parts[5].strip().isdigit() else 0
    bundle_mode = 1 if (len(parts) > 6 and parts[6].strip() in ("1", "true", "نعم", "yes")) else 0

    if stars_val < 0 or tok_val is None or (stars_val == 0 and tok_val == 0 and not usdt_raw):
        await message.answer("⚠️ يجب تحديد سعر بالنجوم أو بالتوكن أو عبر USDT.", parse_mode="HTML")
        return

    db.create_store_service(
        title=title,
        description=desc,
        price_stars=stars_val,
        price_tokens=tok_val,
        category_id=cat_id,
        price_usdt=usdt_raw,
        bundle_mode=bundle_mode,
    )
    db.log_admin_action(message.from_user.id, "ADD_SERVICE", f"{title} ({stars_val}⭐/{tok_val}🪙/{usdt_raw} cat={cat_id} b={bundle_mode})")
    await state.clear()
    kb = InlineKeyboardBuilder()
    kb.button(text="🛍️ العودة لإدارة المتجر", callback_data="admin_services_cfg", style="primary")
    await message.answer(
        f"✅ <b>تم إضافة العرض بنجاح!</b>\n\n"
        f"🎁 <b>العرض:</b> {title}\n"
        f"💰 <b>التسعير:</b> <code>{stars_val} ⭐</code> | <code>{fmt_tok(tok_val)} 🪙</code> | <code>{usdt_raw or '—'}</code>\n"
        f"📁 <b>الفئة:</b> <code>{cat_id}</code> | 🔗 <b>مدمج:</b> <code>{bundle_mode}</code>",
        reply_markup=kb.as_markup(),
        parse_mode="HTML"
    )


@dp.callback_query(F.data.startswith("adm_srv_price_"))
async def cb_adm_srv_price(callback: types.CallbackQuery, state: FSMContext):
    if callback.from_user.id not in ADMIN_IDS:
        return
    srv_id = int(callback.data.split("adm_srv_price_")[1])
    await state.update_data(edit_srv_id=srv_id)
    await state.set_state(AdminForm.waiting_for_edit_service_price)
    kb = InlineKeyboardBuilder()
    kb.button(text="✖️ إلغاء", callback_data="admin_services_cfg", style="danger")
    await safe_show(
        callback,
        "💰 <b>تعديل أسعار العرض</b>\n━━━━━━━━━━━━━━━━━━━━\n"
        "أرسل الأسعار بالصيغة:\n<code>النجوم التوكن USDT</code>\n\n"
        "مثال نجوم فقط: <code>30 0 -</code>\n"
        "مثال نجوم + توكن: <code>30 5 -</code>\n"
        "مثال إضافة USDT: <code>30 5 15 USDT</code>",
        reply_markup=kb.as_markup(),
        prefer_edit=True
    )
    await callback.answer()


@dp.message(AdminForm.waiting_for_edit_service_price)
async def process_adm_srv_price(message: types.Message, state: FSMContext):
    if message.from_user.id not in ADMIN_IDS:
        return
    raw = (message.text or "").strip()
    parts = raw.split()
    if len(parts) < 2 or not parts[0].replace(".", "", 1).isdigit():
        await message.answer("⚠️ الصيغة المطلوبة: <code>30 5 -</code> أو <code>30 0 10$</code>", parse_mode="HTML")
        return
    stars_v = int(float(parts[0]))
    tok_v = parse_float_val(parts[1])
    usdt_v = " ".join(parts[2:]).strip() if len(parts) >= 3 and " ".join(parts[2:]).strip() != "-" else ""
    if tok_v is None or (stars_v == 0 and tok_v == 0 and not usdt_v):
        await message.answer("⚠️ قيمة السعر غير صالحة.", parse_mode="HTML")
        return
    data = await state.get_data()
    srv_id = data.get("edit_srv_id")
    db.update_store_service_pricing(srv_id, stars_v, tok_v, price_usdt=usdt_v)
    db.log_admin_action(message.from_user.id, "UPDATE_SERVICE_PRICE", f"id={srv_id} {stars_v}⭐/{tok_v}🪙/{usdt_v}")
    await state.clear()
    kb = InlineKeyboardBuilder()
    kb.button(text="🛍️ إدارة المتجر", callback_data="admin_services_cfg", style="primary")
    await message.answer("✅ تم تحديث أسعار العرض بنجاح!", reply_markup=kb.as_markup(), parse_mode="HTML")


@dp.callback_query(F.data.startswith("adm_srv_bundle_"))
async def cb_adm_srv_bundle(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    srv_id = int(callback.data.split("adm_srv_bundle_")[1])
    new_b = db.toggle_store_service_bundle_mode(srv_id)
    await callback.answer(f"🔗 وضع السعر المدمج: {'مفعّل (نجوم + توكن معاً)' if new_b else 'متوقف (اختيار بينهما)'}", show_alert=True)
    await cb_admin_services_cfg(callback)


@dp.callback_query(F.data.startswith("adm_srv_tog_"))
async def cb_adm_srv_tog(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    srv_id = int(callback.data.split("adm_srv_tog_")[1])
    db.toggle_store_service_active(srv_id)
    await cb_admin_services_cfg(callback)


@dp.callback_query(F.data.startswith("adm_srv_del_"))
async def cb_adm_srv_del(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    srv_id = int(callback.data.split("adm_srv_del_")[1])
    db.delete_store_service(srv_id)
    db.log_admin_action(callback.from_user.id, "DELETE_SERVICE", f"id={srv_id}")
    await callback.answer("🗑️ تم حذف العرض نهائياً.", show_alert=True)
    await cb_admin_services_cfg(callback)




@dp.callback_query(F.data == "adm_set_clear_cache")
async def cb_adm_set_clear_cache(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    import gc
    _SUB_CACHE.clear()
    db._SETTINGS_CACHE.clear()
    gc.collect()
    await callback.answer("🧹 تم تنظيف الكاش في الذاكرة وتخفيف استهلاك الرام!", show_alert=True)
    await cb_admin_settings(callback)


async def main():
    db.init_db()
    logger.info("Database initialized.")
    try:
        await bot.set_my_short_description(short_description="⚡ PLAYX1 ZONE — Smart Play Points Hub")
        await bot.set_my_description(
            description=(
                "⚡ منصة PLAYX1 ZONE لإدارة ومساعدة مهام ومكافآت Google Play Points بسرعة وأمان.\n"
                "📡 قناتنا الرسمية: https://t.me/PLAYX1_ZONE"
            )
        )
    except Exception as e:
        logger.warning("Error setting bot descriptions: %s", e)
    logger.info("Starting PLAYX1 ZONE bot polling...")
    try:
        await dp.start_polling(bot)
    finally:
        await bot.session.close()


if __name__ == "__main__":
    asyncio.run(main())
