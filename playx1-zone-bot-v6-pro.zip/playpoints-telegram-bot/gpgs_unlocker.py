import requests
import time
from typing import Dict, Any, Optional

GPGS_BASE = "https://games.googleapis.com/games/v1"


class GPGSUnlocker:
    def __init__(self, access_token: str):
        self.access_token = access_token
        self.player_not_found = False
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {self.access_token}",
            "Content-Type": "application/json",
            "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 14; Pixel 8 Pro Build/UD1A.230803.041)"
        })

    def auto_provision_profile(self) -> bool:

        url = f"{GPGS_BASE}/applications/played"
        try:
            resp = self.session.post(url, timeout=15)
            if resp.status_code in [200, 204]:
                self.player_not_found = False
                return True
        except Exception as e:
            print(f"[!] Error auto-provisioning GPGS profile: {e}")
        return False

    def sign_in_game(self) -> bool:

        success = False
        try:
            url_played = f"{GPGS_BASE}/applications/played"
            resp = self.session.post(url_played, timeout=15)
            print(f"[GPGS] applications/played: {resp.status_code}")
            if resp.status_code in [200, 204]:
                success = True


            url_player = f"{GPGS_BASE}/players/me"
            r_player = self.session.get(url_player, timeout=15)
            if r_player.status_code == 200:
                success = True
        except Exception as e:
            print(f"[!] Error in sign_in_game: {e}")
        return success

    def get_player_profile(self) -> Optional[Dict[str, Any]]:

        url = f"{GPGS_BASE}/players/me"
        try:
            resp = self.session.get(url, timeout=15)
            if resp.status_code == 200:
                data = resp.json()
                level_info = data.get("experienceInfo", {})
                return {
                    "displayName": data.get("displayName", "Gamer"),
                    "level": level_info.get("currentLevel", {}).get("level", 1),
                    "xp": level_info.get("currentExperiencePoints", 0)
                }
            elif resp.status_code == 404:
                print("[!] Profile missing (404). Auto-provisioning Google Play Games profile...")
                if self.auto_provision_profile():
                    time.sleep(1)
                    retry_resp = self.session.get(url, timeout=15)
                    if retry_resp.status_code == 200:
                        data = retry_resp.json()
                        level_info = data.get("experienceInfo", {})
                        print(f"[+] Auto-created Play Games profile: {data.get('displayName')}")
                        return {
                            "displayName": data.get("displayName", "Gamer"),
                            "level": level_info.get("currentLevel", {}).get("level", 1),
                            "xp": level_info.get("currentExperiencePoints", 0)
                        }
                self.player_not_found = True
                print(f"[!] GPGS player profile not found (404): {resp.text[:200]}")
            else:
                print(f"[!] GPGS profile error: {resp.status_code} {resp.text[:200]}")
        except Exception as e:
            print(f"[!] Error fetching GPGS profile: {e}")
        return None

    def unlock_achievement(self, achievement_id: str, steps: int = 5) -> bool:

        url = f"{GPGS_BASE}/achievements/{achievement_id}/unlock"
        try:
            resp = self.session.post(url, timeout=15)
            print(f"[GPGS] unlock {achievement_id}: {resp.status_code}")
            if resp.status_code in [200, 204]:
                return True


            inc_url = f"{GPGS_BASE}/achievements/{achievement_id}/increment"
            inc_resp = self.session.post(inc_url, params={"stepsToIncrement": steps}, timeout=15)
            print(f"[GPGS] increment {achievement_id}: {inc_resp.status_code}")
            if inc_resp.status_code in [200, 204]:
                return True

            if resp.status_code == 404 or inc_resp.status_code == 404:
                print(f"[!] 404 encountered during unlock. Auto-provisioning player profile...")
                if self.auto_provision_profile():
                    time.sleep(1)
                    retry = self.session.post(url, timeout=15)
                    if retry.status_code in [200, 204]:
                        return True
                    retry_inc = self.session.post(inc_url, params={"stepsToIncrement": steps}, timeout=15)
                    if retry_inc.status_code in [200, 204]:
                        return True

            print(f"[GPGS] unlock response: {resp.text[:300]}")
            return False
        except requests.exceptions.RequestException as e:
            print(f"[!] GPGS unlock error: {e}")
            return False

    def increment_achievement(self, achievement_id: str, steps: int = 1) -> bool:

        url = f"{GPGS_BASE}/achievements/{achievement_id}/increment"
        params = {"stepsToIncrement": steps}
        try:
            resp = self.session.post(url, params=params, timeout=15)
            print(f"[GPGS] increment {achievement_id}: {resp.status_code}")
            if resp.status_code in [200, 204]:
                return True
            print(f"[GPGS] increment response: {resp.text[:300]}")
            return False
        except requests.exceptions.RequestException as e:
            print(f"[!] GPGS increment error: {e}")
            return False

    def list_achievements(self, game_id: str) -> Optional[list]:

        url = f"{GPGS_BASE}/achievements"
        try:
            resp = self.session.get(url, timeout=15)
            if resp.status_code == 200:
                data = resp.json()
                return data.get("items", [])
            print(f"[GPGS] list achievements: {resp.status_code} {resp.text[:200]}")
        except Exception as e:
            print(f"[!] Error listing achievements: {e}")
        return None

    def record_event(self, package_name: Optional[str] = None, event_name: str = "", amount: int = 1, property_name: str = "amount", **kwargs) -> bool:

        import uuid
        import datetime
        pkg = package_name or kwargs.get("package") or ""
        try:
            player_resp = self.session.get(f"{GPGS_BASE}/players/me", timeout=15)
            if player_resp.status_code != 200:
                print(f"[GPGS] Failed to get player id for event {event_name}: {player_resp.status_code}")
                return False
            player_id = player_resp.json().get("playerId")
            if not player_id:
                return False

            now = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
            payload = {
                "requestTime": now,
                "packageName": pkg,
                "events": [
                    {
                        "eventId": str(uuid.uuid4()),
                        "eventName": event_name,
                        "eventTime": now,
                        "eventProperties": {
                            property_name: {"intValue": str(amount)}
                        }
                    }
                ]
            }
            url = f"{GPGS_BASE}/players/{player_id}/gameStats:batchRecordEvents"
            resp = self.session.post(url, json=payload, timeout=15)
            print(f"[GPGS] record_event {event_name}={amount}: {resp.status_code} {resp.text[:100]}")
            return resp.status_code in [200, 204]
        except Exception as e:
            print(f"[!] Error recording GPGS event: {e}")
            return False

