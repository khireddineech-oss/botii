import sys
import os
import unittest
import tempfile
import sqlite3
from unittest.mock import MagicMock, patch

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import games_catalog
import database as db


class TestCatalogAndDb(unittest.TestCase):
    def test_lords_mobile_catalog(self):
        lm = games_catalog.GAMES_CATALOG.get("lords_mobile")
        self.assertIsNotNone(lm, "lords_mobile not found in catalog")
        self.assertEqual(lm["package"], "com.igg.android.lordsmobile")

        tasks = lm.get("tasks", [])
        titles = [t["title"] for t in tasks]


        signin_task = next((t for t in tasks if t.get("type") == "signin"), None)
        self.assertIsNotNone(signin_task, "lords_mobile missing signin task")
        self.assertIn("Play Games", signin_task["title"])


        skirmish_task = next((t for t in tasks if t.get("achievement_id") == "CgkIxunC2d8JEAIQDg"), None)
        self.assertIsNotNone(skirmish_task, "lords_mobile missing Skirmish 2 Ridge Attack task")
        self.assertEqual(skirmish_task["title"], "Complete Skirmish 2 Ridge Attack")


        castle_5 = next((t for t in tasks if t.get("achievement_id") == "CgkIxunC2d8JEAIQAg"), None)
        castle_10 = next((t for t in tasks if t.get("achievement_id") == "CgkIxunC2d8JEAIQAw"), None)
        castle_15 = next((t for t in tasks if t.get("achievement_id") == "CgkIxunC2d8JEAIQBA"), None)
        self.assertIsNotNone(castle_5, "Missing Castle Lv 5")
        self.assertIsNotNone(castle_10, "Missing Castle Lv 10")
        self.assertIsNotNone(castle_15, "Missing Castle Lv 15")
        print("✅ Lords Mobile catalog verification passed!")

    def test_evony_catalog(self):

        self.assertIn("evony", games_catalog.GAMES_CATALOG)
        self.assertIn("kings_return", games_catalog.GAMES_CATALOG)
        evony = games_catalog.GAMES_CATALOG["evony"]
        self.assertEqual(evony["package"], "com.topgamesinc.evony")

        tasks = evony.get("tasks", [])

        signin_task = next((t for t in tasks if t.get("type") == "signin"), None)
        self.assertIsNotNone(signin_task, "evony missing signin task")


        recruit_task = next((t for t in tasks if t.get("achievement_id") == "CgkI3fiGx4gPEAIQGw"), None)
        self.assertIsNotNone(recruit_task, "evony missing Recruit More task")
        self.assertEqual(recruit_task["title"], "Recruit More")


        general_task = next((t for t in tasks if t.get("achievement_id") == "CgkI3fiGx4gPEAIQGg"), None)
        self.assertIsNotNone(general_task, "evony missing Well-seasoned General task")
        self.assertEqual(general_task["title"], "Well-seasoned General")


        rename_task = next((t for t in tasks if t.get("achievement_id") == "CgkI3fiGx4gPEAIQFw"), None)
        working_task = next((t for t in tasks if t.get("achievement_id") == "CgkI3fiGx4gPEAIQGA"), None)
        dev_task = next((t for t in tasks if t.get("achievement_id") == "CgkI3fiGx4gPEAIQGQ"), None)
        self.assertIsNotNone(rename_task)
        self.assertIsNotNone(working_task)
        self.assertIsNotNone(dev_task)
        print("✅ Evony catalog verification passed!")

    def test_carrom_pool_catalog(self):
        self.assertIn("carrom_pool", games_catalog.GAMES_CATALOG)
        self.assertIn("carrom", games_catalog.GAMES_CATALOG)
        cp = games_catalog.GAMES_CATALOG["carrom_pool"]
        self.assertEqual(cp["package"], "com.miniclip.carrom")

        tasks = cp.get("tasks", [])
        signin_task = next((t for t in tasks if t.get("type") == "signin"), None)
        self.assertIsNotNone(signin_task, "carrom_pool missing signin task")

        rookie = next((t for t in tasks if t.get("achievement_id") == "CgkIw8fZ1Z8dEAIQAQ"), None)
        london = next((t for t in tasks if t.get("achievement_id") == "CgkIw8fZ1Z8dEAIQEw"), None)
        streak = next((t for t in tasks if t.get("achievement_id") == "CgkIw8fZ1Z8dEAIQCA"), None)
        self.assertIsNotNone(rookie)
        self.assertIsNotNone(london)
        self.assertIsNotNone(streak)
        print("✅ Carrom Pool catalog verification passed!")

    def test_package_and_alias_lookups(self):

        self.assertEqual(games_catalog.GAMES_CATALOG["com.topgamesinc.evony"]["name"], "Evony: The King's Return")
        self.assertEqual(games_catalog.GAMES_CATALOG["com.igg.android.lordsmobile"]["name"], "Lords mobile")
        self.assertEqual(games_catalog.GAMES_CATALOG["com.miniclip.carrom"]["name"], "Carrom Pool")

        self.assertIn("EVONY", games_catalog.GAMES_CATALOG)
        self.assertIn("Carrom", games_catalog.GAMES_CATALOG)
        self.assertEqual(games_catalog.GAMES_CATALOG.get("Evony")["package"], "com.topgamesinc.evony")
        print("✅ Package and case-insensitive catalog lookup passed!")

    def test_database_saved_accounts_pagination(self):

        temp_dir = tempfile.mkdtemp()
        temp_db_path = os.path.join(temp_dir, "test.db")
        original_db_path = db.DB_PATH
        db.DB_PATH = temp_db_path
        try:
            db.init_db()
            test_user = 99999999


            for i in range(15):
                db.save_account(test_user, f"acc{i}@gmail.com", f"pwd{i}")

            total_count = db.count_saved_accounts(test_user)
            self.assertEqual(total_count, 15, f"Expected 15 accounts, got {total_count}")


            all_accs = db.get_saved_accounts(test_user)
            self.assertEqual(len(all_accs), 15, "get_saved_accounts without limit should return all 15")


            self.assertIn("id", all_accs[0])
            self.assertIn("email", all_accs[0])
            self.assertIn("password", all_accs[0])


            p1 = db.get_saved_accounts(test_user, limit=6, offset=0)
            self.assertEqual(len(p1), 6)


            p2 = db.get_saved_accounts(test_user, limit=6, offset=6)
            self.assertEqual(len(p2), 6)


            p3 = db.get_saved_accounts(test_user, limit=6, offset=12)
            self.assertEqual(len(p3), 3)


            emails_p1 = {a["email"] for a in p1}
            emails_p2 = {a["email"] for a in p2}
            self.assertTrue(emails_p1.isdisjoint(emails_p2))


            first_id = all_accs[0]["id"]
            acc_by_id = db.get_saved_account_by_id(test_user, first_id)
            self.assertIsNotNone(acc_by_id)
            self.assertEqual(acc_by_id["email"], all_accs[0]["email"])


            acc_by_email = db.get_saved_account_by_email(test_user, "acc0@gmail.com")
            self.assertIsNotNone(acc_by_email)
            self.assertEqual(acc_by_email["password"], "pwd0")

            print("✅ Database saved_accounts pagination verification passed!")
        finally:
            db.DB_PATH = original_db_path
            if os.path.exists(temp_db_path):
                os.remove(temp_db_path)


if __name__ == "__main__":
    unittest.main()
