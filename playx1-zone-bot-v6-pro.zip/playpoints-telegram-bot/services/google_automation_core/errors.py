class GoogleAutomationError(Exception):
    pass
