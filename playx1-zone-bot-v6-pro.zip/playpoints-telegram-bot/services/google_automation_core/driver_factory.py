import logging
import os
import platform
from typing import Optional

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service

import config
from services.device_simulator import DeviceProfile, PIXEL_10_PRO_SPECS as SPECS
from services.google_automation_core.errors import GoogleAutomationError

logger = logging.getLogger(__name__)


def _detect_chrome_binary() -> Optional[str]:
    import shutil
    chrome_bin = (
        os.environ.get("CHROME_BIN")
        or shutil.which("chromium")
        or shutil.which("chromium-browser")
        or shutil.which("google-chrome")
        or shutil.which("chrome")
        or shutil.which("chrome.exe")
    )
    if chrome_bin:
        return chrome_bin
    if platform.system() == "Windows":
        for candidate in [
            os.path.join(os.environ.get("PROGRAMFILES", ""),      "Google", "Chrome", "Application", "chrome.exe"),
            os.path.join(os.environ.get("PROGRAMFILES(X86)", ""), "Google", "Chrome", "Application", "chrome.exe"),
            os.path.join(os.environ.get("LOCALAPPDATA", ""),      "Google", "Chrome", "Application", "chrome.exe"),
        ]:
            if candidate and os.path.exists(candidate):
                return candidate
    return None


def _parse_proxy(proxy_str: str) -> dict | None:

    if not proxy_str:
        return None
    parts = proxy_str.strip().split(":")
    if len(parts) == 2:
        return {"http": f"http://{proxy_str}", "https": f"http://{proxy_str}"}
    if len(parts) == 4:
        ip, port, user, pw = parts
        auth = f"{user}:{pw}@{ip}:{port}"
        return {"http": f"http://{auth}", "https": f"http://{auth}"}
    logger.warning("Unrecognized proxy format: %s", proxy_str)
    return None


def build_driver(profile: DeviceProfile, proxy: str | None = None) -> webdriver.Chrome:

    options = Options()


    if config.HEADLESS:
        options.add_argument("--headless=new")


    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--no-zygote")
    options.add_argument("--disable-gpu-sandbox")
    options.add_argument("--metrics-recording-only")
    options.add_argument("--mute-audio")
    options.add_argument("--disable-gpu")
    options.add_argument("--disable-extensions")
    options.add_argument("--disable-infobars")
    options.add_argument("--disable-notifications")
    options.add_argument("--disable-software-rasterizer")
    options.add_argument("--disable-features=VizDisplayCompositor")
    options.add_argument("--disable-crash-reporter")
    options.add_argument("--disable-background-networking")
    options.add_argument("--disable-default-apps")
    options.add_argument("--disable-translate")
    options.add_argument("--no-first-run")
    options.add_argument("--renderer-process-limit=2")
    options.add_argument("--js-flags=--max-old-space-size=256")
    options.add_argument("--disable-ipc-flooding-protection")


    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_experimental_option("excludeSwitches", ["enable-automation"])
    options.add_experimental_option("useAutomationExtension", False)


    mobile_emulation = {
        "deviceMetrics": {
            "width":       SPECS["width"],
            "height":      SPECS["height"],
            "pixelRatio":  SPECS["pixel_ratio"],
            "mobile":      True,
            "touch":       True,
        },
        "userAgent": profile.user_agent,
    }
    options.add_experimental_option("mobileEmulation", mobile_emulation)


    if proxy:
        parts = proxy.strip().split(":")
        if len(parts) >= 2:
            ip, port = parts[0], parts[1]
            options.add_argument(f"--proxy-server=http://{ip}:{port}")
            logger.info("Using proxy: %s:%s", ip, port)


    chrome_bin = _detect_chrome_binary()
    if chrome_bin:
        options.binary_location = chrome_bin
        logger.info("Chrome binary: %s", chrome_bin)
    else:
        logger.warning("CHROME_BIN not found — using Selenium Manager fallback.")

    chromedriver_path = os.environ.get("CHROMEDRIVER_PATH") or __import__("shutil").which("chromedriver")

    if chromedriver_path:
        driver = webdriver.Chrome(service=Service(chromedriver_path), options=options)
    else:
        driver = webdriver.Chrome(options=options)

    driver.implicitly_wait(0)
    driver.set_page_load_timeout(config.PAGE_LOAD_TIMEOUT)


    tz, lat, lng = config.get_random_timezone_geo()
    try:
        driver.execute_cdp_cmd("Page.addScriptToEvaluateOnNewDocument",
                               {"source": profile.navigator_overrides_js()})
        driver.execute_cdp_cmd("Network.setExtraHTTPHeaders",
                               {"headers": profile.as_headers()})
        driver.execute_cdp_cmd("Emulation.setTouchEmulationEnabled",
                               {"enabled": True, "maxTouchPoints": SPECS["max_touch_points"]})
        driver.execute_cdp_cmd("Emulation.setTimezoneOverride", {"timezoneId": tz})
        driver.execute_cdp_cmd("Emulation.setGeolocationOverride",
                               {"latitude": lat, "longitude": lng, "accuracy": 50})
        logger.info("Session %s | model=%s | tz=%s | proxy=%s",
                    profile.session_id[:8], profile.model, tz, proxy or "none")
    except Exception as exc:
        logger.warning("CDP override failed (non-fatal): %s", exc)

    return driver
