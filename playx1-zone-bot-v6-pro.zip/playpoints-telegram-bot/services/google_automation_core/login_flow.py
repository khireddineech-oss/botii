import logging
import re
import time
from urllib.parse import urlparse

from selenium import webdriver
from selenium.common.exceptions import (
    NoSuchElementException,
    StaleElementReferenceException,
    TimeoutException,
    WebDriverException,
)
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

import config
from services.google_automation_core.errors import GoogleAutomationError

logger = logging.getLogger(__name__)

CHALLENGE_PATHS = ("/signin/v2/challenge", "/signin/challenge", "/v2/challenge", "/v3/signin/challenge", "/challenge")


def _wait(driver, by, value, timeout=config.WEBDRIVER_TIMEOUT) -> WebElement:
    return WebDriverWait(driver, timeout).until(EC.element_to_be_clickable((by, value)))


def _on_challenge_page(driver) -> bool:
    parsed = urlparse(driver.current_url)
    path = parsed.path or ""

    if "challenge/pwd" in path or path.endswith("/pwd"):
        return False
    return (parsed.hostname or "") == "accounts.google.com" and "challenge" in path


def _type_human(field, text: str):

    field.clear()
    field.send_keys(text)
    time.sleep(0.1)


def detect_number_challenge(driver, timeout: int = 10) -> str | None:

    start_time = time.time()
    while time.time() - start_time < timeout:
        try:
            try:
                page_text = driver.find_element(By.TAG_NAME, "body").text
            except Exception:
                page_text = driver.page_source

            for pattern in (
                r"tap\s*(\d{1,3})\s*on your phone",
                r"(?:is this your number|select this number|tap.*number|confirm.*number)[^\d]*(\d{2})",
                r"(\d{2})\s*(?:on your phone|on your device|from your)",
                r"choose.*?(\b\d{2}\b)",
                r"\b(\d{2})\b\s*\n\s*Check your phone",
            ):
                m = re.search(pattern, page_text, re.IGNORECASE | re.DOTALL)
                if m:
                    return m.group(1)

            for selector in ('[data-challengetype="39"]', '[data-challengeui="NUMBER_MATCH"]'):
                try:
                    el = driver.find_element(By.CSS_SELECTOR, selector)
                    m = re.search(r"\b(\d{2})\b", el.text)
                    if m:
                        return m.group(1)
                except NoSuchElementException:
                    pass

            for tag in ("h1", "h2", "h3", "div", "span"):
                for el in driver.find_elements(By.TAG_NAME, tag):
                    try:
                        if re.match(r"^\d{2}$", el.text.strip()):
                            return el.text.strip()
                    except Exception:
                        pass
        except Exception as exc:
            logger.warning("Error detecting number challenge: %s", exc)

        time.sleep(0.8)
    return None


def wait_for_number_confirm(driver, timeout: int = 120) -> bool:

    start = time.time()
    while time.time() - start < timeout:
        try:
            for c in driver.get_cookies():
                if c.get("name") == "oauth_token":
                    logger.info("Number confirm: oauth_token cookie found directly!")
                    return True
            if not _on_challenge_page(driver):
                logger.info("Number confirm: succeeded (%s)", driver.current_url)
                return True
        except Exception:
            pass
        time.sleep(0.5)
    logger.warning("Number confirm: timed out after %ds", timeout)
    return False


def _try_switch_to_totp(driver) -> bool:

    totp_xpaths = (
        '//*[@data-challengetype="6"]',
        '//div[@data-challengetype="6"]',
        '//div[contains(text(),"Authenticator")]',
        '//div[contains(text(),"authenticator")]',
        '//div[contains(text(),"verification code")]',
        '//li[contains(.,"Authenticator")]',
    )
    for xpath in totp_xpaths:
        try:
            driver.find_element(By.XPATH, xpath).click()
            time.sleep(1.5)
            return True
        except NoSuchElementException:
            pass


    for xpath in (
        '//a[contains(text(),"another way")]',
        '//button[contains(text(),"another way")]',
        '//span[contains(text(),"another way")]/ancestor::button',
    ):
        try:
            driver.find_element(By.XPATH, xpath).click()
            time.sleep(1.5)
            break
        except NoSuchElementException:
            pass

    for xpath in totp_xpaths:
        try:
            driver.find_element(By.XPATH, xpath).click()
            time.sleep(1.5)
            return True
        except NoSuchElementException:
            pass

    return False


def gmail_login(driver, email: str, password: str) -> str:

    try:
        driver.get(config.GMAIL_LOGIN_URL)
        time.sleep(0.3)


        for attempt in range(3):
            try:
                field = None
                for sel in ('#identifierId', 'input[name="identifier"]', 'input[type="email"]', 'input[type="text"]'):
                    try:
                        field = WebDriverWait(driver, 4).until(EC.element_to_be_clickable((By.CSS_SELECTOR, sel)))
                        if field and field.is_displayed():
                            break
                    except Exception:
                        continue
                if field:
                    _type_human(field, email)
                    break
            except StaleElementReferenceException:
                logger.warning("Stale email field, retry %d/3", attempt + 1)
                time.sleep(0.3)
        else:
            raise GoogleAutomationError("Email field stale after 3 retries")

        _wait(driver, By.ID, "identifierNext").click()
        time.sleep(1.2)


        pw_typed = False
        for attempt in range(4):
            try:
                pw_field = None
                for sel in ('input[name="Passwd"]', 'input[type="password"]', 'input[name="password"]'):
                    try:
                        pw_field = WebDriverWait(driver, 6).until(EC.element_to_be_clickable((By.CSS_SELECTOR, sel)))
                        if pw_field and pw_field.is_displayed():
                            break
                    except Exception:
                        continue

                if pw_field:
                    time.sleep(0.3)
                    _type_human(pw_field, password)
                    pw_typed = True
                    break
            except (StaleElementReferenceException, NoSuchElementException):
                logger.warning("Stale password field, retry %d/4", attempt + 1)
                time.sleep(0.8)

        if not pw_typed:
            raise GoogleAutomationError("Password field not found or stale")

        for btn_sel in ("passwordNext", 'button[jsname="LgbsSe"]', 'button[type="button"]'):
            try:
                btn = driver.find_element(By.ID if not btn_sel.startswith("button") else By.CSS_SELECTOR, btn_sel)
                if btn.is_displayed():
                    btn.click()
                    break
            except Exception:
                pass

        time.sleep(1.5)
        for _ in range(8):
            try:
                err = driver.find_element(By.CSS_SELECTOR, '[jsname="B34EJ"],[aria-live="assertive"]')
                if err.is_displayed() and err.text.strip():
                    err_txt = err.text.strip()
                    logger.warning("Password submission error for %s: %s", email, err_txt)
                    raise GoogleAutomationError(f"Google login failed: {err_txt}")
            except NoSuchElementException:
                pass

            curr_path = urlparse(driver.current_url).path or ""
            if not curr_path.endswith("/pwd") and "challenge/pwd" not in curr_path:
                break
            time.sleep(0.5)


        parsed = urlparse(driver.current_url)
        hostname = parsed.hostname or ""
        path     = parsed.path or ""

        if _on_challenge_page(driver):

            number = detect_number_challenge(driver, timeout=8)
            if number:
                logger.info("Number challenge for %s — number: %s", email, number)
                return f"needs_number_confirm:{number}"


            for sel in ('input[type="tel"]', 'input[name="totpPin"]', '#totpPin'):
                try:
                    driver.find_element(By.CSS_SELECTOR, sel)
                    return "needs_totp"
                except NoSuchElementException:
                    pass


            if _try_switch_to_totp(driver):
                return "needs_totp"


            try:
                body_txt = driver.find_element(By.TAG_NAME, "body").text.lower()
            except Exception:
                body_txt = ""


            if any(k in body_txt for k in ["tap yes", "check your phone", "google prompt", "اضغط على نعم", "appuyez sur oui"]):
                logger.info("Tap Yes Google prompt detected for %s", email)
                return "needs_tap_yes"


            if "security key" in body_txt or "fido" in body_txt or "usb" in body_txt:
                ctype = "security key / passkey"
            elif "sms" in body_txt or "text message" in body_txt:
                ctype = "SMS verification"
            else:
                ctype = "two-step verification"

            logger.warning("Challenge page for %s: %s | text: %s", email, driver.current_url, body_txt[:250].replace('\n', ' '))
            try:
                clean_em = re.sub(r'[^a-zA-Z0-9]', '_', email)
                driver.save_screenshot(f"/tmp/challenge_{clean_em}.png")
            except Exception:
                pass

            raise GoogleAutomationError(
                f"Account requires {ctype}. Use an App Password instead."
            )

        if hostname == "myaccount.google.com" or (
            hostname.endswith(".google.com") and "/u/" in path
        ):
            return "success"


        try:
            body_text = driver.find_element(By.TAG_NAME, "body").text
            lower_body = body_text.lower()
            if "wrong password" in lower_body or "mot de passe incorrect" in lower_body or "كلمة المرور غير صحيحة" in body_text:
                logger.warning("Google reported wrong password for %s", email)
                raise GoogleAutomationError("كلمة المرور غير صحيحة (Wrong password). يرجى التأكد من كتابة كلمة المرور بدقة.")
            err = driver.find_element(By.CSS_SELECTOR, '[jsname="B34EJ"],[aria-live="assertive"]')
            if err.is_displayed() and err.text:
                logger.warning("Login error element: %s", err.text[:100])
                raise GoogleAutomationError(f"Google login failed: {err.text.strip()}")
        except NoSuchElementException:
            pass


        if (hostname == "accounts.google.com" or hostname.endswith(".google.com")) and ("signin" in path or "challenge" in path):
            return "failed"

        return "success"

    except (TimeoutException, WebDriverException) as exc:
        logger.error("Login error for %s: %s", email, exc)
        return "failed"


def submit_totp_code(driver, code: str) -> bool:

    try:
        field = None
        for sel in ('input[type="tel"]', 'input[name="totpPin"]', '#totpPin', 'input[type="text"]'):
            try:
                field = WebDriverWait(driver, 3).until(EC.element_to_be_clickable((By.CSS_SELECTOR, sel)))
                break
            except TimeoutException:
                continue

        if not field:
            return False

        _type_human(field, code)
        time.sleep(config.human_delay(300, 700))

        for btn in ("#totpNext", 'button[jsname="LgbsSe"]', '[data-action="verify"]', 'button[type="submit"]'):
            try:
                driver.find_element(By.CSS_SELECTOR, btn).click()
                break
            except NoSuchElementException:
                continue

        time.sleep(config.human_delay(1500, 2500))

        parsed = urlparse(driver.current_url)
        if (parsed.hostname or "") == "accounts.google.com" and "challenge" in (parsed.path or ""):
            return False
        return True

    except Exception as exc:
        logger.error("Error submitting TOTP: %s", exc)
        return False
