import logging
from typing import Optional

from services.device_simulator import DeviceProfile
from services.google_automation_core.driver_factory import build_driver
from services.google_automation_core.errors import GoogleAutomationError
from services.google_automation_core.login_flow import (
    gmail_login,
    submit_totp_code,
    wait_for_number_confirm,
)
from services.google_automation_core.offer_scanner import navigate_google_one

import config

logger = logging.getLogger(__name__)


def start_login(email: str, password: str, device: DeviceProfile,
                proxy: str | None = None) -> tuple:

    selected_proxy = proxy or config.get_random_proxy()
    logger.info("Session %s | proxy=%s", device.session_id[:8], selected_proxy or "none")

    driver = build_driver(device, proxy=selected_proxy)
    try:
        status = gmail_login(driver, email, password)
        if status == "failed":
            driver.quit()
            raise GoogleAutomationError("Login failed — check credentials.")
        return driver, status
    except GoogleAutomationError:
        driver.quit()
        raise
    except Exception as exc:
        driver.quit()
        raise GoogleAutomationError(f"Unexpected login error: {exc}") from exc


def submit_2fa_code(driver, code: str) -> bool:
    return submit_totp_code(driver, code)


def wait_for_number_login(driver, timeout: int = 120) -> bool:
    return wait_for_number_confirm(driver, timeout)


def check_offer_with_driver(driver) -> Optional[str]:
    return navigate_google_one(driver)


def close_driver(driver) -> None:
    if driver:
        try:
            driver.quit()
        except Exception:
            pass
