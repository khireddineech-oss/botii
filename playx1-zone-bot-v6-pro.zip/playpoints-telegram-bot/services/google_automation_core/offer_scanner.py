import logging
import os
import time
from datetime import datetime
from typing import Optional

from selenium import webdriver
from selenium.common.exceptions import (
    NoSuchElementException,
    TimeoutException,
    WebDriverException,
)
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

import config

logger = logging.getLogger(__name__)


_SCREENSHOT_DIR = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "..", "..", "..", "logs", "screenshots"
)


def _save_screenshot(driver, label: str) -> None:

    try:
        os.makedirs(_SCREENSHOT_DIR, exist_ok=True)
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        path = os.path.join(_SCREENSHOT_DIR, f"{ts}_{label}.png")
        driver.save_screenshot(path)
        logger.info("Screenshot saved: %s", path)
    except Exception as exc:
        logger.warning("Could not save screenshot: %s", exc)


def _wait_for_page(driver, extra_sleep: float = 0) -> None:

    try:
        WebDriverWait(driver, 15).until(
            lambda d: d.execute_script("return document.readyState") == "complete"
        )
    except TimeoutException:
        pass
    if extra_sleep:
        time.sleep(extra_sleep)


def _dismiss_cookie_banner(driver) -> None:

    for selector in (
        '[aria-label="Accept all"]',
        'button[jsname="higCR"]',
        '[data-action="accept"]',
        'button[aria-label*="Accept"]',
        'button[aria-label*="agree"]',
    ):
        try:
            driver.find_element(By.CSS_SELECTOR, selector).click()
            time.sleep(0.8)
            return
        except NoSuchElementException:
            continue


def _scroll_full_page(driver) -> None:

    try:
        total_height = driver.execute_script("return document.body.scrollHeight")
        step = 400
        current = 0
        while current < total_height:
            driver.execute_script(f"window.scrollTo(0, {current});")
            time.sleep(0.3)
            current += step

        driver.execute_script("window.scrollTo(0, 0);")
        time.sleep(0.5)
    except Exception as exc:
        logger.warning("Scroll error (non-fatal): %s", exc)


def _is_offer_url(url: str) -> bool:

    return bool(url) and "partner-eft-onboard" in url


def _is_whitelisted_domain(url: str) -> bool:

    if not url:
        return False
    from urllib.parse import urlparse
    host = urlparse(url).hostname or ""
    return any(host == d or host.endswith("." + d) for d in config.OFFER_DOMAIN_WHITELIST)


def _find_offer_elements(driver) -> list:

    candidates = []


    for tag in ("a", "button", "div", "span"):
        for el in driver.find_elements(By.TAG_NAME, tag):
            try:
                href = el.get_attribute("href") or el.get_attribute("data-href") or ""
                if "LOCKED" in href and "BARD_ADVANCED" in href:
                    candidates.append(("locked_href", el, href))
            except Exception:
                pass


    for el in driver.find_elements(By.TAG_NAME, "a"):
        try:
            href = el.get_attribute("href") or ""
            if _is_offer_url(href):
                candidates.append(("direct_url", el, href))
        except Exception:
            pass


    keywords = config.GEMINI_OFFER_KEYWORDS
    for el in driver.find_elements(By.TAG_NAME, "a"):
        try:
            href  = el.get_attribute("href") or ""
            label = (el.text + " " + (el.get_attribute("aria-label") or "")).lower()
            if (
                any(kw in label for kw in keywords)
                and _is_whitelisted_domain(href)
                and "LOCKED" not in href
            ):
                candidates.append(("keyword", el, href))
        except Exception:
            pass

    return candidates


def _click_and_capture(driver, el, old_url: str) -> Optional[str]:

    try:
        driver.execute_script("arguments[0].scrollIntoView({block:'center'});", el)
        time.sleep(0.5)
        driver.execute_script("arguments[0].click();", el)
        time.sleep(6)

        current_url = driver.current_url

        if _is_offer_url(current_url):
            return current_url


        for link in driver.find_elements(By.TAG_NAME, "a"):
            try:
                href = link.get_attribute("href") or ""
                if _is_offer_url(href):
                    return href
            except Exception:
                pass


        if "LOCKED" in current_url:
            logger.info("Stayed on LOCKED URL — offer not available")
            return None


        if current_url != old_url and _is_whitelisted_domain(current_url):
            return current_url

        return None
    except Exception as exc:
        logger.warning("Click-and-capture error: %s", exc)
        return None


def extract_offer_link(driver) -> Optional[str]:

    candidates = _find_offer_elements(driver)

    if not candidates:
        logger.info("No candidate offer elements found on page")
        return None

    logger.info("Found %d candidate element(s)", len(candidates))
    old_url = driver.current_url

    for strategy, el, hint in candidates:
        logger.info("Trying strategy=%s hint=%s", strategy, hint[:80] if hint else "")


        if strategy == "direct_url":
            return hint

        result = _click_and_capture(driver, el, old_url)
        if result:
            return result


        if driver.current_url != old_url:
            try:
                driver.back()
                time.sleep(2)
            except Exception:
                pass

    return None


def navigate_google_one(driver) -> Optional[str]:

    urls_to_try = [config.GOOGLE_ONE_URL, config.GOOGLE_ONE_OFFERS_URL]

    for url in urls_to_try:
        try:
            logger.info("Navigating to %s", url)
            driver.get(url)


            _wait_for_page(driver, extra_sleep=4)
            _dismiss_cookie_banner(driver)
            _scroll_full_page(driver)


            time.sleep(2)

            _save_screenshot(driver, f"scan_{url.split('/')[-1] or 'root'}")

            link = extract_offer_link(driver)
            if link:
                logger.info("Offer found: %s", link)
                _save_screenshot(driver, "offer_found")
                return link

            logger.info("No offer on %s", url)

        except (TimeoutException, WebDriverException) as exc:
            logger.warning("Error on %s: %s", url, exc)
            _save_screenshot(driver, "error")

    _save_screenshot(driver, "not_found_final")
    return None
