import json
import logging
import re
import time
import urllib.parse
from typing import Dict, Any, Optional

import requests
import gpsoauth
from selenium.webdriver.common.by import By

logger = logging.getLogger(__name__)

PERKS_URL = "https://play.google.com/store/points/perks"
BATCHEXECUTE_URL = "https://play.google.com/_/PlayStoreUi/data/batchexecute"
MOBILE_UA = (
    "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36"
)


def _detect_tier(html: str) -> str:
    for t in [
        "Platinum", "Gold", "Silver", "Bronze",
        "Platine", "Or", "Argent",
        "البلاتيني", "الذهبي", "الفضي", "البرونزي",
    ]:
        if f'"{t}"' in html or f">{t}<" in html or f'"{t.lower()}"' in html:
            if t in ("Platine", "البلاتيني"):
                return "Platinum"
            if t in ("Or", "الذهبي"):
                return "Gold"
            if t in ("Argent", "الفضي"):
                return "Silver"
            if t in ("Bronze", "البرونزي"):
                return "Bronze"
            return t.capitalize()
    return "Unknown"


def _parse_points_from_response(text: str) -> str:
    if not text:
        return "Unknown"
    m = re.search(r"\+\s*(\d+)", text)
    if m:
        return f"+{m.group(1)}"
    m2 = re.search(r"(\d+)\s*(?:نقطة|نقاط|pts|points)", text, re.IGNORECASE)
    if m2:
        return f"+{m2.group(1)}"
    m3 = re.search(r"(?:ربحت|ربِحت|won)\s+(\d+)", text, re.IGNORECASE)
    if m3:
        return f"+{m3.group(1)}"
    return "+Points"


def _attempt_batchexecute_claim(
    session: requests.Session,
    html: str,
    final_url: str,
    cookie_header: str,
    proxy: Optional[str] = None,
) -> Optional[Dict[str, Any]]:
    """
    Implements the WEEKLY_REWARD_PROB_{N} + rpcids=nTRzR batchexecute flow
    extracted from MainActivity.executeClaim.
    """
    at_m = re.search(r'"SNlM0e":"(.*?)"', html)
    if not at_m:
        return None

    at_token = at_m.group(1)
    sid_m = re.search(r'"f\.sid":(-?\d+)', html)
    f_sid = sid_m.group(1) if sid_m else "1234567890"

    prob_m = re.search(r"WEEKLY_REWARD_PROB_(\d+)", html)
    prob_num = prob_m.group(1) if prob_m else "3"

    auth_user = "0"
    auth_m = re.search(r"authuser-(\d+)", final_url or "")
    if auth_m:
        auth_user = auth_m.group(1)

    query_params = (
        f"?rpcids=nTRzR&source-path=%2Fstore%2Fpoints%2Fperks"
        f"&f.sid={urllib.parse.quote(str(f_sid))}"
        f"&hl=ar&authuser={urllib.parse.quote(str(auth_user))}"
        f"&soc-app=121&soc-platform=1&soc-device=2&rt=c"
    )
    endpoint = f"{BATCHEXECUTE_URL}{query_params}"

    prob_key = f"WEEKLY_REWARD_PROB_{prob_num}"
    f_req = json.dumps(
        [[["nTRzR", json.dumps([None, None, [prob_key, None, None, None, [prob_key]]]), None, "generic"]]],
        separators=(",", ":"),
    )
    body = (
        f"f.req={urllib.parse.quote(f_req, safe='')}"
        f"&at={urllib.parse.quote(at_token, safe='')}&"
    )

    headers = {
        "User-Agent": MOBILE_UA,
        "Content-Type": "application/x-www-form-urlencoded;charset=utf-8",
        "X-Same-Domain": "1",
        "Origin": "https://play.google.com",
        "Referer": PERKS_URL,
    }
    if cookie_header:
        headers["Cookie"] = cookie_header

    proxies = {"http": proxy, "https": proxy} if proxy else None
    resp = session.post(endpoint, data=body, headers=headers, proxies=proxies, timeout=20)
    claim_text = resp.text or ""

    try:
        decoded_text = claim_text.encode("utf-8").decode("unicode_escape")
    except Exception:
        decoded_text = claim_text
    combined_text = claim_text + "\n" + decoded_text

    if (
        ("ربحت" in combined_text)
        or ("ربِحت" in combined_text)
        or ("+" in combined_text and ("points" in combined_text.lower() or "نقاط" in combined_text or "نقطة" in combined_text))
    ):
        pts = _parse_points_from_response(combined_text)
        return {
            "status": "CLAIMED",
            "points": pts,
            "next_date": None,
            "tier": _detect_tier(html),
            "screenshot": None,
            "message": f"Weekly Prize claimed via nTRzR ({pts}).",
        }

    if ("متوفرة" in combined_text) or (
        "available" in combined_text.lower()
        and ("weekly" in combined_text.lower() or "friday" in combined_text.lower() or "prize" in combined_text.lower())
    ):
        avail_m = re.search(r'(?:available on|disponible le|متوفر في)\s*([A-Za-z0-9\s,]+?)(?:<|"|&|\n)', combined_text, re.I)
        next_d = avail_m.group(1).strip() if avail_m and len(avail_m.group(1).strip()) <= 30 else "next Friday"
        return {
            "status": "ALREADY_CLAIMED",
            "points": None,
            "next_date": next_d,
            "tier": _detect_tier(html),
            "screenshot": None,
            "message": f"Weekly Prize already claimed ({next_d}).",
        }

    return None


def fast_claim_weekly_perk(
    email: str,
    master_token: str,
    android_id: str,
    proxy: Optional[str] = None,
    screenshot_prefix: str = "/tmp/weekly",
) -> Dict[str, Any]:
    result = {
        "status": "UNKNOWN",
        "points": None,
        "next_date": None,
        "tier": "Unknown",
        "screenshot": None,
        "message": "",
    }

    try:
        res = gpsoauth.perform_oauth(
            email,
            master_token,
            android_id,
            "weblogin:continue=https%3A%2F%2Fplay.google.com%2Fstore%2Fpoints%2Fperks",
            "com.android.vending",
            "38918a453d07199354f8b19af05ec6562ced5788",
        )
        merge_url = res.get("Auth") if isinstance(res, dict) else None
        if not merge_url:
            logger.warning("Failed to obtain MergeSession URL for %s: %s", email, res)
            result["status"] = "AUTH_REQUIRED"
            result["message"] = "Session expired. Google requested re-authentication."
            return result

        session = requests.Session()
        session.headers.update({
            "User-Agent": MOBILE_UA,
            "Accept-Language": "ar,en-US;q=0.9,en;q=0.8",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
        })
        if proxy:
            session.proxies = {"http": proxy, "https": proxy}

        resp = session.get(merge_url, allow_redirects=True, timeout=20)
        html = resp.text or ""

        if "accounts.google.com" in (resp.url or "") or "signin" in (resp.url or "").lower():
            result["status"] = "AUTH_REQUIRED"
            result["message"] = "Session expired. Google requested re-authentication."
            return result

        tier = _detect_tier(html)
        result["tier"] = tier

        if tier == "Bronze" or ("bronze" in html.lower() and "weekly prize" in html.lower()):
            result["status"] = "NOT_ELIGIBLE"
            result["tier"] = "Bronze"
            result["message"] = "Account is Bronze tier. Weekly prizes unlock at Silver tier or higher."
            return result

        cookie_pairs = []
        for c in session.cookies:
            if "google.com" in (c.domain or ""):
                cookie_pairs.append(f"{c.name}={c.value}")
        cookie_header = "; ".join(cookie_pairs)

        rpc_res = _attempt_batchexecute_claim(
            session=session,
            html=html,
            final_url=resp.url or PERKS_URL,
            cookie_header=cookie_header,
            proxy=proxy,
        )
        if rpc_res:
            return rpc_res

        avail_m = re.search(r'(?:available on|disponible le|متوفر في)\s*([A-Za-z0-9\s,]+?)(?:<|"|&|\n)', html, re.I)
        is_already_claimed = False
        next_date = None

        if avail_m:
            next_date = avail_m.group(1).strip()
            if len(next_date) > 30 or "app" in next_date.lower():
                next_date = "next Friday"
            is_already_claimed = True
        elif (
            "next_reward_package" in html
            or "Next Silver prize" in html
            or "Next Gold prize" in html
            or "الجائزة التالية" in html
        ):
            is_already_claimed = True
            next_date = "next Friday"

        is_app_required = (
            '"73":' in html
            or "download the play store app" in html.lower()
            or "google play games on pc" in html.lower()
            or "sur un appareil android" in html.lower()
            or "نزِّل تطبيق" in html
            or "ألعاب google play على الكمبيوتر" in html.lower()
        )

        if is_app_required and not is_already_claimed:
            result["status"] = "APP_REQUIRED"
            result["message"] = (
                "Google Play requires claiming this reward directly on your mobile device (Play Store > Perks) or Google Play Games PC."
            )
            return result

        if is_already_claimed:
            result["status"] = "ALREADY_CLAIMED"
            result["next_date"] = next_date or "next Friday"
            result["message"] = f"Weekly Prize for this week is already claimed / locked! (Next: {result['next_date']})"
            return result

        claim_keywords = ["claim", "réclamer", "المطالبة"]
        if '"63":' in html and any(kw in html.lower() for kw in claim_keywords):
            logger.info("Account %s has WEB_CLAIMABLE prize! Triggering fallback browser claim...", email)
            try:
                from services.device_simulator import create_device_profile
                from services.google_automation_core.driver_factory import build_driver

                dev = create_device_profile()
                m_driver = build_driver(dev, proxy=proxy)
                try:
                    m_driver.get(merge_url)
                    time.sleep(5)
                    return claim_weekly_perk(m_driver, screenshot_prefix)
                finally:
                    m_driver.quit()
            except Exception as ex:
                logger.warning("Browser claim fallback failed: %s", ex)
                result["status"] = "ERROR"
                result["message"] = f"Failed to click claim: {ex}"
                return result

        result["status"] = "UNKNOWN"
        result["message"] = "Could not determine Weekly Prize status from Perks page."
        return result

    except Exception as e:
        logger.exception("Error in fast_claim_weekly_perk for %s: %s", email, e)
        result["status"] = "ERROR"
        result["message"] = str(e)
        return result


def is_element_enabled(el) -> bool:
    try:
        if el.get_attribute("disabled") is not None:
            return False
        if el.get_attribute("aria-disabled") == "true":
            return False
        classes = (el.get_attribute("class") or "").lower()
        if "disabled" in classes:
            return False
        return True
    except Exception:
        return False


def claim_weekly_perk(driver, screenshot_prefix: str = "/tmp/weekly") -> Dict[str, Any]:
    result = {
        "status": "UNKNOWN",
        "points": None,
        "next_date": None,
        "screenshot": None,
        "message": "",
    }

    try:
        curr_url = driver.current_url or ""
        if "points/perks" not in curr_url:
            logger.info("Navigating to Google Play Points Perks: %s", PERKS_URL)
            driver.get(PERKS_URL)
            time.sleep(4)
            curr_url = driver.current_url or ""

        logger.info("Perks page URL: %s (Title: %s)", curr_url, driver.title)

        if "accounts.google.com" in curr_url or "signin" in curr_url.lower():
            logger.warning("Not logged in or session expired on perks page: %s", curr_url)
            sc_path = f"{screenshot_prefix}_login_required.png"
            try:
                driver.save_screenshot(sc_path)
                result["screenshot"] = sc_path
            except Exception:
                pass
            result["status"] = "AUTH_REQUIRED"
            result["message"] = "Session expired. Google requested re-authentication."
            return result

        time.sleep(2)
        driver.execute_script("window.scrollTo(0, 300);")
        time.sleep(1)

        initial_sc = f"{screenshot_prefix}_page.png"
        try:
            driver.save_screenshot(initial_sc)
            result["screenshot"] = initial_sc
        except Exception:
            pass

        body_elem = driver.find_element(By.TAG_NAME, "body")
        body_text = body_elem.text if body_elem else ""
        html = driver.page_source or ""
        html_lower = html.lower()

        bal_match = re.search(r"(?:Silver|Gold|Platinum|Bronze|Argent|Or|Platine)\s*\n\s*(\d+)", body_text)
        initial_balance = int(bal_match.group(1)) if bal_match else None
        logger.info("Initial Play Points balance detected: %s", initial_balance)

        if "bronze" in html_lower and "weekly prize" in html_lower:
            logger.info("Account is in Bronze tier - weekly prizes start at Silver.")
            result["status"] = "NOT_ELIGIBLE"
            result["message"] = "Account is Bronze tier. Weekly prizes unlock at Silver tier or higher."
            return result

        claim_keywords = ["claim", "réclamer", "claim prize", "open", "ouvrir"]
        claim_btn = None

        for btn in driver.find_elements(By.TAG_NAME, "button"):
            try:
                if not btn.is_displayed():
                    continue
                if not is_element_enabled(btn):
                    continue
                text = (btn.get_attribute("innerText") or btn.text or "").strip().lower()
                aria = (btn.get_attribute("aria-label") or "").strip().lower()
                combined = f"{text} {aria}"
                if any(kw == text or kw in combined for kw in claim_keywords):
                    claim_btn = btn
                    break
            except Exception:
                continue

        if not claim_btn:
            for el in driver.find_elements(By.CSS_SELECTOR, 'div[role="button"], span, a'):
                try:
                    if not el.is_displayed():
                        continue
                    if not is_element_enabled(el):
                        continue
                    text = (el.get_attribute("innerText") or el.text or "").strip().lower()
                    if text in claim_keywords:
                        claim_btn = el
                        break
                except Exception:
                    continue

        if claim_btn:
            logger.info("Found ENABLED Claim button: '%s'! Clicking via JS...", getattr(claim_btn, "text", "Claim")[:30])
            try:
                driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", claim_btn)
                time.sleep(0.5)
            except Exception:
                pass

            driver.execute_script(
                """
                var el = arguments[0];
                var target = el.closest('[data-is-touch-wrapper]') || el.closest('button') || el;
                target.click();
                """,
                claim_btn,
            )

            time.sleep(5)

            claimed_sc = f"{screenshot_prefix}_claimed.png"
            try:
                driver.save_screenshot(claimed_sc)
                result["screenshot"] = claimed_sc
            except Exception:
                pass

            try:
                new_body_elem = driver.find_element(By.TAG_NAME, "body")
                new_body_text = new_body_elem.text if new_body_elem else ""
                new_bal_match = re.search(r"(?:Silver|Gold|Platinum|Bronze|Argent|Or|Platine)\s*\n\s*(\d+)", new_body_text)
                new_balance = int(new_bal_match.group(1)) if new_bal_match else None
            except Exception:
                new_balance = None

            if initial_balance is not None and new_balance is not None and new_balance > initial_balance:
                diff = new_balance - initial_balance
                points_won = f"+{diff}"
                result["status"] = "CLAIMED"
                result["points"] = points_won
                result["message"] = f"Weekly Prize successfully claimed: {points_won} Play Points!"
                return result

            dialogs = driver.find_elements(By.CSS_SELECTOR, '[role="dialog"], div[aria-modal="true"]')
            for d in dialogs:
                d_text = (d.text or "").strip()
                if any(err_kw in d_text.lower() for err_kw in ["something went wrong", "erreur s'est produite", "try again"]):
                    result["status"] = "ERROR"
                    result["message"] = "Google Play returned an error while claiming Weekly Prize."
                    return result

            if dialogs:
                d_text = dialogs[0].text
                pts_m = re.search(r"(\+\s*\d+)\s*(?:pts|points)?", d_text, re.IGNORECASE)
                if pts_m:
                    points_won = pts_m.group(1).replace(" ", "")
                    result["status"] = "CLAIMED"
                    result["points"] = points_won
                    result["message"] = f"Weekly Prize successfully claimed: {points_won} Play Points!"
                    return result

        app_required_keywords = [
            "téléchargez l'appli play store",
            "google play jeux sur pc",
            "download the play store app",
            "google play games on pc",
            "sur un appareil android ou un pc",
            "on an android device or a pc",
        ]
        if any(kw in html_lower for kw in app_required_keywords):
            result["status"] = "APP_REQUIRED"
            result["message"] = "Google Play requires claiming this reward directly on your mobile device or Play Games PC."
            return result

        available_elements = driver.find_elements(
            By.XPATH,
            '//*[contains(translate(text(), "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz"), "available on") or '
            'contains(translate(text(), "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz"), "disponible le") or '
            'contains(translate(text(), "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz"), "next prize") or '
            'contains(translate(text(), "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz"), "prochain prix")]',
        )
        if available_elements:
            avail_text = available_elements[0].text.strip()
            result["status"] = "ALREADY_CLAIMED"
            result["next_date"] = avail_text
            result["message"] = f"Weekly Prize already claimed ({avail_text})."
            return result

        for btn in driver.find_elements(By.TAG_NAME, "button"):
            try:
                t = (btn.text or "").strip().lower()
                if any(kw in t for kw in claim_keywords) and not is_element_enabled(btn):
                    result["status"] = "ALREADY_CLAIMED"
                    result["message"] = "Weekly Prize is currently locked."
                    return result
            except Exception:
                pass

        result["status"] = "UNKNOWN"
        result["message"] = "Could not locate Weekly Prize claim button on Perks page."
        return result

    except Exception as e:
        logger.exception("Error in claim_weekly_perk: %s", e)
        result["status"] = "ERROR"
        result["message"] = str(e)
        return result
