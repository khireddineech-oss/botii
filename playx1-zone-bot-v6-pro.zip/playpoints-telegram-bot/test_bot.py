import sys
import os
import unittest
import asyncio
from unittest.mock import MagicMock, AsyncMock, patch

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import bot
import database as db
import games_catalog
from gpgs_unlocker import GPGSUnlocker


class TestBotPaginationAndTasks(unittest.IsolatedAsyncioTestCase):
    async def test_render_quick_select_zero_accounts(self):
        cb = MagicMock()
        cb.from_user.id = 11111
        cb.answer = AsyncMock()
        cb.message = MagicMock()
        cb.message.answer = AsyncMock()
        cb.message.edit_text = AsyncMock()
        state = MagicMock()

        with patch("database.get_saved_accounts", return_value=[]), \
             patch("database.get_user_language", return_value="en"):
            await bot._render_quick_select(cb, state, page=0, edit=False)
            cb.answer.assert_called_once()
            self.assertIn("No saved accounts found", cb.answer.call_args[0][0])
            print("✅ Zero accounts edge case passed!")

    async def test_render_quick_select_pagination_pages(self):
        cb = MagicMock()
        cb.from_user.id = 22222
        cb.answer = AsyncMock()
        cb.message = MagicMock()
        cb.message.answer = AsyncMock()
        cb.message.edit_text = AsyncMock()
        state = MagicMock()

        dummy_accounts = [{"id": i, "email": f"user{i}@test.com", "password": f"p{i}"} for i in range(15)]

        with patch("database.get_saved_accounts", return_value=dummy_accounts), \
             patch("database.get_user_language", return_value="en"):

            await bot._render_quick_select(cb, state, page=0, edit=False)
            cb.message.answer.assert_called_once()
            call_kwargs = cb.message.answer.call_args[1]
            markup = call_kwargs["reply_markup"]
            buttons = [b.text for row in markup.inline_keyboard for b in row]
            self.assertIn("📨 user0@test.com", buttons)
            self.assertIn("📨 user5@test.com", buttons)
            self.assertNotIn("📨 user6@test.com", buttons)
            self.assertIn("📑 1/3", buttons)
            self.assertIn("Next ▶️", buttons)
            self.assertIn("✖️ Cancel", buttons)


            await bot._render_quick_select(cb, state, page=1, edit=True)
            cb.message.edit_text.assert_called_once()
            call_kwargs_edit = cb.message.edit_text.call_args[1]
            markup_edit = call_kwargs_edit["reply_markup"]
            buttons_edit = [b.text for row in markup_edit.inline_keyboard for b in row]
            self.assertIn("📨 user6@test.com", buttons_edit)
            self.assertIn("📨 user11@test.com", buttons_edit)
            self.assertIn("◀️ Prev", buttons_edit)
            self.assertIn("📑 2/3", buttons_edit)
            self.assertIn("Next ▶️", buttons_edit)
            print("✅ Quick select pagination pages passed!")

    async def test_use_saved_account_id_and_email(self):
        cb = MagicMock()
        cb.from_user.id = 33333
        cb.answer = AsyncMock()
        cb.message = MagicMock()
        cb.message.answer = AsyncMock()
        state = AsyncMock()
        state.get_data = AsyncMock(return_value={"game_name": "Lords Mobile"})
        state.update_data = AsyncMock()
        state.set_state = AsyncMock()


        cb.data = "use_acc_42"
        with patch("database.get_saved_account_by_id", return_value={"id": 42, "email": "test@gmail.com", "password": "secretpassword"}), \
             patch("database.get_user_balance", return_value=100), \
             patch("database.get_user_language", return_value="en"):
            await bot.use_saved_account(cb, state)
            state.update_data.assert_called_with(email="test@gmail.com", password="secretpassword")
            state.set_state.assert_called_with(bot.QuestForm.confirm_credentials)
            cb.message.answer.assert_called_once()


        cb2 = MagicMock()
        cb2.from_user.id = 33333
        cb2.data = "use_acc_legacy@gmail.com"
        cb2.answer = AsyncMock()
        cb2.message = MagicMock()
        cb2.message.answer = AsyncMock()
        state2 = AsyncMock()
        state2.get_data = AsyncMock(return_value={"game_name": "Lords Mobile"})

        with patch("database.get_saved_account_by_id", return_value=None), \
             patch("database.get_saved_account_by_email", return_value={"id": 7, "email": "legacy@gmail.com", "password": "legacypassword"}), \
             patch("database.get_user_balance", return_value=100), \
             patch("database.get_user_language", return_value="en"):
            await bot.use_saved_account(cb2, state2)
            state2.update_data.assert_called_with(email="legacy@gmail.com", password="legacypassword")
            state2.set_state.assert_called_with(bot.QuestForm.confirm_credentials)
            cb2.message.answer.assert_called_once()
            print("✅ ID and Email account lookup passed!")

    def test_execute_single_task_signin_and_achievements(self):
        unlocker = MagicMock(spec=GPGSUnlocker)
        unlocker.sign_in_game = MagicMock(return_value=True)
        unlocker.unlock_achievement = MagicMock(return_value=True)


        lm_signin = {"title": "Sign into Lords Mobile: Kingdom Wars with your Play Games profile", "type": "signin"}
        title, ok = bot._execute_single_task(unlocker, lm_signin, "com.igg.android.lordsmobile")
        self.assertTrue(ok)
        unlocker.sign_in_game.assert_called_once()


        skirmish = {"title": "Complete Skirmish 2 Ridge Attack", "achievement_id": "CgkIxunC2d8JEAIQDg", "type": "standard"}
        title, ok = bot._execute_single_task(unlocker, skirmish, "com.igg.android.lordsmobile")
        self.assertTrue(ok)
        unlocker.unlock_achievement.assert_called_with("CgkIxunC2d8JEAIQDg", steps=5)


        evony_signin = {"title": "Sign into Evony: The King's Return with your Play Games profile", "type": "signin"}
        title, ok = bot._execute_single_task(unlocker, evony_signin, "com.topgamesinc.evony")
        self.assertTrue(ok)

        recruit = {"title": "Recruit More", "achievement_id": "CgkI3fiGx4gPEAIQGw", "type": "standard"}
        title, ok = bot._execute_single_task(unlocker, recruit, "com.topgamesinc.evony")
        self.assertTrue(ok)
        unlocker.unlock_achievement.assert_called_with("CgkI3fiGx4gPEAIQGw", steps=5)

        print("✅ Task execution for signin and achievements passed!")

    async def test_select_quest_command_and_buttons(self):
        msg = MagicMock()
        msg.answer = AsyncMock()
        state = AsyncMock()
        state.clear = AsyncMock()

        await bot.select_quest(msg, state)
        state.clear.assert_called_once()
        msg.answer.assert_called_once()
        self.assertIn("Select the desired chest", msg.answer.call_args[0][0])
        print("✅ select_quest command/button handler passed!")

    async def test_quick_select_with_game_key_restore(self):
        cb = MagicMock()
        cb.from_user.id = 44444
        cb.data = "quick_select_lords_mobile"
        cb.answer = AsyncMock()
        cb.message = MagicMock()
        cb.message.answer = AsyncMock()
        state = AsyncMock()
        state.update_data = AsyncMock()
        state.set_state = AsyncMock()

        dummy_accounts = [{"id": 1, "email": "valid@gmail.com", "password": "pass"}]
        with patch("database.get_saved_accounts", return_value=dummy_accounts), \
             patch("database.get_user_language", return_value="en"):
            await bot.quick_select(cb, state)
            state.update_data.assert_called_with(game_key="lords_mobile", game_name="Lords mobile")
            state.set_state.assert_called_with(bot.QuestForm.waiting_for_credentials)
            cb.message.answer.assert_called_once()
            print("✅ quick_select game_key restore passed!")

    async def test_weekly_acc_selected_by_id(self):
        cb = MagicMock()
        cb.from_user.id = 55555
        cb.data = "weekly_acc_99"
        cb.answer = AsyncMock()
        cb.message = MagicMock()
        cb.message.edit_text = AsyncMock()
        state = AsyncMock()

        with patch("database.get_saved_account_by_id", return_value={"id": 99, "email": "w@gmail.com", "password": "pw"}), \
             patch("bot._execute_weekly_claim", new_callable=AsyncMock) as mock_claim:
            await bot.weekly_acc_selected(cb, state)
            mock_claim.assert_called_once()
            cb.message.edit_text.assert_called_once()
            print("✅ weekly_acc_selected by ID passed!")

    async def test_render_quick_select_filters_missing_passwords(self):
        cb = MagicMock()
        cb.from_user.id = 66666
        cb.answer = AsyncMock()
        cb.message = MagicMock()
        cb.message.answer = AsyncMock()
        state = MagicMock()

        mixed_accounts = [
            {"id": 1, "email": "nopass@gmail.com", "password": ""},
            {"id": 2, "email": "haspass@gmail.com", "password": "securepassword"}
        ]
        with patch("database.get_saved_accounts", return_value=mixed_accounts), \
             patch("database.get_user_language", return_value="en"):
            await bot._render_quick_select(cb, state, page=0, edit=False)
            call_kwargs = cb.message.answer.call_args[1]
            markup = call_kwargs["reply_markup"]
            buttons = [b.text for row in markup.inline_keyboard for b in row]
            self.assertIn("📨 haspass@gmail.com", buttons)
            self.assertNotIn("📨 nopass@gmail.com", buttons)
            print("✅ Filter missing passwords in quick_select passed!")


if __name__ == "__main__":
    unittest.main()
