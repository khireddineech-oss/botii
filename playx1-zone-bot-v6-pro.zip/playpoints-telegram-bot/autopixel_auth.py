import time
import logging
import asyncio
from typing import Tuple, Optional, Dict, Any
from urllib.parse import urlparse

from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

import config
import gpsoauth
from services.device_simulator import create_device_profile, DeviceProfile
from services.google_automation_core.driver_factory import build_driver
from services.google_automation_core.login_flow import (
    gmail_login,
    wait_for_number_confirm,
    submit_totp_code
)

logger = logging.getLogger(__name__)

GPGS_SCOPE = "oauth2:https://www.googleapis.com/auth/games"
GPGS_APP = "com.google.android.play.games"
CLIENT_SIG = "38918a453d07199354f8b19af05ec6562ced5788"


class AutoPixelAuthenticator:
    def __init__(self, email: str, password: str):
        self.email = email.strip() if email else ""
        self.password = password.strip() if password else ""
        self.device: DeviceProfile = create_device_profile()
        self.android_id = self.device.android_id[:16]
        self.driver = None
        self.master_token: Optional[str] = None
        self.access_token: Optional[str] = None
        self.prompt_number: Optional[str] = None

    def start_auth(self) -> Tuple[str, Optional[str]]:

        try:
            logger.info("Starting AutoPixel auth for %s with device %s", self.email, self.device.model)
            self.driver = build_driver(self.device, proxy=config.get_random_proxy())

            status = gmail_login(self.driver, self.email, self.password)
            logger.info("Gmail login status for %s: %s", self.email, status)

            if status == "success":

                return "SUCCESS", None

            elif status.startswith("needs_number_confirm:"):
                self.prompt_number = status.split(":", 1)[1]
                return "NEEDS_NUMBER", self.prompt_number

            elif status == "needs_tap_yes":
                return "NEEDS_TAP_YES", None

            elif status == "needs_totp":
                return "NEEDS_TOTP", None

            else:
                self.close()
                return "FAILED", "Incorrect email or password, or Google security blocked login."

        except Exception as e:
            logger.exception("Error during AutoPixel start_auth: %s", e)
            self.close()
            return "FAILED", str(e)

    def wait_for_approval(self, timeout: int = 120) -> bool:

        if not self.driver:
            return False

        try:
            logger.info("Waiting for phone tap on number %s (timeout: %ds)...", self.prompt_number, timeout)
            confirmed = wait_for_number_confirm(self.driver, timeout=timeout)
            return confirmed
        except Exception as e:
            logger.error("Error waiting for number confirm: %s", e)
            return False

    def submit_totp(self, code: str) -> bool:

        if not self.driver:
            return False
        return submit_totp_code(self.driver, code)

    def extract_tokens(self) -> Tuple[bool, str]:

        if not self.driver:
            return False, "Driver is not running."

        try:
            logger.info("Extracting OAuth tokens from EmbeddedSetup session...")
            oauth_token = None
            start_time = time.time()
            max_duration = 35

            while time.time() - start_time < max_duration:

                try:
                    for c in self.driver.get_cookies():
                        if c.get("name") == "oauth_token":
                            oauth_token = c.get("value")
                            logger.info("Found oauth_token in cookies: %s...", oauth_token[:15])
                            break
                except Exception:
                    pass
                if oauth_token:
                    break


                try:
                    curr_url = self.driver.current_url or ""
                    if "oauth_token=" in curr_url:
                        import urllib.parse
                        p = urllib.parse.urlparse(curr_url)
                        qs = urllib.parse.parse_qs(p.query) or urllib.parse.parse_qs(p.fragment)
                        if "oauth_token" in qs:
                            oauth_token = qs["oauth_token"][0]
                            logger.info("Found oauth_token in URL parameters!")
                            break
                except Exception:
                    pass
                if oauth_token:
                    break


                try:
                    src = self.driver.page_source or ""
                    if "oauth_token" in src:
                        import re
                        m = re.search(r'oauth_token=([a-zA-Z0-9_\-\.]+)', src)
                        if m:
                            oauth_token = m.group(1)
                            logger.info("Found oauth_token in page source: %s...", oauth_token[:15])
                            break
                        m2 = re.search(r'"oauth_token"\s*:\s*"([^"]+)"', src)
                        if m2:
                            oauth_token = m2.group(1)
                            logger.info("Found oauth_token in page JSON: %s...", oauth_token[:15])
                            break
                except Exception:
                    pass
                if oauth_token:
                    break


                try:
                    curr_url = self.driver.current_url or ""
                    curr_lower = curr_url.lower()


                    if "signin/identifier" in curr_lower:
                        logger.warning("Bounced back to signin/identifier during token extraction.")
                        break

                    if "signin/rejected" in curr_lower:
                        logger.error("Google rejected signin on %s", curr_url)
                        return False, "Google blocked this login (Security Risk). Please use an App Password (كلمة مرور التطبيق)."

                    if "signin/unknownerror" in curr_lower:
                        logger.error("Google returned unknownerror on %s", curr_url)
                        try:
                            self.driver.save_screenshot("/tmp/unknownerror.png")
                        except Exception:
                            pass
                        break


                    if "kidsetup" in curr_lower or "speedbump" in curr_lower or "interrupt" in curr_lower:
                        try:
                            radios = self.driver.find_elements(By.CSS_SELECTOR, '[role="radio"], input[type="radio"]')
                            if radios:
                                r0 = radios[0]
                                is_checked = r0.get_attribute("aria-checked") == "true" or r0.is_selected()
                                if not is_checked:
                                    logger.info("Selecting Option 0 (Adult/Myself) via JS dispatch...")
                                    self.driver.execute_script("""
                                        var el = arguments[0];
                                        el.focus();
                                        el.click();
                                        el.dispatchEvent(new Event('input', { bubbles: true }));
                                        el.dispatchEvent(new Event('change', { bubbles: true }));
                                        var p = el.closest('label') || el.closest('[data-value]') || el.parentElement;
                                        if (p) p.click();
                                    """, r0)
                                    time.sleep(1.0)
                            else:
                                adult_candidates = self.driver.find_elements(
                                    By.XPATH,
                                    '//*[contains(translate(text(), "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz"), "i will be using") or '
                                    'contains(translate(text(), "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz"), "for myself") or '
                                    'contains(translate(text(), "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz"), "an adult") or '
                                    'contains(translate(text(), "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz"), "pour moi")]'
                                )
                                if adult_candidates:
                                    logger.info("Clicking adult option element: '%s'", adult_candidates[0].text[:40])
                                    self.driver.execute_script("""
                                        var el = arguments[0];
                                        el.click();
                                        var inp = el.querySelector('input') || (el.parentElement ? el.parentElement.querySelector('input') : null);
                                        if (inp) {
                                            inp.checked = true;
                                            inp.dispatchEvent(new Event('change', { bubbles: true }));
                                        }
                                    """, adult_candidates[0])
                                    time.sleep(1.0)
                        except Exception as e:
                            logger.warning("Error in kidsetup radio handling: %s", e)


                    for cb in self.driver.find_elements(By.CSS_SELECTOR, '[role="checkbox"], input[type="checkbox"]'):
                        try:
                            is_checked = cb.get_attribute("aria-checked") == "true" or cb.is_selected()
                            if not is_checked:
                                self.driver.execute_script("arguments[0].click();", cb)
                                time.sleep(0.3)
                        except Exception:
                            continue


                    btn_clicked = False
                    btn_selectors = [
                        'button[jsname="LgbsSe"]',
                        '#identifierNext',
                        '#passwordNext',
                        '#next',
                        'button[type="submit"]',
                        'button[type="button"]',
                        'div[role="button"]',
                        'button'
                    ]
                    action_keywords = [
                        "next", "continue", "agree", "accepter", "j'accepte",
                        "i agree", "accept", "confirm", "confirmer", "suivant",
                        "continuer", "valider", "ok", "yes", "oui", "more", "plus"
                    ]

                    for sel in btn_selectors:
                        if btn_clicked:
                            break
                        for el in self.driver.find_elements(By.CSS_SELECTOR, sel):
                            try:
                                if not el.is_displayed():
                                    continue
                                is_disabled = (
                                    el.get_attribute("disabled") is not None
                                    or el.get_attribute("aria-disabled") == "true"
                                    or not el.is_enabled()
                                )
                                if is_disabled:
                                    continue

                                text = (el.get_attribute("innerText") or el.text or "").strip().lower()
                                aria = (el.get_attribute("aria-label") or "").strip().lower()
                                combined = f"{text} {aria}"
                                if any(w in combined for w in action_keywords):
                                    logger.info("Clicking action button '%s' (%s) on %s", combined[:30], sel, curr_url)
                                    try:
                                        el.click()
                                    except Exception:
                                        self.driver.execute_script("arguments[0].click();", el)
                                    btn_clicked = True
                                    time.sleep(1.5)
                                    break
                            except Exception:
                                continue


                    if not btn_clicked and ("speedbump" in curr_lower or "interrupt" in curr_lower):
                        for btn in self.driver.find_elements(By.CSS_SELECTOR, 'button.VfPpkd-LgbsSe--raised, button[jscontroller], div[role="button"]'):
                            try:
                                if btn.is_displayed() and btn.is_enabled() and btn.get_attribute("aria-disabled") != "true":
                                    logger.info("Clicking fallback primary button on %s", curr_url)
                                    try:
                                        btn.click()
                                    except Exception:
                                        self.driver.execute_script("arguments[0].click();", btn)
                                    btn_clicked = True
                                    time.sleep(1.5)
                                    break
                            except Exception:
                                pass

                except Exception as ex:
                    logger.warning("Error interacting with page during token extraction: %s", ex)

                time.sleep(0.8)


            self.close()

            if not oauth_token:
                logger.error("Failed to find oauth_token cookie in session")
                return False, "Could not extract oauth_token from Google session."

            logger.info("Found oauth_token! Exchanging for Master Token via gpsoauth...")

            master_res = gpsoauth.exchange_token(
                self.email,
                oauth_token,
                self.android_id,
                service="ac2dm",
                device_country="us",
                operator_country="us",
                client_sig=CLIENT_SIG
            )

            if "Token" not in master_res:
                err = master_res.get("Error", str(master_res))
                logger.error("Failed to exchange oauth_token: %s", err)
                return False, f"Token exchange failed: {err}"

            self.master_token = master_res["Token"]
            logger.info("Master Token acquired successfully (length: %d)", len(self.master_token))


            logger.info("Exchanging Master Token for GPGS scope...")
            gpgs_res = gpsoauth.perform_oauth(
                self.email,
                self.master_token,
                self.android_id,
                service=GPGS_SCOPE,
                app=GPGS_APP,
                client_sig=CLIENT_SIG,
                device_country="us",
                operator_country="us"
            )

            if "Auth" in gpgs_res:
                self.access_token = gpgs_res["Auth"]
                logger.info("GPGS Access Token acquired successfully!")
                return True, "SUCCESS"
            else:
                err = gpgs_res.get("Error", str(gpgs_res))
                logger.error("Failed to acquire GPGS auth token: %s", err)
                return False, f"GPGS OAuth failed: {err}"

        except Exception as e:
            logger.exception("Error extracting tokens: %s", e)
            self.close()
            return False, str(e)

    def close(self):

        if self.driver:
            try:
                self.driver.quit()
            except Exception:
                try:
                    if hasattr(self.driver, 'service') and hasattr(self.driver.service, 'process') and self.driver.service.process:
                        self.driver.service.process.kill()
                except Exception:
                    pass
            self.driver = None

    def __del__(self):
        try:
            self.close()
        except Exception:
            pass
