import os
import random


TELEGRAM_BOT_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN", "")


DEVICE_MODEL        = "Pixel 10 Pro"
DEVICE_BRAND        = "google"
DEVICE_MANUFACTURER = "Google"
ANDROID_VERSION     = "16"
ANDROID_SDK         = "36"
BUILD_ID            = "AP4A.250405.002"


def _detect_chrome_version() -> tuple[str, int]:
    import subprocess, shutil
    for binary in ("chromium", "chromium-browser", "google-chrome", "chrome"):
        path = shutil.which(binary)
        if not path:
            continue
        try:
            out = subprocess.check_output(
                [path, "--version"], stderr=subprocess.DEVNULL, timeout=5,
            ).decode().strip()
            for part in out.split():
                if "." in part and part[0].isdigit():
                    major = int(part.split(".")[0])
                    return part, major
        except Exception:
            continue
    return "124.0.6367.82", 124

CHROME_VERSION, CHROME_MAJOR_VERSION = _detect_chrome_version()

USER_AGENT_TEMPLATES = [
    (
        "Mozilla/5.0 (Linux; Android {android}; {model} Build/{build}; wv) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Version/4.0 Chrome/{chrome} Mobile Safari/537.36"
    ),
    (
        "Mozilla/5.0 (Linux; Android {android}; {model} Build/{build}) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/{chrome} Mobile Safari/537.36"
    ),
]


GMAIL_LOGIN_URL      = "https://accounts.google.com/EmbeddedSetup"
GOOGLE_ONE_URL       = "https://one.google.com/"
GOOGLE_ONE_OFFERS_URL = "https://one.google.com/about/plans"


GEMINI_OFFER_KEYWORDS = [
    "gemini pro", "gemini advanced",
    "12 month", "12-month",
    "free trial", "activate",
    "get started", "claim offer", "redeem",
]

OFFER_DOMAIN_WHITELIST = [
    "one.google.com",
    "gemini.google.com",
    "play.google.com",
    "accounts.google.com",
    "pay.google.com",
]


WEBDRIVER_TIMEOUT  = 20
IMPLICIT_WAIT      = 0
PAGE_LOAD_TIMEOUT  = 35
HEADLESS           = True


def _load_proxies() -> list[str]:
    raw = os.environ.get("PROXIES", "").strip()
    if raw:
        return [p.strip() for p in raw.splitlines() if p.strip()]
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "proxies.txt")
    if os.path.exists(path):
        with open(path) as f:
            return [line.strip() for line in f if line.strip() and not line.startswith("#")]
    return []

PROXY_LIST: list[str] = _load_proxies()

def get_random_proxy() -> str | None:

    return random.choice(PROXY_LIST) if PROXY_LIST else None


TIMEZONE_GEO_POOL = [
    ("America/Los_Angeles", 34.0522,  -118.2437),
    ("America/New_York",    40.7128,   -74.0060),
    ("America/Chicago",     41.8781,   -87.6298),
    ("America/Denver",      39.7392,  -104.9903),
    ("America/Phoenix",     33.4484,  -112.0740),
    ("America/Houston",     29.7604,   -95.3698),
    ("America/Seattle",     47.6062,  -122.3321),
    ("America/Miami",       25.7617,   -80.1918),
    ("America/Atlanta",     33.7490,   -84.3880),
    ("America/Boston",      42.3601,   -71.0589),
]

def get_random_timezone_geo() -> tuple[str, float, float]:

    return random.choice(TIMEZONE_GEO_POOL)


def human_delay(min_ms: int = 800, max_ms: int = 2200) -> float:

    return random.randint(min_ms, max_ms) / 1000


ALLOWED_EMAIL_DOMAINS: list[str] = []


SESSION_TTL_SECONDS: int = 30 * 60


LOG_LEVEL  = "INFO"
LOG_FORMAT = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
