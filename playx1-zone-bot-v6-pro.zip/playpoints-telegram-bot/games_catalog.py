GAMES_CATALOG = {
    "triple_match": {
        "name": "Triple Match",
        "package": "com.master.triple3d.find",
        "app_id": "com.master.triple3d.find",
        "tasks": [
            {
                "title": "App Launch & Session",
                "type": "session"
            },
            {
                "title": "Novice star collector",
                "achievement_id": "CgkI85bM_o0VEAIQAQ",
                "type": "achievement"
            }
        ]
    },
    "angry_birds_2": {
        "name": "Angry birds 2",
        "package": "com.rovio.baba",
        "app_id": "com.rovio.baba",
        "client_sig": "66da9177253113474f6b3043b89e0667902cf115",
        "tasks": [
            {
                "title": "Party Popper",
                "achievement_id": "CgkI0_fOz_QKEAIQAQ",
                "type": "standard"
            },
            {
                "title": "Super Popper",
                "achievement_id": "CgkI0_fOz_QKEAIQAg",
                "type": "standard"
            },
            {
                "title": "Starstruck",
                "achievement_id": "CgkI0_fOz_QKEAIQAw",
                "type": "standard"
            }
        ]
    },
    "dice_dreams": {
        "name": "Dice dreams\u2122",
        "package": "com.superplaystudios.dicedreams",
        "app_id": "com.superplaystudios.dicedreams",
        "client_sig": "e1be3c523dc73eddea9460c71e25cc0a4065e6d8",
        "tasks": [
            {
                "title": "Install The Game",
                "achievement_id": "CgkI8ujCoPoIEAIQSA",
                "type": "standard"
            },
            {
                "title": "First Kingdom",
                "achievement_id": "CgkI8ujCoPoIEAIQRw",
                "type": "standard"
            },
            {
                "title": "Power Roll!",
                "achievement_id": "CgkI8ujCoPoIEAIQPg",
                "type": "standard"
            }
        ]
    },
    "eight_ball_pool": {
        "name": "8 Ball Pool",
        "package": "com.miniclip.eightballpool",
        "app_id": "com.miniclip.eightballpool",
        "client_sig": "87615343657c0a98155d71ec5a3158218b9a9f62",
        "tasks": [
            {
                "title": "8 Ball Win",
                "achievement_id": "CgkI0MydwKUUEAIQAQ",
                "type": "standard"
            },
            {
                "title": "8 Ball Veteran",
                "achievement_id": "CgkI0MydwKUUEAIQAg",
                "type": "standard"
            },
            {
                "title": "8 Ball Pro",
                "achievement_id": "CgkI0MydwKUUEAIQAw",
                "type": "standard"
            }
        ]
    },
    "whiteout_survival": {
        "name": "Whiteout Survival",
        "package": "com.gof.global",
        "app_id": "com.gof.global",
        "client_sig": "972e399936f3a8da300da162aa70709a467c0e0e",
        "tasks": [
            {
                "title": "Furnace Upgrade",
                "achievement_id": "CgkIsP-nyJkEEAIQAw",
                "type": "incremental",
                "steps": 5
            },
            {
                "title": "Consecutive Login",
                "achievement_id": "CgkIsP-nyJkEEAIQBA",
                "type": "incremental",
                "steps": 5
            },
            {
                "title": "Rally Polar Terror",
                "achievement_id": "CgkIsP-nyJkEEAIQBQ",
                "type": "incremental",
                "steps": 5
            }
        ]
    },
    "domino_dreams": {
        "name": "Domino dreams\u2122",
        "package": "com.screenshake.dominodreams",
        "app_id": "com.screenshake.dominodreams",
        "tasks": [
            {
                "title": "Chapter 1 Clear",
                "achievement_id": "CgkI2eK7io0VEAIQAQ",
                "type": "achievement"
            },
            {
                "title": "Level 15 Reached",
                "achievement_id": "CgkI2eK7io0VEAIQAg",
                "type": "achievement"
            }
        ]
    },
    "fruit_ninja": {
        "name": "Fruit ninja",
        "package": "com.halfbrick.fruitninjafree",
        "app_id": "com.halfbrick.fruitninjafree",
        "client_sig": "a21fb02d25e497234206e3e256cc8eeb90897258",
        "tasks": [
            {
                "title": "FRUIT NINJA",
                "achievement_id": "CgkIn8iOvI4QEAIQBA",
                "type": "standard"
            },
            {
                "title": "GREAT FRUIT NINJA",
                "achievement_id": "CgkIn8iOvI4QEAIQBQ",
                "type": "standard"
            },
            {
                "title": "ULTIMATE FRUIT NINJA",
                "achievement_id": "CgkIn8iOvI4QEAIQBg",
                "type": "standard"
            }
        ]
    },
    "hay_day": {
        "name": "Hay Day",
        "package": "com.supercell.hayday",
        "app_id": "com.supercell.hayday",
        "client_sig": "1e7c404b0ee0749cf936606c3ec34cf9d3283be3",
        "tasks": [
            {
                "title": "Dream Farm",
                "achievement_id": "CgkIndvy4_keEAIQBA",
                "type": "standard"
            },
            {
                "title": "Dream Farm II",
                "achievement_id": "CgkIndvy4_keEAIQBQ",
                "type": "standard"
            },
            {
                "title": "Dream Farm III",
                "achievement_id": "CgkIndvy4_keEAIQBg",
                "type": "standard"
            }
        ]
    },
    "lords_mobile": {
        "name": "Lords mobile",
        "package": "com.igg.android.lordsmobile",
        "app_id": "com.igg.android.lordsmobile",
        "client_sig": "75adf545f77fee9de110d4ddfae60bb3b9b17dad",
        "tasks": [
            {
                "title": "Sign into Lords Mobile: Kingdom Wars with your Play Games profile",
                "type": "signin"
            },
            {
                "title": "Complete Skirmish 2 Ridge Attack",
                "achievement_id": "CgkIxunC2d8JEAIQDg",
                "type": "standard"
            },
            {
                "title": "Upgrade Castle to Lv 5",
                "achievement_id": "CgkIxunC2d8JEAIQAg",
                "type": "standard"
            },
            {
                "title": "Upgrade Castle to Lv 10",
                "achievement_id": "CgkIxunC2d8JEAIQAw",
                "type": "standard"
            },
            {
                "title": "Upgrade Castle to Lv 15",
                "achievement_id": "CgkIxunC2d8JEAIQBA",
                "type": "standard"
            }
        ]
    },
    "gossip_harbor": {
        "name": "Gossip Harbor",
        "package": "com.mergegames.gossipharbor",
        "app_id": "com.mergegames.gossipharbor",
        "client_sig": "58e71785c961e7328ea9c76de647f8f6c4403b39",
        "tasks": [
            {
                "title": "Starter Snack Bar (5 Orders)",
                "achievement_id": "CgkI3YvxrpUIEAIQAQ",
                "type": "incremental",
                "steps": 5
            },
            {
                "title": "Welcome to Brimwave",
                "achievement_id": "CgkI3YvxrpUIEAIQBw",
                "type": "standard"
            },
            {
                "title": "Leveled Up (Lvl 6)",
                "achievement_id": "CgkI3YvxrpUIEAIQDA",
                "type": "standard"
            }
        ]
    },
    "farm_heroes_saga": {
        "name": "Farm heroes saga",
        "package": "com.king.farmheroessaga",
        "app_id": "com.king.farmheroessaga",
        "client_sig": "9e93b3336c767c3aba6fcc4deada9f179ee4a05b",
        "tasks": [
            {
                "title": "Get the Game",
                "achievement_id": "CgkIu7q4p9MfEAIQCA",
                "type": "standard"
            },
            {
                "title": "Adept Farmer",
                "achievement_id": "CgkIu7q4p9MfEAIQCQ",
                "type": "standard"
            },
            {
                "title": "Flawless",
                "achievement_id": "CgkIu7q4p9MfEAIQCw",
                "type": "incremental",
                "steps": 5
            }
        ]
    },
    "best_fiends": {
        "name": "Best Fiends",
        "package": "com.Seriously.BestFiends",
        "app_id": "com.Seriously.BestFiends",
        "client_sig": "a1c592da9733a4898b89321b98be2fd6a3d543ab",
        "tasks": [
            {
                "title": "Yellow Rescuer",
                "achievement_id": "CgkI-P-r3fwaEAIQAg",
                "type": "standard"
            },
            {
                "title": "Purple Rescuer",
                "achievement_id": "CgkI-P-r3fwaEAIQAw",
                "type": "standard"
            },
            {
                "title": "Green Rescuer",
                "achievement_id": "CgkI-P-r3fwaEAIQBA",
                "type": "standard"
            }
        ]
    },
    "disney_solitair": {
        "name": "Disney Solitair",
        "package": "com.superplay.disneysolitaire",
        "app_id": "com.superplay.disneysolitaire",
        "tasks": [
            {
                "title": "Reach Level 10",
                "achievement_id": "CgkI22bM_o0VEAIQAQ",
                "type": "achievement"
            }
        ]
    },
    "jurassic_world": {
        "name": "Jurassic World",
        "package": "com.ludia.jurassicworld",
        "app_id": "com.ludia.jurassicworld",
        "client_sig": "eb5c297ff9098faf4cd9944b5ed2b4da32949512",
        "tasks": [
            {
                "title": "Park Manager",
                "achievement_id": "CgkI0IXY_ZoJEAIQLA",
                "type": "standard"
            },
            {
                "title": "Classy!",
                "achievement_id": "CgkI0IXY_ZoJEAIQDQ",
                "type": "standard"
            },
            {
                "title": "Biodiversity Part 1",
                "achievement_id": "CgkI0IXY_ZoJEAIQEQ",
                "type": "incremental",
                "steps": 10
            }
        ]
    },
    "arknights_endfield": {
        "name": "Arknights: Endfield",
        "package": "com.gryphline.endfield.gp",
        "app_id": "com.gryphline.endfield.gp",
        "client_sig": "978a77bfed2e9ed5d0ead626a1bf8ab1cd7a28e7",
        "tasks": [
            {
                "title": "Sign into Arknights: Endfield with your Play Games profile",
                "type": "signin"
            },
            {
                "title": "Process: Awakening",
                "achievement_id": "CgkI1OrtgvEKEAIQAQ",
                "type": "standard"
            },
            {
                "title": "Basic Training",
                "achievement_id": "CgkI1OrtgvEKEAIQAA",
                "type": "standard"
            }
        ]
    },
    "marvel_contest": {
        "name": "MARVEL Contest",
        "package": "com.kabam.marvelbattle",
        "app_id": "com.kabam.marvelbattle",
        "client_sig": "bdff84511d367e926ed15cf6609bf0c815c8e846",
        "tasks": [
            {
                "title": "The Contest",
                "achievement_id": "CgkI35qWta0OEAIQAQ",
                "type": "standard"
            },
            {
                "title": "By The Book",
                "achievement_id": "CgkI35qWta0OEAIQAg",
                "type": "standard"
            },
            {
                "title": "Escalation",
                "achievement_id": "CgkI35qWta0OEAIQAw",
                "type": "standard"
            }
        ]
    },
    "matchington": {
        "name": "Matchington",
        "package": "com.matchington.mansion",
        "app_id": "com.matchington.mansion",
        "client_sig": "d545fdbad97fc41ff95796512af7a62f73b04501",
        "tasks": [
            {
                "title": "Fix the Door",
                "achievement_id": "CgkI86v1r4MBEAIQAA",
                "type": "standard"
            },
            {
                "title": "Name your Cat",
                "achievement_id": "CgkI86v1r4MBEAIQAg",
                "type": "standard"
            },
            {
                "title": "Redecorate",
                "achievement_id": "CgkI86v1r4MBEAIQAw",
                "type": "standard"
            }
        ]
    },
    "mobile_legends": {
        "name": "Mobile legends",
        "package": "com.mobile.legends",
        "app_id": "com.mobile.legends",
        "client_sig": "d659c5397a8f2a5b6f3489e546a389ca54fd28fc",
        "tasks": [
            {
                "title": "5 HEROES",
                "achievement_id": "CggI4oqc83cQAhAE",
                "type": "standard"
            },
            {
                "title": "3 SKINS",
                "achievement_id": "CggI4oqc83cQAhAF",
                "type": "standard"
            },
            {
                "title": "5 WINS",
                "achievement_id": "CggI4oqc83cQAhAG",
                "type": "standard"
            }
        ]
    },
    "pokemon_masters_ex": {
        "name": "Pok\u00e9mon Masters EX",
        "package": "com.dena.a12026418",
        "app_id": "com.dena.a12026418",
        "client_sig": "1f166dcc0fac8a6c8c5d11679e33f7596de8e0f4",
        "tasks": [
            {
                "title": "Complete the designated area 1",
                "achievement_id": "CgkIxNGLuvsSEAIQAA",
                "type": "standard"
            },
            {
                "title": "Complete the designated area 2",
                "achievement_id": "CgkIxNGLuvsSEAIQAg",
                "type": "standard"
            },
            {
                "title": "Complete the designated area 3",
                "achievement_id": "CgkIxNGLuvsSEAIQAw",
                "type": "standard"
            }
        ]
    },
    "pokemon_tcgp": {
        "name": "Pok\u00e9mon TCGP",
        "package": "jp.pokemon.pokemontcgp",
        "app_id": "jp.pokemon.pokemontcgp",
        "client_sig": "c50b2f056cc84fcf8752e6c23bd3819128b923a2",
        "tasks": [
            {
                "title": "Raise your player level",
                "achievement_id": "CgkIg7-InK8eEAIQBQ",
                "type": "incremental",
                "steps": 3
            },
            {
                "title": "Use pack stamina to open booster packs 1",
                "achievement_id": "CgkIg7-InK8eEAIQAQ",
                "type": "incremental",
                "steps": 4
            },
            {
                "title": "Use pack stamina to open booster packs 2",
                "achievement_id": "CgkIg7-InK8eEAIQAg",
                "type": "incremental",
                "steps": 30
            }
        ]
    },
    "rise_of_castles": {
        "name": "Rise of Castles\u2122",
        "package": "com.im30.ROE.gp",
        "app_id": "com.im30.ROE.gp",
        "client_sig": "1f3603691327f50b184baea092c6c3e608d99a0d",
        "tasks": [
            {
                "title": "First Steps",
                "achievement_id": "CgkI_c_FyZ8bEAIQFg",
                "type": "incremental",
                "steps": 3
            },
            {
                "title": "Progressing Daily",
                "achievement_id": "CgkI_c_FyZ8bEAIQAw",
                "type": "incremental",
                "steps": 7
            },
            {
                "title": "Perseverance",
                "achievement_id": "CgkI_c_FyZ8bEAIQBA",
                "type": "incremental",
                "steps": 14
            }
        ]
    },
    "summoners_war": {
        "name": "Summoners War",
        "package": "com.com2us.smon.normal.freefull.google.kr.android.common",
        "app_id": "com.com2us.smon.normal.freefull.google.kr.android.common",
        "client_sig": "eaddcde759b1a71993e90720e9ed3956cb1e1a1d",
        "tasks": [
            {
                "title": "Set Your Budget",
                "achievement_id": "CgkIi9-Vv5oZEAIQAg",
                "type": "standard"
            },
            {
                "title": "Equip a Rune Set",
                "achievement_id": "CgkIi9-Vv5oZEAIQAw",
                "type": "standard"
            },
            {
                "title": "Garen Forest Peace",
                "achievement_id": "CgkIi9-Vv5oZEAIQBA",
                "type": "standard"
            }
        ]
    },
    "kings_return": {
        "name": "Evony: The King's Return",
        "package": "com.topgamesinc.evony",
        "app_id": "com.topgamesinc.evony",
        "client_sig": "4013e37cec52744bb3dc4af2406e222053c0de1a",
        "tasks": [
            {
                "title": "Sign into Evony: The King's Return with your Play Games profile",
                "type": "signin"
            },
            {
                "title": "Recruit More",
                "achievement_id": "CgkI3fiGx4gPEAIQGw",
                "type": "standard"
            },
            {
                "title": "Well-seasoned General",
                "achievement_id": "CgkI3fiGx4gPEAIQGg",
                "type": "standard"
            },
            {
                "title": "Rename",
                "achievement_id": "CgkI3fiGx4gPEAIQFw",
                "type": "standard"
            },
            {
                "title": "Working Together",
                "achievement_id": "CgkI3fiGx4gPEAIQGA",
                "type": "standard"
            },
            {
                "title": "Development",
                "achievement_id": "CgkI3fiGx4gPEAIQGQ",
                "type": "standard"
            }
        ]
    },
    "war_machines": {
        "name": "War machines",
        "package": "com.fungames.battletanksbeta",
        "app_id": "com.fungames.battletanksbeta",
        "client_sig": "8411caa8d4e81dcbc141178586b55181c8370603",
        "tasks": [
            {
                "title": "First Step!",
                "achievement_id": "CgkI4pKymoMTEAIQCA",
                "type": "standard"
            },
            {
                "title": "Tank! What tank!",
                "achievement_id": "CgkI4pKymoMTEAIQCQ",
                "type": "standard"
            },
            {
                "title": "Pimp My Tank!",
                "achievement_id": "CgkI4pKymoMTEAIQCg",
                "type": "standard"
            }
        ]
    },
    "yalla_ludo": {
        "name": "Yalla Ludo",
        "package": "com.yalla.yallagames",
        "app_id": "com.yalla.yallagames",
        "client_sig": "a2affbd64ef6b3658c32e592acc23ac1e507643d",
        "tasks": [
            {
                "title": "Fresh Start",
                "achievement_id": "CgkI0peF5c8REAIQAQ",
                "type": "standard"
            },
            {
                "title": "First Ludo Win",
                "achievement_id": "CgkI0peF5c8REAIQAg",
                "type": "standard"
            },
            {
                "title": "First Domino Win",
                "achievement_id": "CgkI0peF5c8REAIQAw",
                "type": "standard"
            }
        ]
    },
    "gardenscapes": {
        "name": "Gardenscapes",
        "package": "com.playrix.gardenscapes",
        "app_id": "com.playrix.gardenscapes",
        "client_sig": "b0cb218c78f839529f5721e1b0757a91d1bc1e2e",
        "tasks": [
            {
                "title": "Sign into Gardenscapes with your Play Games profile",
                "type": "signin"
            },
            {
                "title": "Collect 40 bombs",
                "achievement_id": "CgkIzvLA59wVEAIQcQ",
                "type": "incremental",
                "steps": 40,
                "event_name": "bombCollected",
                "amount": 50
            },
            {
                "title": "Match 99 Apple Pieces",
                "event_name": "redTilesCleared",
                "amount": 150
            },
            {
                "title": "Save 140 Moves Remaining",
                "event_name": "stepsLeft",
                "amount": 200
            }
        ]
    },
    "carrom_pool": {
        "name": "Carrom Pool",
        "package": "com.miniclip.carrom",
        "app_id": "com.miniclip.carrom",
        "client_sig": "eadbcfcfe5f7724503277f8a867d1af5c644a3f6",
        "tasks": [
            {
                "title": "Sign into Carrom Pool: Disc Game with your Play Games profile",
                "type": "signin"
            },
            {
                "title": "Rookie",
                "achievement_id": "CgkIw8fZ1Z8dEAIQAQ",
                "type": "standard"
            },
            {
                "title": "Road to London",
                "achievement_id": "CgkIw8fZ1Z8dEAIQEw",
                "type": "standard"
            },
            {
                "title": "Streak",
                "achievement_id": "CgkIw8fZ1Z8dEAIQCA",
                "type": "standard"
            }
        ]
    }
}


class _GamesCatalogDict(dict):

    def _resolve_key(self, key):
        if not isinstance(key, str):
            return key
        k_lower = key.strip().lower()
        if k_lower in ("evony", "evony: the king's return", "the kings return", "the king's return"):
            return "kings_return"
        if k_lower in ("carrom", "carrom pool", "carrom_pool: disc game"):
            return "carrom_pool"
        if k_lower in ("lords", "lords_mobile", "lords mobile", "lords mobile: kingdom wars"):
            return "lords_mobile"
        if "." in k_lower:
            for k, v in self.items():
                if v.get("package", "").lower() == k_lower or v.get("app_id", "").lower() == k_lower:
                    return k
        return key

    def __getitem__(self, key):
        resolved = self._resolve_key(key)
        return super().__getitem__(resolved)

    def get(self, key, default=None):
        resolved = self._resolve_key(key)
        return super().get(resolved, default)

    def __contains__(self, key):
        resolved = self._resolve_key(key)
        return super().__contains__(resolved)


GAMES_CATALOG = _GamesCatalogDict(GAMES_CATALOG)
