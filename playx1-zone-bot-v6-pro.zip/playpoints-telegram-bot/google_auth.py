import uuid
import time
import gpsoauth
from typing import Optional, Tuple


CLIENT_SIG = "38918a453d07199354f8b19af05ec6562ced5788"


GPGS_SCOPE = "oauth2:https://www.googleapis.com/auth/games"
GPGS_APP = "com.google.android.play.games"


EMBEDDED_SETUP_URL = "https://accounts.google.com/EmbeddedSetup"


class GoogleAuthenticator:


    def __init__(self, email: str, password: Optional[str] = None,
                 android_id: Optional[str] = None):
        self.email = email.strip()
        self.password = password.strip() if password else None
        self.android_id = android_id or uuid.uuid4().hex[:16]
        self.master_token: Optional[str] = None
        self.access_token: Optional[str] = None
        self.auth_method: Optional[str] = None

    def login(self) -> Tuple[str, dict]:

        if not self.password:
            return "BAD_CREDENTIALS", {"error": "No password provided"}

        try:

            res = gpsoauth.perform_master_login(
                self.email,
                self.password,
                self.android_id,
                service="ac2dm",
                device_country="us",
                operator_country="us",
                lang="en",
                sdk_version=28,
            )

            if "Token" in res:

                self.master_token = res["Token"]
                self.auth_method = "direct"
                return self._get_gpgs_token()


            err = res.get("Error", "")
            if "NeedsBrowser" in err or "InvalidSecondFactor" in err:

                return "NEEDS_TOKEN", {
                    "url": EMBEDDED_SETUP_URL,
                    "reason": "2FA_ENABLED"
                }
            elif "BadAuthentication" in err:


                return "NEEDS_TOKEN", {
                    "url": EMBEDDED_SETUP_URL,
                    "reason": "AUTH_BLOCKED"
                }
            else:
                return "ERROR", {"error": err or str(res)}

        except Exception as e:
            return "ERROR", {"error": str(e)}

    def login_with_token(self, oauth_token: str) -> Tuple[str, dict]:

        try:

            res = gpsoauth.exchange_token(
                self.email,
                oauth_token.strip(),
                self.android_id,
                service="ac2dm",
                device_country="us",
                operator_country="us",
                lang="en",
                sdk_version=28,
            )

            if "Token" in res:
                self.master_token = res["Token"]
                self.auth_method = "token_exchange"
                return self._get_gpgs_token()

            err = res.get("Error", "")
            if "BadAuthentication" in err:
                return "TOKEN_INVALID", {
                    "error": "oauth_token is invalid or expired. Please get a fresh one."
                }
            return "ERROR", {"error": err or str(res)}

        except Exception as e:
            return "ERROR", {"error": str(e)}

    def login_with_master_token(self, master_token: str) -> Tuple[str, dict]:

        self.master_token = master_token.strip()
        self.auth_method = "saved_master"
        return self._get_gpgs_token()

    def _get_gpgs_token(self) -> Tuple[str, dict]:

        if not self.master_token:
            return "ERROR", {"error": "No master token available"}

        try:
            oauth_res = gpsoauth.perform_oauth(
                self.email,
                self.master_token,
                self.android_id,
                service=GPGS_SCOPE,
                app=GPGS_APP,
                client_sig=CLIENT_SIG,
                device_country="us",
                operator_country="us",
                lang="en",
                sdk_version=28,
            )

            if "Auth" in oauth_res:
                self.access_token = oauth_res["Auth"]
                return "SUCCESS", {
                    "master_token": self.master_token,
                    "method": self.auth_method
                }

            err = oauth_res.get("Error", "")
            return "ERROR", {"error": f"GPGS OAuth failed: {err}"}

        except Exception as e:
            return "ERROR", {"error": str(e)}
