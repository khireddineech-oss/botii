#!/usr/bin/env bash
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PID_FILE="$DIR/bot.pid"
LOG_FILE="$DIR/bot.log"
VENV_PYTHON="$DIR/venv/bin/python3"

if [ ! -f "$VENV_PYTHON" ]; then
    VENV_PYTHON="$(command -v python3)"
fi

export MALLOC_ARENA_MAX=2
export PYTHONOPTIMIZE=1
export PYTHONDONTWRITEBYTECODE=1

if [ -f "$DIR/.env" ]; then
    export $(grep -v '^#' "$DIR/.env" | xargs)
fi

case "$1" in
    start)
        if [ -f "$PID_FILE" ] && kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
            echo "Bot is already running (PID: $(cat "$PID_FILE"))"
            exit 1
        fi
        echo "Starting PLAYX1 ZONE Bot..."
        nohup "$VENV_PYTHON" -u "$DIR/bot.py" < /dev/null >> "$LOG_FILE" 2>&1 &
        BOT_PID=$!
        disown $BOT_PID
        echo $BOT_PID > "$PID_FILE"
        sleep 2
        if kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
            echo "Bot started (PID: $(cat "$PID_FILE"))"
            echo "Logs: $LOG_FILE"
        else
            echo "Bot failed to start:"
            tail -n 20 "$LOG_FILE"
        fi
        ;;
    stop)
        if [ -f "$PID_FILE" ]; then
            PID="$(cat "$PID_FILE")"
            if kill -0 "$PID" 2>/dev/null; then
                kill "$PID"
                for i in $(seq 1 10); do
                    if ! kill -0 "$PID" 2>/dev/null; then
                        break
                    fi
                    sleep 0.5
                done
                if kill -0 "$PID" 2>/dev/null; then
                    kill -9 "$PID" 2>/dev/null
                fi
                rm -f "$PID_FILE"
                echo "Bot stopped (PID: $PID)"
            else
                rm -f "$PID_FILE"
                echo "Stale PID removed"
            fi
        else
            echo "Bot is not running"
        fi
        ;;
    restart)
        $0 stop
        sleep 1
        $0 start
        ;;
    status)
        if [ -f "$PID_FILE" ] && kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
            echo "Bot is RUNNING (PID: $(cat "$PID_FILE"))"
        else
            echo "Bot is STOPPED"
        fi
        ;;
    logs)
        tail -f "$LOG_FILE"
        ;;
    *)
        echo "Usage: $0 {start|stop|restart|status|logs}"
        exit 1
        ;;
esac
