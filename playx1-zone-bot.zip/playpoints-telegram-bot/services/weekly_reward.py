import logging
import os
import re
import time
from typing import Dict, Any, Optional

import requests
import gpsoauth
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

logger = logging.getLogger(__name__)

PERKS_URL = "https://play.google.com/store/points/perks"


def fast_claim_weekly_perk(
    email: str,
    master_token: str,
    android_id: str,
    proxy: Optional[str] = None,
    screenshot_prefix: str = "/tmp/weekly"
) -> Dict[str, Any]:

    result = {
        "status": "UNKNOWN",
        "points": None,
        "next_date": None,
        "tier": "Unknown",
        "screenshot": None,
        "message": ""
    }

    try:

        res = gpsoauth.perform_oauth(
            email, master_token, android_id,
            "weblogin:continue=https%3A%2F%2Fplay.google.com%2Fstore%2Fpoints%2Fperks",
            "com.android.vending",
            "38918a453d07199354f8b19af05ec6562ced5788"
        )
        merge_url = res.get("Auth") if isinstance(res, dict) else None
        if not merge_url:
            logger.warning("Failed to obtain MergeSession URL for %s: %s", email, res)
            result["status"] = "AUTH_REQUIRED"
            result["message"] = "Session expired. Google requested re-authentication."
            return result


        session = requests.Session()
        session.headers.update({
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "Accept-Language": "en-US,en;q=0.9",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
        })
        if proxy:
            session.proxies = {"http": proxy, "https": proxy}

        resp = session.get(merge_url, allow_redirects=True, timeout=15)
        html = resp.text


        if "accounts.google.com" in resp.url or "signin" in resp.url.lower():
            result["status"] = "AUTH_REQUIRED"
            result["message"] = "Session expired. Google requested re-authentication."
            return result


        tier = "Unknown"
        for t in ["Platinum", "Gold", "Silver", "Bronze", "Platine", "Or", "Argent", "البلاتيني", "الذهبي", "الفضي", "البرونزي"]:
            if f'"{t}"' in html or f'>{t}<' in html or f'"{t.lower()}"' in html:
                if t in ("Platine", "البلاتيني"):
                    tier = "Platinum"
                elif t in ("Or", "الذهبي"):
                    tier = "Gold"
                elif t in ("Argent", "الفضي"):
                    tier = "Silver"
                elif t in ("Bronze", "البرونزي"):
                    tier = "Bronze"
                else:
                    tier = t.capitalize()
                break
        result["tier"] = tier


        if tier == "Bronze" or ("bronze" in html.lower() and "weekly prize" in html.lower()):
            result["status"] = "NOT_ELIGIBLE"
            result["tier"] = "Bronze"
            result["message"] = "Account is Bronze tier. Weekly prizes unlock at Silver tier or higher."
            return result


        avail_m = re.search(r'(?:available on|disponible le|متوفر في)\s*([A-Za-z0-9\s,]+?)(?:<|"|&|\.|\n)', html, re.I)
        is_already_claimed = False
        next_date = None

        if avail_m:
            next_date = avail_m.group(1).strip()
            if len(next_date) > 30 or "app" in next_date.lower():
                next_date = "next Friday"
            is_already_claimed = True
        elif "next_reward_package" in html or "Next Silver prize" in html or "Next Gold prize" in html or "الجائزة التالية" in html:
            is_already_claimed = True
            next_date = "next Friday"


        is_app_required = (
            '"73":' in html or
            "download the play store app" in html.lower() or
            "google play games on pc" in html.lower() or
            "sur un appareil android" in html.lower() or
            "نزِّل تطبيق" in html or
            "ألعاب google play على الكمبيوتر" in html.lower()
        )

        if is_app_required and not is_already_claimed:
            result["status"] = "APP_REQUIRED"
            result["message"] = (
                "Google Play requires claiming this reward directly on your mobile device (Play Store > Perks) or Google Play Games PC."
            )
            return result

        if is_already_claimed:
            result["status"] = "ALREADY_CLAIMED"
            result["next_date"] = next_date or "next Friday"
            result["message"] = f"Weekly Prize for this week is already claimed / locked! (Next: {result['next_date']})"
            return result


        claim_keywords = ["claim", "réclamer", "المطالبة"]
        if '"63":' in html and any(kw in html.lower() for kw in claim_keywords):
            logger.info("Account %s has WEB_CLAIMABLE prize! Triggering fallback browser claim...", email)
            try:
                from services.device_simulator import create_device_profile
                from services.google_automation_core.driver_factory import build_driver
                dev = create_device_profile()
                m_driver = build_driver(dev)
                try:
                    m_driver.get(merge_url)
                    time.sleep(5)
                    return claim_weekly_perk(m_driver, screenshot_prefix)
                finally:
                    m_driver.quit()
            except Exception as ex:
                logger.warning("Browser claim fallback failed: %s", ex)
                result["status"] = "ERROR"
                result["message"] = f"Failed to click claim: {ex}"
                return result

        result["status"] = "UNKNOWN"
        result["message"] = "Could not determine Weekly Prize status from Perks page."
        return result

    except Exception as e:
        logger.exception("Error in fast_claim_weekly_perk for %s: %s", email, e)
        result["status"] = "ERROR"
        result["message"] = str(e)
        return result


def is_element_enabled(el) -> bool:

    try:
        if el.get_attribute("disabled") is not None:
            return False
        if el.get_attribute("aria-disabled") == "true":
            return False
        classes = (el.get_attribute("class") or "").lower()
        if "disabled" in classes:
            return False
        return True
    except Exception:
        return False


def claim_weekly_perk(driver, screenshot_prefix: str = "/tmp/weekly") -> Dict[str, Any]:

    result = {
        "status": "UNKNOWN",
        "points": None,
        "next_date": None,
        "screenshot": None,
        "message": ""
    }

    try:
        curr_url = driver.current_url or ""
        if "points/perks" not in curr_url:
            logger.info("Navigating to Google Play Points Perks: %s", PERKS_URL)
            driver.get(PERKS_URL)
            time.sleep(4)
            curr_url = driver.current_url or ""

        logger.info("Perks page URL: %s (Title: %s)", curr_url, driver.title)


        if "accounts.google.com" in curr_url or "signin" in curr_url.lower():
            logger.warning("Not logged in or session expired on perks page: %s", curr_url)
            sc_path = f"{screenshot_prefix}_login_required.png"
            try:
                driver.save_screenshot(sc_path)
                result["screenshot"] = sc_path
            except Exception:
                pass
            result["status"] = "AUTH_REQUIRED"
            result["message"] = "Session expired. Google requested re-authentication."
            return result


        time.sleep(2)
        driver.execute_script("window.scrollTo(0, 300);")
        time.sleep(1)

        initial_sc = f"{screenshot_prefix}_page.png"
        try:
            driver.save_screenshot(initial_sc)
            result["screenshot"] = initial_sc
        except Exception:
            pass

        body_elem = driver.find_element(By.TAG_NAME, "body")
        body_text = body_elem.text if body_elem else ""
        html = driver.page_source or ""
        html_lower = html.lower()


        bal_match = re.search(r'(?:Silver|Gold|Platinum|Bronze|Argent|Or|Platine)\s*\n\s*(\d+)', body_text)
        initial_balance = int(bal_match.group(1)) if bal_match else None
        logger.info("Initial Play Points balance detected: %s", initial_balance)


        if "bronze" in html_lower and "weekly prize" in html_lower:
            logger.info("Account is in Bronze tier - weekly prizes start at Silver.")
            result["status"] = "NOT_ELIGIBLE"
            result["message"] = "Account is Bronze tier. Weekly prizes unlock at Silver tier or higher."
            return result


        claim_keywords = ["claim", "réclamer", "claim prize", "open", "ouvrir"]
        claim_btn = None


        for btn in driver.find_elements(By.TAG_NAME, "button"):
            try:
                if not btn.is_displayed():
                    continue
                if not is_element_enabled(btn):
                    continue
                text = (btn.get_attribute("innerText") or btn.text or "").strip().lower()
                aria = (btn.get_attribute("aria-label") or "").strip().lower()
                combined = f"{text} {aria}"
                if any(kw == text or kw in combined for kw in claim_keywords):
                    claim_btn = btn
                    break
            except Exception:
                continue


        if not claim_btn:
            for el in driver.find_elements(By.CSS_SELECTOR, 'div[role="button"], span, a'):
                try:
                    if not el.is_displayed():
                        continue
                    if not is_element_enabled(el):
                        continue
                    text = (el.get_attribute("innerText") or el.text or "").strip().lower()
                    if text in claim_keywords:
                        claim_btn = el
                        break
                except Exception:
                    continue


        if claim_btn:
            logger.info("Found ENABLED Claim button: '%s'! Clicking via JS...", getattr(claim_btn, 'text', 'Claim')[:30])
            try:
                driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", claim_btn)
                time.sleep(0.5)
            except Exception:
                pass

            driver.execute_script("""
                var el = arguments[0];
                var target = el.closest('[data-is-touch-wrapper]') || el.closest('button') || el;
                target.click();
            """, claim_btn)


            time.sleep(5)

            claimed_sc = f"{screenshot_prefix}_claimed.png"
            try:
                driver.save_screenshot(claimed_sc)
                result["screenshot"] = claimed_sc
            except Exception:
                pass


            try:
                new_body_elem = driver.find_element(By.TAG_NAME, "body")
                new_body_text = new_body_elem.text if new_body_elem else ""
                new_bal_match = re.search(r'(?:Silver|Gold|Platinum|Bronze|Argent|Or|Platine)\s*\n\s*(\d+)', new_body_text)
                new_balance = int(new_bal_match.group(1)) if new_bal_match else None
            except Exception:
                new_balance = None

            if initial_balance is not None and new_balance is not None and new_balance > initial_balance:
                diff = new_balance - initial_balance
                points_won = f"+{diff}"
                result["status"] = "CLAIMED"
                result["points"] = points_won
                result["message"] = f"Weekly Prize successfully claimed: {points_won} Play Points!"
                logger.info("Weekly prize claimed! Balance increased from %d to %d (%s pts)", initial_balance, new_balance, points_won)
                return result


            dialogs = driver.find_elements(By.CSS_SELECTOR, '[role="dialog"], div[aria-modal="true"]')
            for d in dialogs:
                d_text = (d.text or "").strip()
                if any(err_kw in d_text.lower() for err_kw in ["something went wrong", "erreur s'est produite", "try again"]):
                    logger.warning("Google Play error dialog after claim: '%s'", d_text)
                    result["status"] = "ERROR"
                    result["message"] = (
                        "Google Play returned: 'Something went wrong'.\n\n"
                        "⚠️ Sbeb: Country / IP Mismatch (Compte UK £ avec IP US).\n"
                        "Google t-bloki l-claim ta3 Weekly Prize ki ykon kyn decalage bin region ta3 l-compte w l-IP.\n\n"
                        "👉 Hal: Iftah Google Play Store f téléphonek w cliqui Claim rah tmchi direct!"
                    )
                    return result


            if dialogs:
                d_text = dialogs[0].text
                pts_m = re.search(r'(\+\s*\d+)\s*(?:pts|points)?', d_text, re.IGNORECASE)
                if pts_m:
                    points_won = pts_m.group(1).replace(" ", "")
                    result["status"] = "CLAIMED"
                    result["points"] = points_won
                    result["message"] = f"Weekly Prize successfully claimed: {points_won} Play Points!"
                    logger.info("Weekly prize claimed from dialog: %s", points_won)
                    return result


            still_enabled = False
            for btn in driver.find_elements(By.TAG_NAME, "button"):
                try:
                    if btn.is_displayed() and is_element_enabled(btn) and any(kw in (btn.text or "").lower() for kw in claim_keywords):
                        still_enabled = True
                        break
                except Exception:
                    pass

            if still_enabled:
                result["status"] = "ERROR"
                result["message"] = (
                    "Google Play did not process the reward click.\n"
                    "👉 Google requires claiming this reward directly on your mobile device!"
                )
                return result


        app_required_keywords = [
            "téléchargez l'appli play store", "google play jeux sur pc",
            "download the play store app", "google play games on pc",
            "sur un appareil android ou un pc", "on an android device or a pc"
        ]
        if any(kw in html_lower for kw in app_required_keywords):
            logger.info("Google Play requires native Android app or Google Play Games PC for this claim.")
            result["status"] = "APP_REQUIRED"
            result["message"] = (
                "Google Play mbloki l-claim mn l-web 3la had l-compte: "
                "talba t-claimih direct mn l-app Play Store f l-téléphone wela Google Play Games f PC."
            )
            return result


        available_elements = driver.find_elements(
            By.XPATH,
            '//*[contains(translate(text(), "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz"), "available on") or '
            'contains(translate(text(), "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz"), "disponible le") or '
            'contains(translate(text(), "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz"), "next prize") or '
            'contains(translate(text(), "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz"), "prochain prix")]'
        )
        if available_elements:
            avail_text = available_elements[0].text.strip()
            logger.info("Weekly prize already claimed / locked: %s", avail_text)
            result["status"] = "ALREADY_CLAIMED"
            result["next_date"] = avail_text
            result["message"] = f"Weekly Prize for this week is already claimed / locked! ({avail_text})"
            return result


        for btn in driver.find_elements(By.TAG_NAME, "button"):
            try:
                t = (btn.text or "").strip().lower()
                if any(kw in t for kw in claim_keywords) and not is_element_enabled(btn):
                    result["status"] = "ALREADY_CLAIMED"
                    result["message"] = "Weekly Prize is currently locked by Google Play (Already claimed or waiting for weekly drop time)."
                    return result
            except Exception:
                pass

        result["status"] = "UNKNOWN"
        result["message"] = "Could not locate Weekly Prize claim button on Perks page."
        return result

    except Exception as e:
        logger.exception("Error in claim_weekly_perk: %s", e)
        result["status"] = "ERROR"
        result["message"] = str(e)
        return result
