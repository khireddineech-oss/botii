import os
import re
import math
import time
import socket
import asyncio
import logging
from datetime import datetime
from typing import Dict, Any, Optional, List, Tuple, Union
from concurrent.futures import ThreadPoolExecutor

import aiohttp
import gpsoauth
from aiogram import Bot, Dispatcher, F, types, BaseMiddleware
from aiogram.types import (
    InlineKeyboardMarkup,
    InlineKeyboardButton,
    FSInputFile,
    LabeledPrice,
    PreCheckoutQuery,
    ReplyKeyboardRemove,
)
from aiogram.filters import CommandStart, Command, StateFilter, CommandObject
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiogram.client.session.aiohttp import AiohttpSession

import database as db
from games_catalog import GAMES_CATALOG
from google_auth import GoogleAuthenticator, EMBEDDED_SETUP_URL
from autopixel_auth import AutoPixelAuthenticator
from gpgs_unlocker import GPGSUnlocker
from services.weekly_reward import claim_weekly_perk, fast_claim_weekly_perk
from services.device_simulator import create_device_profile
from services.google_automation_core.driver_factory import build_driver

QUEST_SEMAPHORE = asyncio.Semaphore(20)
QUEST_EXECUTOR = ThreadPoolExecutor(max_workers=30)
PAGE_SIZE_ACCOUNTS = 6

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

BOT_TOKEN = os.getenv("BOT_TOKEN")
PAYMENT_BOT_TOKEN = os.getenv("PAYMENT_BOT_TOKEN")

if not BOT_TOKEN or not PAYMENT_BOT_TOKEN:
    env_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env")
    if os.path.exists(env_file):
        with open(env_file, encoding="utf-8") as f:
            for line in f:
                line_str = line.strip()
                if not line_str or line_str.startswith("#"):
                    continue
                if line_str.startswith("BOT_TOKEN=") and not BOT_TOKEN:
                    BOT_TOKEN = line_str.split("=", 1)[1].strip()
                elif line_str.startswith("PAYMENT_BOT_TOKEN=") and not PAYMENT_BOT_TOKEN:
                    PAYMENT_BOT_TOKEN = line_str.split("=", 1)[1].strip()

if not BOT_TOKEN:
    raise RuntimeError("BOT_TOKEN is not set in environment or .env file.")

session = AiohttpSession()
session._connector_init["family"] = socket.AF_INET
bot = Bot(token=BOT_TOKEN, session=session)

payment_bot = None
if PAYMENT_BOT_TOKEN:
    payment_session = AiohttpSession()
    payment_session._connector_init["family"] = socket.AF_INET
    payment_bot = Bot(token=PAYMENT_BOT_TOKEN, session=payment_session)
    logger.info("Payment bot initialized.")

dp = Dispatcher(storage=MemoryStorage())

ADMIN_IDS = [
    int(x) for x in os.getenv("ADMIN_IDS", "9093744527").split(",")
    if x.strip().isdigit()
]

CHANNEL_URL = "https://t.me/PLAYX1_ZONE"
CHANNEL_HANDLE = "@PLAYX1_ZONE"
BRAND_NAME = "PLAYX1 ZONE"
CHEST_COST = 2

STARS_PACKS = [
    (1, 2),
    (2, 4),
    (3, 6),
    (6, 13),
    (12, 25),
    (26, 50),
    (54, 100),
    (112, 200),
    (350, 600),
    (700, 1000),
]

INTRO_GIF_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "intro.gif")

_SUB_CACHE: Dict[int, Tuple[float, bool, List[Dict[str, str]]]] = {}
_SUB_CACHE_TTL = 120.0


def get_chest_cost() -> int:
    val = db.get_setting_int("chest_cost", CHEST_COST)
    return val if val >= 0 else CHEST_COST


def get_welcome_bonus() -> int:
    val = db.get_setting_int("welcome_bonus", 8)
    return val if val >= 0 else 8


def get_admin_lang() -> str:
    lang = db.get_setting("admin_lang", "ar")
    return lang if lang in ("ar", "en", "fr") else "ar"


def cleanup_file(filepath: Optional[str]):
    if filepath and os.path.exists(filepath):
        try:
            os.remove(filepath)
        except Exception:
            pass


def parse_channels_input(raw_text: str) -> List[str]:
    tokens = raw_text.strip().replace(",", " ").split()
    results = []
    for item in tokens:
        item = item.strip()
        if not item:
            continue
        item = re.sub(r"^https?://(?:www\.)?t\.m(?:e)?/", "", item)
        item = item.split("/")[0].split("?")[0]
        item = item.lstrip("@").strip()
        if item:
            results.append(f"@{item}")
    return list(dict.fromkeys(results))


async def safe_show(
    target: Union[types.Message, types.CallbackQuery],
    text: str,
    reply_markup: Optional[InlineKeyboardMarkup] = None,
    prefer_edit: bool = True,
    disable_web_page_preview: bool = True,
):
    if isinstance(target, types.CallbackQuery):
        msg = target.message
        if prefer_edit and msg and msg.text is not None:
            try:
                await msg.edit_text(
                    text,
                    reply_markup=reply_markup,
                    parse_mode="HTML",
                    disable_web_page_preview=disable_web_page_preview,
                )
                return msg
            except Exception as e:
                if "message is not modified" in str(e).lower():
                    return msg
        return await msg.answer(
            text,
            reply_markup=reply_markup,
            parse_mode="HTML",
            disable_web_page_preview=disable_web_page_preview,
        )
    return await target.answer(
        text,
        reply_markup=reply_markup,
        parse_mode="HTML",
        disable_web_page_preview=disable_web_page_preview,
    )


async def send_welcome_message(chat_id: int, user_id: int, text: str, reply_markup):
    if os.path.exists(INTRO_GIF_PATH):
        try:
            return await bot.send_animation(
                chat_id=chat_id,
                animation=FSInputFile(INTRO_GIF_PATH),
                caption=text,
                reply_markup=reply_markup,
                parse_mode="HTML",
            )
        except Exception as e:
            logger.warning("Failed to send intro gif: %s", e)
    return await bot.send_message(
        chat_id=chat_id,
        text=text,
        reply_markup=reply_markup,
        parse_mode="HTML",
        disable_web_page_preview=True,
    )


async def check_all_channels_subscription(
    bot_instance: Bot, user_id: int, use_cache: bool = True
) -> Tuple[bool, List[Dict[str, str]]]:
    if not db.get_setting_bool("force_sub_enabled", True):
        return (True, [])
    now = time.time()
    if use_cache and user_id in _SUB_CACHE:
        ts, is_sub, missing = _SUB_CACHE[user_id]
        if now - ts < _SUB_CACHE_TTL:
            return is_sub, missing

    channels = db.get_mandatory_channels()
    if not channels:
        return (True, [])

    missing = []
    for ch in channels:
        ch_uname = ch["channel_username"]
        try:
            member = await bot_instance.get_chat_member(chat_id=ch_uname, user_id=user_id)
            if member.status not in ("creator", "administrator", "member", "restricted"):
                missing.append(ch)
        except Exception as e:
            logger.warning("Error checking %s for user %s: %s", ch_uname, user_id, e)
            missing.append(ch)

    is_subscribed = len(missing) == 0
    _SUB_CACHE[user_id] = (now, is_subscribed, missing)
    return (is_subscribed, missing)


STRINGS = {
    "ar": {
        "quest": "🚀 فتح الصناديق",
        "weekly": "👑 هدية الجمعة",
        "balance": "💳 محفظتي والشحن",
        "rewards": "🎉 مركز الهدايا",
        "leaderboard": "🥇 نخبة الداعمين",
        "help": "📘 دليل الاستخدام",
        "lang": "🌐 اللغة",
        "channel": "📡 PLAYX1 ZONE",
        "admin": "🛡️ لوحة الإدارة",
        "home": "🏠 القائمة الرئيسية",
        "cancel": "✖️ إلغاء",
        "back": "↩️ رجوع",
        "welcome": (
            "⚡ <b>مرحباً بك في منصة PLAYX1 ZONE الذكية</b> ⚡\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "نظام آلي فائق السرعة لإنجاز صناديق ومكافآت <b>Google Play Points</b> بضغطة زر.\n\n"
            "✦ <b>رصيد ترحيبي فوري:</b> {welcome_bonus} توكن مجاناً عند البداية\n"
            "✦ <b>تشغيل متوازي وآمن:</b> فتح إنجازات الألعاب واستلام النقاط خلال ثوانٍ\n"
            "✦ <b>باقات مرنة:</b> شحن فوري عبر نجوم تليجرام ومكافآت يومية\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "💳 <b>رصيدك الحالي:</b> <code>{balance}</code> توكن\n"
            "📦 <b>تكلفة الصندوق:</b> <code>{chest_cost}</code> توكن\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "🧭 <i>اختر القسم المطلوب من الأزرار أدناه للبدء:</i>"
        ),
        "sub_req": (
            "🔐 <b>بوابة الدخول — PLAYX1 ZONE</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "للاستفادة من خدمات البوت المجانية والفورية، يرجى الانضمام أولاً إلى قنواتنا الرسمية أدناه.\n\n"
            "👇 <i>اشترك في القنوات ثم اضغط على زر التحقق:</i>"
        ),
        "sub_alert": "🔒 يرجى الاشتراك في جميع القنوات المطلوبة أولاً.",
        "sub_btn_check": "✅ تحقّق من اشتراكي الآن",
        "sub_ok": "🎉 تم تأكيد اشتراكك بنجاح! أهلاً بك في PLAYX1 ZONE.",
        "sub_fail": "⚠️ لم نرصد اشتراكك في كل القنوات بعد، تأكد وحاول مجدداً.",
        "banned": (
            "🚫 <b>تم تقييد وصولك إلى البوت</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "حسابك موقوف حالياً من قبل الإدارة."
        ),
        "maint": (
            "🛠️ <b>البوت في وضع الصيانة المؤقتة</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "نعمل حالياً على تحديث الأنظمة لتحسين السرعة والأداء.\n"
            "📡 تابع آخر الأخبار عبر قناتنا: https://t.me/PLAYX1_ZONE"
        ),
    },
    "en": {
        "quest": "🚀 Quest Vault",
        "weekly": "👑 Friday Perk",
        "balance": "💳 Wallet & Top-Up",
        "rewards": "🎉 Bonus Center",
        "leaderboard": "🥇 Top Supporters",
        "help": "📘 User Guide",
        "lang": "🌐 Language",
        "channel": "📡 PLAYX1 ZONE",
        "admin": "🛡️ Admin Control",
        "home": "🏠 Main Menu",
        "cancel": "✖️ Cancel",
        "back": "↩️ Back",
        "welcome": (
            "⚡ <b>Welcome to PLAYX1 ZONE Automation</b> ⚡\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "High-speed automated engine to complete <b>Google Play Points</b> chests & weekly perks.\n\n"
            "✦ <b>Welcome Gift:</b> {welcome_bonus} free tokens on startup\n"
            "✦ <b>Instant Execution:</b> Parallel achievement sync in seconds\n"
            "✦ <b>Flexible Top-Up:</b> Instant Telegram Stars packs & free rewards\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "💳 <b>Your Wallet:</b> <code>{balance}</code> Tokens\n"
            "📦 <b>Quest Cost:</b> <code>{chest_cost}</code> Tokens\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "🧭 <i>Select an option from the menu below to get started:</i>"
        ),
        "sub_req": (
            "🔐 <b>Access Gate — PLAYX1 ZONE</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "To unlock all automated bot services, please join our official channel(s) below first.\n\n"
            "👇 <i>Join the channels and tap Verify below:</i>"
        ),
        "sub_alert": "🔒 Please join all required channels first.",
        "sub_btn_check": "✅ Verify My Membership",
        "sub_ok": "🎉 Membership verified! Welcome to PLAYX1 ZONE.",
        "sub_fail": "⚠️ Subscription not detected yet. Join all channels and retry.",
        "banned": (
            "🚫 <b>Access Restricted</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "Your account is currently suspended by administration."
        ),
        "maint": (
            "🛠️ <b>Scheduled Maintenance Mode</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "We are upgrading our servers for faster performance.\n"
            "📡 Stay updated on our channel: https://t.me/PLAYX1_ZONE"
        ),
    },
    "fr": {
        "quest": "🚀 Coffres & Quêtes",
        "weekly": "👑 Bonus Vendredi",
        "balance": "💳 Solde & Recharge",
        "rewards": "🎉 Espace Cadeaux",
        "leaderboard": "🥇 Top Membres",
        "help": "📘 Guide Rapide",
        "lang": "🌐 Langue",
        "channel": "📡 PLAYX1 ZONE",
        "admin": "🛡️ Panneau Admin",
        "home": "🏠 Menu Principal",
        "cancel": "✖️ Annuler",
        "back": "↩️ Retour",
        "welcome": (
            "⚡ <b>Bienvenue sur PLAYX1 ZONE</b> ⚡\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "Moteur automatisé ultra-rapide pour valider vos coffres et bonus <b>Google Play Points</b>.\n\n"
            "✦ <b>Cadeau de Bienvenue :</b> {welcome_bonus} tokens offerts au démarrage\n"
            "✦ <b>Validation Express :</b> Synchronisation parallèle en quelques secondes\n"
            "✦ <b>Packs Flexibles :</b> Recharge instantanée Telegram Stars & bonus gratuits\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "💳 <b>Votre Solde :</b> <code>{balance}</code> Tokens\n"
            "📦 <b>Coût par Coffre :</b> <code>{chest_cost}</code> Tokens\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "🧭 <i>Choisissez une action dans le menu ci-dessous :</i>"
        ),
        "sub_req": (
            "🔐 <b>Accès Requis — PLAYX1 ZONE</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "Pour utiliser les outils automatisés du bot, veuillez rejoindre nos chaînes officielles ci-dessous.\n\n"
            "👇 <i>Rejoignez les chaînes puis cliquez sur Vérifier :</i>"
        ),
        "sub_alert": "🔒 Veuillez d'abord rejoindre toutes les chaînes requises.",
        "sub_btn_check": "✅ Vérifier mon Abonnement",
        "sub_ok": "🎉 Abonnement confirmé ! Bienvenue sur PLAYX1 ZONE.",
        "sub_fail": "⚠️ Abonnement non détecté. Rejoignez toutes les chaînes puis réessayez.",
        "banned": (
            "🚫 <b>Accès Restreint</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "Votre compte est actuellement suspendu par l'administration."
        ),
        "maint": (
            "🛠️ <b>Maintenance en Cours</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "Nos serveurs sont en cours de mise à jour.\n"
            "📡 Suivez les actualités sur : https://t.me/PLAYX1_ZONE"
        ),
    },
}

ADMIN_STRINGS = {
    "ar": {
        "title": "🛡️ <b>مركز التحكم الإداري — PLAYX1 ZONE</b>",
        "subtitle": (
            "━━━━━━━━━━━━━━━━━━━━\n"
            "⚙️ <b>حالة النظام:</b> {maint} | 📡 <b>الاشتراك الإجباري:</b> {fsub}\n"
            "📦 <b>تكلفة الصندوق:</b> <code>{cost}</code> | 🎁 <b>هدية التسجيل:</b> <code>{wbonus}</code>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "اختر الأداة الإدارية المطلوبة:"
        ),
        "on": "🟢 مفعّل",
        "off": "🔴 متوقف",
        "maint_on": "🟠 صيانة",
        "maint_off": "🟢 يعمل",
        "btn_stats": "📊 الإحصائيات",
        "btn_lookup": "🔎 بحث عن عضو",
        "btn_add": "➕ شحن توكنات",
        "btn_sub": "➖ خصم توكنات",
        "btn_gift_all": "🎁 هدية للجميع",
        "btn_bans": "🚫 المحظورون",
        "btn_mand": "📡 القنوات الإجبارية",
        "btn_promo_ch": "🌟 القنوات الشريكة",
        "btn_promos": "🎫 أكواد الهدايا",
        "btn_bcast": "📣 إذاعة شاملة",
        "btn_dm": "📩 رسالة لعضو",
        "btn_settings": "⚙️ إعدادات البوت",
        "btn_backup": "💾 نسخة احتياطية",
        "btn_lang": "🌐 لغة اللوحة: العربية",
        "btn_home": "🏠 واجهة البوت",
        "btn_close": "✖️ إغلاق",
        "btn_back_admin": "↩️ لوحة الإدارة",
        "btn_cancel": "✖️ إلغاء",
        "closed": "تم إغلاق لوحة الإدارة.",
        "lang_title": "🌐 <b>اختر لغة لوحة التحكم الإدارية:</b>",
        "lang_updated": "✅ تم تغيير لغة لوحة الإدارة إلى العربية.",
        "stats_body": (
            "📊 <b>التقرير الإحصائي الشامل — PLAYX1 ZONE</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "👥 <b>إجمالي الأعضاء:</b> <code>{total_users}</code>\n"
            "🆕 <b>أعضاء اليوم:</b> <code>{new_users_today}</code>\n"
            "🚫 <b>الحسابات المحظورة:</b> <code>{banned_users}</code>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "💳 <b>التوكنات المتداولة:</b> <code>{total_balance}</code>\n"
            "🛍️ <b>التوكنات المشتراة:</b> <code>{tokens_purchased}</code>\n"
            "⭐ <b>إجمالي النجوم:</b> <code>{stars_spent}</code>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "🚀 <b>صناديق مكتملة:</b> <code>{completed_quests}</code>\n"
            "⚠️ <b>محاولات فاشلة:</b> <code>{failed_quests}</code>\n"
            "🔑 <b>حسابات محفوظة:</b> <code>{saved_accs}</code>\n"
            "🤝 <b>إحالات ناجحة:</b> <code>{total_referrals}</code>\n"
            "📡 <b>قنوات إجبارية / شريكة:</b> <code>{mandatory_channels} / {promo_channels}</code>\n"
            "🎫 <b>أكواد هدايا نشطة:</b> <code>{active_promos}</code>"
        ),
        "lookup_prompt": "🔎 <b>البحث عن عضو:</b>\n\nأرسل معرّف التليجرام (ID) أو اليوزرنيم (<code>@username</code>):\n<i>(أو أرسل /cancel للإلغاء)</i>",
        "user_not_found": "⚠️ لم يتم العثور على هذا العضو في قاعدة البيانات.",
        "user_card": (
            "👤 <b>بطاقة العضو</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "🆔 <b>المعرّف:</b> <code>{uid}</code>\n"
            "🔖 <b>اليوزر:</b> {uname}\n"
            "💳 <b>الرصيد:</b> <code>{bal}</code> توكن\n"
            "🌐 <b>اللغة:</b> <code>{ulang}</code>\n"
            "🛡️ <b>الحالة:</b> {status}\n"
            "🚀 <b>الصناديق المنجزة:</b> <code>{qcount}</code>\n"
            "🔑 <b>الحسابات المحفوظة:</b> <code>{acount}</code>\n"
            "🤝 <b>الإحالات النشطة:</b> <code>{rcount}</code>\n"
            "⭐ <b>النجوم المنفقة:</b> <code>{stars}</code>\n"
            "📅 <b>تاريخ الانضمام:</b> <code>{created}</code>"
        ),
        "status_active": "🟢 نشط",
        "status_banned": "🔴 محظور",
        "u_btn_add": "➕ شحن لهذا العضو",
        "u_btn_sub": "➖ خصم من هذا العضو",
        "u_btn_ban": "🚫 حظر العضو",
        "u_btn_unban": "✅ فك الحظر",
        "u_btn_dm": "📩 مراسلة العضو",
        "add_prompt": "➕ <b>شحن توكنات لعضو:</b>\n\nأرسل المعرّف أو اليوزر متبوعاً بالكمية:\nمثال: <code>@username 25</code> أو <code>123456789 25</code>",
        "add_one_prompt": "➕ <b>أرسل عدد التوكنات المراد إضافتها للعضو</b> <code>{uid}</code>:",
        "sub_prompt": "➖ <b>خصم توكنات من عضو:</b>\n\nأرسل المعرّف أو اليوزر متبوعاً بالكمية:\nمثال: <code>@username 10</code> أو <code>123456789 10</code>",
        "sub_one_prompt": "➖ <b>أرسل عدد التوكنات المراد خصمها من العضو</b> <code>{uid}</code>:",
        "bad_format": "⚠️ صيغة غير صحيحة! يرجى التأكد والمحاولة مجدداً.",
        "added_ok": "✅ <b>تم شحن {amount} توكن للعضو {target} بنجاح!</b>\n💳 الرصيد الجديد: <code>{bal}</code> توكن",
        "sub_ok": "✅ <b>تم خصم {amount} توكن من العضو {target}.</b>\n💳 الرصيد الجديد: <code>{bal}</code> توكن",
        "gift_prompt": "🎁 <b>توزيع هدية جماعية لكل الأعضاء:</b>\n\nأرسل عدد التوكنات المراد إضافتها لكل عضو نشط (مثال: <code>5</code>):",
        "gift_done": "🎉 <b>تم توزيع هدية جماعية بنجاح!</b>\n\n🎁 <b>القيمة:</b> +{amount} توكن\n👥 <b>المستفيدون:</b> {count} عضو\n📨 <b>تم إشعارهم:</b> {sent} | ❌ <b>فشل الإشعار:</b> {failed}",
        "bans_title": "🚫 <b>إدارة الأعضاء المحظورين:</b>\n\n",
        "bans_empty": "<i>لا يوجد أي أعضاء محظورين حالياً.</i>",
        "btn_ban_new": "➕ حظر عضو جديد",
        "ban_prompt": "🚫 <b>حظر عضو:</b>\n\nأرسل معرّف العضو (ID) أو اليوزر (<code>@username</code>):",
        "cannot_ban_admin": "⚠️ لا يمكن حظر حساب الأدمن!",
        "banned_ok": "🚫 تم حظر العضو <code>{uid}</code> بنجاح.",
        "unbanned_ok": "✅ تم فك الحظر عن العضو <code>{uid}</code> بنجاح.",
        "mand_title": "📡 <b>القنوات الإجبارية للاشتراك:</b>\n\n",
        "mand_empty": "<i>لا توجد قنوات إجبارية حالياً.</i>\n",
        "btn_add_mand": "➕ إضافة قناة إجبارية",
        "btn_toggle_fsub": "🔄 الاشتراك الإجباري: {state}",
        "add_mand_prompt": (
            "📡 <b>إضافة قنوات إجبارية:</b>\n\n"
            "أرسل معرّفات أو روابط القنوات (سطر لكل قناة):\n"
            "<code>@PLAYX1_ZONE\nhttps://t.me/channel2</code>\n\n"
            "⚠️ <i>تأكد من رفع البوت @{bot_uname} مشرفاً داخل كل قناة!</i>"
        ),
        "mand_added": "✅ <b>تمت إضافة {n} قناة إجبارية بنجاح:</b>\n\n",
        "ch_deleted": "✅ تم حذف القناة {ch}.",
        "promo_ch_title": "🌟 <b>القنوات الشريكة والإعلانية:</b>\n\n",
        "promo_ch_empty": "<i>لا توجد قنوات شريكة مضافة بعد.</i>\n",
        "btn_add_promo_ch": "➕ إضافة قناة شريكة",
        "add_promo_ch_prompt": (
            "🌟 <b>إضافة قنوات شريكة:</b>\n\n"
            "أرسل روابط أو معرّفات القنوات (سطر لكل قناة):\n"
            "<code>https://t.me/channel1\n@channel2</code>"
        ),
        "promo_ch_added": "✅ <b>تمت إضافة {n} قناة شريكة بنجاح:</b>\n\n",
        "promos_title": "🎫 <b>إدارة أكواد الهدايا:</b>\n\n",
        "promos_empty": "<i>لا توجد أكواد هدايا نشطة حالياً.</i>\n",
        "btn_new_promo": "➕ إنشاء كود جديد",
        "new_promo_prompt": (
            "🎫 <b>إنشاء كود هدية جديد:</b>\n\n"
            "أرسل البيانات بالصيغة التالية:\n"
            "<code>CODE TOKENS MAX_USES</code>\n\n"
            "مثال: <code>PLAYX10 10 100</code>"
        ),
        "promo_created": (
            "✅ <b>تم إنشاء كود الهدية بنجاح!</b>\n\n"
            "🎫 <b>الكود:</b> <code>{code}</code>\n"
            "🎁 <b>المكافأة:</b> +{tokens} توكن\n"
            "👥 <b>الحد الأقصى:</b> {max_uses} مستخدم"
        ),
        "promo_bcast_btn": "📣 إذاعة الكود للجميع",
        "promo_deleted": "✅ تم حذف الكود {code}.",
        "bcast_prompt": "📣 <b>إذاعة شاملة لجميع الأعضاء:</b>\n\nأرسل الآن رسالتك (نص، صورة، فيديو، أو ملف) وسيتم نسخها وإرسالها للجميع:",
        "bcast_running": "⏳ جاري الإرسال إلى <b>{n}</b> عضو...",
        "bcast_done": "📣 <b>اكتملت الإذاعة بنجاح!</b>\n\n✅ <b>نجح الإرسال:</b> {ok}\n❌ <b>فشل/محظور:</b> {fail}",
        "dm_prompt_user": "📩 <b>إرسال رسالة خاصة لعضو:</b>\n\nأرسل معرّف العضو (ID) أو اليوزر (<code>@username</code>):",
        "dm_prompt_msg": "✍️ <b>أرسل الآن الرسالة المطلوب إيصالها للعضو</b> <code>{uid}</code>:",
        "dm_sent": "✅ تم إيصال رسالتك إلى العضو <code>{uid}</code> بنجاح.",
        "dm_fail": "❌ تعذر إرسال الرسالة للعضو (ربما قام بحظر البوت).",
        "settings_title": (
            "⚙️ <b>إعدادات نظام PLAYX1 ZONE</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "🛠️ <b>وضع الصيانة:</b> {maint}\n"
            "📡 <b>الاشتراك الإجباري:</b> {fsub}\n"
            "📦 <b>تكلفة الصندوق:</b> <code>{cost}</code> توكن\n"
            "🎁 <b>رصيد الترحيب:</b> <code>{wbonus}</code> توكن"
        ),
        "btn_maint": "🛠️ وضع الصيانة: {state}",
        "btn_fsub": "📡 الاشتراك الإجباري: {state}",
        "btn_edit_cost": "📦 تعديل تكلفة الصندوق",
        "btn_edit_welcome": "🎁 تعديل رصيد الترحيب",
        "cost_prompt": "📦 <b>تعديل تكلفة الصندوق:</b>\n\nأرسل العدد الجديد للتوكنات المطلوبة لكل صندوق (مثال: <code>2</code>):",
        "welcome_prompt": "🎁 <b>تعديل رصيد الترحيب للأعضاء الجدد:</b>\n\nأرسل العدد الجديد للتوكنات المجانية عند التسجيل (مثال: <code>8</code>):",
        "setting_saved": "✅ تم حفظ الإعداد الجديد بنجاح!",
        "backup_caption": "💾 <b>نسخة احتياطية لقاعدة بيانات PLAYX1 ZONE</b>\n🕒 {ts}",
        "backup_err": "❌ تعذر العثور على ملف قاعدة البيانات.",
    },
    "en": {
        "title": "🛡️ <b>Admin Control Center — PLAYX1 ZONE</b>",
        "subtitle": (
            "━━━━━━━━━━━━━━━━━━━━\n"
            "⚙️ <b>System:</b> {maint} | 📡 <b>Force Sub:</b> {fsub}\n"
            "📦 <b>Quest Cost:</b> <code>{cost}</code> | 🎁 <b>Welcome Gift:</b> <code>{wbonus}</code>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "Choose an administrative tool below:"
        ),
        "on": "🟢 Enabled",
        "off": "🔴 Disabled",
        "maint_on": "🟠 Maintenance",
        "maint_off": "🟢 Online",
        "btn_stats": "📊 Analytics",
        "btn_lookup": "🔎 User Lookup",
        "btn_add": "➕ Credit Tokens",
        "btn_sub": "➖ Deduct Tokens",
        "btn_gift_all": "🎁 Gift Everyone",
        "btn_bans": "🚫 Banned Users",
        "btn_mand": "📡 Mandatory Channels",
        "btn_promo_ch": "🌟 Partner Channels",
        "btn_promos": "🎫 Gift Codes",
        "btn_bcast": "📣 Broadcast",
        "btn_dm": "📩 Message User",
        "btn_settings": "⚙️ Bot Settings",
        "btn_backup": "💾 DB Backup",
        "btn_lang": "🌐 Panel Lang: English",
        "btn_home": "🏠 Bot Home",
        "btn_close": "✖️ Close",
        "btn_back_admin": "↩️ Admin Panel",
        "btn_cancel": "✖️ Cancel",
        "closed": "Admin panel closed.",
        "lang_title": "🌐 <b>Select Admin Panel Language:</b>",
        "lang_updated": "✅ Admin panel language switched to English.",
        "stats_body": (
            "📊 <b>Platform Analytics — PLAYX1 ZONE</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "👥 <b>Total Users:</b> <code>{total_users}</code>\n"
            "🆕 <b>Joined Today:</b> <code>{new_users_today}</code>\n"
            "🚫 <b>Banned Users:</b> <code>{banned_users}</code>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "💳 <b>Tokens in Wallets:</b> <code>{total_balance}</code>\n"
            "🛍️ <b>Tokens Purchased:</b> <code>{tokens_purchased}</code>\n"
            "⭐ <b>Total Stars Spent:</b> <code>{stars_spent}</code>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "🚀 <b>Completed Quests:</b> <code>{completed_quests}</code>\n"
            "⚠️ <b>Failed Attempts:</b> <code>{failed_quests}</code>\n"
            "🔑 <b>Saved Accounts:</b> <code>{saved_accs}</code>\n"
            "🤝 <b>Active Referrals:</b> <code>{total_referrals}</code>\n"
            "📡 <b>Mandatory / Partner Ch:</b> <code>{mandatory_channels} / {promo_channels}</code>\n"
            "🎫 <b>Active Gift Codes:</b> <code>{active_promos}</code>"
        ),
        "lookup_prompt": "🔎 <b>User Lookup:</b>\n\nSend Telegram ID or username (<code>@username</code>):\n<i>(or send /cancel)</i>",
        "user_not_found": "⚠️ User not found in database.",
        "user_card": (
            "👤 <b>User Profile</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "🆔 <b>ID:</b> <code>{uid}</code>\n"
            "🔖 <b>Username:</b> {uname}\n"
            "💳 <b>Balance:</b> <code>{bal}</code> Tokens\n"
            "🌐 <b>Language:</b> <code>{ulang}</code>\n"
            "🛡️ <b>Status:</b> {status}\n"
            "🚀 <b>Completed Quests:</b> <code>{qcount}</code>\n"
            "🔑 <b>Saved Accounts:</b> <code>{acount}</code>\n"
            "🤝 <b>Referrals:</b> <code>{rcount}</code>\n"
            "⭐ <b>Stars Spent:</b> <code>{stars}</code>\n"
            "📅 <b>Joined:</b> <code>{created}</code>"
        ),
        "status_active": "🟢 Active",
        "status_banned": "🔴 Banned",
        "u_btn_add": "➕ Credit User",
        "u_btn_sub": "➖ Deduct User",
        "u_btn_ban": "🚫 Ban User",
        "u_btn_unban": "✅ Unban User",
        "u_btn_dm": "📩 Message User",
        "add_prompt": "➕ <b>Credit Tokens:</b>\n\nSend username/ID and amount:\nExample: <code>@username 25</code> or <code>123456789 25</code>",
        "add_one_prompt": "➕ <b>Enter token amount to credit user</b> <code>{uid}</code>:",
        "sub_prompt": "➖ <b>Deduct Tokens:</b>\n\nSend username/ID and amount:\nExample: <code>@username 10</code> or <code>123456789 10</code>",
        "sub_one_prompt": "➖ <b>Enter token amount to deduct from user</b> <code>{uid}</code>:",
        "bad_format": "⚠️ Invalid format! Please check and try again.",
        "added_ok": "✅ <b>Credited {amount} tokens to {target}!</b>\n💳 New Balance: <code>{bal}</code> Tokens",
        "sub_ok": "✅ <b>Deducted {amount} tokens from {target}.</b>\n💳 New Balance: <code>{bal}</code> Tokens",
        "gift_prompt": "🎁 <b>Global Token Gift:</b>\n\nEnter token amount to grant every active user (e.g. <code>5</code>):",
        "gift_done": "🎉 <b>Global Gift Distributed!</b>\n\n🎁 <b>Amount:</b> +{amount} Tokens\n👥 <b>Credited Users:</b> {count}\n📨 <b>Notified:</b> {sent} | ❌ <b>Failed:</b> {failed}",
        "bans_title": "🚫 <b>Banned Users Management:</b>\n\n",
        "bans_empty": "<i>No banned users currently.</i>",
        "btn_ban_new": "➕ Ban a User",
        "ban_prompt": "🚫 <b>Ban User:</b>\n\nSend user ID or <code>@username</code>:",
        "cannot_ban_admin": "⚠️ Cannot ban an administrator!",
        "banned_ok": "🚫 User <code>{uid}</code> has been banned.",
        "unbanned_ok": "✅ User <code>{uid}</code> has been unbanned.",
        "mand_title": "📡 <b>Mandatory Channels (Force Sub):</b>\n\n",
        "mand_empty": "<i>No mandatory channels configured.</i>\n",
        "btn_add_mand": "➕ Add Mandatory Channel",
        "btn_toggle_fsub": "🔄 Force Sub: {state}",
        "add_mand_prompt": (
            "📡 <b>Add Mandatory Channels:</b>\n\n"
            "Send channel handles or links (one per line):\n"
            "<code>@PLAYX1_ZONE\nhttps://t.me/channel2</code>\n\n"
            "⚠️ <i>Make sure @{bot_uname} is added as Admin in each channel!</i>"
        ),
        "mand_added": "✅ <b>Added {n} mandatory channel(s):</b>\n\n",
        "ch_deleted": "✅ Channel {ch} removed.",
        "promo_ch_title": "🌟 <b>Partner & Sponsored Channels:</b>\n\n",
        "promo_ch_empty": "<i>No partner channels configured yet.</i>\n",
        "btn_add_promo_ch": "➕ Add Partner Channel",
        "add_promo_ch_prompt": (
            "🌟 <b>Add Partner Channels:</b>\n\n"
            "Send channel links or handles (one per line):\n"
            "<code>https://t.me/channel1\n@channel2</code>"
        ),
        "promo_ch_added": "✅ <b>Added {n} partner channel(s):</b>\n\n",
        "promos_title": "🎫 <b>Gift Codes Management:</b>\n\n",
        "promos_empty": "<i>No active gift codes.</i>\n",
        "btn_new_promo": "➕ Create Gift Code",
        "new_promo_prompt": (
            "🎫 <b>Create New Gift Code:</b>\n\n"
            "Send using format:\n"
            "<code>CODE TOKENS MAX_USES</code>\n\n"
            "Example: <code>PLAYX10 10 100</code>"
        ),
        "promo_created": (
            "✅ <b>Gift Code Created!</b>\n\n"
            "🎫 <b>Code:</b> <code>{code}</code>\n"
            "🎁 <b>Reward:</b> +{tokens} Tokens\n"
            "👥 <b>Max Uses:</b> {max_uses} users"
        ),
        "promo_bcast_btn": "📣 Broadcast Code to All",
        "promo_deleted": "✅ Code {code} deleted.",
        "bcast_prompt": "📣 <b>Global Broadcast:</b>\n\nSend any message (text, photo, video, or document) to broadcast to all users:",
        "bcast_running": "⏳ Broadcasting to <b>{n}</b> users...",
        "bcast_done": "📣 <b>Broadcast Finished!</b>\n\n✅ <b>Delivered:</b> {ok}\n❌ <b>Failed/Blocked:</b> {fail}",
        "dm_prompt_user": "📩 <b>Direct Message User:</b>\n\nSend user ID or <code>@username</code>:",
        "dm_prompt_msg": "✍️ <b>Send the message to deliver to</b> <code>{uid}</code>:",
        "dm_sent": "✅ Message delivered to <code>{uid}</code>.",
        "dm_fail": "❌ Could not send message (user may have blocked the bot).",
        "settings_title": (
            "⚙️ <b>PLAYX1 ZONE System Settings</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "🛠️ <b>Maintenance Mode:</b> {maint}\n"
            "📡 <b>Force Subscription:</b> {fsub}\n"
            "📦 <b>Quest Cost:</b> <code>{cost}</code> Tokens\n"
            "🎁 <b>Welcome Gift:</b> <code>{wbonus}</code> Tokens"
        ),
        "btn_maint": "🛠️ Maintenance: {state}",
        "btn_fsub": "📡 Force Sub: {state}",
        "btn_edit_cost": "📦 Edit Quest Cost",
        "btn_edit_welcome": "🎁 Edit Welcome Gift",
        "cost_prompt": "📦 <b>Edit Quest Cost:</b>\n\nEnter the new token cost per chest (e.g. <code>2</code>):",
        "welcome_prompt": "🎁 <b>Edit Welcome Bonus:</b>\n\nEnter free tokens granted to new users (e.g. <code>8</code>):",
        "setting_saved": "✅ Setting updated successfully!",
        "backup_caption": "💾 <b>PLAYX1 ZONE Database Backup</b>\n🕒 {ts}",
        "backup_err": "❌ Database file not found.",
    },
    "fr": {
        "title": "🛡️ <b>Centre de Contrôle Admin — PLAYX1 ZONE</b>",
        "subtitle": (
            "━━━━━━━━━━━━━━━━━━━━\n"
            "⚙️ <b>Système :</b> {maint} | 📡 <b>Abonnement Forcé :</b> {fsub}\n"
            "📦 <b>Coût Coffre :</b> <code>{cost}</code> | 🎁 <b>Bonus Départ :</b> <code>{wbonus}</code>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "Choisissez un outil d'administration :"
        ),
        "on": "🟢 Activé",
        "off": "🔴 Désactivé",
        "maint_on": "🟠 Maintenance",
        "maint_off": "🟢 En Ligne",
        "btn_stats": "📊 Statistiques",
        "btn_lookup": "🔎 Chercher Membre",
        "btn_add": "➕ Créditer Tokens",
        "btn_sub": "➖ Déduire Tokens",
        "btn_gift_all": "🎁 Cadeau Global",
        "btn_bans": "🚫 Utilisateurs Bannis",
        "btn_mand": "📡 Chaînes Obligatoires",
        "btn_promo_ch": "🌟 Chaînes Partenaires",
        "btn_promos": "🎫 Codes Cadeaux",
        "btn_bcast": "📣 Diffusion Globale",
        "btn_dm": "📩 Message Privé",
        "btn_settings": "⚙️ Paramètres Bot",
        "btn_backup": "💾 Sauvegarde BDD",
        "btn_lang": "🌐 Langue : Français",
        "btn_home": "🏠 Accueil Bot",
        "btn_close": "✖️ Fermer",
        "btn_back_admin": "↩️ Panneau Admin",
        "btn_cancel": "✖️ Annuler",
        "closed": "Panneau admin fermé.",
        "lang_title": "🌐 <b>Choisissez la langue du Panneau Admin :</b>",
        "lang_updated": "✅ Langue du panneau définie sur Français.",
        "stats_body": (
            "📊 <b>Statistiques Globales — PLAYX1 ZONE</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "👥 <b>Total Membres :</b> <code>{total_users}</code>\n"
            "🆕 <b>Nouveaux Aujourd'hui :</b> <code>{new_users_today}</code>\n"
            "🚫 <b>Membres Bannis :</b> <code>{banned_users}</code>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "💳 <b>Tokens en Circulation :</b> <code>{total_balance}</code>\n"
            "🛍️ <b>Tokens Achetés :</b> <code>{tokens_purchased}</code>\n"
            "⭐ <b>Total Stars Dépensées :</b> <code>{stars_spent}</code>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "🚀 <b>Quêtes Validées :</b> <code>{completed_quests}</code>\n"
            "⚠️ <b>Échecs :</b> <code>{failed_quests}</code>\n"
            "🔑 <b>Comptes Sauvegardés :</b> <code>{saved_accs}</code>\n"
            "🤝 <b>Parrainages Actifs :</b> <code>{total_referrals}</code>\n"
            "📡 <b>Chaînes Oblig. / Part. :</b> <code>{mandatory_channels} / {promo_channels}</code>\n"
            "🎫 <b>Codes Actifs :</b> <code>{active_promos}</code>"
        ),
        "lookup_prompt": "🔎 <b>Recherche Membre :</b>\n\nEnvoyez l'ID Telegram ou le pseudo (<code>@username</code>) :\n<i>(ou /cancel pour annuler)</i>",
        "user_not_found": "⚠️ Utilisateur introuvable dans la base.",
        "user_card": (
            "👤 <b>Fiche Membre</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "🆔 <b>ID :</b> <code>{uid}</code>\n"
            "🔖 <b>Pseudo :</b> {uname}\n"
            "💳 <b>Solde :</b> <code>{bal}</code> Tokens\n"
            "🌐 <b>Langue :</b> <code>{ulang}</code>\n"
            "🛡️ <b>Statut :</b> {status}\n"
            "🚀 <b>Quêtes Validées :</b> <code>{qcount}</code>\n"
            "🔑 <b>Comptes Sauvegardés :</b> <code>{acount}</code>\n"
            "🤝 <b>Parrainages :</b> <code>{rcount}</code>\n"
            "⭐ <b>Stars Dépensées :</b> <code>{stars}</code>\n"
            "📅 <b>Inscrit le :</b> <code>{created}</code>"
        ),
        "status_active": "🟢 Actif",
        "status_banned": "🔴 Banni",
        "u_btn_add": "➕ Créditer",
        "u_btn_sub": "➖ Déduire",
        "u_btn_ban": "🚫 Bannir",
        "u_btn_unban": "✅ Débannir",
        "u_btn_dm": "📩 Envoyer MP",
        "add_prompt": "➕ <b>Créditer des Tokens :</b>\n\nFormat : <code>@username 25</code> ou <code>123456789 25</code>",
        "add_one_prompt": "➕ <b>Entrez le montant à créditer à</b> <code>{uid}</code> :",
        "sub_prompt": "➖ <b>Déduire des Tokens :</b>\n\nFormat : <code>@username 10</code> ou <code>123456789 10</code>",
        "sub_one_prompt": "➖ <b>Entrez le montant à déduire de</b> <code>{uid}</code> :",
        "bad_format": "⚠️ Format invalide ! Veuillez réessayer.",
        "added_ok": "✅ <b>+{amount} tokens crédités à {target} !</b>\n💳 Nouveau solde : <code>{bal}</code> Tokens",
        "sub_ok": "✅ <b>-{amount} tokens déduits de {target}.</b>\n💳 Nouveau solde : <code>{bal}</code> Tokens",
        "gift_prompt": "🎁 <b>Cadeau Global :</b>\n\nEntrez le nombre de tokens à offrir à tous les membres actifs (ex : <code>5</code>) :",
        "gift_done": "🎉 <b>Cadeau Global Distribué !</b>\n\n🎁 <b>Montant :</b> +{amount} Tokens\n👥 <b>Bénéficiaires :</b> {count}\n📨 <b>Notifiés :</b> {sent} | ❌ <b>Échecs :</b> {failed}",
        "bans_title": "🚫 <b>Gestion des Membres Bannis :</b>\n\n",
        "bans_empty": "<i>Aucun membre banni actuellement.</i>",
        "btn_ban_new": "➕ Bannir un Membre",
        "ban_prompt": "🚫 <b>Bannir un Membre :</b>\n\nEnvoyez son ID ou <code>@username</code> :",
        "cannot_ban_admin": "⚠️ Impossible de bannir un administrateur !",
        "banned_ok": "🚫 L'utilisateur <code>{uid}</code> a été banni.",
        "unbanned_ok": "✅ L'utilisateur <code>{uid}</code> a été débanni.",
        "mand_title": "📡 <b>Chaînes Obligatoires :</b>\n\n",
        "mand_empty": "<i>Aucune chaîne obligatoire configurée.</i>\n",
        "btn_add_mand": "➕ Ajouter Chaîne Obligatoire",
        "btn_toggle_fsub": "🔄 Abonnement Forcé : {state}",
        "add_mand_prompt": (
            "📡 <b>Ajouter des Chaînes Obligatoires :</b>\n\n"
            "Envoyez les pseudos ou liens (un par ligne) :\n"
            "<code>@PLAYX1_ZONE\nhttps://t.me/channel2</code>\n\n"
            "⚠️ <i>Assurez-vous que @{bot_uname} soit Admin dans chaque chaîne !</i>"
        ),
        "mand_added": "✅ <b>{n} chaîne(s) obligatoire(s) ajoutée(s) :</b>\n\n",
        "ch_deleted": "✅ Chaîne {ch} supprimée.",
        "promo_ch_title": "🌟 <b>Chaînes Partenaires :</b>\n\n",
        "promo_ch_empty": "<i>Aucune chaîne partenaire configurée.</i>\n",
        "btn_add_promo_ch": "➕ Ajouter Chaîne Partenaire",
        "add_promo_ch_prompt": (
            "🌟 <b>Ajouter des Chaînes Partenaires :</b>\n\n"
            "Envoyez les liens ou pseudos (un par ligne) :\n"
            "<code>https://t.me/channel1\n@channel2</code>"
        ),
        "promo_ch_added": "✅ <b>{n} chaîne(s) partenaire(s) ajoutée(s) :</b>\n\n",
        "promos_title": "🎫 <b>Gestion des Codes Cadeaux :</b>\n\n",
        "promos_empty": "<i>Aucun code cadeau actif.</i>\n",
        "btn_new_promo": "➕ Créer un Code",
        "new_promo_prompt": (
            "🎫 <b>Créer un Code Cadeau :</b>\n\n"
            "Format : <code>CODE TOKENS MAX_USES</code>\n\n"
            "Exemple : <code>PLAYX10 10 100</code>"
        ),
        "promo_created": (
            "✅ <b>Code Cadeau Créé !</b>\n\n"
            "🎫 <b>Code :</b> <code>{code}</code>\n"
            "🎁 <b>Récompense :</b> +{tokens} Tokens\n"
            "👥 <b>Limite :</b> {max_uses} membres"
        ),
        "promo_bcast_btn": "📣 Diffuser ce Code",
        "promo_deleted": "✅ Code {code} supprimé.",
        "bcast_prompt": "📣 <b>Diffusion Globale :</b>\n\nEnvoyez le message (texte, photo, vidéo ou fichier) à diffuser à tous les membres :",
        "bcast_running": "⏳ Envoi en cours à <b>{n}</b> membres...",
        "bcast_done": "📣 <b>Diffusion Terminée !</b>\n\n✅ <b>Envoyés :</b> {ok}\n❌ <b>Échecs/Bloqués :</b> {fail}",
        "dm_prompt_user": "📩 <b>Message Privé :</b>\n\nEnvoyez l'ID ou <code>@username</code> du destinataire :",
        "dm_prompt_msg": "✍️ <b>Envoyez maintenant le message pour</b> <code>{uid}</code> :",
        "dm_sent": "✅ Message envoyé à <code>{uid}</code>.",
        "dm_fail": "❌ Échec d'envoi (l'utilisateur a peut-être bloqué le bot).",
        "settings_title": (
            "⚙️ <b>Paramètres Système PLAYX1 ZONE</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "🛠️ <b>Mode Maintenance :</b> {maint}\n"
            "📡 <b>Abonnement Forcé :</b> {fsub}\n"
            "📦 <b>Coût par Coffre :</b> <code>{cost}</code> Tokens\n"
            "🎁 <b>Bonus Départ :</b> <code>{wbonus}</code> Tokens"
        ),
        "btn_maint": "🛠️ Maintenance : {state}",
        "btn_fsub": "📡 Abonnement Forcé : {state}",
        "btn_edit_cost": "📦 Modifier Coût Coffre",
        "btn_edit_welcome": "🎁 Modifier Bonus Départ",
        "cost_prompt": "📦 <b>Modifier le Coût par Coffre :</b>\n\nEntrez le nouveau coût en tokens (ex : <code>2</code>) :",
        "welcome_prompt": "🎁 <b>Modifier le Bonus de Bienvenue :</b>\n\nEntrez le nombre de tokens offerts aux nouveaux membres (ex : <code>8</code>) :",
        "setting_saved": "✅ Paramètre enregistré !",
        "backup_caption": "💾 <b>Sauvegarde Base de Données PLAYX1 ZONE</b>\n🕒 {ts}",
        "backup_err": "❌ Fichier de base de données introuvable.",
    },
}


class AdminForm(StatesGroup):
    waiting_for_add_tokens = State()
    waiting_for_sub_tokens = State()
    waiting_for_add_tokens_target = State()
    waiting_for_sub_tokens_target = State()
    waiting_for_lookup = State()
    waiting_for_broadcast = State()
    waiting_for_add_mandatory = State()
    waiting_for_add_promo_ch = State()
    waiting_for_add_promo = State()
    waiting_for_gift_all = State()
    waiting_for_ban_user = State()
    waiting_for_dm_user = State()
    waiting_for_dm_message = State()
    waiting_for_edit_cost = State()
    waiting_for_edit_welcome = State()


class UserForm(StatesGroup):
    waiting_for_promo_code = State()


class QuestForm(StatesGroup):
    waiting_for_credentials = State()
    confirm_credentials = State()
    waiting_for_oauth_token = State()


class WeeklyForm(StatesGroup):
    waiting_for_account_selection = State()
    waiting_for_credentials = State()
    confirm_credentials = State()


def get_missing_sub_keyboard(missing_channels: Optional[List[Dict[str, str]]] = None, lang: str = "ar"):
    channels_to_show = db.get_mandatory_channels()
    builder = InlineKeyboardBuilder()
    styles = ["primary", "success"]
    for i, ch in enumerate(channels_to_show):
        raw_name = ch.get("title") or ch.get("channel_username") or ""
        clean_name = raw_name.strip().lstrip("@").strip()
        if not clean_name:
            clean_name = ch.get("channel_username", "").lstrip("@").strip()
        link = ch.get("invite_link") or f"https://t.me/{ch['channel_username'].lstrip('@')}"
        builder.button(text=f"📡 {clean_name}", url=link, style=styles[i % len(styles)])
    t = STRINGS.get(lang, STRINGS["ar"])
    builder.button(text=t["sub_btn_check"], callback_data="check_sub", style="success")
    builder.adjust(1)
    return builder.as_markup()


class ForceSubMiddleware(BaseMiddleware):
    async def __call__(self, handler, event: types.TelegramObject, data: Dict[str, Any]):
        user = getattr(event, "from_user", None)
        if not user or user.is_bot:
            return await handler(event, data)

        db.get_or_create_user(user.id, user.username)
        logger.info("User interaction: id=%s, username=@%s", user.id, user.username)

        if user.id in ADMIN_IDS:
            return await handler(event, data)

        user_lang = db.get_user_language(user.id) or "ar"
        t = STRINGS.get(user_lang, STRINGS["ar"])

        if db.is_user_banned(user.id):
            if isinstance(event, types.Message):
                await event.answer(t["banned"], parse_mode="HTML")
            elif isinstance(event, types.CallbackQuery):
                await event.answer(t["banned"].replace("<b>", "").replace("</b>", "")[:180], show_alert=True)
            return

        if db.get_setting_bool("maintenance_mode", False):
            if isinstance(event, types.Message):
                await event.answer(t["maint"], parse_mode="HTML", disable_web_page_preview=True)
            elif isinstance(event, types.CallbackQuery):
                await event.answer("🛠️ Maintenance Mode", show_alert=True)
            return

        if isinstance(event, types.Message) and event.text:
            text_val = event.text.strip()
            if text_val.startswith("/start"):
                parts = text_val.split()
                if len(parts) > 1 and parts[1].startswith("ref_"):
                    inviter_str = parts[1].replace("ref_", "").strip()
                    if inviter_str.isdigit():
                        db.record_referral(int(inviter_str), user.id)

        if isinstance(event, types.CallbackQuery) and event.data == "check_sub":
            return await handler(event, data)

        bot_instance: Bot = data.get("bot") or bot
        is_sub, missing = await check_all_channels_subscription(bot_instance, user.id)
        if not is_sub:
            if isinstance(event, types.Message):
                await event.answer(
                    t["sub_req"],
                    reply_markup=get_missing_sub_keyboard(missing, lang=user_lang),
                    parse_mode="HTML",
                )
            elif isinstance(event, types.CallbackQuery):
                await event.answer(t["sub_alert"], show_alert=True)
                try:
                    await event.message.answer(
                        t["sub_req"],
                        reply_markup=get_missing_sub_keyboard(missing, lang=user_lang),
                        parse_mode="HTML",
                    )
                except Exception:
                    pass
            return

        return await handler(event, data)


dp.message.outer_middleware(ForceSubMiddleware())
dp.callback_query.outer_middleware(ForceSubMiddleware())


def get_main_menu(user_id: Optional[int] = None, lang: Optional[str] = None) -> InlineKeyboardMarkup:
    if not lang and user_id:
        lang = db.get_user_language(user_id)
    if not lang or lang not in STRINGS:
        lang = "ar"
    t = STRINGS[lang]
    builder = InlineKeyboardBuilder()
    builder.button(text=t["quest"], callback_data="nav_quests", style="primary")
    builder.button(text=t["weekly"], callback_data="nav_weekly", style="success")
    builder.button(text=t["balance"], callback_data="nav_wallet", style="primary")
    builder.button(text=t["rewards"], callback_data="nav_rewards", style="success")
    builder.button(text=t["leaderboard"], callback_data="nav_top", style="primary")
    builder.button(text=t["help"], callback_data="nav_guide", style="primary")
    builder.button(text=t["lang"], callback_data="nav_lang", style="primary")
    builder.button(text=t["channel"], url=CHANNEL_URL, style="success")
    if user_id and user_id in ADMIN_IDS:
        builder.button(text=t["admin"], callback_data="admin_menu", style="danger")
        builder.adjust(2, 2, 2, 2, 1)
    else:
        builder.adjust(2, 2, 2, 2)
    return builder.as_markup()


def get_admin_menu_keyboard(alang: Optional[str] = None) -> InlineKeyboardMarkup:
    lang = alang or get_admin_lang()
    a = ADMIN_STRINGS.get(lang, ADMIN_STRINGS["ar"])
    builder = InlineKeyboardBuilder()
    builder.button(text=a["btn_stats"], callback_data="admin_stats", style="primary")
    builder.button(text=a["btn_lookup"], callback_data="admin_lookup", style="primary")
    builder.button(text=a["btn_add"], callback_data="admin_add_tokens", style="success")
    builder.button(text=a["btn_sub"], callback_data="admin_sub_tokens", style="danger")
    builder.button(text=a["btn_gift_all"], callback_data="admin_gift_all", style="success")
    builder.button(text=a["btn_bans"], callback_data="admin_bans", style="danger")
    builder.button(text=a["btn_mand"], callback_data="admin_mandatory_channels", style="primary")
    builder.button(text=a["btn_promo_ch"], callback_data="admin_promo_channels", style="primary")
    builder.button(text=a["btn_promos"], callback_data="admin_promos", style="success")
    builder.button(text=a["btn_bcast"], callback_data="admin_broadcast", style="primary")
    builder.button(text=a["btn_dm"], callback_data="admin_dm_user", style="primary")
    builder.button(text=a["btn_settings"], callback_data="admin_settings", style="primary")
    builder.button(text=a["btn_backup"], callback_data="admin_backup", style="success")
    builder.button(text=a["btn_lang"], callback_data="admin_lang_menu", style="primary")
    builder.button(text=a["btn_home"], callback_data="nav_home", style="primary")
    builder.button(text=a["btn_close"], callback_data="admin_close", style="danger")
    builder.adjust(2, 2, 2, 2, 2, 2, 2, 2)
    return builder.as_markup()


def get_admin_panel_text(alang: Optional[str] = None) -> str:
    lang = alang or get_admin_lang()
    a = ADMIN_STRINGS.get(lang, ADMIN_STRINGS["ar"])
    maint = a["maint_on"] if db.get_setting_bool("maintenance_mode", False) else a["maint_off"]
    fsub = a["on"] if db.get_setting_bool("force_sub_enabled", True) else a["off"]
    return a["title"] + "\n" + a["subtitle"].format(
        maint=maint,
        fsub=fsub,
        cost=get_chest_cost(),
        wbonus=get_welcome_bonus(),
    )


def get_games_keyboard(lang: str = "ar") -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    styles = ["primary", "success"]
    for i, (key, data) in enumerate(GAMES_CATALOG.items()):
        builder.button(text=data["name"], callback_data=f"game_{key}", style=styles[i % len(styles)])
    builder.adjust(2)
    t = STRINGS.get(lang, STRINGS["ar"])
    nav = InlineKeyboardBuilder()
    nav.button(text=t["home"], callback_data="nav_home", style="danger")
    nav.adjust(1)
    builder.attach(nav)
    return builder.as_markup()


def get_confirmation_keyboard(lang: str = "ar") -> InlineKeyboardMarkup:
    cost = get_chest_cost()
    builder = InlineKeyboardBuilder()
    if lang == "fr":
        builder.button(text=f"⚡ Lancer Maintenant ({cost} 🪙)", callback_data="pay_confirm", style="success")
        builder.button(text="📝 Changer Compte", callback_data="pay_edit", style="primary")
        builder.button(text="✖️ Annuler", callback_data="pay_cancel", style="danger")
    elif lang == "en":
        builder.button(text=f"⚡ Launch Now ({cost} 🪙)", callback_data="pay_confirm", style="success")
        builder.button(text="📝 Edit Account", callback_data="pay_edit", style="primary")
        builder.button(text="✖️ Cancel", callback_data="pay_cancel", style="danger")
    else:
        builder.button(text=f"⚡ تأكيد والبدء الآن ({cost} 🪙)", callback_data="pay_confirm", style="success")
        builder.button(text="📝 تعديل الحساب", callback_data="pay_edit", style="primary")
        builder.button(text="✖️ إلغاء", callback_data="pay_cancel", style="danger")
    builder.adjust(1, 2)
    return builder.as_markup()


def _welcome_text_for(user_id: int, lang: Optional[str] = None) -> str:
    user = db.get_or_create_user(user_id)
    use_lang = lang or db.get_user_language(user_id) or "ar"
    t = STRINGS.get(use_lang, STRINGS["ar"])
    return t["welcome"].format(
        balance=user["balance"],
        chest_cost=get_chest_cost(),
        welcome_bonus=get_welcome_bonus(),
    )


@dp.message(CommandStart(), StateFilter("*"))
async def cmd_start(message: types.Message, state: FSMContext, command: Optional[CommandObject] = None):
    await state.clear()
    user_id = message.from_user.id
    username = message.from_user.username
    db.get_or_create_user(user_id, username)

    if command and command.args:
        ref_arg = command.args.strip()
        inviter_str = ref_arg.replace("ref_", "")
        if inviter_str.isdigit():
            db.record_referral(int(inviter_str), user_id)

    is_sub, _ = await check_all_channels_subscription(bot, user_id)
    if is_sub or user_id in ADMIN_IDS:
        rewarded_inviter = db.reward_referral_if_pending(user_id, inviter_reward=3, invited_bonus=0)
        if rewarded_inviter:
            inv_lang = db.get_user_language(rewarded_inviter) or "ar"
            try:
                if inv_lang == "en":
                    inv_msg = (
                        "🎊 <b>Referral Reward Credited!</b>\n"
                        f"Your invited member @{username or user_id} joined & verified.\n"
                        "💳 <b>+3 Tokens</b> have been added to your wallet!"
                    )
                elif inv_lang == "fr":
                    inv_msg = (
                        "🎊 <b>Prime de Parrainage Créditée !</b>\n"
                        f"Votre filleul @{username or user_id} a rejoint nos chaînes.\n"
                        "💳 <b>+3 Tokens</b> ajoutés à votre solde !"
                    )
                else:
                    inv_msg = (
                        "🎊 <b>مكافأة إحالة جديدة!</b>\n"
                        f"انضم صديقك @{username or user_id} وأكمل الاشتراك بنجاح.\n"
                        "💳 تم شحن <b>+3 توكن</b> إلى محفظتك!"
                    )
                await bot.send_message(rewarded_inviter, inv_msg, parse_mode="HTML")
            except Exception:
                pass

    lang = db.get_user_language(user_id) or "ar"
    try:
        rm = await message.answer("⚡", reply_markup=ReplyKeyboardRemove())
        await rm.delete()
    except Exception:
        pass
    await send_welcome_message(message.chat.id, user_id, _welcome_text_for(user_id, lang), get_main_menu(user_id, lang))


@dp.callback_query(F.data == "nav_home", StateFilter("*"))
async def cb_nav_home(callback: types.CallbackQuery, state: FSMContext):
    await state.clear()
    user_id = callback.from_user.id
    lang = db.get_user_language(user_id) or "ar"
    text = _welcome_text_for(user_id, lang)
    kb = get_main_menu(user_id, lang)
    if callback.message and callback.message.text is not None:
        try:
            await callback.message.edit_text(text, reply_markup=kb, parse_mode="HTML", disable_web_page_preview=True)
            await callback.answer()
            return
        except Exception:
            pass
    await send_welcome_message(callback.message.chat.id, user_id, text, kb)
    await callback.answer()


@dp.message(Command("cancel"), StateFilter("*"))
async def cmd_cancel(message: types.Message, state: FSMContext):
    await state.clear()
    user_id = message.from_user.id
    lang = db.get_user_language(user_id) or "ar"
    cancel_msg = {
        "en": "✖️ <b>Operation cancelled.</b> Choose an action below:",
        "fr": "✖️ <b>Opération annulée.</b> Choisissez une option ci-dessous :",
        "ar": "✖️ <b>تم إلغاء العملية الحالية.</b> اختر من القائمة أدناه:",
    }.get(lang, "✖️ <b>تم إلغاء العملية الحالية.</b>")
    await message.answer(cancel_msg, reply_markup=get_main_menu(user_id, lang), parse_mode="HTML")


async def _show_quests_menu(target: Union[types.Message, types.CallbackQuery], user_id: int, state: FSMContext):
    await state.clear()
    lang = db.get_user_language(user_id) or "ar"
    if lang == "en":
        q_text = (
            "🚀 <b>PLAYX1 ZONE — Quest Vault</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "Pick the active chest game you want to complete automatically:\n"
            "📌 <i>Verify that this game quest is visible inside your Google Play Points tab first.</i>"
        )
    elif lang == "fr":
        q_text = (
            "🚀 <b>PLAYX1 ZONE — Coffres & Quêtes</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "Sélectionnez le jeu correspondant au coffre à valider :\n"
            "📌 <i>Assurez-vous que la mission apparaît bien dans votre onglet Google Play Points.</i>"
        )
    else:
        q_text = (
            "🚀 <b>خزنة الصناديق — PLAYX1 ZONE</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "اختر اللعبة الخاصة بالصندوق الذي تريد إنجازه الآن:\n"
            "📌 <i>تأكد أولاً أن مهمة هذا الصندوق ظاهرة لديك داخل قسم Google Play Points.</i>"
        )
    await safe_show(target, q_text, reply_markup=get_games_keyboard(lang), prefer_edit=True)
    if isinstance(target, types.CallbackQuery):
        await target.answer()


@dp.message(Command("goal"), StateFilter("*"))
@dp.message(Command("goals"), StateFilter("*"))
@dp.message(Command("quest"), StateFilter("*"))
@dp.message(Command("quests"), StateFilter("*"))
@dp.message(Command("boost"), StateFilter("*"))
async def select_quest(message: types.Message, state: FSMContext):
    await _show_quests_menu(message, message.from_user.id, state)


@dp.callback_query(F.data.in_({"nav_quests", "menu_select_quest"}), StateFilter("*"))
async def menu_select_quest_cb(callback: types.CallbackQuery, state: FSMContext):
    await _show_quests_menu(callback, callback.from_user.id, state)


async def _render_weekly_menu(
    target_event: Union[types.Message, types.CallbackQuery],
    user_id: int,
    state: FSMContext,
    page: int = 0,
    edit: bool = False,
):
    lang = db.get_user_language(user_id) or "ar"
    t = STRINGS.get(lang, STRINGS["ar"])
    saved = db.get_saved_accounts(user_id)
    saved = [acc for acc in saved if acc.get("email") and acc.get("password")]

    if not saved:
        await state.set_state(WeeklyForm.waiting_for_credentials)
        if lang == "en":
            empty_text = (
                "👑 <b>Friday Weekly Perk Claimer</b>\n"
                "━━━━━━━━━━━━━━━━━━━━\n"
                "Send your Google account credentials to collect this week's Play Points drop:\n\n"
                "📥 Format: <code>email:password</code>\n\n"
                "⚡ <i>Saved automatically for instant 1-tap claims every Friday.</i>"
            )
        elif lang == "fr":
            empty_text = (
                "👑 <b>Récupérateur Bonus du Vendredi</b>\n"
                "━━━━━━━━━━━━━━━━━━━━\n"
                "Envoyez vos identifiants Google pour réclamer votre prix hebdomadaire :\n\n"
                "📥 Format : <code>email:password</code>\n\n"
                "⚡ <i>Sauvegardé automatiquement pour vos prochaines réclamations en un clic.</i>"
            )
        else:
            empty_text = (
                "👑 <b>استلام هدية الجمعة الأسبوعية</b>\n"
                "━━━━━━━━━━━━━━━━━━━━\n"
                "أرسل بيانات حساب Google الخاص بك للمطالبة بجائزة نقاط Play لهذا الأسبوع:\n\n"
                "📥 الصيغة: <code>email:password</code>\n\n"
                "⚡ <i>سيتم حفظ الحساب تلقائياً لاستلام الهدايا بنقرة واحدة كل جمعة.</i>"
            )
        kb = InlineKeyboardBuilder()
        kb.button(text=t["home"], callback_data="nav_home", style="danger")
        await safe_show(target_event, empty_text, reply_markup=kb.as_markup(), prefer_edit=edit)
        if isinstance(target_event, types.CallbackQuery):
            await target_event.answer()
        return

    total_accounts = len(saved)
    total_pages = max(1, math.ceil(total_accounts / PAGE_SIZE_ACCOUNTS))
    page = max(0, min(page, total_pages - 1))

    start_idx = page * PAGE_SIZE_ACCOUNTS
    end_idx = min(start_idx + PAGE_SIZE_ACCOUNTS, total_accounts)
    page_accounts = saved[start_idx:end_idx]

    builder = InlineKeyboardBuilder()
    for offset_i, acc in enumerate(page_accounts):
        global_idx = start_idx + offset_i
        acc_id = acc.get("id")
        cb_val = str(acc_id) if acc_id is not None else str(global_idx)
        builder.button(text=f"📨 {acc['email']}", callback_data=f"weekly_acc_{cb_val}", style="primary")
    builder.adjust(1)

    if total_pages > 1:
        nav_builder = InlineKeyboardBuilder()
        btn_prev = "◀️ Prev" if lang == "en" else ("◀️ Préc." if lang == "fr" else "◀️ السابق")
        btn_next = "Next ▶️" if lang == "en" else ("Suiv. ▶️" if lang == "fr" else "التالي ▶️")
        if page > 0:
            nav_builder.button(text=btn_prev, callback_data=f"weekly_page_{page - 1}")
        nav_builder.button(text=f"📑 {page + 1}/{total_pages}", callback_data=f"weekly_page_info_{page + 1}_{total_pages}")
        if page < total_pages - 1:
            nav_builder.button(text=btn_next, callback_data=f"weekly_page_{page + 1}")
        nav_builder.adjust(3 if (page > 0 and page < total_pages - 1) else 2)
        builder.attach(nav_builder)

    action_builder = InlineKeyboardBuilder()
    if lang == "en":
        action_builder.button(text="➕ Add New Account", callback_data="weekly_acc_new", style="success")
        action_builder.button(text=t["home"], callback_data="nav_home", style="danger")
        page_info = f"\n📑 <i>Page {page + 1}/{total_pages} • {total_accounts} saved accounts</i>" if total_pages > 1 else ""
        msg_text = (
            "👑 <b>Friday Weekly Perk Claimer</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"Choose an account to claim this week's Play Points prize:{page_info}\n\n"
            "✨ <i>Available every Friday for Silver, Gold, Platinum & Diamond tiers.</i>"
        )
    elif lang == "fr":
        action_builder.button(text="➕ Nouveau Compte", callback_data="weekly_acc_new", style="success")
        action_builder.button(text=t["home"], callback_data="nav_home", style="danger")
        page_info = f"\n📑 <i>Page {page + 1}/{total_pages} • {total_accounts} comptes</i>" if total_pages > 1 else ""
        msg_text = (
            "👑 <b>Récupérateur Bonus du Vendredi</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"Sélectionnez un compte pour réclamer votre prix hebdomadaire :{page_info}\n\n"
            "✨ <i>Disponible chaque vendredi pour les niveaux Argent, Or, Platine et Diamant.</i>"
        )
    else:
        action_builder.button(text="➕ إضافة حساب جديد", callback_data="weekly_acc_new", style="success")
        action_builder.button(text=t["home"], callback_data="nav_home", style="danger")
        page_info = f"\n📑 <i>الصفحة {page + 1} من {total_pages} • الإجمالي: {total_accounts} حساب</i>" if total_pages > 1 else ""
        msg_text = (
            "👑 <b>استلام هدية الجمعة الأسبوعية</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"اختر أحد حساباتك المحفوظة لاستلام جائزة هذا الأسبوع:{page_info}\n\n"
            "✨ <i>تتوفر الهدية كل يوم جمعة للمستويات الفضي والذهبي والبلاتيني والماسي.</i>"
        )
    action_builder.adjust(1)
    builder.attach(action_builder)

    await state.update_data(saved_accounts=saved, weekly_page=page)
    await state.set_state(WeeklyForm.waiting_for_account_selection)

    await safe_show(target_event, msg_text, reply_markup=builder.as_markup(), prefer_edit=edit)
    if isinstance(target_event, types.CallbackQuery):
        await target_event.answer()


@dp.message(Command("weekly"), StateFilter("*"))
async def weekly_prize_menu(message: types.Message, state: FSMContext):
    await state.clear()
    await _render_weekly_menu(message, message.from_user.id, state, page=0, edit=False)


@dp.callback_query(F.data == "nav_weekly", StateFilter("*"))
async def cb_nav_weekly(callback: types.CallbackQuery, state: FSMContext):
    await state.clear()
    await _render_weekly_menu(callback, callback.from_user.id, state, page=0, edit=True)


@dp.callback_query(F.data.startswith("weekly_page_info_"))
async def weekly_page_info_handler(callback: types.CallbackQuery):
    parts = callback.data.split("_")
    if len(parts) >= 5:
        await callback.answer(f"📑 {parts[3]} / {parts[4]}")
    else:
        await callback.answer()


@dp.callback_query(WeeklyForm.waiting_for_account_selection, F.data.startswith("weekly_page_"))
@dp.callback_query(F.data.startswith("weekly_page_"))
async def weekly_page_handler(callback: types.CallbackQuery, state: FSMContext):
    try:
        page = int(callback.data.split("weekly_page_")[1])
    except ValueError:
        await callback.answer()
        return
    await _render_weekly_menu(callback, callback.from_user.id, state, page=page, edit=True)


@dp.callback_query(WeeklyForm.waiting_for_account_selection, F.data.startswith("weekly_acc_"))
@dp.callback_query(F.data.startswith("weekly_acc_"))
async def weekly_acc_selected(callback: types.CallbackQuery, state: FSMContext):
    data = callback.data.split("weekly_acc_")[1]
    user_id = callback.from_user.id
    lang = db.get_user_language(user_id) or "ar"
    t = STRINGS.get(lang, STRINGS["ar"])

    if data == "new":
        await state.set_state(WeeklyForm.waiting_for_credentials)
        if lang == "en":
            prompt = "👑 <b>Link New Google Account</b>\n━━━━━━━━━━━━━━━━━━━━\nSend credentials in format:\n<code>email:password</code>"
        elif lang == "fr":
            prompt = "👑 <b>Ajouter un Compte Google</b>\n━━━━━━━━━━━━━━━━━━━━\nEnvoyez vos identifiants au format :\n<code>email:password</code>"
        else:
            prompt = "👑 <b>إضافة حساب Google جديد</b>\n━━━━━━━━━━━━━━━━━━━━\nأرسل البيانات بالصيغة التالية:\n<code>email:password</code>"
        kb = InlineKeyboardBuilder()
        kb.button(text=t["back"], callback_data="nav_weekly", style="danger")
        await safe_show(callback, prompt, reply_markup=kb.as_markup(), prefer_edit=True)
        await callback.answer()
        return

    acc = None
    if data.isdigit():
        acc = db.get_saved_account_by_id(user_id, int(data))
    if not acc and data.isdigit():
        try:
            idx = int(data)
            state_data = await state.get_data()
            saved = state_data.get("saved_accounts", [])
            if not saved or idx >= len(saved):
                saved = db.get_saved_accounts(user_id)
                saved = [a for a in saved if a.get("email") and a.get("password")]
            if idx < len(saved):
                acc = saved[idx]
        except (ValueError, IndexError):
            pass
    if not acc:
        acc = db.get_saved_account_by_email(user_id, data)

    if not acc or not acc.get("password"):
        await callback.answer("⚠️ Account not found!", show_alert=True)
        return

    email = acc["email"]
    password = acc["password"]
    await callback.answer()

    connecting_txt = {
        "en": f"👑 <b>Processing Friday Perk...</b>\n\n📨 <b>Account:</b> <code>{email}</code>\n⚡ <i>Connecting to Google Play Points...</i>",
        "fr": f"👑 <b>Traitement du Bonus Hebdo...</b>\n\n📨 <b>Compte :</b> <code>{email}</code>\n⚡ <i>Connexion à Google Play Points...</i>",
        "ar": f"👑 <b>جاري فحص واستلام هدية الجمعة...</b>\n\n📨 <b>الحساب:</b> <code>{email}</code>\n⚡ <i>جاري الاتصال بخوادم Google Play Points...</i>",
    }.get(lang)
    status_msg = await safe_show(callback, connecting_txt, prefer_edit=True)
    await _execute_weekly_claim(user_id, email, password, status_msg, state)


@dp.message(WeeklyForm.waiting_for_credentials)
async def weekly_credentials_entered(message: types.Message, state: FSMContext):
    text = (message.text or "").strip()
    user_id = message.from_user.id
    lang = db.get_user_language(user_id) or "ar"
    if ":" not in text:
        err_fmt = {
            "en": "⚠️ <b>Invalid Format</b>\nUse: <code>email:password</code>\nExample: <code>player@gmail.com:Pass1234</code>",
            "fr": "⚠️ <b>Format Invalide</b>\nUtilisez : <code>email:password</code>\nExemple : <code>player@gmail.com:Pass1234</code>",
            "ar": "⚠️ <b>صيغة غير صحيحة!</b>\nاستخدم: <code>email:password</code>\nمثال: <code>player@gmail.com:Pass1234</code>",
        }.get(lang)
        await message.answer(err_fmt, parse_mode="HTML")
        return

    email, password = text.split(":", 1)
    email = email.strip()
    password = password.strip()

    try:
        await message.delete()
    except Exception:
        pass

    db.save_account(user_id, email, password)

    connecting_txt = {
        "en": f"👑 <b>Processing Friday Perk...</b>\n\n📨 <b>Account:</b> <code>{email}</code>\n⚡ <i>Connecting to Google Play Points...</i>",
        "fr": f"👑 <b>Traitement du Bonus Hebdo...</b>\n\n📨 <b>Compte :</b> <code>{email}</code>\n⚡ <i>Connexion à Google Play Points...</i>",
        "ar": f"👑 <b>جاري فحص واستلام هدية الجمعة...</b>\n\n📨 <b>الحساب:</b> <code>{email}</code>\n⚡ <i>جاري الاتصال بخوادم Google Play Points...</i>",
    }.get(lang)
    status_msg = await message.answer(connecting_txt, parse_mode="HTML")
    await _execute_weekly_claim(user_id, email, password, status_msg, state)


async def _execute_weekly_claim(user_id: int, email: str, password: str, status_msg: types.Message, state: FSMContext):
    sc_prefix = f"/tmp/weekly_{user_id}"
    claim_res = None
    lang = db.get_user_language(user_id) or "ar"

    mt_info = db.get_master_token(user_id, email)
    if mt_info and mt_info.get("master_token"):
        loading_text = {
            "en": f"👑 <b>Checking Play Points Perks...</b>\n\n📨 <b>Account:</b> <code>{email}</code>\n⚡ <i>Saved session active. Scanning reward...</i>",
            "fr": f"👑 <b>Vérification des Avantages...</b>\n\n📨 <b>Compte :</b> <code>{email}</code>\n⚡ <i>Session enregistrée active. Analyse...</i>",
            "ar": f"👑 <b>جاري الدخول إلى مزايا Play Points...</b>\n\n📨 <b>الحساب:</b> <code>{email}</code>\n⚡ <i>الجلسة المحفوظة جاهزة. جاري فحص الهدية...</i>",
        }.get(lang)
        await status_msg.edit_text(loading_text, parse_mode="HTML")

        try:
            claim_res = await asyncio.to_thread(
                fast_claim_weekly_perk,
                email,
                mt_info["master_token"],
                mt_info["android_id"],
                None,
                sc_prefix,
            )
        except Exception as e:
            logger.warning("Fast weekly claim failed, falling back to full login: %s", e)

    if not claim_res or claim_res.get("status") == "AUTH_REQUIRED":
        ap_auth = AutoPixelAuthenticator(email, password)
        status, result = await asyncio.to_thread(ap_auth.start_auth)

        if status in ("NEEDS_NUMBER", "NEEDS_TAP_YES"):
            if lang == "en":
                if status == "NEEDS_NUMBER":
                    prompt_text = (
                        "📲 <b>Phone Approval Needed</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                        f"👉 <b>Tap number <code>{result}</code> on your phone</b>\n\n"
                        f"<i>Approve the Google security prompt and choose <b>{result}</b>.</i>\n"
                        "⏳ <i>Waiting up to 2 minutes...</i>"
                    )
                else:
                    prompt_text = (
                        "📲 <b>Phone Approval Needed</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                        "👉 <b>Tap 'Yes, it's me' on your phone</b>\n\n"
                        "<i>Open the Google notification on your device to approve sign-in.</i>\n"
                        "⏳ <i>Waiting up to 2 minutes...</i>"
                    )
                timeout_msg = "⌛ <b>Verification expired.</b> No response was received on your device."
                confirmed_msg = "✅ <b>Device approval received!</b>\n⚡ <i>Collecting your Friday reward...</i>"
            elif lang == "fr":
                if status == "NEEDS_NUMBER":
                    prompt_text = (
                        "📲 <b>Validation sur Téléphone Requise</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                        f"👉 <b>Appuyez sur le chiffre <code>{result}</code> sur votre appareil</b>\n\n"
                        f"<i>Validez l'alerte Google et choisissez <b>{result}</b>.</i>\n"
                        "⏳ <i>En attente (2 minutes max)...</i>"
                    )
                else:
                    prompt_text = (
                        "📲 <b>Validation sur Téléphone Requise</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                        "👉 <b>Appuyez sur 'Oui, c'est moi' sur votre appareil</b>\n\n"
                        "<i>Ouvrez la notification Google pour confirmer.</i>\n"
                        "⏳ <i>En attente (2 minutes max)...</i>"
                    )
                timeout_msg = "⌛ <b>Délai expiré.</b> Confirmation non validée à temps."
                confirmed_msg = "✅ <b>Connexion validée !</b>\n⚡ <i>Récupération du bonus hebdomadaire...</i>"
            else:
                if status == "NEEDS_NUMBER":
                    prompt_text = (
                        "📲 <b>مطلوب الموافقة من هاتفك</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                        f"👉 <b>اختر الرقم <code>{result}</code> في إشعار Google على هاتفك</b>\n\n"
                        f"<i>اضغط «نعم، إنه أنا» ثم حدد الرقم <b>{result}</b> لإكمال الدخول.</i>\n"
                        "💡 <i>يظهر التنبيه في شاشة الهاتف أو تطبيق Gmail (ليس رسالة SMS).</i>\n"
                        "⏳ <i>بانتظار موافقتك (مهلة دقيقتين)...</i>"
                    )
                else:
                    prompt_text = (
                        "📲 <b>مطلوب الموافقة من هاتفك</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                        "👉 <b>اضغط «نعم، إنه أنا» في إشعار Google على هاتفك</b>\n\n"
                        "<i>افتح إشعار الأمان من شريط الإشعارات أو تطبيق Gmail للمتابعة.</i>\n"
                        "⏳ <i>بانتظار موافقتك (مهلة دقيقتين)...</i>"
                    )
                timeout_msg = "⌛ <b>انتهت مهلة الموافقة!</b> لم يتم تأكيد الإشعار في الوقت المحدد."
                confirmed_msg = "✅ <b>تمت الموافقة من هاتفك بنجاح!</b>\n⚡ <i>جاري استلام هدية الجمعة...</i>"

            await status_msg.edit_text(prompt_text, parse_mode="HTML")
            approved = await asyncio.to_thread(ap_auth.wait_for_approval, 120)
            if not approved:
                ap_auth.close()
                await status_msg.edit_text(timeout_msg, reply_markup=get_main_menu(user_id, lang), parse_mode="HTML")
                await state.clear()
                return
            await status_msg.edit_text(confirmed_msg, parse_mode="HTML")

        elif status != "SUCCESS":
            ap_auth.close()
            await status_msg.edit_text(
                f"❌ <b>Google Sign-In Failed:</b>\n\n<code>{result}</code>",
                reply_markup=get_main_menu(user_id, lang),
                parse_mode="HTML",
            )
            await state.clear()
            return

        await asyncio.to_thread(ap_auth.extract_tokens)
        ap_auth.close()
        if ap_auth.master_token:
            db.save_master_token(user_id, email, ap_auth.master_token, ap_auth.android_id)
            claim_res = await asyncio.to_thread(
                fast_claim_weekly_perk,
                email,
                ap_auth.master_token,
                ap_auth.android_id,
                None,
                sc_prefix,
            )
        else:
            claim_res = {"status": "ERROR", "message": "Failed to extract Google session tokens."}

    await state.clear()
    st = claim_res.get("status")
    sc_file = claim_res.get("screenshot")
    menu_kb = get_main_menu(user_id, lang)

    try:
        if st == "CLAIMED":
            pts = claim_res.get("points", "+Points")
            caption = {
                "en": (
                    "🎊 <b>Friday Perk Collected!</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                    f"🏆 <b>Points Won:</b> <code>{pts}</code> Play Points\n"
                    f"📨 <b>Account:</b> <code>{email}</code>\n\n"
                    "✨ <i>Credited directly to your Google Play balance.</i>"
                ),
                "fr": (
                    "🎊 <b>Bonus Hebdomadaire Récupéré !</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                    f"🏆 <b>Gain :</b> <code>{pts}</code> Play Points\n"
                    f"📨 <b>Compte :</b> <code>{email}</code>\n\n"
                    "✨ <i>Crédité directement sur votre solde Google Play.</i>"
                ),
                "ar": (
                    "🎊 <b>تم استلام هدية الجمعة بنجاح!</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                    f"🏆 <b>الجائزة:</b> <code>{pts}</code> Play Points\n"
                    f"📨 <b>الحساب:</b> <code>{email}</code>\n\n"
                    "✨ <i>أُضيفت النقاط مباشرة إلى رصيدك في Google Play.</i>"
                ),
            }.get(lang)
        elif st == "APP_REQUIRED":
            caption = {
                "en": (
                    "📱 <b>Mobile / PC App Required</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                    f"📨 <b>Account:</b> <code>{email}</code>\n\n"
                    "Google requires claiming this account's prize directly in the Play Store app or Play Games PC.\n"
                    "👉 Go to: <b>Play Points → Perks → Claim Weekly Prize</b>."
                ),
                "fr": (
                    "📱 <b>Réclamation via l'Application Requise</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                    f"📨 <b>Compte :</b> <code>{email}</code>\n\n"
                    "Google demande de réclamer ce bonus depuis l'app Play Store ou Play Jeux PC.\n"
                    "👉 Allez dans : <b>Play Points → Avantages → Prix hebdomadaire</b>."
                ),
                "ar": (
                    "📱 <b>يتطلب الاستلام من تطبيق المتجر</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                    f"📨 <b>الحساب:</b> <code>{email}</code>\n\n"
                    "تفرض Google استلام هدية هذا الحساب مباشرة عبر تطبيق Google Play في هاتفك أو Play Games على الكمبيوتر.\n"
                    "👉 افتح: <b>Play Points ← المزايا ← المطالبة بالجائزة الأسبوعية</b>."
                ),
            }.get(lang)
        elif st == "ALREADY_CLAIMED":
            next_d = claim_res.get("next_date", "Friday")
            caption = {
                "en": (
                    "ℹ️ <b>Already Collected This Week</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                    f"📨 <b>Account:</b> <code>{email}</code>\n"
                    f"🗓️ <b>Next Drop:</b> <b>{next_d}</b>"
                ),
                "fr": (
                    "ℹ️ <b>Bonus Déjà Réclamé Cette Semaine</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                    f"📨 <b>Compte :</b> <code>{email}</code>\n"
                    f"🗓️ <b>Prochaine date :</b> <b>{next_d}</b>"
                ),
                "ar": (
                    "ℹ️ <b>تم استلام هدية هذا الأسبوع مسبقاً</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                    f"📨 <b>الحساب:</b> <code>{email}</code>\n"
                    f"🗓️ <b>موعد الجائزة القادمة:</b> <b>{next_d}</b>"
                ),
            }.get(lang)
        elif st == "NOT_ELIGIBLE":
            caption = {
                "en": (
                    "⚠️ <b>Account Not Eligible Yet</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                    f"📨 <b>Account:</b> <code>{email}</code>\n\n"
                    "🥉 Currently on <b>Bronze Tier</b>. Weekly prizes unlock at <b>Silver Tier</b> or higher."
                ),
                "fr": (
                    "⚠️ <b>Compte Non Éligible</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                    f"📨 <b>Compte :</b> <code>{email}</code>\n\n"
                    "🥉 Niveau actuel : <b>Bronze</b>. Les bonus s'activent à partir du niveau <b>Argent</b>."
                ),
                "ar": (
                    "⚠️ <b>الحساب غير مؤهل حالياً</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                    f"📨 <b>الحساب:</b> <code>{email}</code>\n\n"
                    "🥉 الحساب في <b>المستوى البرونزي</b> حالياً، وتُفتح الجائزة الأسبوعية بدءاً من <b>المستوى الفضي</b> فأعلى."
                ),
            }.get(lang)
            await status_msg.edit_text(caption, reply_markup=menu_kb, parse_mode="HTML")
            return
        else:
            err_msg = claim_res.get("message", "Unknown error")
            caption = f"❌ <b>Weekly Perk Notice</b>\n━━━━━━━━━━━━━━━━━━━━\n{err_msg}\n\n📨 <b>Account:</b> <code>{email}</code>"

        if sc_file and os.path.exists(sc_file):
            try:
                await status_msg.answer_photo(
                    photo=FSInputFile(sc_file),
                    caption=caption[:1024],
                    reply_markup=menu_kb,
                    parse_mode="HTML",
                )
                await status_msg.delete()
                return
            except Exception:
                pass
        await status_msg.edit_text(caption, reply_markup=menu_kb, parse_mode="HTML")
    except Exception as e:
        logger.exception("Error rendering weekly claim response: %s", e)
    finally:
        cleanup_file(sc_file)


@dp.callback_query(F.data == "check_sub")
async def cb_check_sub(callback: types.CallbackQuery, state: FSMContext):
    user_id = callback.from_user.id
    _SUB_CACHE.pop(user_id, None)
    is_sub, _ = await check_all_channels_subscription(bot, user_id, use_cache=False)
    lang = db.get_user_language(user_id) or "ar"
    t = STRINGS.get(lang, STRINGS["ar"])
    if is_sub:
        await callback.answer(t["sub_ok"], show_alert=False)
        try:
            await callback.message.delete()
        except Exception:
            pass
        db.get_or_create_user(user_id, callback.from_user.username)
        inviter_id = db.reward_referral_if_pending(user_id, inviter_reward=3, invited_bonus=0)
        if inviter_id:
            inv_lang = db.get_user_language(inviter_id) or "ar"
            try:
                if inv_lang == "en":
                    inv_msg = (
                        "🎊 <b>Referral Reward Credited!</b>\n"
                        f"Your invited member @{callback.from_user.username or user_id} joined & verified.\n"
                        "💳 <b>+3 Tokens</b> added to your wallet!"
                    )
                elif inv_lang == "fr":
                    inv_msg = (
                        "🎊 <b>Prime de Parrainage Créditée !</b>\n"
                        f"Votre filleul @{callback.from_user.username or user_id} a rejoint nos chaînes.\n"
                        "💳 <b>+3 Tokens</b> ajoutés à votre solde !"
                    )
                else:
                    inv_msg = (
                        "🎊 <b>مكافأة إحالة جديدة!</b>\n"
                        f"انضم صديقك @{callback.from_user.username or user_id} وأكمل الاشتراك بنجاح.\n"
                        "💳 تم شحن <b>+3 توكن</b> إلى محفظتك!"
                    )
                await bot.send_message(inviter_id, inv_msg, parse_mode="HTML")
            except Exception:
                pass
        await send_welcome_message(callback.message.chat.id, user_id, _welcome_text_for(user_id, lang), get_main_menu(user_id, lang))
    else:
        await callback.answer(t["sub_fail"], show_alert=True)


@dp.callback_query(F.data.startswith("game_"))
async def game_selected(callback: types.CallbackQuery, state: FSMContext):
    game_key = callback.data.split("game_")[1]
    if game_key not in GAMES_CATALOG:
        await callback.answer("Game not found!", show_alert=True)
        return

    game = GAMES_CATALOG[game_key]
    await state.update_data(game_key=game_key, game_name=game["name"])
    await state.set_state(QuestForm.waiting_for_credentials)

    user_id = callback.from_user.id
    lang = db.get_user_language(user_id) or "ar"

    if lang == "en":
        text = (
            f"🚀 <b>Selected Quest:</b> {game['name']}\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "📥 <b>Send your Google credentials:</b>\n"
            "<code>email---password</code>\n\n"
            "✨ <i>You can also send the email first, followed by the password in the next message.</i>\n"
            "📲 <b>Note:</b> Keep your phone ready in case Google displays a confirmation number."
        )
        btn_quick = "⚡ Saved Accounts"
        btn_info = "🔐 Verification Guide"
        btn_back = "↩️ All Quests"
        btn_cancel = "✖️ Cancel"
    elif lang == "fr":
        text = (
            f"🚀 <b>Coffre Choisi :</b> {game['name']}\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "📥 <b>Envoyez vos identifiants Google :</b>\n"
            "<code>email---password</code>\n\n"
            "✨ <i>Ou envoyez l'email d'abord, puis le mot de passe dans le message suivant.</i>\n"
            "📲 <b>Astuce :</b> Gardez votre téléphone à portée de main pour valider le chiffre Google."
        )
        btn_quick = "⚡ Comptes Sauvegardés"
        btn_info = "🔐 Guide de Vérification"
        btn_back = "↩️ Tous les Coffres"
        btn_cancel = "✖️ Annuler"
    else:
        text = (
            f"🚀 <b>الصندوق المحدد:</b> {game['name']}\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "📥 <b>أرسل بيانات حساب Google الخاص بك:</b>\n"
            "<code>email---password</code>\n\n"
            "✨ <i>يمكنك أيضاً إرسال الإيميل أولاً ثم كلمة المرور في رسالة منفصلة.</i>\n"
            "📲 <b>تذكير:</b> أبقِ هاتفك بجانبك للضغط على رقم التأكيد إن طُلب منك."
        )
        btn_quick = "⚡ اختيار من حساباتي المحفوظة"
        btn_info = "🔐 شرح آلية التحقق"
        btn_back = "↩️ قائمة الصناديق"
        btn_cancel = "✖️ إلغاء"

    builder = InlineKeyboardBuilder()
    builder.button(text=btn_quick, callback_data=f"quick_select_{game_key}", style="success")
    builder.button(text=btn_info, callback_data="verification_info", style="primary")
    builder.button(text=btn_back, callback_data="nav_quests", style="primary")
    builder.button(text=btn_cancel, callback_data="pay_cancel", style="danger")
    builder.adjust(1, 1, 2)

    await safe_show(callback, text, reply_markup=builder.as_markup(), prefer_edit=True)
    await callback.answer()


async def _render_quick_select(
    callback: types.CallbackQuery,
    state: FSMContext,
    page: int = 0,
    edit: bool = False,
):
    user_id = callback.from_user.id
    lang = db.get_user_language(user_id) or "ar"
    accounts = db.get_saved_accounts(user_id)
    valid_accounts = [acc for acc in accounts if acc.get("email") and acc.get("password")]

    if not valid_accounts:
        err_msg = (
            "No saved accounts found! Enter your credentials manually."
            if lang == "en" else
            ("Aucun compte sauvegardé ! Entrez vos identifiants manuellement." if lang == "fr" else "لا توجد حسابات محفوظة بعد! أرسل بياناتك يدوياً.")
        )
        await callback.answer(err_msg, show_alert=True)
        return

    total_accounts = len(valid_accounts)
    total_pages = max(1, math.ceil(total_accounts / PAGE_SIZE_ACCOUNTS))
    page = max(0, min(page, total_pages - 1))

    start_idx = page * PAGE_SIZE_ACCOUNTS
    end_idx = min(start_idx + PAGE_SIZE_ACCOUNTS, total_accounts)
    page_accounts = valid_accounts[start_idx:end_idx]

    builder = InlineKeyboardBuilder()
    for acc in page_accounts:
        acc_id = acc.get("id")
        cb_val = str(acc_id) if acc_id is not None else acc["email"]
        builder.button(text=f"📨 {acc['email']}", callback_data=f"use_acc_{cb_val}", style="primary")
    builder.adjust(1)

    if total_pages > 1:
        nav_builder = InlineKeyboardBuilder()
        btn_prev = "◀️ Prev" if lang == "en" else ("◀️ Préc." if lang == "fr" else "◀️ السابق")
        btn_next = "Next ▶️" if lang == "en" else ("Suiv. ▶️" if lang == "fr" else "التالي ▶️")
        if page > 0:
            nav_builder.button(text=btn_prev, callback_data=f"quick_page_{page - 1}")
        nav_builder.button(text=f"📑 {page + 1}/{total_pages}", callback_data=f"quick_page_info_{page + 1}_{total_pages}")
        if page < total_pages - 1:
            nav_builder.button(text=btn_next, callback_data=f"quick_page_{page + 1}")
        nav_builder.adjust(3 if (page > 0 and page < total_pages - 1) else 2)
        builder.attach(nav_builder)

    cancel_text = "✖️ Cancel" if lang == "en" else ("✖️ Annuler" if lang == "fr" else "✖️ إلغاء")
    action_builder = InlineKeyboardBuilder()
    action_builder.button(text=cancel_text, callback_data="pay_cancel", style="danger")
    action_builder.adjust(1)
    builder.attach(action_builder)

    if lang == "en":
        page_info = f"\n<i>Page {page + 1}/{total_pages} • {total_accounts} accounts</i>" if total_pages > 1 else ""
        prompt_title = f"⚡ <b>Saved Accounts Vault</b>{page_info}"
    elif lang == "fr":
        page_info = f"\n<i>Page {page + 1}/{total_pages} • {total_accounts} comptes</i>" if total_pages > 1 else ""
        prompt_title = f"⚡ <b>Comptes Sauvegardés</b>{page_info}"
    else:
        page_info = f"\n<i>الصفحة {page + 1} من {total_pages} • الإجمالي: {total_accounts} حساب</i>" if total_pages > 1 else ""
        prompt_title = f"⚡ <b>اختر حساباً من خزنتك المحفوظة:</b>{page_info}"

    await safe_show(callback, prompt_title, reply_markup=builder.as_markup(), prefer_edit=edit)
    await callback.answer()


@dp.callback_query(F.data == "quick_select")
@dp.callback_query(F.data.startswith("quick_select_"))
async def quick_select(callback: types.CallbackQuery, state: FSMContext):
    if callback.data.startswith("quick_select_"):
        gk = callback.data.split("quick_select_")[1]
        if gk in GAMES_CATALOG:
            await state.update_data(game_key=gk, game_name=GAMES_CATALOG[gk]["name"])
            await state.set_state(QuestForm.waiting_for_credentials)
    await _render_quick_select(callback, state, page=0, edit=True)


@dp.callback_query(F.data.startswith("quick_page_info_"))
async def quick_page_info_handler(callback: types.CallbackQuery):
    parts = callback.data.split("_")
    if len(parts) >= 5:
        await callback.answer(f"📑 {parts[3]} / {parts[4]}")
    else:
        await callback.answer()


@dp.callback_query(F.data.startswith("quick_page_"))
async def quick_page_handler(callback: types.CallbackQuery, state: FSMContext):
    try:
        page = int(callback.data.split("quick_page_")[1])
    except ValueError:
        await callback.answer()
        return
    await _render_quick_select(callback, state, page=page, edit=True)


def _format_confirm_text(lang: str, game_name: str, email: str, masked_pw: str, balance: int) -> str:
    cost = get_chest_cost()
    if lang == "fr":
        return (
            "🧾 <b>Récapitulatif & Lancement</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"🚀 <b>Coffre :</b> {game_name}\n"
            f"📨 <b>Compte :</b> <code>{email}</code>\n"
            f"🔑 <b>Mot de passe :</b> <code>{masked_pw}</code>\n"
            f"💳 <b>Frais :</b> {cost} Tokens (Solde : {balance} 🪙)\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "📲 <i>Gardez votre téléphone déverrouillé si Google demande une confirmation.</i>"
        )
    if lang == "en":
        return (
            "🧾 <b>Order Summary & Launch</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"🚀 <b>Quest:</b> {game_name}\n"
            f"📨 <b>Account:</b> <code>{email}</code>\n"
            f"🔑 <b>Password:</b> <code>{masked_pw}</code>\n"
            f"💳 <b>Cost:</b> {cost} Tokens (Wallet: {balance} 🪙)\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "📲 <i>Keep your phone unlocked in case Google sends a confirmation prompt.</i>"
        )
    return (
        "🧾 <b>مراجعة الطلب وتأكيد التشغيل</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"🚀 <b>الصندوق:</b> {game_name}\n"
        f"📨 <b>الحساب:</b> <code>{email}</code>\n"
        f"🔑 <b>كلمة المرور:</b> <code>{masked_pw}</code>\n"
        f"💳 <b>التكلفة:</b> {cost} توكن (محفظتك: {balance} 🪙)\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "📲 <i>أبقِ هاتفك مفتوحاً تحسباً لوصول إشعار تأكيد من Google.</i>"
    )


@dp.callback_query(F.data.startswith("use_acc_"))
async def use_saved_account(callback: types.CallbackQuery, state: FSMContext):
    target = callback.data.split("use_acc_")[1]
    user_id = callback.from_user.id
    acc = None
    if target.isdigit():
        acc = db.get_saved_account_by_id(user_id, int(target))
    if not acc:
        acc = db.get_saved_account_by_email(user_id, target)
    if not acc:
        accounts = db.get_saved_accounts(user_id)
        acc = next((a for a in accounts if str(a.get("id")) == target or a.get("email") == target), None)

    if not acc or not acc.get("password"):
        await callback.answer("⚠️ Account not found!", show_alert=True)
        return

    email = acc["email"]
    pwd = acc["password"]
    data = await state.get_data()
    game_name = data.get("game_name", "Selected Quest")
    await state.update_data(email=email, password=pwd)
    await state.set_state(QuestForm.confirm_credentials)

    balance = db.get_user_balance(user_id)
    masked_pw = pwd[:4] + "••••" + pwd[-4:] if len(pwd) > 8 else pwd[:2] + "••••" + pwd[-2:]
    lang = db.get_user_language(user_id) or "ar"

    confirm_text = _format_confirm_text(lang, game_name, email, masked_pw, balance)
    await safe_show(callback, confirm_text, reply_markup=get_confirmation_keyboard(lang), prefer_edit=True)
    await callback.answer()


@dp.message(QuestForm.waiting_for_credentials)
async def process_credentials(message: types.Message, state: FSMContext):
    text = (message.text or "").strip()
    email, password = None, None

    if "---" in text:
        parts = text.split("---", 1)
        email, password = parts[0].strip(), parts[1].strip()
    elif "\n" in text:
        parts = text.split("\n", 1)
        email, password = parts[0].strip(), parts[1].strip()

    user_id = message.from_user.id
    lang = db.get_user_language(user_id) or "ar"

    if not email or not password:
        if "@" in text:
            await state.update_data(email=text.strip())
            pw_prompt = {
                "en": f"📨 <b>Account:</b> <code>{text.strip()}</code>\n\n🔑 <b>Now send the password:</b>\n🔒 <i>Encrypted during transmission.</i>",
                "fr": f"📨 <b>Compte :</b> <code>{text.strip()}</code>\n\n🔑 <b>Envoyez maintenant le mot de passe :</b>\n🔒 <i>Transmission chiffrée.</i>",
                "ar": f"📨 <b>الحساب:</b> <code>{text.strip()}</code>\n\n🔑 <b>أرسل الآن كلمة المرور في رسالة منفصلة:</b>\n🔒 <i>يتم حذف رسالتك تلقائياً بعد الاستلام.</i>",
            }.get(lang)
            await message.answer(pw_prompt, parse_mode="HTML")
            return
        data = await state.get_data()
        if data.get("email") and not data.get("password"):
            password = text.strip()
            email = data["email"]
        else:
            fmt_err = {
                "en": "⚠️ Send credentials as: <code>email---password</code>",
                "fr": "⚠️ Envoyez vos identifiants sous la forme : <code>email---password</code>",
                "ar": "⚠️ يرجى إرسال البيانات بالصيغة: <code>email---password</code>",
            }.get(lang)
            await message.answer(fmt_err, parse_mode="HTML")
            return

    try:
        await message.delete()
    except Exception:
        pass

    data = await state.get_data()
    game_name = data.get("game_name", "Selected Quest")
    await state.update_data(email=email, password=password)
    await state.set_state(QuestForm.confirm_credentials)

    balance = db.get_user_balance(user_id)
    masked_pw = password[:4] + "••••" + password[-4:] if len(password) > 8 else password[:2] + "••••" + password[-2:]
    confirm_text = _format_confirm_text(lang, game_name, email, masked_pw, balance)
    await message.answer(confirm_text, reply_markup=get_confirmation_keyboard(lang), parse_mode="HTML")


@dp.callback_query(F.data == "verification_info")
async def verification_info(callback: types.CallbackQuery):
    lang = db.get_user_language(callback.from_user.id) or "ar"
    if lang == "en":
        text = (
            "🔐 <b>How PLAYX1 ZONE Verification Works</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            "<b>1. Smart Session Login:</b>\n"
            "Saved accounts reconnect immediately using encrypted Master Tokens without repeating security prompts.\n\n"
            "<b>2. Live Device Approval:</b>\n"
            "For new logins, approve the Google prompt on your phone when notified.\n\n"
            "<b>3. High-Security / Passkey Accounts:</b>\n"
            "Use a 16-character Google App Password for seamless authentication."
        )
    elif lang == "fr":
        text = (
            "🔐 <b>Fonctionnement de la Vérification PLAYX1 ZONE</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            "<b>1. Session Rapide :</b>\n"
            "Les comptes déjà vérifiés se reconnectent instantanément via un jeton sécurisé.\n\n"
            "<b>2. Validation Téléphone :</b>\n"
            "Pour une première connexion, confirmez simplement l'alerte Google sur votre téléphone.\n\n"
            "<b>3. Comptes Haute Sécurité / Passkey :</b>\n"
            "Utilisez un mot de passe d'application Google (16 caractères)."
        )
    else:
        text = (
            "🔐 <b>آلية التحقق والأمان في PLAYX1 ZONE</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            "<b>1. الدخول الفوري بالجلسة المحفوظة:</b>\n"
            "بعد أول تسجيل ناجح، يتم حفظ الجلسة الآمنة لتنفيذ المهام لاحقاً خلال ثوانٍ دون تكرار التأكيد.\n\n"
            "<b>2. تأكيد الهاتف المباشر:</b>\n"
            "عند تسجيل الدخول الأول، يظهر لك رقم التأكيد وتوافق عليه من هاتفك مباشرة.\n\n"
            "<b>3. حسابات الحماية العالية (Passkey / 2FA):</b>\n"
            "يمكنك استخدام كلمة مرور التطبيقات (App Password) المكونة من 16 حرفاً لتسجيل دخول فوري."
        )
    kb = InlineKeyboardBuilder()
    kb.button(text=STRINGS[lang]["home"], callback_data="nav_home", style="primary")
    await callback.message.answer(text, reply_markup=kb.as_markup(), parse_mode="HTML")
    await callback.answer()


@dp.callback_query(F.data == "pay_edit")
async def pay_edit(callback: types.CallbackQuery, state: FSMContext):
    lang = db.get_user_language(callback.from_user.id) or "ar"
    await state.set_state(QuestForm.waiting_for_credentials)
    msg = {
        "en": "📝 <b>Enter updated credentials:</b>\n<code>email---password</code>",
        "fr": "📝 <b>Envoyez les nouveaux identifiants :</b>\n<code>email---password</code>",
        "ar": "📝 <b>أرسل بيانات الحساب الجديدة:</b>\n<code>email---password</code>",
    }.get(lang)
    await safe_show(callback, msg, prefer_edit=True)
    await callback.answer()


@dp.callback_query(F.data == "pay_confirm")
async def execute_quest(callback: types.CallbackQuery, state: FSMContext):
    user_id = callback.from_user.id
    lang = db.get_user_language(user_id) or "ar"
    cost = get_chest_cost()
    balance = db.get_user_balance(user_id)

    data = await state.get_data()
    email = data.get("email")
    password = data.get("password")
    game_key = data.get("game_key", "triple_match")
    game = GAMES_CATALOG.get(game_key, GAMES_CATALOG["triple_match"])

    if not email or not password:
        await callback.answer("⚠️ Session expired! Start again.", show_alert=True)
        return

    if balance < cost:
        low_bal = {
            "en": f"⚠️ Insufficient wallet balance! You need {cost} tokens.",
            "fr": f"⚠️ Solde insuffisant ! Il vous faut {cost} tokens.",
            "ar": f"⚠️ رصيدك غير كافٍ! تحتاج إلى {cost} توكن على الأقل.",
        }.get(lang)
        await callback.answer(low_bal, show_alert=True)
        return

    db.update_balance(user_id, -cost)
    db.save_account(user_id, email, password)

    init_txt = {
        "en": "⚡ <b>Booting PLAYX1 Engine...</b>\n🔐 <i>Connecting securely to Google Services...</i>",
        "fr": "⚡ <b>Démarrage du Moteur PLAYX1...</b>\n🔐 <i>Connexion sécurisée aux services Google...</i>",
        "ar": "⚡ <b>جاري تشغيل محرك PLAYX1 السريع...</b>\n🔐 <i>جاري الاتصال الآمن بحساب Google...</i>",
    }.get(lang)
    status_msg = await safe_show(callback, init_txt, prefer_edit=True)
    await callback.answer()

    ap_auth = None
    try:
        saved = db.get_master_token(user_id, email)
        if saved:
            logger.info("Trying saved master token for %s...", email)
            auth_fast = GoogleAuthenticator(email, android_id=saved["android_id"])
            st_fast, _ = auth_fast.login_with_master_token(saved["master_token"])
            if st_fast == "SUCCESS":
                fast_txt = {
                    "en": f"⚡ <b>Instant Session Restored!</b>\n📨 <code>{email}</code>\n🚀 <i>Syncing game achievements...</i>",
                    "fr": f"⚡ <b>Session Restaurée Instantanément !</b>\n📨 <code>{email}</code>\n🚀 <i>Validation des succès en cours...</i>",
                    "ar": f"⚡ <b>تم استرجاع الجلسة فوراً!</b>\n📨 <code>{email}</code>\n🚀 <i>جاري فتح إنجازات اللعبة...</i>",
                }.get(lang)
                await status_msg.edit_text(fast_txt, parse_mode="HTML")
                await _run_quest_unlocking(auth_fast, game, game_key, email, user_id, status_msg, state, cost)
                return

        ap_auth = AutoPixelAuthenticator(email, password)
        status, result = await asyncio.to_thread(ap_auth.start_auth)
        logger.info("Auth start for %s: %s", email, status)

        if status in ("NEEDS_NUMBER", "NEEDS_TAP_YES"):
            if status == "NEEDS_NUMBER":
                prompt_text = {
                    "en": (
                        "📲 <b>Phone Security Check</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                        f"👉 <b>Tap number <code>{result}</code> on your phone</b>\n\n"
                        f"<i>Approve Google's notification and pick <b>{result}</b>.</i>\n"
                        "⏳ <i>Waiting up to 2 minutes...</i>"
                    ),
                    "fr": (
                        "📲 <b>Vérification sur Téléphone</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                        f"👉 <b>Appuyez sur <code>{result}</code> sur votre appareil</b>\n\n"
                        f"<i>Acceptez la demande Google puis choisissez <b>{result}</b>.</i>\n"
                        "⏳ <i>En attente (2 minutes)...</i>"
                    ),
                    "ar": (
                        "📲 <b>تأكيد الدخول من هاتفك</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                        f"👉 <b>اضغط على الرقم <code>{result}</code> في إشعار Google</b>\n\n"
                        f"<i>اختر «نعم، إنه أنا» ثم الرقم <b>{result}</b> على شاشة هاتفك أو Gmail.</i>\n"
                        "⏳ <i>بانتظار التأكيد (دقيقتان)...</i>"
                    ),
                }.get(lang)
            else:
                prompt_text = {
                    "en": (
                        "📲 <b>Phone Security Check</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                        "👉 <b>Tap 'Yes, it's me' on your phone</b>\n\n"
                        "⏳ <i>Waiting up to 2 minutes...</i>"
                    ),
                    "fr": (
                        "📲 <b>Vérification sur Téléphone</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                        "👉 <b>Appuyez sur 'Oui, c'est moi' sur votre appareil</b>\n\n"
                        "⏳ <i>En attente (2 minutes)...</i>"
                    ),
                    "ar": (
                        "📲 <b>تأكيد الدخول من هاتفك</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                        "👉 <b>اضغط «نعم، إنه أنا» في إشعار Google على هاتفك</b>\n\n"
                        "⏳ <i>بانتظار التأكيد (دقيقتان)...</i>"
                    ),
                }.get(lang)

            await status_msg.edit_text(prompt_text, parse_mode="HTML")
            approved = await asyncio.to_thread(ap_auth.wait_for_approval, 120)
            if not approved:
                ap_auth.close()
                db.update_balance(user_id, cost)
                t_out = {
                    "en": f"⌛ <b>Approval timed out.</b> Refunded +{cost} tokens to your wallet.",
                    "fr": f"⌛ <b>Délai expiré.</b> +{cost} tokens remboursés sur votre solde.",
                    "ar": f"⌛ <b>انتهت مهلة التأكيد!</b> تم إرجاع +{cost} توكن إلى محفظتك تلقائياً.",
                }.get(lang)
                await status_msg.edit_text(t_out, reply_markup=get_main_menu(user_id, lang), parse_mode="HTML")
                await state.clear()
                return

            t_ok = {
                "en": "✅ <b>Device Approved!</b>\n🚀 <i>Preparing Google Play Games session...</i>",
                "fr": "✅ <b>Appareil Validé !</b>\n🚀 <i>Préparation de la session Google Play Jeux...</i>",
                "ar": "✅ <b>تم التأكيد بنجاح!</b>\n🚀 <i>جاري تجهيز جلسة Google Play Games...</i>",
            }.get(lang)
            await status_msg.edit_text(t_ok, parse_mode="HTML")

        elif status == "SUCCESS":
            s_ok = {
                "en": "✅ <b>Signed In!</b>\n🚀 <i>Extracting Google Play session...</i>",
                "fr": "✅ <b>Connecté !</b>\n🚀 <i>Extraction de la session Google Play...</i>",
                "ar": "✅ <b>تم تسجيل الدخول!</b>\n🚀 <i>جاري استخراج الجلسة الآمنة...</i>",
            }.get(lang)
            await status_msg.edit_text(s_ok, parse_mode="HTML")

        else:
            ap_auth.close()
            db.update_balance(user_id, cost)
            help_tip = ""
            if result and any(w in result.lower() for w in ["security key", "two-step", "app password", "verification"]):
                help_tip = (
                    "\n\n💡 <b>حل سريع لحسابات الحماية العالية (Passkey / 2FA):</b>\n"
                    "1. افتح: <a href='https://myaccount.google.com/apppasswords'>myaccount.google.com/apppasswords</a>\n"
                    "2. أنشئ <b>كلمة مرور تطبيق (App Password)</b> من 16 حرفاً.\n"
                    "3. استخدمها مع إيميلك في البوت لتسجيل دخول فوري."
                )
            await status_msg.edit_text(
                f"❌ <b>فشل تسجيل الدخول / Sign-In Failed:</b>\n\n<code>{result}</code>"
                f"{help_tip}\n\n"
                f"💳 <i>تم استرجاع التوكنات إلى محفظتك (+{cost} 🪙).</i>",
                reply_markup=get_main_menu(user_id, lang),
                parse_mode="HTML",
                disable_web_page_preview=True,
            )
            await state.clear()
            return

        tokens_ok, token_msg = await asyncio.to_thread(ap_auth.extract_tokens)
        if not tokens_ok:
            db.update_balance(user_id, cost)
            await status_msg.edit_text(
                f"❌ <b>Session Error:</b> <code>{token_msg}</code>\n\n💳 <i>Refunded +{cost} 🪙.</i>",
                reply_markup=get_main_menu(user_id, lang),
                parse_mode="HTML",
            )
            await state.clear()
            return

        if ap_auth.master_token:
            db.save_master_token(user_id, email, ap_auth.master_token, ap_auth.android_id)

        await _run_quest_unlocking(ap_auth, game, game_key, email, user_id, status_msg, state, cost)

    except Exception as e:
        logger.exception("Unexpected error during quest execution for %s: %s", email, e)
        if ap_auth:
            try:
                ap_auth.close()
            except Exception:
                pass
        db.update_balance(user_id, cost)
        try:
            await status_msg.edit_text(
                f"❌ <b>Execution Error:</b> <code>{str(e)[:150]}</code>\n\n💳 <i>Refunded +{cost} 🪙.</i>",
                reply_markup=get_main_menu(user_id, lang),
                parse_mode="HTML",
            )
        except Exception:
            pass
        await state.clear()


@dp.callback_query(F.data == "token_help")
async def token_help(callback: types.CallbackQuery):
    text = (
        "📋 <b>OAuth Token Extraction Guide</b>\n━━━━━━━━━━━━━━━━━━━━\n"
        "<b>Mobile (Chrome):</b>\n"
        "1. Open the Google login link in Chrome & sign in.\n"
        "2. Tap 'I agree' on the consent screen.\n"
        "3. Open <code>chrome://cookies</code> and locate <code>oauth_token</code>.\n"
        "4. Copy its value and send it here.\n\n"
        "<b>Desktop (Chrome / Edge):</b>\n"
        "1. Sign in via the link and click 'I agree'.\n"
        "2. Press <b>F12</b> → Application → Cookies → accounts.google.com.\n"
        "3. Copy <code>oauth_token</code> and paste it here within 2 minutes."
    )
    await callback.message.answer(text, parse_mode="HTML")
    await callback.answer()


@dp.callback_query(F.data == "cancel_token_flow")
async def cancel_token_flow(callback: types.CallbackQuery, state: FSMContext):
    user_id = callback.from_user.id
    cost = get_chest_cost()
    lang = db.get_user_language(user_id) or "ar"
    db.update_balance(user_id, cost)
    await state.clear()
    await safe_show(
        callback,
        f"✖️ <b>Process cancelled.</b>\n💳 <i>Refunded +{cost} tokens to your wallet.</i>",
        reply_markup=get_main_menu(user_id, lang),
        prefer_edit=True,
    )
    await callback.answer()


@dp.message(QuestForm.waiting_for_oauth_token)
async def process_oauth_token(message: types.Message, state: FSMContext):
    oauth_token = (message.text or "").strip()
    try:
        await message.delete()
    except Exception:
        pass

    user_id = message.from_user.id
    lang = db.get_user_language(user_id) or "ar"
    cost = get_chest_cost()

    if len(oauth_token) < 10:
        await message.answer(
            "⚠️ Invalid <code>oauth_token</code> format. Send the full value starting with <code>oauth2_4/</code> or /cancel.",
            parse_mode="HTML",
        )
        return

    data = await state.get_data()
    email = data.get("email")
    android_id = data.get("auth_android_id")
    game_key = data.get("game_key", "triple_match")
    game = GAMES_CATALOG.get(game_key, GAMES_CATALOG["triple_match"])

    status_msg = await message.answer(
        "🔄 <b>Exchanging OAuth Token...</b>\n⚡ <i>Validating with Google MTP...</i>",
        parse_mode="HTML",
    )

    auth = GoogleAuthenticator(email, android_id=android_id)
    auth_status, details = auth.login_with_token(oauth_token)
    logger.info("Token exchange for %s: status=%s", email, auth_status)

    if auth_status == "SUCCESS":
        master_token = details.get("master_token")
        if master_token:
            db.save_master_token(user_id, email, master_token, auth.android_id)

        await status_msg.edit_text(
            f"✅ <b>MTP Session Connected!</b>\n📨 <code>{email}</code>\n🚀 <i>Unlocking quest achievements...</i>",
            parse_mode="HTML",
        )
        await _run_quest_unlocking(auth, game, game_key, email, user_id, status_msg, state, cost)
        return

    if auth_status == "TOKEN_INVALID":
        await status_msg.edit_text(
            "⚠️ <b>Token Invalid or Expired.</b>\nGenerate a fresh token and send it again, or send /cancel.",
            parse_mode="HTML",
        )
        return

    db.update_balance(user_id, cost)
    error_msg = details.get("error", "Unknown error")
    await status_msg.edit_text(
        f"❌ <b>Token Exchange Failed</b>\n<code>{error_msg}</code>\n\n💳 <i>Refunded +{cost} tokens.</i>",
        reply_markup=get_main_menu(user_id, lang),
        parse_mode="HTML",
    )
    await state.clear()


def _execute_single_task(unlocker: GPGSUnlocker, task: dict, package: Optional[str]) -> Tuple[str, bool]:
    title = task.get("title", "Task")
    ach_id = task.get("achievement_id")
    event_name = task.get("event_name")
    task_type = task.get("type", "")
    success = False

    if task_type in ["session", "signin"] or "sign into" in title.lower():
        success = unlocker.sign_in_game()

    if ach_id:
        steps = task.get("steps", 5)
        ach_ok = unlocker.unlock_achievement(ach_id, steps=steps)
        success = success or ach_ok

    if event_name:
        amount = task.get("amount", 1)
        prop = task.get("property_name", "amount")
        ev_ok = unlocker.record_event(package_name=package, event_name=event_name, amount=amount, property_name=prop)
        success = success or ev_ok

    return (title, success)


def _sync_unlock_all(
    email: str,
    master_token: Optional[str],
    android_id: Optional[str],
    access_token: str,
    game: dict,
) -> Tuple[Optional[dict], List[Tuple[str, bool]], bool]:
    target_token = access_token
    if game.get("package") and game.get("client_sig") and master_token and android_id:
        try:
            game_res = gpsoauth.perform_oauth(
                email,
                master_token,
                android_id,
                service="oauth2:https://www.googleapis.com/auth/games",
                app=game["package"],
                client_sig=game["client_sig"],
            )
            if "Auth" in game_res:
                target_token = game_res["Auth"]
            else:
                logger.warning("Failed to get app-scoped token: %s", game_res.get("Error"))
        except Exception as e:
            logger.warning("Error getting app-scoped GPGS token: %s", e)

    unlocker = GPGSUnlocker(target_token)
    profile = unlocker.get_player_profile()
    if unlocker.player_not_found:
        return (None, [], True)

    unlocker.sign_in_game()
    tasks = game.get("tasks", [])
    package = game.get("package")

    num_workers = max(1, min(len(tasks), 5)) if tasks else 1
    with ThreadPoolExecutor(max_workers=num_workers) as pool:
        futures = [pool.submit(_execute_single_task, unlocker, t, package) for t in tasks]
        results = [f.result() for f in futures]

    return (profile, results, False)


async def _run_quest_unlocking(
    auth: GoogleAuthenticator,
    game: dict,
    game_key: str,
    email: str,
    user_id: int,
    status_msg: types.Message,
    state: FSMContext,
    cost: Optional[int] = None,
):
    quest_cost = get_chest_cost() if cost is None else cost
    lang = db.get_user_language(user_id) or "ar"

    if not auth.access_token:
        db.update_balance(user_id, quest_cost)
        await status_msg.edit_text(
            f"❌ <b>Authentication Error:</b> No GPGS token obtained.\n💳 <i>Refunded +{quest_cost} tokens.</i>",
            reply_markup=get_main_menu(user_id, lang),
            parse_mode="HTML",
        )
        await state.clear()
        return

    tasks = game.get("tasks", [])
    total_tasks = len(tasks)

    sync_txt = {
        "en": f"⚡ <b>Running Quest Sync: {game['name']}</b>\n📨 <code>{email}</code>\n🚀 <i>Processing {total_tasks} tasks in parallel...</i>",
        "fr": f"⚡ <b>Synchronisation Express : {game['name']}</b>\n📨 <code>{email}</code>\n🚀 <i>Traitement parallèle de {total_tasks} tâches...</i>",
        "ar": f"⚡ <b>جاري التنفيذ المتوازي: {game['name']}</b>\n📨 <code>{email}</code>\n🚀 <i>مزامنة {total_tasks} مهام دفعة واحدة مع Google Play Games...</i>",
    }.get(lang)
    await status_msg.edit_text(sync_txt, parse_mode="HTML")

    async with QUEST_SEMAPHORE:
        loop = asyncio.get_running_loop()
        profile, unlock_results, player_not_found = await loop.run_in_executor(
            QUEST_EXECUTOR,
            _sync_unlock_all,
            email,
            auth.master_token,
            auth.android_id,
            auth.access_token,
            game,
        )

    if player_not_found:
        db.update_balance(user_id, quest_cost)
        rem = db.get_user_balance(user_id)
        if lang == "en":
            pnf_text = (
                "⚠️ <b>No Play Games Gamer Profile Found</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                f"📨 <b>Account:</b> <code>{email}</code>\n\n"
                "Google API returned <code>404 Player Not Found</code>.\n\n"
                "👉 <b>Fix in 5 seconds:</b>\n"
                "1. Open <b>Google Play Games</b> on your phone with this account.\n"
                "2. Create any Gamer Tag.\n"
                "3. Come back and run the quest again.\n\n"
                f"💳 <i>Refunded +{quest_cost} tokens (Wallet: {rem} 🪙).</i>"
            )
        elif lang == "fr":
            pnf_text = (
                "⚠️ <b>Profil Google Play Jeux Manquant</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                f"📨 <b>Compte :</b> <code>{email}</code>\n\n"
                "Réponse API : <code>404 Player Not Found</code>.\n\n"
                "👉 <b>Activation rapide :</b>\n"
                "1. Ouvrez <b>Google Play Jeux</b> avec ce compte.\n"
                "2. Créez un pseudo joueur.\n"
                "3. Relancez ensuite la quête sur le bot.\n\n"
                f"💳 <i>+{quest_cost} tokens remboursés (Solde : {rem} 🪙).</i>"
            )
        else:
            pnf_text = (
                "⚠️ <b>الحساب لا يملك ملف لاعب في ألعاب Google Play</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                f"📨 <b>الحساب:</b> <code>{email}</code>\n\n"
                "استجابة Google: <code>404 Player Not Found</code>.\n\n"
                "👉 <b>التفعيل في ثوانٍ:</b>\n"
                "1. افتح تطبيق <b>ألعاب Google Play</b> على هاتفك بهذا الحساب.\n"
                "2. اختر أي اسم لاعب (Gamer Tag) لتفعيل الملف.\n"
                "3. عُد للبوت وأعد تشغيل المهمة بنجاح.\n\n"
                f"💳 <i>تم إرجاع +{quest_cost} توكن إلى محفظتك (رصيدك: {rem} 🪙).</i>"
            )
        await status_msg.edit_text(pnf_text, reply_markup=get_main_menu(user_id, lang), parse_mode="HTML")
        await state.clear()
        return

    profile_name = profile["displayName"] if profile else "Play Points Member"
    profile_level = profile["level"] if profile else 1
    raw_xp = profile.get("xp", 0) if profile else 0
    try:
        profile_xp = f"{int(raw_xp):,}"
    except (ValueError, TypeError):
        profile_xp = str(raw_xp)

    any_success = any(s for _, s in unlock_results)
    if any_success:
        db.log_quest(user_id, email, game_key, "COMPLETED")
    else:
        db.log_quest(user_id, email, game_key, "FAILED")
        db.update_balance(user_id, quest_cost)
    await state.clear()

    done_count = sum(1 for _, s in unlock_results if s)
    completed_list = "\n".join([
        f"{'🟢' if s else '🔴'} {t} — {'Unlocked' if s else 'Rejected'}"
        for t, s in unlock_results
    ])
    rem_bal = db.get_user_balance(user_id)
    home_lbl = STRINGS[lang]["home"]

    claim_btn_text = {
        "ar": "🎁 افتح متجر Play واستلم النقاط",
        "fr": "🎁 Ouvrir Play Store & Réclamer",
        "en": "🎁 Open Play Store & Claim Points",
    }.get(lang)

    retry_btn_text = {
        "ar": "🚀 إنجاز صندوق آخر",
        "fr": "🚀 Lancer un Autre Coffre",
        "en": "🚀 Complete Another Quest",
    }.get(lang)

    tip_claim_text = {
        "ar": "✨ <b>اضغط على زر الاستلام أدناه لفتح الصندوق وإضافة نقاطك فوراً!</b>",
        "fr": "✨ <b>Cliquez ci-dessous pour ouvrir le coffre et récupérer vos points !</b>",
        "en": "✨ <b>Tap the button below to open your chest and collect your points!</b>",
    }.get(lang)

    if any_success:
        final_kb = InlineKeyboardMarkup(
            inline_keyboard=[
                [InlineKeyboardButton(
                    text=("✅ " if s else "⚠️ ") + t,
                    callback_data="noop",
                )] for t, s in unlock_results
            ] + [
                [InlineKeyboardButton(text=claim_btn_text, url="https://play.google.com/store/points")],
                [
                    InlineKeyboardButton(text=retry_btn_text, callback_data="nav_quests"),
                    InlineKeyboardButton(text=home_lbl, callback_data="nav_home"),
                ],
            ]
        )
        final_text = (
            f"🏆 <b>{profile_name}</b> • Lv.{profile_level} ({profile_xp} XP)\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"⚡ <b>Synced Tasks ({done_count}/{total_tasks}):</b>\n"
            f"{completed_list}\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"💳 <b>Remaining Wallet:</b> <code>{rem_bal}</code> 🪙\n\n"
            f"{tip_claim_text}"
        )
    else:
        final_kb = InlineKeyboardMarkup(
            inline_keyboard=[
                [InlineKeyboardButton(text=retry_btn_text, callback_data="nav_quests")],
                [InlineKeyboardButton(text=home_lbl, callback_data="nav_home")],
            ]
        )
        final_text = (
            "❌ <b>Achievement Sync Unsuccessful</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"🚀 <b>Game:</b> {game['name']}\n"
            f"📨 <b>Account:</b> <code>{email}</code>\n\n"
            f"{completed_list}\n\n"
            f"💳 <i>Refunded +{quest_cost} tokens (Wallet: {rem_bal} 🪙).</i>"
        )
    await status_msg.edit_text(final_text, reply_markup=final_kb, parse_mode="HTML")


@dp.callback_query(F.data == "pay_cancel", StateFilter("*"))
async def cancel_process(callback: types.CallbackQuery, state: FSMContext):
    await state.clear()
    user_id = callback.from_user.id
    lang = db.get_user_language(user_id) or "ar"
    msg = {
        "en": "✖️ <b>Action cancelled.</b>",
        "fr": "✖️ <b>Action annulée.</b>",
        "ar": "✖️ <b>تم إلغاء العملية.</b>",
    }.get(lang)
    await safe_show(callback, msg, reply_markup=get_main_menu(user_id, lang), prefer_edit=True)
    await callback.answer()


@dp.callback_query(F.data == "noop")
async def noop_handler(callback: types.CallbackQuery):
    await callback.answer()


@dp.callback_query(F.data == "nav_wallet", StateFilter("*"))
async def cb_nav_wallet(callback: types.CallbackQuery, state: FSMContext):
    await state.clear()
    user_id = callback.from_user.id
    bal = db.get_user_balance(user_id)
    cost = get_chest_cost()
    lang = db.get_user_language(user_id) or "ar"
    t = STRINGS.get(lang, STRINGS["ar"])

    if lang == "en":
        text = (
            "💳 <b>PLAYX1 ZONE — Your Wallet</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"🪙 <b>Available Balance:</b> <code>{bal}</code> Tokens\n"
            f"📦 <b>Quest Cost:</b> <code>{cost}</code> Tokens\n\n"
            "✨ <i>Every completed chest grants 50 Google Play Points!</i>\n\n"
            "⭐ <b>Instant Telegram Stars Top-Up:</b>\n"
            "Automated delivery straight into your wallet seconds after payment."
        )
        btn_shop = "⭐ Open Stars Store"
    elif lang == "fr":
        text = (
            "💳 <b>PLAYX1 ZONE — Votre Portefeuille</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"🪙 <b>Solde Disponible :</b> <code>{bal}</code> Tokens\n"
            f"📦 <b>Coût par Coffre :</b> <code>{cost}</code> Tokens\n\n"
            "✨ <i>Chaque coffre complété rapporte 50 Google Play Points !</i>\n\n"
            "⭐ <b>Recharge Express Telegram Stars :</b>\n"
            "Livraison automatique et immédiate sur votre compte."
        )
        btn_shop = "⭐ Boutique Telegram Stars"
    else:
        text = (
            "💳 <b>محفظتي — PLAYX1 ZONE</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"🪙 <b>الرصيد المتاح:</b> <code>{bal}</code> توكن\n"
            f"📦 <b>تكلفة الصندوق:</b> <code>{cost}</code> توكن\n\n"
            "✨ <i>كل صندوق مكتمل يمنحك 50 نقطة داخل Google Play Points!</i>\n\n"
            "⭐ <b>الشحن الفوري بنجوم تليجرام:</b>\n"
            "شحن آلي ومؤمّن يُضاف إلى محفظتك في اللحظة نفسها."
        )
        btn_shop = "⭐ الدخول لمتجر النجوم"

    builder = InlineKeyboardBuilder()
    builder.button(text=btn_shop, callback_data="stars_shop", style="success")
    builder.button(text=t["home"], callback_data="nav_home", style="primary")
    builder.adjust(1)
    await safe_show(callback, text, reply_markup=builder.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.callback_query(F.data == "stars_shop")
async def cb_stars_shop(callback: types.CallbackQuery):
    user_id = callback.from_user.id
    lang = db.get_user_language(user_id) or "ar"
    t = STRINGS.get(lang, STRINGS["ar"])

    if lang == "en":
        text = (
            "⭐ <b>PLAYX1 ZONE — Stars Token Store</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "⚡ <i>Select your package below for instant automated delivery:</i>"
        )
    elif lang == "fr":
        text = (
            "⭐ <b>PLAYX1 ZONE — Boutique Stars</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "⚡ <i>Sélectionnez votre pack pour un crédit instantané :</i>"
        )
    else:
        text = (
            "⭐ <b>متجر التوكنات — نجوم تليجرام</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "⚡ <i>اختر الباقة المناسبة لك ليتم الشحن الفوري والآمن:</i>"
        )

    builder = InlineKeyboardBuilder()
    styles = ["primary", "success"]
    for i, (tokens, stars) in enumerate(STARS_PACKS):
        builder.button(text=f"🪙 {tokens}  •  {stars} ⭐", callback_data=f"buy_stars_{tokens}_{stars}", style=styles[i % len(styles)])
    builder.adjust(2)
    nav = InlineKeyboardBuilder()
    nav.button(text=t["home"], callback_data="nav_home", style="danger")
    nav.adjust(1)
    builder.attach(nav)
    await safe_show(callback, text, reply_markup=builder.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.callback_query(F.data.startswith("buy_stars_"))
async def cb_buy_stars(callback: types.CallbackQuery):
    parts = callback.data.split("_")
    tokens = int(parts[2])
    stars = int(parts[3])
    user_id = callback.from_user.id
    lang = db.get_user_language(user_id) or "ar"

    if payment_bot:
        try:
            invoice_link = await payment_bot.create_invoice_link(
                title=f"🪙 {tokens} PLAYX1 ZONE Tokens",
                description=f"Instant top-up of {tokens} tokens for PLAYX1 ZONE Play Points quests.",
                payload=f"stars_pack_{user_id}_{tokens}_{stars}",
                currency="XTR",
                prices=[LabeledPrice(label=f"{tokens} Tokens", amount=stars)],
                provider_token="",
            )
            builder = InlineKeyboardBuilder()
            if lang == "en":
                btn_pay = f"⭐ Pay {stars} Stars (+{tokens} 🪙)"
                btn_back = "↩️ Back to Store"
                text = (
                    f"⭐ <b>Checkout — {tokens} Tokens Pack</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                    f"🪙 <b>Credit:</b> +{tokens} Tokens\n"
                    f"⭐ <b>Total:</b> {stars} Telegram Stars\n\n"
                    "<i>Tap below to complete payment securely via Telegram Stars:</i>"
                )
            elif lang == "fr":
                btn_pay = f"⭐ Payer {stars} Stars (+{tokens} 🪙)"
                btn_back = "↩️ Retour Boutique"
                text = (
                    f"⭐ <b>Paiement — Pack {tokens} Tokens</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                    f"🪙 <b>Crédit :</b> +{tokens} Tokens\n"
                    f"⭐ <b>Prix :</b> {stars} Telegram Stars\n\n"
                    "<i>Cliquez ci-dessous pour régler instantanément :</i>"
                )
            else:
                btn_pay = f"⭐ دفع {stars} نجمة (+{tokens} 🪙)"
                btn_back = "↩️ العودة للمتجر"
                text = (
                    f"⭐ <b>فاتورة الشحن — باقة {tokens} توكن</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                    f"🪙 <b>الرصيد المضاف:</b> +{tokens} توكن\n"
                    f"⭐ <b>التكلفة:</b> {stars} نجمة تليجرام\n\n"
                    "<i>اضغط زر الدفع أدناه لإتمام الشحن الفوري:</i>"
                )
            builder.button(text=btn_pay, url=invoice_link)
            builder.button(text=btn_back, callback_data="stars_shop", style="danger")
            builder.adjust(1)
            await safe_show(callback, text, reply_markup=builder.as_markup(), prefer_edit=True)
            await callback.answer()
            return
        except Exception as e:
            logger.exception("Payment bot invoice link failed, using direct invoice: %s", e)

    await callback.bot.send_invoice(
        chat_id=callback.from_user.id,
        title=f"🪙 {tokens} PLAYX1 ZONE Tokens",
        description=f"Instant top-up of {tokens} tokens for PLAYX1 ZONE Play Points quests.",
        payload=f"stars_pack_{user_id}_{tokens}_{stars}",
        currency="XTR",
        prices=[LabeledPrice(label=f"{tokens} Tokens", amount=stars)],
        provider_token="",
    )
    await callback.answer()


@dp.pre_checkout_query()
async def process_pre_checkout(pre_checkout_query: PreCheckoutQuery):
    await pre_checkout_query.answer(ok=True)


@dp.message(F.successful_payment)
async def process_successful_payment(message: types.Message):
    payment = message.successful_payment
    payload = payment.invoice_payload or ""
    parts = payload.split("_")

    if len(parts) >= 5:
        user_id = int(parts[2])
        tokens = int(parts[3])
        stars = int(parts[4])
    elif len(parts) >= 4:
        user_id = message.from_user.id
        tokens = int(parts[2])
        stars = int(parts[3])
    else:
        user_id = message.from_user.id
        tokens = 2
        stars = 3

    charge_id = payment.telegram_payment_charge_id
    db.record_star_purchase(user_id, tokens, stars, charge_id)
    new_bal = db.get_user_balance(user_id)
    lang = db.get_user_language(user_id) or "ar"

    if lang == "en":
        text = (
            "🎊 <b>Top-Up Completed!</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            f"⭐ <b>Stars Paid:</b> {stars} ⭐\n"
            f"🪙 <b>Tokens Credited:</b> +{tokens} 🪙\n"
            f"💳 <b>Updated Wallet:</b> <code>{new_bal}</code> Tokens\n\n"
            "Thank you for choosing <b>PLAYX1 ZONE</b>!"
        )
    elif lang == "fr":
        text = (
            "🎊 <b>Recharge Validée !</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            f"⭐ <b>Stars Payées :</b> {stars} ⭐\n"
            f"🪙 <b>Tokens Ajoutés :</b> +{tokens} 🪙\n"
            f"💳 <b>Nouveau Solde :</b> <code>{new_bal}</code> Tokens\n\n"
            "Merci de votre confiance envers <b>PLAYX1 ZONE</b> !"
        )
    else:
        text = (
            "🎊 <b>تم الشحن بنجاح!</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            f"⭐ <b>النجوم المدفوعة:</b> {stars} ⭐\n"
            f"🪙 <b>التوكنات المضافة:</b> +{tokens} 🪙\n"
            f"💳 <b>محفظتك الآن:</b> <code>{new_bal}</code> توكن\n\n"
            "شكراً لثقتك بمنصة <b>PLAYX1 ZONE</b>!"
        )

    try:
        await bot.send_message(chat_id=user_id, text=text, reply_markup=get_main_menu(user_id, lang), parse_mode="HTML")
    except Exception as e:
        logger.warning("Could not send confirmation from main bot: %s", e)
        await message.answer(text, reply_markup=get_main_menu(user_id, lang), parse_mode="HTML")


@dp.callback_query(F.data == "nav_rewards", StateFilter("*"))
async def cb_nav_rewards(callback: types.CallbackQuery, state: FSMContext):
    await state.clear()
    user_id = callback.from_user.id
    ref_info = db.get_referral_info(user_id)
    bot_user = await bot.get_me()
    ref_link = f"https://t.me/{bot_user.username}?start=ref_{user_id}"
    lang = db.get_user_language(user_id) or "ar"
    t = STRINGS.get(lang, STRINGS["ar"])

    mandatory_channels = db.get_mandatory_channels()
    total_ch = len(mandatory_channels)
    total_ch_tokens = total_ch * 2
    claimed_chs = db.get_user_claimed_channels(user_id)
    is_claimed = (len(claimed_chs) >= total_ch and total_ch > 0) or db.is_channel_bonus_claimed(user_id)

    if lang == "en":
        ch_status = f"✅ Collected (+{total_ch_tokens} 🪙)" if is_claimed else "🎁 Ready (+2 🪙 / channel)"
        text = (
            "🎉 <b>PLAYX1 ZONE — Bonus Center</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            "<b>1. Invite & Earn (+3 🪙 / friend):</b>\n"
            f"👥 Invited: <code>{ref_info['total_invited']}</code> | ✅ Active: <code>{ref_info['completed_invited']}</code>\n"
            f"💰 Earned: <code>{ref_info['tokens_earned']}</code> Tokens\n"
            f"🔗 <code>{ref_link}</code>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "<b>2. Channel Loyalty Bonus:</b>\n"
            f"• Earn <b>+2 Tokens</b> for every official channel subscribed.\n"
            f"• Status: <b>{ch_status}</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "<b>3. Gift Codes:</b>\n"
            "• Activate exclusive codes posted on @PLAYX1_ZONE!"
        )
        btn_share = "📤 Share Invite Link"
        btn_claim = "🎁 Collect Channel Bonus"
        btn_promo = "🎫 Activate Gift Code"
        partner_hdr = "\n━━━━━━━━━━━━━━━━━━━━\n🌟 <b>Featured Partner Channels:</b>"
        share_msg = "Join PLAYX1 ZONE Bot for free Google Play Points tokens!"
    elif lang == "fr":
        ch_status = f"✅ Récupéré (+{total_ch_tokens} 🪙)" if is_claimed else "🎁 Disponible (+2 🪙 / chaîne)"
        text = (
            "🎉 <b>PLAYX1 ZONE — Espace Cadeaux</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            "<b>1. Parrainage (+3 🪙 / ami) :</b>\n"
            f"👥 Invités : <code>{ref_info['total_invited']}</code> | ✅ Validés : <code>{ref_info['completed_invited']}</code>\n"
            f"💰 Gagnés : <code>{ref_info['tokens_earned']}</code> Tokens\n"
            f"🔗 <code>{ref_link}</code>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "<b>2. Bonus Abonnement Chaînes :</b>\n"
            f"• Recevez <b>+2 Tokens</b> par chaîne officielle rejointe.\n"
            f"• Statut : <b>{ch_status}</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "<b>3. Codes Cadeaux :</b>\n"
            "• Utilisez les codes exclusifs publiés sur @PLAYX1_ZONE !"
        )
        btn_share = "📤 Partager mon Lien"
        btn_claim = "🎁 Réclamer Bonus Chaînes"
        btn_promo = "🎫 Activer un Code Cadeau"
        partner_hdr = "\n━━━━━━━━━━━━━━━━━━━━\n🌟 <b>Chaînes Partenaires :</b>"
        share_msg = "Rejoignez le bot PLAYX1 ZONE pour gagner des tokens Google Play Points!"
    else:
        ch_status = f"✅ تم الاستلام (+{total_ch_tokens} 🪙)" if is_claimed else "🎁 متاح الآن (+2 🪙 لكل قناة)"
        text = (
            "🎉 <b>مركز الهدايا — PLAYX1 ZONE</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            "<b>1. برنامج الإحالة (+3 🪙 لكل صديق):</b>\n"
            f"👥 المدعوون: <code>{ref_info['total_invited']}</code> | ✅ المؤكدون: <code>{ref_info['completed_invited']}</code>\n"
            f"💰 أرباحك: <code>{ref_info['tokens_earned']}</code> توكن\n"
            f"🔗 <code>{ref_link}</code>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "<b>2. مكافأة الانضمام للقنوات:</b>\n"
            f"• احصل على <b>+2 توكن</b> عن كل قناة رسمية تشترك بها.\n"
            f"• الحالة: <b>{ch_status}</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "<b>3. أكواد الهدايا الحصرية:</b>\n"
            "• فعّل الأكواد التي نوزعها باستمرار في قناة @PLAYX1_ZONE!"
        )
        btn_share = "📤 مشاركة رابط الإحالة"
        btn_claim = "🎁 استلام مكافأة القنوات"
        btn_promo = "🎫 تفعيل كود هدية"
        partner_hdr = "\n━━━━━━━━━━━━━━━━━━━━\n🌟 <b>قنوات شريكة ومميزة:</b>"
        share_msg = "انضم لبوت PLAYX1 ZONE لإنجاز مهام Google Play Points مجاناً!"

    builder = InlineKeyboardBuilder()
    builder.button(
        text=btn_share,
        url=f"https://t.me/share/url?url={ref_link}&text={share_msg.replace(' ', '%20')}",
        style="primary",
    )
    if not is_claimed and total_ch > 0:
        builder.button(text=btn_claim, callback_data="claim_channel_bonus", style="success")
    builder.button(text=btn_promo, callback_data="user_enter_promo", style="primary")

    promo_channels = db.get_promo_channels()
    if promo_channels:
        text += partner_hdr
        styles = ["primary", "success"]
        for i, pch in enumerate(promo_channels):
            raw_title = pch.get("title") or pch.get("channel_username") or ""
            clean_title = raw_title.strip().lstrip("@").strip() or pch.get("channel_username", "").lstrip("@").strip()
            builder.button(text=f"🌟 {clean_title}", url=pch["invite_link"], style=styles[i % len(styles)])

    builder.button(text=t["home"], callback_data="nav_home", style="danger")
    builder.adjust(1)
    await safe_show(callback, text, reply_markup=builder.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.callback_query(F.data == "claim_channel_bonus")
async def cb_claim_channel_bonus(callback: types.CallbackQuery):
    user_id = callback.from_user.id
    lang = db.get_user_language(user_id) or "ar"
    is_sub, _ = await check_all_channels_subscription(bot, user_id)
    if not is_sub:
        err = "🔒 Join all required channels first!" if lang == "en" else ("🔒 Rejoignez d'abord toutes les chaînes !" if lang == "fr" else "🔒 يجب الاشتراك في جميع القنوات المطلوبة أولاً!")
        await callback.answer(err, show_alert=True)
        return

    mandatory = db.get_mandatory_channels()
    ch_names = [ch["channel_username"] for ch in mandatory]
    awarded, _ = db.claim_channel_bonus_per_channel(user_id, ch_names, reward_per_channel=2)

    if awarded > 0:
        new_bal = db.get_user_balance(user_id)
        if lang == "en":
            succ = f"🎉 +{awarded} Tokens added to your wallet!"
            msg = f"✅ Credited <b>+{awarded} Tokens</b>! Updated wallet: <code>{new_bal}</code> 🪙"
        elif lang == "fr":
            succ = f"🎉 +{awarded} Tokens ajoutés à votre solde !"
            msg = f"✅ <b>+{awarded} Tokens</b> crédités ! Nouveau solde : <code>{new_bal}</code> 🪙"
        else:
            succ = f"🎉 تمت إضافة +{awarded} توكن إلى محفظتك!"
            msg = f"✅ تم شحن <b>+{awarded} توكن</b> بنجاح! رصيدك الآن: <code>{new_bal}</code> 🪙"
        await callback.answer(succ, show_alert=True)
        await callback.message.answer(msg, reply_markup=get_main_menu(user_id, lang), parse_mode="HTML")
    else:
        already = "ℹ️ Channel bonus already collected!" if lang == "en" else ("ℹ️ Bonus déjà récupéré !" if lang == "fr" else "ℹ️ لقد استلمت مكافأة القنوات مسبقاً!")
        await callback.answer(already, show_alert=True)


@dp.callback_query(F.data == "user_enter_promo")
async def cb_user_enter_promo(callback: types.CallbackQuery, state: FSMContext):
    user_id = callback.from_user.id
    lang = db.get_user_language(user_id) or "ar"
    t = STRINGS.get(lang, STRINGS["ar"])
    await state.set_state(UserForm.waiting_for_promo_code)

    text = {
        "en": "🎫 <b>Activate Gift Code</b>\n━━━━━━━━━━━━━━━━━━━━\nSend your gift code below to claim free tokens:",
        "fr": "🎫 <b>Activer un Code Cadeau</b>\n━━━━━━━━━━━━━━━━━━━━\nEnvoyez votre code ci-dessous pour recevoir vos tokens :",
        "ar": "🎫 <b>تفعيل كود هدية</b>\n━━━━━━━━━━━━━━━━━━━━\nأرسل الكود الترويجي الآن لاستلام التوكنات فوراً:",
    }.get(lang)
    builder = InlineKeyboardBuilder()
    builder.button(text=t["cancel"], callback_data="pay_cancel", style="danger")
    await safe_show(callback, text, reply_markup=builder.as_markup(), prefer_edit=True)
    await callback.answer()


async def _handle_promo_redemption(message: types.Message, code_text: str):
    user_id = message.from_user.id
    lang = db.get_user_language(user_id) or "ar"
    success, status, reward = db.redeem_promo_code(user_id, code_text)
    if success:
        new_bal = db.get_user_balance(user_id)
        ok_msg = {
            "en": f"🎊 <b>Gift Code Activated!</b>\n━━━━━━━━━━━━━━━━━━━━\n🎫 <b>Code:</b> <code>{code_text}</code>\n🪙 <b>Reward:</b> +{reward} Tokens\n💳 <b>Wallet:</b> <code>{new_bal}</code> 🪙",
            "fr": f"🎊 <b>Code Cadeau Activé !</b>\n━━━━━━━━━━━━━━━━━━━━\n🎫 <b>Code :</b> <code>{code_text}</code>\n🪙 <b>Gain :</b> +{reward} Tokens\n💳 <b>Solde :</b> <code>{new_bal}</code> 🪙",
            "ar": f"🎊 <b>تم تفعيل كود الهدية بنجاح!</b>\n━━━━━━━━━━━━━━━━━━━━\n🎫 <b>الكود:</b> <code>{code_text}</code>\n🪙 <b>المكافأة:</b> +{reward} توكن\n💳 <b>محفظتك الآن:</b> <code>{new_bal}</code> 🪙",
        }.get(lang)
        await message.answer(ok_msg, reply_markup=get_main_menu(user_id, lang), parse_mode="HTML")
        return

    err_map = {
        "NOT_FOUND": {
            "en": "❌ <b>Invalid gift code!</b>",
            "fr": "❌ <b>Code cadeau introuvable !</b>",
            "ar": "❌ <b>الكود غير صحيح أو غير موجود!</b>",
        },
        "EXPIRED": {
            "en": "⌛ <b>This gift code has reached its redemption limit.</b>",
            "fr": "⌛ <b>Ce code cadeau a atteint sa limite d'utilisation.</b>",
            "ar": "⌛ <b>انتهت صلاحية هذا الكود أو اكتمل الحد الأقصى للمستفيدين.</b>",
        },
        "ALREADY_USED": {
            "en": "⚠️ <b>You already redeemed this gift code!</b>",
            "fr": "⚠️ <b>Vous avez déjà utilisé ce code cadeau !</b>",
            "ar": "⚠️ <b>لقد استخدمت هذا الكود مسبقاً!</b>",
        },
    }
    err_txt = err_map.get(status, {}).get(lang, "❌ <b>Error redeeming code.</b>")
    await message.answer(err_txt, reply_markup=get_main_menu(user_id, lang), parse_mode="HTML")


@dp.message(UserForm.waiting_for_promo_code)
async def process_user_promo_code(message: types.Message, state: FSMContext):
    await state.clear()
    await _handle_promo_redemption(message, (message.text or "").strip().upper())


@dp.message(Command("promo"), StateFilter("*"))
@dp.message(Command("redeem"), StateFilter("*"))
async def cmd_promo(message: types.Message, state: FSMContext, command: Optional[CommandObject] = None):
    lang = db.get_user_language(message.from_user.id) or "ar"
    if command and command.args:
        await state.clear()
        await _handle_promo_redemption(message, command.args.strip().upper())
    else:
        await state.set_state(UserForm.waiting_for_promo_code)
        builder = InlineKeyboardBuilder()
        builder.button(text=STRINGS[lang]["cancel"], callback_data="pay_cancel", style="danger")
        prompt = {
            "en": "🎫 <b>Activate Gift Code</b>\nSend your code now (or use <code>/promo CODE</code>):",
            "fr": "🎫 <b>Activer un Code Cadeau</b>\nEnvoyez votre code (ou utilisez <code>/promo CODE</code>) :",
            "ar": "🎫 <b>تفعيل كود هدية</b>\nأرسل الكود الآن (أو استخدم <code>/promo CODE</code>):",
        }.get(lang)
        await message.answer(prompt, reply_markup=builder.as_markup(), parse_mode="HTML")


@dp.callback_query(F.data == "nav_top", StateFilter("*"))
async def cb_nav_top(callback: types.CallbackQuery, state: FSMContext):
    await state.clear()
    user_id = callback.from_user.id
    lang = db.get_user_language(user_id) or "ar"
    t = STRINGS.get(lang, STRINGS["ar"])
    top_buyers = db.get_top_buyers(10)

    medals = ["🥇", "🥈", "🥉", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣", "🔟"]
    prizes = ["50 🪙", "30 🪙", "20 🪙"] + ["10 🪙"] * 7
    empty_lbl = {"en": "Open slot", "fr": "Place libre", "ar": "مقعد متاح"}.get(lang)

    board_lines = []
    for idx in range(10):
        if idx < len(top_buyers):
            u = top_buyers[idx]
            uname = f"@{u['username']}" if u.get("username") else f"ID {str(u['user_id'])[:4]}***"
            board_lines.append(f"{medals[idx]} <b>{uname}</b> • {u['tokens_purchased']} 🪙 ({u['stars_spent']} ⭐) [{prizes[idx]}]")
        else:
            board_lines.append(f"{medals[idx]} <i>{empty_lbl}</i> [{prizes[idx]}]")

    if lang == "en":
        text = (
            "🥇 <b>PLAYX1 ZONE — Top Supporters</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            + "\n".join(board_lines)
            + "\n━━━━━━━━━━━━━━━━━━━━\n"
            "🎁 <b>Weekly Supporter Rewards:</b>\n"
            "• 🥇 #1: 50 Tokens | 🥈 #2: 30 Tokens | 🥉 #3: 20 Tokens\n"
            "• #4 to #10: 10 Tokens each"
        )
        btn_shop = "⭐ Top-Up & Climb the Ranks"
    elif lang == "fr":
        text = (
            "🥇 <b>PLAYX1 ZONE — Top Membres</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            + "\n".join(board_lines)
            + "\n━━━━━━━━━━━━━━━━━━━━\n"
            "🎁 <b>Récompenses Hebdomadaires :</b>\n"
            "• 🥇 1er : 50 Tokens | 🥈 2e : 30 Tokens | 🥉 3e : 20 Tokens\n"
            "• 4e au 10e : 10 Tokens chacun"
        )
        btn_shop = "⭐ Recharger & Monter au Classement"
    else:
        text = (
            "🥇 <b>نخبة الداعمين — PLAYX1 ZONE</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            + "\n".join(board_lines)
            + "\n━━━━━━━━━━━━━━━━━━━━\n"
            "🎁 <b>جوائز الصدارة الأسبوعية:</b>\n"
            "• 🥇 الأول: 50 توكن | 🥈 الثاني: 30 توكن | 🥉 الثالث: 20 توكن\n"
            "• المراكز 4 إلى 10: 10 توكن لكل متصدر"
        )
        btn_shop = "⭐ اشحن وتصدّر القائمة الآن"

    builder = InlineKeyboardBuilder()
    builder.button(text=btn_shop, callback_data="stars_shop", style="success")
    builder.button(text=t["home"], callback_data="nav_home", style="primary")
    builder.adjust(1)
    await safe_show(callback, text, reply_markup=builder.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.callback_query(F.data == "nav_lang", StateFilter("*"))
async def cb_nav_lang(callback: types.CallbackQuery, state: FSMContext):
    await state.clear()
    lang = db.get_user_language(callback.from_user.id) or "ar"
    text = (
        "🌐 <b>Language Settings / إعدادات اللغة / Langue</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "Choose your preferred interface language:"
    )
    builder = InlineKeyboardBuilder()
    builder.button(text="🇩🇿 العربية", callback_data="set_lang_ar", style="success" if lang == "ar" else "primary")
    builder.button(text="🇬🇧 English", callback_data="set_lang_en", style="success" if lang == "en" else "primary")
    builder.button(text="🇫🇷 Français", callback_data="set_lang_fr", style="success" if lang == "fr" else "primary")
    builder.button(text=STRINGS[lang]["home"], callback_data="nav_home", style="danger")
    builder.adjust(1)
    await safe_show(callback, text, reply_markup=builder.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.callback_query(F.data.startswith("set_lang_"))
async def process_set_language(callback: types.CallbackQuery):
    lang = callback.data.split("set_lang_")[1]
    if lang not in STRINGS:
        lang = "ar"
    user_id = callback.from_user.id
    db.set_user_language(user_id, lang)

    msg_map = {
        "ar": "✅ تم تفعيل اللغة العربية بنجاح!",
        "en": "✅ Interface language switched to English!",
        "fr": "✅ Langue de l'interface définie sur Français !",
    }
    await callback.answer(msg_map[lang], show_alert=False)
    await safe_show(
        callback,
        _welcome_text_for(user_id, lang),
        reply_markup=get_main_menu(user_id, lang),
        prefer_edit=True,
    )


@dp.callback_query(F.data == "nav_guide", StateFilter("*"))
async def cb_nav_guide(callback: types.CallbackQuery, state: FSMContext):
    await state.clear()
    lang = db.get_user_language(callback.from_user.id) or "ar"
    t = STRINGS.get(lang, STRINGS["ar"])
    if lang == "en":
        text = (
            "📘 <b>PLAYX1 ZONE — Quick Guide</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            "<b>⚡ Steps to Complete a Quest:</b>\n"
            "1. Open Google Play Store → Play Points → Earn.\n"
            "2. Confirm the chest quest is visible on your account.\n"
            "3. Tap <b>🚀 Quest Vault</b> and select the game.\n"
            "4. Send your credentials (or pick a saved account) & launch.\n"
            "5. Open Play Store and collect your 50 Play Points!\n\n"
            "<b>🔐 Supported Auth Modes:</b>\n"
            "• Direct Login • Phone Prompt • Google App Password • Saved Master Token\n\n"
            f"📡 <b>Official Channel:</b> {CHANNEL_URL}"
        )
    elif lang == "fr":
        text = (
            "📘 <b>PLAYX1 ZONE — Guide Rapide</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            "<b>⚡ Étapes de Validation :</b>\n"
            "1. Ouvrez Google Play Store → Play Points → Gagner.\n"
            "2. Vérifiez que la quête du coffre est affichée.\n"
            "3. Appuyez sur <b>🚀 Coffres & Quêtes</b> et choisissez le jeu.\n"
            "4. Entrez vos identifiants (ou choisissez un compte sauvegardé).\n"
            "5. Ouvrez le Play Store pour récupérer vos 50 Play Points !\n\n"
            "<b>🔐 Méthodes Supportées :</b>\n"
            "• Connexion Directe • Validation Téléphone • App Password • Session Sauvegardée\n\n"
            f"📡 <b>Chaîne Officielle :</b> {CHANNEL_URL}"
        )
    else:
        text = (
            "📘 <b>دليل الاستخدام السريع — PLAYX1 ZONE</b>\n━━━━━━━━━━━━━━━━━━━━\n"
            "<b>⚡ خطوات إنهاء أي صندوق:</b>\n"
            "1. افتح متجر Google Play ← نقاط Play ← كسب (Earn).\n"
            "2. تأكد من ظهور مهمة الصندوق على حسابك.\n"
            "3. اضغط <b>🚀 فتح الصناديق</b> واختر اللعبة المطلوبة.\n"
            "4. أرسل بيانات الحساب (أو اختر حساباً محفوظاً) واضغط تأكيد.\n"
            "5. افتح المتجر لاستلام 50 نقطة مباشرة في حسابك!\n\n"
            "<b>🔐 طرق المصادقة المدعومة:</b>\n"
            "• الدخول المباشر • تأكيد الهاتف • كلمة مرور التطبيقات (App Password) • الجلسة المحفوظة\n\n"
            f"📡 <b>قناتنا الرسمية:</b> {CHANNEL_URL}"
        )
    builder = InlineKeyboardBuilder()
    builder.button(text=t["channel"], url=CHANNEL_URL, style="success")
    builder.button(text=t["home"], callback_data="nav_home", style="primary")
    builder.adjust(1)
    await safe_show(callback, text, reply_markup=builder.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.message(Command("admin"), StateFilter("*"))
async def admin_panel(message: types.Message, state: FSMContext):
    if message.from_user.id not in ADMIN_IDS:
        return
    await state.clear()
    alang = get_admin_lang()
    await message.answer(get_admin_panel_text(alang), reply_markup=get_admin_menu_keyboard(alang), parse_mode="HTML")


@dp.callback_query(F.data == "admin_menu", StateFilter("*"))
async def cb_admin_menu(callback: types.CallbackQuery, state: FSMContext):
    if callback.from_user.id not in ADMIN_IDS:
        return
    await state.clear()
    alang = get_admin_lang()
    await safe_show(callback, get_admin_panel_text(alang), reply_markup=get_admin_menu_keyboard(alang), prefer_edit=True)
    await callback.answer()


@dp.callback_query(F.data == "admin_close", StateFilter("*"))
async def cb_admin_close(callback: types.CallbackQuery, state: FSMContext):
    if callback.from_user.id not in ADMIN_IDS:
        return
    await state.clear()
    a = ADMIN_STRINGS[get_admin_lang()]
    try:
        await callback.message.delete()
    except Exception:
        pass
    await callback.answer(a["closed"])


@dp.callback_query(F.data == "admin_lang_menu")
async def cb_admin_lang_menu(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    alang = get_admin_lang()
    a = ADMIN_STRINGS[alang]
    builder = InlineKeyboardBuilder()
    builder.button(text="🇩🇿 العربية", callback_data="set_admin_lang_ar", style="success" if alang == "ar" else "primary")
    builder.button(text="🇬🇧 English", callback_data="set_admin_lang_en", style="success" if alang == "en" else "primary")
    builder.button(text="🇫🇷 Français", callback_data="set_admin_lang_fr", style="success" if alang == "fr" else "primary")
    builder.button(text=a["btn_back_admin"], callback_data="admin_menu", style="danger")
    builder.adjust(1)
    await safe_show(callback, a["lang_title"], reply_markup=builder.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.callback_query(F.data.startswith("set_admin_lang_"))
async def cb_set_admin_lang(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    new_lang = callback.data.split("set_admin_lang_")[1]
    if new_lang not in ADMIN_STRINGS:
        new_lang = "ar"
    db.set_setting("admin_lang", new_lang)
    await callback.answer(ADMIN_STRINGS[new_lang]["lang_updated"], show_alert=False)
    await safe_show(callback, get_admin_panel_text(new_lang), reply_markup=get_admin_menu_keyboard(new_lang), prefer_edit=True)


@dp.callback_query(F.data == "admin_stats")
async def cb_admin_stats(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    stats = db.get_admin_stats()
    text = a["stats_body"].format(**stats)
    builder = InlineKeyboardBuilder()
    builder.button(text=a["btn_back_admin"], callback_data="admin_menu", style="primary")
    await safe_show(callback, text, reply_markup=builder.as_markup(), prefer_edit=True)
    await callback.answer()


def _render_user_card(user: Dict[str, Any], alang: str) -> Tuple[str, InlineKeyboardMarkup]:
    a = ADMIN_STRINGS[alang]
    uid = user["user_id"]
    uname = f"@{user['username']}" if user.get("username") else "—"
    banned = bool(user.get("is_banned"))
    ref_info = db.get_referral_info(uid)
    text = a["user_card"].format(
        uid=uid,
        uname=uname,
        bal=user.get("balance", 0),
        ulang=user.get("language", "ar"),
        status=a["status_banned"] if banned else a["status_active"],
        qcount=db.get_user_quests_count(uid),
        acount=db.count_saved_accounts(uid),
        rcount=ref_info["completed_invited"],
        stars=user.get("stars_spent", 0),
        created=user.get("created_at", "N/A"),
    )
    builder = InlineKeyboardBuilder()
    builder.button(text=a["u_btn_add"], callback_data=f"admin_u_add_{uid}", style="success")
    builder.button(text=a["u_btn_sub"], callback_data=f"admin_u_sub_{uid}", style="danger")
    if banned:
        builder.button(text=a["u_btn_unban"], callback_data=f"admin_u_unban_{uid}", style="success")
    else:
        builder.button(text=a["u_btn_ban"], callback_data=f"admin_u_ban_{uid}", style="danger")
    builder.button(text=a["u_btn_dm"], callback_data=f"admin_u_dm_{uid}", style="primary")
    builder.button(text=a["btn_back_admin"], callback_data="admin_menu", style="primary")
    builder.adjust(2, 2, 1)
    return text, builder.as_markup()


@dp.callback_query(F.data == "admin_lookup")
async def cb_admin_lookup(callback: types.CallbackQuery, state: FSMContext):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    await state.set_state(AdminForm.waiting_for_lookup)
    builder = InlineKeyboardBuilder()
    builder.button(text=a["btn_cancel"], callback_data="admin_menu", style="danger")
    await safe_show(callback, a["lookup_prompt"], reply_markup=builder.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.message(AdminForm.waiting_for_lookup)
async def process_admin_lookup(message: types.Message, state: FSMContext):
    if message.from_user.id not in ADMIN_IDS:
        return
    alang = get_admin_lang()
    a = ADMIN_STRINGS[alang]
    user = db.get_user_by_query((message.text or "").strip())
    await state.clear()
    if not user:
        kb = InlineKeyboardBuilder()
        kb.button(text=a["btn_back_admin"], callback_data="admin_menu", style="primary")
        await message.answer(a["user_not_found"], reply_markup=kb.as_markup(), parse_mode="HTML")
        return
    card_txt, card_kb = _render_user_card(user, alang)
    await message.answer(card_txt, reply_markup=card_kb, parse_mode="HTML")


@dp.callback_query(F.data.startswith("admin_u_add_"))
async def cb_admin_u_add(callback: types.CallbackQuery, state: FSMContext):
    if callback.from_user.id not in ADMIN_IDS:
        return
    uid = int(callback.data.split("admin_u_add_")[1])
    a = ADMIN_STRINGS[get_admin_lang()]
    await state.update_data(target_uid=uid)
    await state.set_state(AdminForm.waiting_for_add_tokens_target)
    kb = InlineKeyboardBuilder()
    kb.button(text=a["btn_cancel"], callback_data="admin_menu", style="danger")
    await safe_show(callback, a["add_one_prompt"].format(uid=uid), reply_markup=kb.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.message(AdminForm.waiting_for_add_tokens_target)
async def process_admin_u_add(message: types.Message, state: FSMContext):
    if message.from_user.id not in ADMIN_IDS:
        return
    alang = get_admin_lang()
    a = ADMIN_STRINGS[alang]
    raw = (message.text or "").strip()
    if not raw.isdigit():
        await message.answer(a["bad_format"], parse_mode="HTML")
        return
    amount = int(raw)
    data = await state.get_data()
    uid = data.get("target_uid")
    await state.clear()
    new_bal = db.update_balance(uid, amount)
    try:
        u_lang = db.get_user_language(uid) or "ar"
        ntf = {
            "en": f"🎁 <b>+{amount} Tokens credited by PLAYX1 ZONE Admin!</b>\n💳 New Wallet: <code>{new_bal}</code> 🪙",
            "fr": f"🎁 <b>+{amount} Tokens ajoutés par l'Admin PLAYX1 ZONE !</b>\n💳 Solde : <code>{new_bal}</code> 🪙",
            "ar": f"🎁 <b>تم شحن +{amount} توكن لحسابك من إدارة PLAYX1 ZONE!</b>\n💳 رصيدك الجديد: <code>{new_bal}</code> 🪙",
        }.get(u_lang)
        await bot.send_message(uid, ntf, parse_mode="HTML")
    except Exception:
        pass
    kb = InlineKeyboardBuilder()
    kb.button(text=a["btn_back_admin"], callback_data="admin_menu", style="primary")
    await message.answer(a["added_ok"].format(amount=amount, target=uid, bal=new_bal), reply_markup=kb.as_markup(), parse_mode="HTML")


@dp.callback_query(F.data.startswith("admin_u_sub_"))
async def cb_admin_u_sub(callback: types.CallbackQuery, state: FSMContext):
    if callback.from_user.id not in ADMIN_IDS:
        return
    uid = int(callback.data.split("admin_u_sub_")[1])
    a = ADMIN_STRINGS[get_admin_lang()]
    await state.update_data(target_uid=uid)
    await state.set_state(AdminForm.waiting_for_sub_tokens_target)
    kb = InlineKeyboardBuilder()
    kb.button(text=a["btn_cancel"], callback_data="admin_menu", style="danger")
    await safe_show(callback, a["sub_one_prompt"].format(uid=uid), reply_markup=kb.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.message(AdminForm.waiting_for_sub_tokens_target)
async def process_admin_u_sub(message: types.Message, state: FSMContext):
    if message.from_user.id not in ADMIN_IDS:
        return
    alang = get_admin_lang()
    a = ADMIN_STRINGS[alang]
    raw = (message.text or "").strip()
    if not raw.isdigit():
        await message.answer(a["bad_format"], parse_mode="HTML")
        return
    amount = int(raw)
    data = await state.get_data()
    uid = data.get("target_uid")
    await state.clear()
    new_bal = db.update_balance(uid, -amount)
    kb = InlineKeyboardBuilder()
    kb.button(text=a["btn_back_admin"], callback_data="admin_menu", style="primary")
    await message.answer(a["sub_ok"].format(amount=amount, target=uid, bal=new_bal), reply_markup=kb.as_markup(), parse_mode="HTML")


@dp.callback_query(F.data.startswith("admin_u_ban_"))
async def cb_admin_u_ban(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    uid = int(callback.data.split("admin_u_ban_")[1])
    alang = get_admin_lang()
    a = ADMIN_STRINGS[alang]
    if uid in ADMIN_IDS:
        await callback.answer(a["cannot_ban_admin"], show_alert=True)
        return
    db.set_user_banned(uid, True)
    await callback.answer(a["banned_ok"].format(uid=uid).replace("<code>", "").replace("</code>", ""), show_alert=True)
    user = db.get_user_by_query(str(uid))
    if user:
        card_txt, card_kb = _render_user_card(user, alang)
        await safe_show(callback, card_txt, reply_markup=card_kb, prefer_edit=True)


@dp.callback_query(F.data.startswith("admin_u_unban_"))
async def cb_admin_u_unban(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    uid = int(callback.data.split("admin_u_unban_")[1])
    alang = get_admin_lang()
    a = ADMIN_STRINGS[alang]
    db.set_user_banned(uid, False)
    await callback.answer(a["unbanned_ok"].format(uid=uid).replace("<code>", "").replace("</code>", ""), show_alert=True)
    user = db.get_user_by_query(str(uid))
    if user:
        card_txt, card_kb = _render_user_card(user, alang)
        await safe_show(callback, card_txt, reply_markup=card_kb, prefer_edit=True)


@dp.callback_query(F.data.startswith("admin_u_dm_"))
async def cb_admin_u_dm(callback: types.CallbackQuery, state: FSMContext):
    if callback.from_user.id not in ADMIN_IDS:
        return
    uid = int(callback.data.split("admin_u_dm_")[1])
    a = ADMIN_STRINGS[get_admin_lang()]
    await state.update_data(dm_uid=uid)
    await state.set_state(AdminForm.waiting_for_dm_message)
    kb = InlineKeyboardBuilder()
    kb.button(text=a["btn_cancel"], callback_data="admin_menu", style="danger")
    await safe_show(callback, a["dm_prompt_msg"].format(uid=uid), reply_markup=kb.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.callback_query(F.data == "admin_add_tokens")
async def cb_admin_add_tokens(callback: types.CallbackQuery, state: FSMContext):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    await state.set_state(AdminForm.waiting_for_add_tokens)
    kb = InlineKeyboardBuilder()
    kb.button(text=a["btn_cancel"], callback_data="admin_menu", style="danger")
    await safe_show(callback, a["add_prompt"], reply_markup=kb.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.message(AdminForm.waiting_for_add_tokens)
async def process_admin_add_tokens(message: types.Message, state: FSMContext):
    if message.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    parts = (message.text or "").strip().split()
    if len(parts) < 2 or not parts[1].lstrip("-").isdigit():
        await message.answer(a["bad_format"], parse_mode="HTML")
        return
    target, amount = parts[0], int(parts[1])
    user = db.get_user_by_query(target)
    await state.clear()
    kb = InlineKeyboardBuilder()
    kb.button(text=a["btn_back_admin"], callback_data="admin_menu", style="primary")
    if not user:
        await message.answer(a["user_not_found"], reply_markup=kb.as_markup(), parse_mode="HTML")
        return
    new_bal = db.update_balance(user["user_id"], amount)
    try:
        u_lang = db.get_user_language(user["user_id"]) or "ar"
        ntf = {
            "en": f"🎁 <b>+{amount} Tokens credited to your wallet!</b>\n💳 New Balance: <code>{new_bal}</code> 🪙",
            "fr": f"🎁 <b>+{amount} Tokens crédités sur votre solde !</b>\n💳 Nouveau Solde : <code>{new_bal}</code> 🪙",
            "ar": f"🎁 <b>تمت إضافة +{amount} توكن إلى محفظتك!</b>\n💳 الرصيد الجديد: <code>{new_bal}</code> 🪙",
        }.get(u_lang)
        await bot.send_message(user["user_id"], ntf, parse_mode="HTML")
    except Exception:
        pass
    uname = f"@{user['username']}" if user.get("username") else str(user["user_id"])
    await message.answer(a["added_ok"].format(amount=amount, target=uname, bal=new_bal), reply_markup=kb.as_markup(), parse_mode="HTML")


@dp.callback_query(F.data == "admin_sub_tokens")
async def cb_admin_sub_tokens(callback: types.CallbackQuery, state: FSMContext):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    await state.set_state(AdminForm.waiting_for_sub_tokens)
    kb = InlineKeyboardBuilder()
    kb.button(text=a["btn_cancel"], callback_data="admin_menu", style="danger")
    await safe_show(callback, a["sub_prompt"], reply_markup=kb.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.message(AdminForm.waiting_for_sub_tokens)
async def process_admin_sub_tokens(message: types.Message, state: FSMContext):
    if message.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    parts = (message.text or "").strip().split()
    if len(parts) < 2 or not parts[1].isdigit():
        await message.answer(a["bad_format"], parse_mode="HTML")
        return
    target, amount = parts[0], int(parts[1])
    user = db.get_user_by_query(target)
    await state.clear()
    kb = InlineKeyboardBuilder()
    kb.button(text=a["btn_back_admin"], callback_data="admin_menu", style="primary")
    if not user:
        await message.answer(a["user_not_found"], reply_markup=kb.as_markup(), parse_mode="HTML")
        return
    new_bal = db.update_balance(user["user_id"], -amount)
    uname = f"@{user['username']}" if user.get("username") else str(user["user_id"])
    await message.answer(a["sub_ok"].format(amount=amount, target=uname, bal=new_bal), reply_markup=kb.as_markup(), parse_mode="HTML")


@dp.callback_query(F.data == "admin_gift_all")
async def cb_admin_gift_all(callback: types.CallbackQuery, state: FSMContext):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    await state.set_state(AdminForm.waiting_for_gift_all)
    kb = InlineKeyboardBuilder()
    kb.button(text=a["btn_cancel"], callback_data="admin_menu", style="danger")
    await safe_show(callback, a["gift_prompt"], reply_markup=kb.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.message(AdminForm.waiting_for_gift_all)
async def process_admin_gift_all(message: types.Message, state: FSMContext):
    if message.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    raw = (message.text or "").strip()
    if not raw.isdigit() or int(raw) <= 0:
        await message.answer(a["bad_format"], parse_mode="HTML")
        return
    amount = int(raw)
    await state.clear()
    credited = db.gift_tokens_to_all(amount)
    active_ids = db.get_active_user_ids()
    sent, failed = 0, 0
    for uid in active_ids:
        u_lang = db.get_user_language(uid) or "ar"
        gift_txt = {
            "en": f"🎉 <b>PLAYX1 ZONE Gift!</b>\nEveryone just received <b>+{amount} Free Tokens</b> in their wallet! 🪙",
            "fr": f"🎉 <b>Cadeau PLAYX1 ZONE !</b>\nVous venez de recevoir <b>+{amount} Tokens Gratuits</b> dans votre solde ! 🪙",
            "ar": f"🎉 <b>هدية جماعية من PLAYX1 ZONE!</b>\nتم توزيع <b>+{amount} توكن مجاني</b> على محفظتك الآن! 🪙",
        }.get(u_lang)
        try:
            await bot.send_message(uid, gift_txt, parse_mode="HTML")
            sent += 1
            await asyncio.sleep(0.04)
        except Exception:
            failed += 1
    kb = InlineKeyboardBuilder()
    kb.button(text=a["btn_back_admin"], callback_data="admin_menu", style="primary")
    await message.answer(
        a["gift_done"].format(amount=amount, count=credited, sent=sent, failed=failed),
        reply_markup=kb.as_markup(),
        parse_mode="HTML",
    )


@dp.callback_query(F.data == "admin_bans")
async def cb_admin_bans(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    banned = db.get_banned_users()
    text = a["bans_title"]
    builder = InlineKeyboardBuilder()
    if banned:
        for u in banned:
            uname = f"@{u['username']}" if u.get("username") else str(u["user_id"])
            text += f"• <code>{u['user_id']}</code> ({uname})\n"
            builder.button(text=f"✅ Unban {u['user_id']}", callback_data=f"admin_fast_unban_{u['user_id']}", style="success")
    else:
        text += a["bans_empty"]
    builder.button(text=a["btn_ban_new"], callback_data="admin_ban_new", style="danger")
    builder.button(text=a["btn_back_admin"], callback_data="admin_menu", style="primary")
    builder.adjust(1)
    await safe_show(callback, text, reply_markup=builder.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.callback_query(F.data.startswith("admin_fast_unban_"))
async def cb_admin_fast_unban(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    uid = int(callback.data.split("admin_fast_unban_")[1])
    a = ADMIN_STRINGS[get_admin_lang()]
    db.set_user_banned(uid, False)
    await callback.answer(a["unbanned_ok"].format(uid=uid).replace("<code>", "").replace("</code>", ""), show_alert=True)
    await cb_admin_bans(callback)


@dp.callback_query(F.data == "admin_ban_new")
async def cb_admin_ban_new(callback: types.CallbackQuery, state: FSMContext):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    await state.set_state(AdminForm.waiting_for_ban_user)
    kb = InlineKeyboardBuilder()
    kb.button(text=a["btn_cancel"], callback_data="admin_bans", style="danger")
    await safe_show(callback, a["ban_prompt"], reply_markup=kb.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.message(AdminForm.waiting_for_ban_user)
async def process_admin_ban_user(message: types.Message, state: FSMContext):
    if message.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    user = db.get_user_by_query((message.text or "").strip())
    await state.clear()
    kb = InlineKeyboardBuilder()
    kb.button(text=a["btn_bans"], callback_data="admin_bans", style="primary")
    if not user:
        await message.answer(a["user_not_found"], reply_markup=kb.as_markup(), parse_mode="HTML")
        return
    if user["user_id"] in ADMIN_IDS:
        await message.answer(a["cannot_ban_admin"], reply_markup=kb.as_markup(), parse_mode="HTML")
        return
    db.set_user_banned(user["user_id"], True)
    await message.answer(a["banned_ok"].format(uid=user["user_id"]), reply_markup=kb.as_markup(), parse_mode="HTML")


@dp.callback_query(F.data == "admin_mandatory_channels")
async def cb_admin_mandatory_channels(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    channels = db.get_mandatory_channels()
    fsub_on = db.get_setting_bool("force_sub_enabled", True)
    text = a["mand_title"]
    builder = InlineKeyboardBuilder()
    if channels:
        for ch in channels:
            ch_name = ch["channel_username"]
            title = ch.get("title") or ch_name
            text += f"• <b>{title}:</b> <code>{ch_name}</code>\n"
            builder.button(text=f"🗑️ {ch_name}", callback_data=f"del_mand_{ch_name}", style="danger")
    else:
        text += a["mand_empty"]
    builder.button(text=a["btn_add_mand"], callback_data="admin_add_mandatory", style="success")
    builder.button(text=a["btn_toggle_fsub"].format(state=a["on"] if fsub_on else a["off"]), callback_data="admin_toggle_fsub_ch", style="primary")
    builder.button(text=a["btn_back_admin"], callback_data="admin_menu", style="primary")
    builder.adjust(1)
    await safe_show(callback, text, reply_markup=builder.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.callback_query(F.data == "admin_toggle_fsub_ch")
async def cb_admin_toggle_fsub_ch(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    cur = db.get_setting_bool("force_sub_enabled", True)
    db.set_setting("force_sub_enabled", "0" if cur else "1")
    _SUB_CACHE.clear()
    await cb_admin_mandatory_channels(callback)


@dp.callback_query(F.data.startswith("del_mand_"))
async def cb_del_mand(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    ch_name = callback.data.split("del_mand_")[1]
    db.remove_sponsored_channel(ch_name)
    _SUB_CACHE.clear()
    await callback.answer(a["ch_deleted"].format(ch=ch_name), show_alert=True)
    await cb_admin_mandatory_channels(callback)


@dp.callback_query(F.data == "admin_add_mandatory")
async def cb_admin_add_mandatory(callback: types.CallbackQuery, state: FSMContext):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    me = await bot.get_me()
    await state.set_state(AdminForm.waiting_for_add_mandatory)
    builder = InlineKeyboardBuilder()
    builder.button(text=a["btn_cancel"], callback_data="admin_mandatory_channels", style="danger")
    await safe_show(callback, a["add_mand_prompt"].format(bot_uname=me.username), reply_markup=builder.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.message(AdminForm.waiting_for_add_mandatory)
async def process_admin_add_mandatory(message: types.Message, state: FSMContext):
    if message.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    channel_list = parse_channels_input(message.text or "")
    if not channel_list:
        await message.answer(a["bad_format"], parse_mode="HTML")
        return

    added = []
    for ch_name in channel_list:
        clean_fallback = ch_name.lstrip("@").strip()
        title = clean_fallback
        invite_link = f"https://t.me/{clean_fallback}"
        try:
            chat = await bot.get_chat(ch_name)
            title = (chat.title or clean_fallback).strip().lstrip("@").strip()
        except Exception:
            pass
        db.add_sponsored_channel(ch_name, title, invite_link, channel_type="mandatory")
        added.append(f"• <b>{title}:</b> {ch_name}")

    _SUB_CACHE.clear()
    await state.clear()
    builder = InlineKeyboardBuilder()
    builder.button(text=a["btn_mand"], callback_data="admin_mandatory_channels", style="primary")
    await message.answer(a["mand_added"].format(n=len(added)) + "\n".join(added), reply_markup=builder.as_markup(), parse_mode="HTML")


@dp.callback_query(F.data == "admin_promo_channels")
async def cb_admin_promo_channels(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    channels = db.get_promo_channels()
    text = a["promo_ch_title"]
    builder = InlineKeyboardBuilder()
    if channels:
        for ch in channels:
            ch_name = ch["channel_username"]
            title = ch.get("title") or ch_name
            text += f"• <b>{title}:</b> <code>{ch_name}</code>\n"
            builder.button(text=f"🗑️ {ch_name}", callback_data=f"del_promo_ch_{ch_name}", style="danger")
    else:
        text += a["promo_ch_empty"]
    builder.button(text=a["btn_add_promo_ch"], callback_data="admin_add_promo_ch", style="success")
    builder.button(text=a["btn_back_admin"], callback_data="admin_menu", style="primary")
    builder.adjust(1)
    await safe_show(callback, text, reply_markup=builder.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.callback_query(F.data.startswith("del_promo_ch_"))
async def cb_del_promo_ch(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    ch_name = callback.data.split("del_promo_ch_")[1]
    db.remove_sponsored_channel(ch_name)
    await callback.answer(a["ch_deleted"].format(ch=ch_name), show_alert=True)
    await cb_admin_promo_channels(callback)


@dp.callback_query(F.data == "admin_add_promo_ch")
async def cb_admin_add_promo_ch(callback: types.CallbackQuery, state: FSMContext):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    await state.set_state(AdminForm.waiting_for_add_promo_ch)
    builder = InlineKeyboardBuilder()
    builder.button(text=a["btn_cancel"], callback_data="admin_promo_channels", style="danger")
    await safe_show(callback, a["add_promo_ch_prompt"], reply_markup=builder.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.message(AdminForm.waiting_for_add_promo_ch)
async def process_admin_add_promo_ch(message: types.Message, state: FSMContext):
    if message.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    channel_list = parse_channels_input(message.text or "")
    if not channel_list:
        await message.answer(a["bad_format"], parse_mode="HTML")
        return

    added = []
    for ch_name in channel_list:
        clean_fallback = ch_name.lstrip("@").strip()
        title = clean_fallback
        invite_link = f"https://t.me/{clean_fallback}"
        try:
            chat = await bot.get_chat(ch_name)
            title = (chat.title or clean_fallback).strip().lstrip("@").strip()
        except Exception:
            pass
        db.add_sponsored_channel(ch_name, title, invite_link, channel_type="promo")
        added.append(f"• <b>{title}:</b> {ch_name}")

    await state.clear()
    builder = InlineKeyboardBuilder()
    builder.button(text=a["btn_promo_ch"], callback_data="admin_promo_channels", style="primary")
    await message.answer(a["promo_ch_added"].format(n=len(added)) + "\n".join(added), reply_markup=builder.as_markup(), parse_mode="HTML")


@dp.callback_query(F.data == "admin_promos")
async def cb_admin_promos(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    promos = db.get_all_promo_codes()
    text = a["promos_title"]
    builder = InlineKeyboardBuilder()
    if promos:
        for p in promos:
            text += f"• <code>{p['code']}</code> ➜ <b>+{p['reward_tokens']} 🪙</b> ({p['current_uses']}/{p['max_uses']})\n"
            builder.button(text=f"📣 {p['code']}", callback_data=f"bcast_promo_{p['code']}", style="primary")
            builder.button(text=f"🗑️ {p['code']}", callback_data=f"del_promo_{p['code']}", style="danger")
    else:
        text += a["promos_empty"]
    builder.button(text=a["btn_new_promo"], callback_data="admin_add_promo", style="success")
    builder.button(text=a["btn_back_admin"], callback_data="admin_menu", style="primary")
    builder.adjust(2)
    await safe_show(callback, text, reply_markup=builder.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.callback_query(F.data == "admin_add_promo")
async def cb_admin_add_promo(callback: types.CallbackQuery, state: FSMContext):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    await state.set_state(AdminForm.waiting_for_add_promo)
    builder = InlineKeyboardBuilder()
    builder.button(text=a["btn_cancel"], callback_data="admin_promos", style="danger")
    await safe_show(callback, a["new_promo_prompt"], reply_markup=builder.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.message(AdminForm.waiting_for_add_promo)
async def process_admin_add_promo(message: types.Message, state: FSMContext):
    if message.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    parts = (message.text or "").strip().split()
    if len(parts) < 3 or not parts[1].isdigit() or not parts[2].isdigit():
        await message.answer(a["bad_format"], parse_mode="HTML")
        return
    code, tokens, max_uses = parts[0].upper(), int(parts[1]), int(parts[2])
    db.create_promo_code(code, tokens, max_uses)
    await state.clear()

    builder = InlineKeyboardBuilder()
    builder.button(text=a["promo_bcast_btn"], callback_data=f"bcast_promo_{code}", style="success")
    builder.button(text=a["btn_promos"], callback_data="admin_promos", style="primary")
    builder.adjust(1)
    await message.answer(
        a["promo_created"].format(code=code, tokens=tokens, max_uses=max_uses),
        reply_markup=builder.as_markup(),
        parse_mode="HTML",
    )


@dp.callback_query(F.data.startswith("del_promo_"))
async def cb_del_promo(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    code = callback.data.split("del_promo_")[1]
    db.delete_promo_code(code)
    await callback.answer(a["promo_deleted"].format(code=code), show_alert=True)
    await cb_admin_promos(callback)


@dp.callback_query(F.data.startswith("bcast_promo_"))
async def cb_bcast_promo(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    code = callback.data.split("bcast_promo_")[1]
    promos = db.get_all_promo_codes()
    promo = next((p for p in promos if p["code"] == code), None)
    if not promo:
        await callback.answer("Code not found!", show_alert=True)
        return

    tokens = promo["reward_tokens"]
    max_uses = promo["max_uses"]
    await callback.answer("⏳...", show_alert=False)

    user_ids = db.get_active_user_ids()
    ok, fail = 0, 0
    for uid in user_ids:
        u_lang = db.get_user_language(uid) or "ar"
        if u_lang == "en":
            bcast_text = (
                "🎁 <b>New PLAYX1 ZONE Gift Code!</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                f"🎫 <b>Code:</b> <code>{code}</code>\n"
                f"🪙 <b>Reward:</b> +{tokens} Free Tokens\n"
                f"👥 <b>Limit:</b> First {max_uses} members\n\n"
                f"Tap below or send <code>/promo {code}</code>"
            )
            btn_redeem = "🎫 Activate Now"
        elif u_lang == "fr":
            bcast_text = (
                "🎁 <b>Nouveau Code Cadeau PLAYX1 ZONE !</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                f"🎫 <b>Code :</b> <code>{code}</code>\n"
                f"🪙 <b>Gain :</b> +{tokens} Tokens Gratuits\n"
                f"👥 <b>Limite :</b> {max_uses} premiers membres\n\n"
                f"Cliquez ci-dessous ou envoyez <code>/promo {code}</code>"
            )
            btn_redeem = "🎫 Activer Maintenant"
        else:
            bcast_text = (
                "🎁 <b>كود هدية جديد من PLAYX1 ZONE!</b>\n━━━━━━━━━━━━━━━━━━━━\n"
                f"🎫 <b>الكود:</b> <code>{code}</code>\n"
                f"🪙 <b>المكافأة:</b> +{tokens} توكن مجاني\n"
                f"👥 <b>الحد الأقصى:</b> لأول {max_uses} مستخدم\n\n"
                f"فعّله الآن بالزر أدناه أو عبر <code>/promo {code}</code>"
            )
            btn_redeem = "🎫 تفعيل الكود الآن"

        builder = InlineKeyboardBuilder()
        builder.button(text=btn_redeem, callback_data="user_enter_promo", style="success")
        try:
            await bot.send_message(uid, bcast_text, reply_markup=builder.as_markup(), parse_mode="HTML")
            ok += 1
            await asyncio.sleep(0.04)
        except Exception:
            fail += 1

    kb = InlineKeyboardBuilder()
    kb.button(text=a["btn_back_admin"], callback_data="admin_menu", style="primary")
    await callback.message.answer(a["bcast_done"].format(ok=ok, fail=fail), reply_markup=kb.as_markup(), parse_mode="HTML")


@dp.callback_query(F.data == "admin_broadcast")
async def cb_admin_broadcast(callback: types.CallbackQuery, state: FSMContext):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    await state.set_state(AdminForm.waiting_for_broadcast)
    kb = InlineKeyboardBuilder()
    kb.button(text=a["btn_cancel"], callback_data="admin_menu", style="danger")
    await safe_show(callback, a["bcast_prompt"], reply_markup=kb.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.message(AdminForm.waiting_for_broadcast)
async def process_admin_broadcast(message: types.Message, state: FSMContext):
    if message.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    await state.clear()
    user_ids = db.get_all_user_ids()
    status_msg = await message.answer(a["bcast_running"].format(n=len(user_ids)), parse_mode="HTML")
    ok, fail = 0, 0
    for uid in user_ids:
        try:
            await bot.copy_message(chat_id=uid, from_chat_id=message.chat.id, message_id=message.message_id)
            ok += 1
            await asyncio.sleep(0.04)
        except Exception:
            fail += 1
    kb = InlineKeyboardBuilder()
    kb.button(text=a["btn_back_admin"], callback_data="admin_menu", style="primary")
    await status_msg.edit_text(a["bcast_done"].format(ok=ok, fail=fail), reply_markup=kb.as_markup(), parse_mode="HTML")


@dp.callback_query(F.data == "admin_dm_user")
async def cb_admin_dm_user(callback: types.CallbackQuery, state: FSMContext):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    await state.set_state(AdminForm.waiting_for_dm_user)
    kb = InlineKeyboardBuilder()
    kb.button(text=a["btn_cancel"], callback_data="admin_menu", style="danger")
    await safe_show(callback, a["dm_prompt_user"], reply_markup=kb.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.message(AdminForm.waiting_for_dm_user)
async def process_admin_dm_user(message: types.Message, state: FSMContext):
    if message.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    user = db.get_user_by_query((message.text or "").strip())
    if not user:
        await state.clear()
        kb = InlineKeyboardBuilder()
        kb.button(text=a["btn_back_admin"], callback_data="admin_menu", style="primary")
        await message.answer(a["user_not_found"], reply_markup=kb.as_markup(), parse_mode="HTML")
        return
    await state.update_data(dm_uid=user["user_id"])
    await state.set_state(AdminForm.waiting_for_dm_message)
    kb = InlineKeyboardBuilder()
    kb.button(text=a["btn_cancel"], callback_data="admin_menu", style="danger")
    await message.answer(a["dm_prompt_msg"].format(uid=user["user_id"]), reply_markup=kb.as_markup(), parse_mode="HTML")


@dp.message(AdminForm.waiting_for_dm_message)
async def process_admin_dm_message(message: types.Message, state: FSMContext):
    if message.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    data = await state.get_data()
    uid = data.get("dm_uid")
    await state.clear()
    kb = InlineKeyboardBuilder()
    kb.button(text=a["btn_back_admin"], callback_data="admin_menu", style="primary")
    try:
        await bot.copy_message(chat_id=uid, from_chat_id=message.chat.id, message_id=message.message_id)
        await message.answer(a["dm_sent"].format(uid=uid), reply_markup=kb.as_markup(), parse_mode="HTML")
    except Exception:
        await message.answer(a["dm_fail"], reply_markup=kb.as_markup(), parse_mode="HTML")


@dp.callback_query(F.data == "admin_settings")
async def cb_admin_settings(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    maint = db.get_setting_bool("maintenance_mode", False)
    fsub = db.get_setting_bool("force_sub_enabled", True)
    cost = get_chest_cost()
    wbonus = get_welcome_bonus()
    text = a["settings_title"].format(
        maint=a["maint_on"] if maint else a["maint_off"],
        fsub=a["on"] if fsub else a["off"],
        cost=cost,
        wbonus=wbonus,
    )
    builder = InlineKeyboardBuilder()
    builder.button(text=a["btn_maint"].format(state=a["on"] if maint else a["off"]), callback_data="admin_toggle_maint", style="danger" if maint else "success")
    builder.button(text=a["btn_fsub"].format(state=a["on"] if fsub else a["off"]), callback_data="admin_toggle_fsub", style="success" if fsub else "danger")
    builder.button(text=a["btn_edit_cost"], callback_data="admin_edit_cost", style="primary")
    builder.button(text=a["btn_edit_welcome"], callback_data="admin_edit_welcome", style="primary")
    builder.button(text=a["btn_back_admin"], callback_data="admin_menu", style="primary")
    builder.adjust(1, 1, 2, 1)
    await safe_show(callback, text, reply_markup=builder.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.callback_query(F.data == "admin_toggle_maint")
async def cb_admin_toggle_maint(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    cur = db.get_setting_bool("maintenance_mode", False)
    db.set_setting("maintenance_mode", "0" if cur else "1")
    await cb_admin_settings(callback)


@dp.callback_query(F.data == "admin_toggle_fsub")
async def cb_admin_toggle_fsub(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    cur = db.get_setting_bool("force_sub_enabled", True)
    db.set_setting("force_sub_enabled", "0" if cur else "1")
    _SUB_CACHE.clear()
    await cb_admin_settings(callback)


@dp.callback_query(F.data == "admin_edit_cost")
async def cb_admin_edit_cost(callback: types.CallbackQuery, state: FSMContext):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    await state.set_state(AdminForm.waiting_for_edit_cost)
    kb = InlineKeyboardBuilder()
    kb.button(text=a["btn_cancel"], callback_data="admin_settings", style="danger")
    await safe_show(callback, a["cost_prompt"], reply_markup=kb.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.message(AdminForm.waiting_for_edit_cost)
async def process_admin_edit_cost(message: types.Message, state: FSMContext):
    if message.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    raw = (message.text or "").strip()
    if not raw.isdigit():
        await message.answer(a["bad_format"], parse_mode="HTML")
        return
    db.set_setting("chest_cost", raw)
    await state.clear()
    kb = InlineKeyboardBuilder()
    kb.button(text=a["btn_settings"], callback_data="admin_settings", style="primary")
    await message.answer(a["setting_saved"], reply_markup=kb.as_markup(), parse_mode="HTML")


@dp.callback_query(F.data == "admin_edit_welcome")
async def cb_admin_edit_welcome(callback: types.CallbackQuery, state: FSMContext):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    await state.set_state(AdminForm.waiting_for_edit_welcome)
    kb = InlineKeyboardBuilder()
    kb.button(text=a["btn_cancel"], callback_data="admin_settings", style="danger")
    await safe_show(callback, a["welcome_prompt"], reply_markup=kb.as_markup(), prefer_edit=True)
    await callback.answer()


@dp.message(AdminForm.waiting_for_edit_welcome)
async def process_admin_edit_welcome(message: types.Message, state: FSMContext):
    if message.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    raw = (message.text or "").strip()
    if not raw.isdigit():
        await message.answer(a["bad_format"], parse_mode="HTML")
        return
    db.set_setting("welcome_bonus", raw)
    await state.clear()
    kb = InlineKeyboardBuilder()
    kb.button(text=a["btn_settings"], callback_data="admin_settings", style="primary")
    await message.answer(a["setting_saved"], reply_markup=kb.as_markup(), parse_mode="HTML")


@dp.callback_query(F.data == "admin_backup")
async def cb_admin_backup(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    if not os.path.exists(db.DB_PATH):
        await callback.answer(a["backup_err"], show_alert=True)
        return
    ts = datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC")
    await callback.message.answer_document(
        document=FSInputFile(str(db.DB_PATH)),
        caption=a["backup_caption"].format(ts=ts),
        parse_mode="HTML",
    )
    await callback.answer("✅", show_alert=False)


@dp.message(Command("id"), StateFilter("*"))
@dp.message(Command("myid"), StateFilter("*"))
async def cmd_myid(message: types.Message):
    uid = message.from_user.id
    uname = f"@{message.from_user.username}" if message.from_user.username else "—"
    await message.answer(f"🆔 <b>ID:</b> <code>{uid}</code>\n🔖 <b>Username:</b> {uname}", parse_mode="HTML")


@dp.message(Command("add"), StateFilter("*"))
async def cmd_quick_add(message: types.Message):
    if message.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    parts = (message.text or "").strip().split()
    if len(parts) < 3 or not parts[2].lstrip("-").isdigit():
        await message.answer("<code>/add @username 20</code>", parse_mode="HTML")
        return
    target, amount = parts[1], int(parts[2])
    user = db.get_user_by_query(target)
    if not user:
        await message.answer(a["user_not_found"], parse_mode="HTML")
        return
    new_bal = db.update_balance(user["user_id"], amount)
    try:
        u_lang = db.get_user_language(user["user_id"]) or "ar"
        ntf = {
            "en": f"🎁 <b>+{amount} Tokens credited!</b>\n💳 Wallet: <code>{new_bal}</code> 🪙",
            "fr": f"🎁 <b>+{amount} Tokens crédités !</b>\n💳 Solde : <code>{new_bal}</code> 🪙",
            "ar": f"🎁 <b>تم شحن +{amount} توكن في محفظتك!</b>\n💳 الرصيد: <code>{new_bal}</code> 🪙",
        }.get(u_lang)
        await bot.send_message(user["user_id"], ntf, parse_mode="HTML")
    except Exception:
        pass
    await message.answer(a["added_ok"].format(amount=amount, target=target, bal=new_bal), parse_mode="HTML")


@dp.message(Command("stats"), StateFilter("*"))
async def cmd_quick_stats(message: types.Message):
    if message.from_user.id not in ADMIN_IDS:
        return
    a = ADMIN_STRINGS[get_admin_lang()]
    stats = db.get_admin_stats()
    await message.answer(a["stats_body"].format(**stats), parse_mode="HTML")


async def main():
    db.init_db()
    logger.info("Database initialized.")
    try:
        await bot.set_my_short_description(short_description="⚡ PLAYX1 ZONE — Play Points Automation")
        await bot.set_my_description(
            description=(
                "⚡ منصة PLAYX1 ZONE لإنجاز مهام وجوائز Google Play Points تلقائياً وبسرعة فائقة.\n"
                "📡 قناتنا الرسمية: https://t.me/PLAYX1_ZONE"
            )
        )
    except Exception as e:
        logger.warning("Error setting bot descriptions: %s", e)
    logger.info("Starting PLAYX1 ZONE bot polling...")
    if payment_bot:
        logger.info("Multi-bot polling active (main bot + payment bot).")
        try:
            await dp.start_polling(bot, payment_bot)
        finally:
            await bot.session.close()
            await payment_bot.session.close()
    else:
        try:
            await dp.start_polling(bot)
        finally:
            await bot.session.close()


if __name__ == "__main__":
    asyncio.run(main())
