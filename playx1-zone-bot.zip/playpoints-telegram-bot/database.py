import sqlite3
from typing import Optional, List, Dict, Any, Tuple
from pathlib import Path

DB_PATH = Path(__file__).parent / "pointbot.db"

DEFAULT_CHANNEL_USERNAME = "@PLAYX1_ZONE"
DEFAULT_CHANNEL_TITLE = "PLAYX1 ZONE"
DEFAULT_CHANNEL_LINK = "https://t.me/PLAYX1_ZONE"


def get_db_connection() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH, timeout=15.0)
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA busy_timeout = 5000")
    conn.execute("PRAGMA synchronous = NORMAL")
    return conn


def init_db():
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            username TEXT,
            balance INTEGER DEFAULT 8,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    cursor.execute("PRAGMA table_info(users)")
    cols = [r[1] for r in cursor.fetchall()]
    if "language" not in cols:
        cursor.execute("ALTER TABLE users ADD COLUMN language TEXT DEFAULT 'ar'")
    if "referrer_id" not in cols:
        cursor.execute("ALTER TABLE users ADD COLUMN referrer_id INTEGER")
    if "channel_bonus_claimed" not in cols:
        cursor.execute("ALTER TABLE users ADD COLUMN channel_bonus_claimed INTEGER DEFAULT 0")
    if "tokens_purchased" not in cols:
        cursor.execute("ALTER TABLE users ADD COLUMN tokens_purchased INTEGER DEFAULT 0")
    if "stars_spent" not in cols:
        cursor.execute("ALTER TABLE users ADD COLUMN stars_spent INTEGER DEFAULT 0")
    if "is_banned" not in cols:
        cursor.execute("ALTER TABLE users ADD COLUMN is_banned INTEGER DEFAULT 0")

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS bot_settings (
            key TEXT PRIMARY KEY,
            value TEXT
        )
    """)

    default_settings = [
        ("force_sub_enabled", "1"),
        ("maintenance_mode", "0"),
        ("chest_cost", "2"),
        ("welcome_bonus", "8"),
        ("admin_lang", "ar"),
    ]
    for k, v in default_settings:
        cursor.execute("INSERT OR IGNORE INTO bot_settings (key, value) VALUES (?, ?)", (k, v))

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS user_channel_claims (
            user_id INTEGER,
            channel_username TEXT,
            claimed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY(user_id, channel_username)
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS saved_accounts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            email TEXT,
            password TEXT,
            last_used TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (user_id),
            UNIQUE(user_id, email)
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS quest_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            email TEXT,
            game_key TEXT,
            status TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS master_tokens (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            email TEXT,
            master_token TEXT,
            android_id TEXT,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (user_id),
            UNIQUE(user_id, email)
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS sponsored_channels (
            channel_username TEXT PRIMARY KEY,
            title TEXT,
            invite_link TEXT,
            channel_type TEXT DEFAULT 'mandatory',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    cursor.execute("PRAGMA table_info(sponsored_channels)")
    ch_cols = [r[1] for r in cursor.fetchall()]
    if "channel_type" not in ch_cols:
        cursor.execute("ALTER TABLE sponsored_channels ADD COLUMN channel_type TEXT DEFAULT 'mandatory'")

    cursor.execute("SELECT value FROM bot_settings WHERE key = 'channels_seeded'")
    seeded = cursor.fetchone()
    if not seeded:
        cursor.execute("""
            INSERT OR IGNORE INTO sponsored_channels (channel_username, title, invite_link, channel_type)
            VALUES (?, ?, ?, 'mandatory')
        """, (DEFAULT_CHANNEL_USERNAME, DEFAULT_CHANNEL_TITLE, DEFAULT_CHANNEL_LINK))
        cursor.execute("INSERT OR REPLACE INTO bot_settings (key, value) VALUES ('channels_seeded', '1')")

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS referrals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            inviter_id INTEGER,
            invited_id INTEGER UNIQUE,
            rewarded INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS star_purchases (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            tokens INTEGER,
            stars INTEGER,
            charge_id TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS promo_codes (
            code TEXT PRIMARY KEY,
            reward_tokens INTEGER,
            max_uses INTEGER DEFAULT 1,
            current_uses INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS promo_code_redemptions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            code TEXT,
            user_id INTEGER,
            redeemed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(code, user_id)
        )
    """)

    conn.commit()
    conn.close()


def get_setting(key: str, default: str = "") -> str:
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT value FROM bot_settings WHERE key = ?", (key,))
        row = cursor.fetchone()
        return row[0] if row and row[0] is not None else default
    except Exception:
        return default
    finally:
        conn.close()


def set_setting(key: str, value: str):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT OR REPLACE INTO bot_settings (key, value) VALUES (?, ?)",
        (key, str(value))
    )
    conn.commit()
    conn.close()


def get_setting_int(key: str, default: int = 0) -> int:
    raw = get_setting(key, str(default))
    try:
        return int(raw)
    except (ValueError, TypeError):
        return default


def get_setting_bool(key: str, default: bool = False) -> bool:
    raw = get_setting(key, "1" if default else "0").strip().lower()
    return raw in ("1", "true", "yes", "on")


def get_or_create_user(user_id: int, username: Optional[str] = None) -> Dict[str, Any]:
    conn = get_db_connection()
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
    row = cursor.fetchone()

    if not row:
        try:
            cursor.execute("SELECT value FROM bot_settings WHERE key = 'welcome_bonus'")
            wb_row = cursor.fetchone()
            start_balance = int(wb_row[0]) if wb_row and str(wb_row[0]).isdigit() else 8
        except Exception:
            start_balance = 8
        cursor.execute(
            "INSERT INTO users (user_id, username, balance, language) VALUES (?, ?, ?, 'ar')",
            (user_id, username, start_balance)
        )
        conn.commit()
        cursor.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
        row = cursor.fetchone()
    elif username and row["username"] != username:
        cursor.execute("UPDATE users SET username = ? WHERE user_id = ?", (username, user_id))
        conn.commit()
        cursor.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
        row = cursor.fetchone()

    user_data = dict(row)
    conn.close()
    return user_data


def get_user_balance(user_id: int) -> int:
    user = get_or_create_user(user_id)
    return user.get("balance", 0)


def update_balance(user_id: int, delta: int) -> int:
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("BEGIN IMMEDIATE")
        cursor.execute("UPDATE users SET balance = MAX(0, balance + ?) WHERE user_id = ?", (delta, user_id))
        cursor.execute("SELECT balance FROM users WHERE user_id = ?", (user_id,))
        row = cursor.fetchone()
        new_bal = row[0] if row else 0
        conn.commit()
        return new_bal
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def is_user_banned(user_id: int) -> bool:
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT is_banned FROM users WHERE user_id = ?", (user_id,))
        row = cursor.fetchone()
        return bool(row and row[0])
    except Exception:
        return False
    finally:
        conn.close()


def set_user_banned(user_id: int, banned: bool) -> bool:
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE users SET is_banned = ? WHERE user_id = ?", (1 if banned else 0, user_id))
    updated = cursor.rowcount > 0
    conn.commit()
    conn.close()
    return updated


def get_banned_users() -> List[Dict[str, Any]]:
    conn = get_db_connection()
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("SELECT user_id, username, balance FROM users WHERE is_banned = 1 ORDER BY user_id DESC LIMIT 30")
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]


def gift_tokens_to_all(amount: int) -> int:
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("BEGIN IMMEDIATE")
        cursor.execute("UPDATE users SET balance = balance + ? WHERE COALESCE(is_banned, 0) = 0", (amount,))
        count = cursor.rowcount
        conn.commit()
        return count
    except Exception:
        conn.rollback()
        return 0
    finally:
        conn.close()


def get_user_language(user_id: int) -> str:
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT language FROM users WHERE user_id = ?", (user_id,))
    row = cursor.fetchone()
    conn.close()
    if row and row[0]:
        return row[0]
    return "ar"


def set_user_language(user_id: int, lang: str):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE users SET language = ? WHERE user_id = ?", (lang, user_id))
    conn.commit()
    conn.close()


def get_mandatory_channels() -> List[Dict[str, str]]:
    conn = get_db_connection()
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute(
        "SELECT channel_username, title, invite_link FROM sponsored_channels WHERE channel_type = 'mandatory' ORDER BY created_at ASC"
    )
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_promo_channels() -> List[Dict[str, str]]:
    conn = get_db_connection()
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute(
        "SELECT channel_username, title, invite_link FROM sponsored_channels WHERE channel_type = 'promo' ORDER BY created_at ASC"
    )
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_sponsored_channels() -> List[Dict[str, str]]:
    return get_mandatory_channels()


def add_sponsored_channel(channel_username: str, title: str = "", invite_link: str = "", channel_type: str = "mandatory") -> bool:
    channel_username = channel_username.strip()
    if not channel_username.startswith("@"):
        channel_username = f"@{channel_username}"
    if not invite_link:
        invite_link = f"https://t.me/{channel_username.lstrip('@')}"
    if not title:
        title = channel_username
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("""
            INSERT INTO sponsored_channels (channel_username, title, invite_link, channel_type)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(channel_username) DO UPDATE SET
                title=excluded.title,
                invite_link=excluded.invite_link,
                channel_type=excluded.channel_type
        """, (channel_username, title, invite_link, channel_type))
        conn.commit()
        return True
    except Exception:
        return False
    finally:
        conn.close()


def remove_sponsored_channel(channel_username: str) -> bool:
    channel_username = channel_username.strip()
    if not channel_username.startswith("@"):
        channel_username = f"@{channel_username}"
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM sponsored_channels WHERE channel_username = ?", (channel_username,))
    deleted = cursor.rowcount > 0
    conn.commit()
    conn.close()
    return deleted


def record_referral(inviter_id: int, invited_id: int) -> bool:
    if inviter_id == invited_id:
        return False
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("BEGIN IMMEDIATE")
        cursor.execute("INSERT OR IGNORE INTO referrals (inviter_id, invited_id) VALUES (?, ?)", (inviter_id, invited_id))
        inserted = cursor.rowcount > 0
        cursor.execute("UPDATE users SET referrer_id = ? WHERE user_id = ? AND referrer_id IS NULL", (inviter_id, invited_id))
        conn.commit()
        return inserted
    except Exception:
        conn.rollback()
        return False
    finally:
        conn.close()


def reward_referral_if_pending(invited_id: int, inviter_reward: int = 3, invited_bonus: int = 0) -> Optional[int]:
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("BEGIN IMMEDIATE")
        cursor.execute("SELECT inviter_id, rewarded FROM referrals WHERE invited_id = ?", (invited_id,))
        row = cursor.fetchone()
        if not row or row[1] == 1:
            conn.commit()
            return None
        inviter_id = row[0]
        cursor.execute("UPDATE referrals SET rewarded = 1 WHERE invited_id = ?", (invited_id,))
        cursor.execute("UPDATE users SET balance = balance + ? WHERE user_id = ?", (inviter_reward, inviter_id))
        if invited_bonus > 0:
            cursor.execute("UPDATE users SET balance = balance + ? WHERE user_id = ?", (invited_bonus, invited_id))
        conn.commit()
        return inviter_id
    except Exception:
        conn.rollback()
        return None
    finally:
        conn.close()


def get_referral_info(user_id: int) -> Dict[str, Any]:
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM referrals WHERE inviter_id = ?", (user_id,))
    total_invited = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM referrals WHERE inviter_id = ? AND rewarded = 1", (user_id,))
    completed_invited = cursor.fetchone()[0]
    conn.close()
    return {
        "total_invited": total_invited,
        "completed_invited": completed_invited,
        "tokens_earned": completed_invited * 3
    }


def get_user_claimed_channels(user_id: int) -> List[str]:
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT channel_username FROM user_channel_claims WHERE user_id = ?", (user_id,))
    rows = cursor.fetchall()
    conn.close()
    return [r[0] for r in rows]


def claim_channel_bonus_per_channel(user_id: int, channel_usernames: List[str], reward_per_channel: int = 2) -> Tuple[int, int]:
    if not channel_usernames:
        return (0, 0)
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("BEGIN IMMEDIATE")
        cursor.execute("SELECT channel_username FROM user_channel_claims WHERE user_id = ?", (user_id,))
        already_claimed = {r[0].lower().lstrip("@") for r in cursor.fetchall()}

        new_channels = []
        for ch in channel_usernames:
            clean_ch = ch.lower().lstrip("@")
            if clean_ch and clean_ch not in already_claimed:
                new_channels.append(clean_ch)
                already_claimed.add(clean_ch)

        if not new_channels:
            conn.commit()
            return (0, 0)

        tokens_to_add = len(new_channels) * reward_per_channel
        for ch in new_channels:
            cursor.execute("INSERT OR IGNORE INTO user_channel_claims (user_id, channel_username) VALUES (?, ?)", (user_id, ch))

        cursor.execute("UPDATE users SET balance = balance + ?, channel_bonus_claimed = 1 WHERE user_id = ?", (tokens_to_add, user_id))
        conn.commit()
        return (tokens_to_add, len(new_channels))
    except Exception:
        conn.rollback()
        return (0, 0)
    finally:
        conn.close()


def is_channel_bonus_claimed(user_id: int) -> bool:
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT channel_bonus_claimed FROM users WHERE user_id = ?", (user_id,))
    row = cursor.fetchone()
    conn.close()
    return bool(row and row[0])


def claim_channel_bonus(user_id: int, reward: int = 2) -> bool:
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT channel_bonus_claimed FROM users WHERE user_id = ?", (user_id,))
    row = cursor.fetchone()
    if row and row[0]:
        conn.close()
        return False
    cursor.execute("UPDATE users SET channel_bonus_claimed = 1, balance = balance + ? WHERE user_id = ?", (reward, user_id))
    conn.commit()
    conn.close()
    return True


def record_star_purchase(user_id: int, tokens: int, stars: int, charge_id: str):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO star_purchases (user_id, tokens, stars, charge_id)
        VALUES (?, ?, ?, ?)
    """, (user_id, tokens, stars, charge_id))
    cursor.execute("""
        UPDATE users
        SET balance = balance + ?,
            tokens_purchased = tokens_purchased + ?,
            stars_spent = stars_spent + ?
        WHERE user_id = ?
    """, (tokens, tokens, stars, user_id))
    conn.commit()
    conn.close()


def get_top_buyers(limit: int = 10) -> List[Dict[str, Any]]:
    conn = get_db_connection()
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("""
        SELECT user_id, username, tokens_purchased, stars_spent, balance
        FROM users
        WHERE tokens_purchased > 0
        ORDER BY tokens_purchased DESC, stars_spent DESC
        LIMIT ?
    """, (limit,))
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]


def save_account(user_id: int, email: str, password: str):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO saved_accounts (user_id, email, password, last_used)
        VALUES (?, ?, ?, CURRENT_TIMESTAMP)
        ON CONFLICT(user_id, email) DO UPDATE SET password=excluded.password, last_used=CURRENT_TIMESTAMP
    """, (user_id, email, password))
    conn.commit()
    conn.close()


def get_saved_accounts(user_id: int, limit: Optional[int] = None, offset: int = 0) -> List[Dict[str, Any]]:
    conn = get_db_connection()
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    if limit is not None:
        cursor.execute(
            "SELECT id, email, password FROM saved_accounts WHERE user_id = ? ORDER BY last_used DESC LIMIT ? OFFSET ?",
            (user_id, limit, offset)
        )
    else:
        cursor.execute(
            "SELECT id, email, password FROM saved_accounts WHERE user_id = ? ORDER BY last_used DESC",
            (user_id,)
        )
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]


def count_saved_accounts(user_id: int) -> int:
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM saved_accounts WHERE user_id = ?", (user_id,))
    row = cursor.fetchone()
    cnt = row[0] if row else 0
    conn.close()
    return cnt


def get_saved_account_by_id(user_id: int, account_id: int) -> Optional[Dict[str, Any]]:
    conn = get_db_connection()
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute(
        "SELECT id, email, password FROM saved_accounts WHERE id = ? AND user_id = ?",
        (account_id, user_id)
    )
    row = cursor.fetchone()
    conn.close()
    return dict(row) if row else None


def get_saved_account_by_email(user_id: int, email: str) -> Optional[Dict[str, Any]]:
    conn = get_db_connection()
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute(
        "SELECT id, email, password FROM saved_accounts WHERE user_id = ? AND email = ?",
        (user_id, email)
    )
    row = cursor.fetchone()
    conn.close()
    return dict(row) if row else None


def log_quest(user_id: int, email: str, game_key: str, status: str):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO quest_logs (user_id, email, game_key, status) VALUES (?, ?, ?, ?)",
        (user_id, email, game_key, status)
    )
    conn.commit()
    conn.close()


def get_user_quests_count(user_id: int) -> int:
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM quest_logs WHERE user_id = ? AND status = 'COMPLETED'", (user_id,))
    row = cursor.fetchone()
    conn.close()
    return row[0] if row else 0


def save_master_token(user_id: int, email: str, master_token: str, android_id: str):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO master_tokens (user_id, email, master_token, android_id, updated_at)
        VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
        ON CONFLICT(user_id, email) DO UPDATE SET
            master_token=excluded.master_token,
            android_id=excluded.android_id,
            updated_at=CURRENT_TIMESTAMP
    """, (user_id, email, master_token, android_id))
    conn.commit()
    conn.close()


def get_master_token(user_id: int, email: str) -> Optional[Dict[str, str]]:
    conn = get_db_connection()
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute(
        "SELECT master_token, android_id FROM master_tokens WHERE user_id = ? AND email = ?",
        (user_id, email)
    )
    row = cursor.fetchone()
    conn.close()
    if row:
        return dict(row)
    return None


def get_user_by_query(query: str) -> Optional[Dict[str, Any]]:
    conn = get_db_connection()
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    q = str(query).strip().lstrip("@")
    if q.isdigit():
        cursor.execute("SELECT * FROM users WHERE user_id = ?", (int(q),))
    else:
        cursor.execute("SELECT * FROM users WHERE LOWER(username) = LOWER(?)", (q,))
    row = cursor.fetchone()
    conn.close()
    return dict(row) if row else None


def get_all_user_ids() -> List[int]:
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT user_id FROM users")
    ids = [r[0] for r in cursor.fetchall()]
    conn.close()
    return ids


def get_active_user_ids() -> List[int]:
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT user_id FROM users WHERE COALESCE(is_banned, 0) = 0")
    ids = [r[0] for r in cursor.fetchall()]
    conn.close()
    return ids


def get_admin_stats() -> Dict[str, Any]:
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*), SUM(balance), SUM(tokens_purchased), SUM(stars_spent) FROM users")
    row = cursor.fetchone()
    total_users = row[0] if row else 0
    total_balance = row[1] if row and row[1] else 0
    tokens_purchased = row[2] if row and row[2] else 0
    stars_spent = row[3] if row and row[3] else 0
    cursor.execute("SELECT COUNT(*) FROM users WHERE DATE(created_at) = DATE('now')")
    new_users_today = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM users WHERE COALESCE(is_banned, 0) = 1")
    banned_users = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM quest_logs WHERE status = 'COMPLETED'")
    completed_quests = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM quest_logs WHERE status != 'COMPLETED'")
    failed_quests = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM saved_accounts")
    saved_accs = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM sponsored_channels WHERE channel_type = 'mandatory'")
    mandatory_channels = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM sponsored_channels WHERE channel_type = 'promo'")
    promo_channels = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM referrals WHERE rewarded = 1")
    total_referrals = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM promo_codes WHERE current_uses < max_uses")
    active_promos = cursor.fetchone()[0]
    conn.close()
    return {
        "total_users": total_users,
        "new_users_today": new_users_today,
        "banned_users": banned_users,
        "total_balance": total_balance,
        "tokens_purchased": tokens_purchased,
        "stars_spent": stars_spent,
        "completed_quests": completed_quests,
        "failed_quests": failed_quests,
        "saved_accs": saved_accs,
        "total_channels": mandatory_channels + promo_channels,
        "mandatory_channels": mandatory_channels,
        "promo_channels": promo_channels,
        "total_referrals": total_referrals,
        "active_promos": active_promos,
    }


def create_promo_code(code: str, reward_tokens: int, max_uses: int = 1) -> bool:
    code = code.strip().upper()
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("""
            INSERT INTO promo_codes (code, reward_tokens, max_uses, current_uses)
            VALUES (?, ?, ?, 0)
            ON CONFLICT(code) DO UPDATE SET
                reward_tokens = excluded.reward_tokens,
                max_uses = excluded.max_uses,
                current_uses = 0
        """, (code, reward_tokens, max_uses))
        conn.commit()
        return True
    except Exception:
        return False
    finally:
        conn.close()


def get_all_promo_codes() -> List[Dict[str, Any]]:
    conn = get_db_connection()
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("SELECT code, reward_tokens, max_uses, current_uses, created_at FROM promo_codes ORDER BY created_at DESC")
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]


def delete_promo_code(code: str) -> bool:
    code = code.strip().upper()
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM promo_codes WHERE code = ?", (code,))
    deleted = cursor.rowcount > 0
    conn.commit()
    conn.close()
    return deleted


def redeem_promo_code(user_id: int, code: str) -> Tuple[bool, str, int]:
    code = code.strip().upper()
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT reward_tokens, max_uses, current_uses FROM promo_codes WHERE code = ?", (code,))
    promo = cursor.fetchone()
    if not promo:
        conn.close()
        return (False, "NOT_FOUND", 0)

    reward_tokens, max_uses, current_uses = promo[0], promo[1], promo[2]
    if current_uses >= max_uses:
        conn.close()
        return (False, "EXPIRED", 0)

    cursor.execute("SELECT id FROM promo_code_redemptions WHERE code = ? AND user_id = ?", (code, user_id))
    if cursor.fetchone():
        conn.close()
        return (False, "ALREADY_USED", 0)

    try:
        cursor.execute("INSERT INTO promo_code_redemptions (code, user_id) VALUES (?, ?)", (code, user_id))
        cursor.execute("UPDATE promo_codes SET current_uses = current_uses + 1 WHERE code = ?", (code,))
        cursor.execute("UPDATE users SET balance = balance + ? WHERE user_id = ?", (reward_tokens, user_id))
        conn.commit()
        return (True, "SUCCESS", reward_tokens)
    except Exception:
        conn.rollback()
        return (False, "ERROR", 0)
    finally:
        conn.close()
