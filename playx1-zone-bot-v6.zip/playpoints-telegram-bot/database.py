import sqlite3
import time
from datetime import datetime, timezone
from typing import Optional, List, Dict, Any, Tuple
from pathlib import Path

DB_PATH = Path(__file__).parent / "pointbot.db"

DEFAULT_CHANNEL_USERNAME = "@PLAYX1_ZONE"
DEFAULT_CHANNEL_TITLE = "PLAYX1 ZONE"
DEFAULT_CHANNEL_LINK = "https://t.me/PLAYX1_ZONE"

_SETTINGS_CACHE: Dict[str, Tuple[float, str]] = {}
_SETTINGS_CACHE_TTL = 25.0


def _fmt_num(val: float) -> str:
    v = round(float(val), 4)
    if v == int(v):
        return str(int(v))
    return f"{v:g}"


def get_db_connection() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH, timeout=15.0)
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA busy_timeout = 5000")
    conn.execute("PRAGMA synchronous = NORMAL")
    conn.execute("PRAGMA cache_size = -8000")
    conn.execute("PRAGMA temp_store = MEMORY")
    conn.execute("PRAGMA mmap_size = 33554432")
    return conn


def init_db():
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            username TEXT,
            balance REAL DEFAULT 8,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    cursor.execute("PRAGMA table_info(users)")
    cols = [r[1] for r in cursor.fetchall()]
    if "language" not in cols:
        cursor.execute("ALTER TABLE users ADD COLUMN language TEXT DEFAULT 'ar'")
    if "referrer_id" not in cols:
        cursor.execute("ALTER TABLE users ADD COLUMN referrer_id INTEGER")
    if "channel_bonus_claimed" not in cols:
        cursor.execute("ALTER TABLE users ADD COLUMN channel_bonus_claimed INTEGER DEFAULT 0")
    if "tokens_purchased" not in cols:
        cursor.execute("ALTER TABLE users ADD COLUMN tokens_purchased REAL DEFAULT 0")
    if "stars_spent" not in cols:
        cursor.execute("ALTER TABLE users ADD COLUMN stars_spent INTEGER DEFAULT 0")
    if "is_banned" not in cols:
        cursor.execute("ALTER TABLE users ADD COLUMN is_banned INTEGER DEFAULT 0")
    if "checkin_streak" not in cols:
        cursor.execute("ALTER TABLE users ADD COLUMN checkin_streak INTEGER DEFAULT 0")
    if "last_checkin_date" not in cols:
        cursor.execute("ALTER TABLE users ADD COLUMN last_checkin_date TEXT")
    if "total_checkins" not in cols:
        cursor.execute("ALTER TABLE users ADD COLUMN total_checkins INTEGER DEFAULT 0")

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS bot_settings (
            key TEXT PRIMARY KEY,
            value TEXT
        )
    """)

    default_settings = [
        ("force_sub_enabled", "1"),
        ("maintenance_mode", "0"),
        ("chest_cost", "2"),
        ("welcome_bonus", "8"),
        ("admin_lang", "ar"),
        # Weekly Prize system settings (token-based & admin controlled)
        ("weekly_prize_enabled", "1"),
        ("weekly_prize_cost", "1"),
        ("weekly_free_first_time", "0"),
        ("weekly_refund_on_ineligible", "1"),
        ("weekly_refund_on_already_claimed", "1"),
        # Referral system settings
        ("referral_enabled", "1"),
        ("referral_inviter_reward", "3"),
        ("referral_invited_bonus", "0"),
        ("referral_require_sub", "1"),
        # Channel reward system settings
        ("channel_reward_enabled", "1"),
        ("channel_reward_default", "2"),
        ("channel_verify_live", "1"),
        # Daily check-in settings (supports decimals such as 0.25)
        ("checkin_enabled", "1"),
        ("checkin_day_1", "0.25"),
        ("checkin_day_2", "0.25"),
        ("checkin_day_3", "0.5"),
        ("checkin_day_4", "0.5"),
        ("checkin_day_5", "0.5"),
        ("checkin_day_6", "0.5"),
        ("checkin_day_7", "1"),
        # Additional Admin toggles & controls
        ("quests_enabled", "1"),
        ("stars_shop_enabled", "1"),
        ("promo_codes_enabled", "1"),
        ("auto_save_accounts", "1"),
        ("services_store_enabled", "1"),
    ]
    for k, v in default_settings:
        cursor.execute("INSERT OR IGNORE INTO bot_settings (key, value) VALUES (?, ?)", (k, v))

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS user_channel_claims (
            user_id INTEGER,
            channel_username TEXT,
            claimed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY(user_id, channel_username)
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS saved_accounts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            email TEXT,
            password TEXT,
            last_used TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (user_id),
            UNIQUE(user_id, email)
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS quest_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            email TEXT,
            game_key TEXT,
            status TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS master_tokens (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            email TEXT,
            master_token TEXT,
            android_id TEXT,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (user_id),
            UNIQUE(user_id, email)
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS sponsored_channels (
            channel_username TEXT PRIMARY KEY,
            title TEXT,
            invite_link TEXT,
            channel_type TEXT DEFAULT 'mandatory',
            reward_tokens REAL DEFAULT 2,
            is_active INTEGER DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    cursor.execute("PRAGMA table_info(sponsored_channels)")
    ch_cols = [r[1] for r in cursor.fetchall()]
    if "channel_type" not in ch_cols:
        cursor.execute("ALTER TABLE sponsored_channels ADD COLUMN channel_type TEXT DEFAULT 'mandatory'")
    if "reward_tokens" not in ch_cols:
        cursor.execute("ALTER TABLE sponsored_channels ADD COLUMN reward_tokens REAL DEFAULT 2")
    if "is_active" not in ch_cols:
        cursor.execute("ALTER TABLE sponsored_channels ADD COLUMN is_active INTEGER DEFAULT 1")

    cursor.execute("SELECT value FROM bot_settings WHERE key = 'channels_seeded'")
    seeded = cursor.fetchone()
    if not seeded:
        cursor.execute("""
            INSERT OR IGNORE INTO sponsored_channels (channel_username, title, invite_link, channel_type, reward_tokens, is_active)
            VALUES (?, ?, ?, 'mandatory', 2, 1)
        """, (DEFAULT_CHANNEL_USERNAME, DEFAULT_CHANNEL_TITLE, DEFAULT_CHANNEL_LINK))
        cursor.execute("INSERT OR REPLACE INTO bot_settings (key, value) VALUES ('channels_seeded', '1')")

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS referrals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            inviter_id INTEGER,
            invited_id INTEGER UNIQUE,
            rewarded INTEGER DEFAULT 0,
            reward_amount REAL DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    cursor.execute("PRAGMA table_info(referrals)")
    ref_cols = [r[1] for r in cursor.fetchall()]
    if "reward_amount" not in ref_cols:
        cursor.execute("ALTER TABLE referrals ADD COLUMN reward_amount REAL DEFAULT 0")

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS star_purchases (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            tokens REAL,
            stars INTEGER,
            charge_id TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS promo_codes (
            code TEXT PRIMARY KEY,
            reward_tokens REAL,
            max_uses INTEGER DEFAULT 1,
            current_uses INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS promo_code_redemptions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            code TEXT,
            user_id INTEGER,
            redeemed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(code, user_id)
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS weekly_claim_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            email TEXT,
            status TEXT,
            points_won TEXT,
            cost_charged REAL DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS admin_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            admin_id INTEGER,
            action TEXT,
            details TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS store_categories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT DEFAULT '',
            is_active INTEGER DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS store_services (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            category_id INTEGER DEFAULT 0,
            title TEXT NOT NULL,
            description TEXT DEFAULT '',
            price_stars INTEGER DEFAULT 0,
            price_tokens REAL DEFAULT 0,
            price_usdt TEXT DEFAULT '',
            bundle_mode INTEGER DEFAULT 0,
            is_active INTEGER DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    cursor.execute("PRAGMA table_info(store_services)")
    srv_cols = [r[1] for r in cursor.fetchall()]
    if "category_id" not in srv_cols:
        cursor.execute("ALTER TABLE store_services ADD COLUMN category_id INTEGER DEFAULT 0")
    if "price_usdt" not in srv_cols:
        cursor.execute("ALTER TABLE store_services ADD COLUMN price_usdt TEXT DEFAULT ''")
    if "bundle_mode" not in srv_cols:
        cursor.execute("ALTER TABLE store_services ADD COLUMN bundle_mode INTEGER DEFAULT 0")

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS service_orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_code TEXT UNIQUE,
            user_id INTEGER,
            service_id INTEGER,
            service_title TEXT,
            payment_method TEXT,
            amount_paid REAL,
            status TEXT DEFAULT 'PAID',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    cursor.execute("CREATE INDEX IF NOT EXISTS idx_saved_accounts_uid ON saved_accounts(user_id)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_quest_logs_uid ON quest_logs(user_id, status)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_master_tokens_uid_email ON master_tokens(user_id, email)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_referrals_inviter ON referrals(inviter_id, rewarded)")

    conn.commit()
    conn.close()


def get_setting(key: str, default: str = "") -> str:
    now = time.monotonic()
    cached = _SETTINGS_CACHE.get(key)
    if cached and (now - cached[0]) < _SETTINGS_CACHE_TTL:
        return cached[1]
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT value FROM bot_settings WHERE key = ?", (key,))
        row = cursor.fetchone()
        val = row[0] if row and row[0] is not None else default
        _SETTINGS_CACHE[key] = (now, val)
        return val
    except Exception:
        return default
    finally:
        conn.close()


def set_setting(key: str, value: str):
    val_str = str(value)
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            "INSERT OR REPLACE INTO bot_settings (key, value) VALUES (?, ?)",
            (key, val_str)
        )
        conn.commit()
        _SETTINGS_CACHE[key] = (time.monotonic(), val_str)
    finally:
        conn.close()


def get_setting_int(key: str, default: int = 0) -> int:
    raw = get_setting(key, str(default))
    try:
        return int(float(raw))
    except (ValueError, TypeError):
        return default


def get_setting_float(key: str, default: float = 0.0) -> float:
    raw = get_setting(key, str(default)).replace(",", ".")
    try:
        return round(float(raw), 4)
    except (ValueError, TypeError):
        return default


def get_setting_bool(key: str, default: bool = False) -> bool:
    raw = get_setting(key, "1" if default else "0").strip().lower()
    return raw in ("1", "true", "yes", "on")


def log_admin_action(admin_id: int, action: str, details: str = ""):
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            "INSERT INTO admin_logs (admin_id, action, details) VALUES (?, ?, ?)",
            (admin_id, action, details[:300])
        )
        conn.commit()
    except Exception:
        pass
    finally:
        conn.close()


def get_recent_admin_logs(limit: int = 15) -> List[Dict[str, Any]]:
    conn = get_db_connection()
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT admin_id, action, details, created_at FROM admin_logs ORDER BY id DESC LIMIT ?", (limit,))
        rows = cursor.fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def clear_admin_logs() -> int:
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("BEGIN IMMEDIATE")
        cursor.execute("SELECT COUNT(*) FROM admin_logs")
        cnt = int(cursor.fetchone()[0] or 0)
        cursor.execute("DELETE FROM admin_logs")
        conn.commit()
        return cnt
    except Exception:
        conn.rollback()
        return 0
    finally:
        conn.close()


def get_or_create_user(user_id: int, username: Optional[str] = None) -> Dict[str, Any]:
    conn = get_db_connection()
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
    row = cursor.fetchone()

    if not row:
        try:
            cursor.execute("SELECT value FROM bot_settings WHERE key = 'welcome_bonus'")
            wb_row = cursor.fetchone()
            start_balance = round(float(wb_row[0]), 4) if wb_row and wb_row[0] is not None else 8.0
        except Exception:
            start_balance = 8.0
        cursor.execute(
            "INSERT INTO users (user_id, username, balance, language) VALUES (?, ?, ?, 'ar')",
            (user_id, username, start_balance)
        )
        conn.commit()
        cursor.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
        row = cursor.fetchone()
    elif username and row["username"] != username:
        cursor.execute("UPDATE users SET username = ? WHERE user_id = ?", (username, user_id))
        conn.commit()
        cursor.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
        row = cursor.fetchone()

    user_data = dict(row)
    conn.close()
    return user_data


def get_user_balance(user_id: int) -> float:
    user = get_or_create_user(user_id)
    bal = user.get("balance", 0)
    return round(float(bal), 4) if bal is not None else 0.0


def update_balance(user_id: int, delta: float) -> float:
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("BEGIN IMMEDIATE")
        cursor.execute(
            "UPDATE users SET balance = ROUND(MAX(0.0, COALESCE(balance, 0.0) + ?), 4) WHERE user_id = ?",
            (round(float(delta), 4), user_id)
        )
        cursor.execute("SELECT balance FROM users WHERE user_id = ?", (user_id,))
        row = cursor.fetchone()
        new_bal = round(float(row[0]), 4) if row and row[0] is not None else 0.0
        conn.commit()
        return new_bal
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def is_user_banned(user_id: int) -> bool:
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT is_banned FROM users WHERE user_id = ?", (user_id,))
        row = cursor.fetchone()
        return bool(row and row[0])
    except Exception:
        return False
    finally:
        conn.close()


def set_user_banned(user_id: int, banned: bool) -> bool:
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE users SET is_banned = ? WHERE user_id = ?", (1 if banned else 0, user_id))
    updated = cursor.rowcount > 0
    conn.commit()
    conn.close()
    return updated


def get_banned_users() -> List[Dict[str, Any]]:
    conn = get_db_connection()
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("SELECT user_id, username, balance FROM users WHERE is_banned = 1 ORDER BY user_id DESC LIMIT 30")
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]


def gift_tokens_to_all(amount: float) -> int:
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("BEGIN IMMEDIATE")
        cursor.execute(
            "UPDATE users SET balance = ROUND(COALESCE(balance, 0.0) + ?, 4) WHERE COALESCE(is_banned, 0) = 0",
            (round(float(amount), 4),)
        )
        count = cursor.rowcount
        conn.commit()
        return count
    except Exception:
        conn.rollback()
        return 0
    finally:
        conn.close()


def get_user_language(user_id: int) -> str:
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT language FROM users WHERE user_id = ?", (user_id,))
    row = cursor.fetchone()
    conn.close()
    if row and row[0]:
        return row[0]
    return "ar"


def set_user_language(user_id: int, lang: str):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE users SET language = ? WHERE user_id = ?", (lang, user_id))
    conn.commit()
    conn.close()


# =========================================================
# CHANNELS MANAGEMENT (Mandatory + Partner / Earn Channels)
# =========================================================

def get_mandatory_channels() -> List[Dict[str, Any]]:
    conn = get_db_connection()
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute(
        "SELECT channel_username, title, invite_link, COALESCE(reward_tokens, 2) AS reward_tokens, COALESCE(is_active, 1) AS is_active "
        "FROM sponsored_channels WHERE channel_type = 'mandatory' ORDER BY created_at ASC"
    )
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_promo_channels() -> List[Dict[str, Any]]:
    conn = get_db_connection()
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute(
        "SELECT channel_username, title, invite_link, COALESCE(reward_tokens, 2) AS reward_tokens, COALESCE(is_active, 1) AS is_active "
        "FROM sponsored_channels WHERE channel_type = 'promo' ORDER BY created_at ASC"
    )
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_all_earn_channels() -> List[Dict[str, Any]]:
    conn = get_db_connection()
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute(
        "SELECT channel_username, title, invite_link, channel_type, COALESCE(reward_tokens, 2) AS reward_tokens, COALESCE(is_active, 1) AS is_active "
        "FROM sponsored_channels WHERE COALESCE(is_active, 1) = 1 AND COALESCE(reward_tokens, 0) > 0 ORDER BY created_at ASC"
    )
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_channel_by_username(channel_username: str) -> Optional[Dict[str, Any]]:
    ch = channel_username.strip()
    if not ch.startswith("@"):
        ch = f"@{ch}"
    conn = get_db_connection()
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM sponsored_channels WHERE LOWER(channel_username) = LOWER(?)", (ch,))
    row = cursor.fetchone()
    conn.close()
    return dict(row) if row else None


def get_sponsored_channels() -> List[Dict[str, Any]]:
    return get_mandatory_channels()


def add_sponsored_channel(
    channel_username: str,
    title: str = "",
    invite_link: str = "",
    channel_type: str = "mandatory",
    reward_tokens: Optional[float] = None,
) -> bool:
    channel_username = channel_username.strip()
    if not channel_username.startswith("@"):
        channel_username = f"@{channel_username}"
    if not invite_link:
        invite_link = f"https://t.me/{channel_username.lstrip('@')}"
    if not title:
        title = channel_username
    if reward_tokens is None:
        reward_tokens = get_setting_float("channel_reward_default", 2.0)
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("""
            INSERT INTO sponsored_channels (channel_username, title, invite_link, channel_type, reward_tokens, is_active)
            VALUES (?, ?, ?, ?, ?, 1)
            ON CONFLICT(channel_username) DO UPDATE SET
                title=excluded.title,
                invite_link=excluded.invite_link,
                channel_type=excluded.channel_type,
                reward_tokens=excluded.reward_tokens,
                is_active=1
        """, (channel_username, title, invite_link, channel_type, round(float(reward_tokens), 4)))
        conn.commit()
        return True
    except Exception:
        return False
    finally:
        conn.close()


def update_channel_reward(channel_username: str, reward_tokens: float) -> bool:
    ch = channel_username.strip()
    if not ch.startswith("@"):
        ch = f"@{ch}"
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "UPDATE sponsored_channels SET reward_tokens = ? WHERE LOWER(channel_username) = LOWER(?)",
        (round(float(reward_tokens), 4), ch)
    )
    ok = cursor.rowcount > 0
    conn.commit()
    conn.close()
    return ok


def bulk_update_all_channels_reward(reward_tokens: float) -> int:
    val = round(float(reward_tokens), 4)
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("UPDATE sponsored_channels SET reward_tokens = ?", (val,))
        updated = cursor.rowcount
        cursor.execute(
            "INSERT OR REPLACE INTO bot_settings (key, value) VALUES (?, ?)",
            ("channel_reward_default", _fmt_num(val))
        )
        conn.commit()
        _SETTINGS_CACHE["channel_reward_default"] = (time.monotonic(), _fmt_num(val))
        return updated
    except Exception:
        conn.rollback()
        return 0
    finally:
        conn.close()


def toggle_channel_active(channel_username: str) -> Optional[int]:
    ch = channel_username.strip()
    if not ch.startswith("@"):
        ch = f"@{ch}"
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT COALESCE(is_active, 1) FROM sponsored_channels WHERE LOWER(channel_username) = LOWER(?)", (ch,))
    row = cursor.fetchone()
    if not row:
        conn.close()
        return None
    new_val = 0 if row[0] else 1
    cursor.execute("UPDATE sponsored_channels SET is_active = ? WHERE LOWER(channel_username) = LOWER(?)", (new_val, ch))
    conn.commit()
    conn.close()
    return new_val


def remove_sponsored_channel(channel_username: str) -> bool:
    channel_username = channel_username.strip()
    if not channel_username.startswith("@"):
        channel_username = f"@{channel_username}"
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM sponsored_channels WHERE LOWER(channel_username) = LOWER(?)", (channel_username,))
    deleted = cursor.rowcount > 0
    conn.commit()
    conn.close()
    return deleted


def get_user_claimed_channels(user_id: int) -> List[str]:
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT channel_username FROM user_channel_claims WHERE user_id = ?", (user_id,))
    rows = cursor.fetchall()
    conn.close()
    return [r[0].lower().lstrip("@") for r in rows]


def claim_single_channel_reward(user_id: int, channel_username: str, reward_amount: float) -> Tuple[bool, float]:
    clean_ch = channel_username.lower().lstrip("@")
    if not clean_ch or reward_amount <= 0:
        return (False, 0.0)
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("BEGIN IMMEDIATE")
        cursor.execute(
            "SELECT 1 FROM user_channel_claims WHERE user_id = ? AND LOWER(REPLACE(channel_username, '@', '')) = ?",
            (user_id, clean_ch)
        )
        if cursor.fetchone():
            conn.commit()
            return (False, 0.0)
        cursor.execute(
            "INSERT INTO user_channel_claims (user_id, channel_username) VALUES (?, ?)",
            (user_id, clean_ch)
        )
        amt = round(float(reward_amount), 4)
        cursor.execute(
            "UPDATE users SET balance = ROUND(COALESCE(balance, 0.0) + ?, 4), channel_bonus_claimed = 1 WHERE user_id = ?",
            (amt, user_id)
        )
        conn.commit()
        return (True, amt)
    except Exception:
        conn.rollback()
        return (False, 0.0)
    finally:
        conn.close()


def claim_channel_bonus_per_channel(
    user_id: int,
    channels_with_rewards: List[Any],
    reward_per_channel: float = 2.0
) -> Tuple[float, int]:
    if not channels_with_rewards:
        return (0.0, 0)
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("BEGIN IMMEDIATE")
        cursor.execute("SELECT channel_username FROM user_channel_claims WHERE user_id = ?", (user_id,))
        already_claimed = {r[0].lower().lstrip("@") for r in cursor.fetchall()}

        total_added = 0.0
        claimed_count = 0
        for ch_obj in channels_with_rewards:
            uname = ch_obj["channel_username"] if isinstance(ch_obj, dict) else str(ch_obj)
            clean_ch = uname.lower().lstrip("@")
            if not clean_ch or clean_ch in already_claimed:
                continue
            r_amt = float(ch_obj.get("reward_tokens", reward_per_channel)) if isinstance(ch_obj, dict) else float(reward_per_channel)
            if r_amt <= 0:
                continue
            cursor.execute("INSERT OR IGNORE INTO user_channel_claims (user_id, channel_username) VALUES (?, ?)", (user_id, clean_ch))
            already_claimed.add(clean_ch)
            total_added = round(total_added + r_amt, 4)
            claimed_count += 1

        if claimed_count == 0:
            conn.commit()
            return (0.0, 0)

        cursor.execute(
            "UPDATE users SET balance = ROUND(COALESCE(balance, 0.0) + ?, 4), channel_bonus_claimed = 1 WHERE user_id = ?",
            (total_added, user_id)
        )
        conn.commit()
        return (total_added, claimed_count)
    except Exception:
        conn.rollback()
        return (0.0, 0)
    finally:
        conn.close()


def is_channel_bonus_claimed(user_id: int) -> bool:
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT channel_bonus_claimed FROM users WHERE user_id = ?", (user_id,))
    row = cursor.fetchone()
    conn.close()
    return bool(row and row[0])


# =========================================================
# REFERRAL SYSTEM
# =========================================================

def record_referral(inviter_id: int, invited_id: int) -> bool:
    if inviter_id == invited_id:
        return False
    if not get_setting_bool("referral_enabled", True):
        return False
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("BEGIN IMMEDIATE")
        cursor.execute("INSERT OR IGNORE INTO referrals (inviter_id, invited_id) VALUES (?, ?)", (inviter_id, invited_id))
        inserted = cursor.rowcount > 0
        cursor.execute("UPDATE users SET referrer_id = ? WHERE user_id = ? AND referrer_id IS NULL", (inviter_id, invited_id))
        conn.commit()
        return inserted
    except Exception:
        conn.rollback()
        return False
    finally:
        conn.close()


def reward_referral_if_pending(
    invited_id: int,
    inviter_reward: Optional[float] = None,
    invited_bonus: Optional[float] = None
) -> Optional[Tuple[int, float, float]]:
    if not get_setting_bool("referral_enabled", True):
        return None
    if inviter_reward is None:
        inviter_reward = get_setting_float("referral_inviter_reward", 3.0)
    if invited_bonus is None:
        invited_bonus = get_setting_float("referral_invited_bonus", 0.0)

    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("BEGIN IMMEDIATE")
        cursor.execute("SELECT inviter_id, rewarded FROM referrals WHERE invited_id = ?", (invited_id,))
        row = cursor.fetchone()
        if not row or row[1] == 1:
            conn.commit()
            return None
        inviter_id = row[0]
        inv_r = round(float(inviter_reward), 4)
        new_b = round(float(invited_bonus), 4)
        cursor.execute(
            "UPDATE referrals SET rewarded = 1, reward_amount = ? WHERE invited_id = ?",
            (inv_r, invited_id)
        )
        if inv_r > 0:
            cursor.execute(
                "UPDATE users SET balance = ROUND(COALESCE(balance, 0.0) + ?, 4) WHERE user_id = ?",
                (inv_r, inviter_id)
            )
        if new_b > 0:
            cursor.execute(
                "UPDATE users SET balance = ROUND(COALESCE(balance, 0.0) + ?, 4) WHERE user_id = ?",
                (new_b, invited_id)
            )
        conn.commit()
        return (inviter_id, inv_r, new_b)
    except Exception:
        conn.rollback()
        return None
    finally:
        conn.close()


def get_referral_info(user_id: int) -> Dict[str, Any]:
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM referrals WHERE inviter_id = ?", (user_id,))
    total_invited = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*), COALESCE(SUM(reward_amount), 0) FROM referrals WHERE inviter_id = ? AND rewarded = 1", (user_id,))
    r_row = cursor.fetchone()
    completed_invited = r_row[0] if r_row else 0
    sum_earned = round(float(r_row[1]), 4) if r_row and r_row[1] else 0.0
    if sum_earned == 0 and completed_invited > 0:
        rate = get_setting_float("referral_inviter_reward", 3.0)
        sum_earned = round(completed_invited * rate, 4)
    conn.close()
    return {
        "total_invited": total_invited,
        "completed_invited": completed_invited,
        "tokens_earned": sum_earned,
    }


def get_top_referrers(limit: int = 10) -> List[Dict[str, Any]]:
    conn = get_db_connection()
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("""
        SELECT r.inviter_id AS user_id, u.username, COUNT(*) AS refs, COALESCE(SUM(r.reward_amount), 0) AS earned
        FROM referrals r
        LEFT JOIN users u ON u.user_id = r.inviter_id
        WHERE r.rewarded = 1
        GROUP BY r.inviter_id
        ORDER BY refs DESC
        LIMIT ?
    """, (limit,))
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]


# =========================================================
# DAILY CHECK-IN SYSTEM
# =========================================================

def get_checkin_schedule() -> List[float]:
    defaults = [0.25, 0.25, 0.5, 0.5, 0.5, 0.5, 1.0]
    res = []
    for day in range(1, 8):
        res.append(get_setting_float(f"checkin_day_{day}", defaults[day - 1]))
    return res


def get_checkin_status(user_id: int) -> Dict[str, Any]:
    user = get_or_create_user(user_id)
    today_str = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    yesterday_str = datetime.fromtimestamp(datetime.now(timezone.utc).timestamp() - 86400, tz=timezone.utc).strftime("%Y-%m-%d")

    last_date = user.get("last_checkin_date") or ""
    raw_streak = int(user.get("checkin_streak") or 0)
    total_checkins = int(user.get("total_checkins") or 0)
    schedule = get_checkin_schedule()

    if last_date == today_str:
        claimed_today = True
        effective_streak = raw_streak
        next_day_num = (effective_streak % 7) + 1
    elif last_date == yesterday_str:
        claimed_today = False
        effective_streak = raw_streak if raw_streak < 7 else 0
        next_day_num = effective_streak + 1
    else:
        claimed_today = False
        effective_streak = 0
        next_day_num = 1

    return {
        "claimed_today": claimed_today,
        "effective_streak": effective_streak,
        "next_day_num": next_day_num,
        "schedule": schedule,
        "total_checkins": total_checkins,
        "balance": round(float(user.get("balance") or 0.0), 4),
    }


def perform_daily_checkin(user_id: int) -> Tuple[bool, str, float, int, float]:
    if not get_setting_bool("checkin_enabled", True):
        return (False, "DISABLED", 0.0, 0, get_user_balance(user_id))

    today_str = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    yesterday_str = datetime.fromtimestamp(datetime.now(timezone.utc).timestamp() - 86400, tz=timezone.utc).strftime("%Y-%m-%d")
    schedule = get_checkin_schedule()

    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("BEGIN IMMEDIATE")
        cursor.execute("SELECT balance, checkin_streak, last_checkin_date, total_checkins FROM users WHERE user_id = ?", (user_id,))
        row = cursor.fetchone()
        if not row:
            conn.rollback()
            get_or_create_user(user_id)
            return perform_daily_checkin(user_id)

        cur_bal = float(row[0] or 0.0)
        raw_streak = int(row[1] or 0)
        last_date = row[2] or ""
        total_ci = int(row[3] or 0)

        if last_date == today_str:
            conn.commit()
            return (False, "ALREADY_CLAIMED", 0.0, raw_streak, round(cur_bal, 4))

        if last_date == yesterday_str:
            new_streak = (raw_streak + 1) if raw_streak < 7 else 1
        else:
            new_streak = 1

        reward = round(float(schedule[new_streak - 1]), 4)
        new_bal = round(cur_bal + reward, 4)

        cursor.execute(
            """
            UPDATE users
            SET balance = ?,
                checkin_streak = ?,
                last_checkin_date = ?,
                total_checkins = ?
            WHERE user_id = ?
            """,
            (new_bal, new_streak, today_str, total_ci + 1, user_id)
        )
        conn.commit()
        return (True, "SUCCESS", reward, new_streak, new_bal)
    except Exception:
        conn.rollback()
        return (False, "ERROR", 0.0, 0, get_user_balance(user_id))
    finally:
        conn.close()


def reset_user_checkin_streak(user_id: int):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE users SET checkin_streak = 0, last_checkin_date = NULL WHERE user_id = ?", (user_id,))
    conn.commit()
    conn.close()


# =========================================================
# WEEKLY PRIZE LOGS & PURCHASES
# =========================================================

def log_weekly_claim(user_id: int, email: str, status: str, points_won: str = "", cost_charged: float = 0.0):
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            "INSERT INTO weekly_claim_logs (user_id, email, status, points_won, cost_charged) VALUES (?, ?, ?, ?, ?)",
            (user_id, email, status, str(points_won or ""), round(float(cost_charged), 4))
        )
        conn.commit()
    except Exception:
        pass
    finally:
        conn.close()


def has_user_used_weekly_before(user_id: int) -> bool:
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM weekly_claim_logs WHERE user_id = ? AND status IN ('CLAIMED', 'APP_REQUIRED', 'ALREADY_CLAIMED')", (user_id,))
    cnt = cursor.fetchone()[0]
    conn.close()
    return cnt > 0


def record_star_purchase(user_id: int, tokens: float, stars: int, charge_id: str):
    conn = get_db_connection()
    cursor = conn.cursor()
    t_val = round(float(tokens), 4)
    cursor.execute("""
        INSERT INTO star_purchases (user_id, tokens, stars, charge_id)
        VALUES (?, ?, ?, ?)
    """, (user_id, t_val, stars, charge_id))
    cursor.execute("""
        UPDATE users
        SET balance = ROUND(COALESCE(balance, 0.0) + ?, 4),
            tokens_purchased = ROUND(COALESCE(tokens_purchased, 0.0) + ?, 4),
            stars_spent = COALESCE(stars_spent, 0) + ?
        WHERE user_id = ?
    """, (t_val, t_val, stars, user_id))
    conn.commit()
    conn.close()


def get_top_buyers(limit: int = 10) -> List[Dict[str, Any]]:
    conn = get_db_connection()
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("""
        SELECT user_id, username, tokens_purchased, stars_spent, balance
        FROM users
        WHERE tokens_purchased > 0
        ORDER BY tokens_purchased DESC, stars_spent DESC
        LIMIT ?
    """, (limit,))
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]


def save_account(user_id: int, email: str, password: str):
    if not get_setting_bool("auto_save_accounts", True):
        return
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO saved_accounts (user_id, email, password, last_used)
        VALUES (?, ?, ?, CURRENT_TIMESTAMP)
        ON CONFLICT(user_id, email) DO UPDATE SET password=excluded.password, last_used=CURRENT_TIMESTAMP
    """, (user_id, email, password))
    conn.commit()
    conn.close()


def get_saved_accounts(user_id: int, limit: Optional[int] = None, offset: int = 0) -> List[Dict[str, Any]]:
    conn = get_db_connection()
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    if limit is not None:
        cursor.execute(
            "SELECT id, email, password FROM saved_accounts WHERE user_id = ? ORDER BY last_used DESC LIMIT ? OFFSET ?",
            (user_id, limit, offset)
        )
    else:
        cursor.execute(
            "SELECT id, email, password FROM saved_accounts WHERE user_id = ? ORDER BY last_used DESC",
            (user_id,)
        )
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]


def count_saved_accounts(user_id: int) -> int:
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM saved_accounts WHERE user_id = ?", (user_id,))
    row = cursor.fetchone()
    cnt = row[0] if row else 0
    conn.close()
    return cnt


def get_saved_account_by_id(user_id: int, account_id: int) -> Optional[Dict[str, Any]]:
    conn = get_db_connection()
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute(
        "SELECT id, email, password FROM saved_accounts WHERE id = ? AND user_id = ?",
        (account_id, user_id)
    )
    row = cursor.fetchone()
    conn.close()
    return dict(row) if row else None


def get_saved_account_by_email(user_id: int, email: str) -> Optional[Dict[str, Any]]:
    conn = get_db_connection()
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute(
        "SELECT id, email, password FROM saved_accounts WHERE user_id = ? AND email = ?",
        (user_id, email)
    )
    row = cursor.fetchone()
    conn.close()
    return dict(row) if row else None


def log_quest(user_id: int, email: str, game_key: str, status: str):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO quest_logs (user_id, email, game_key, status) VALUES (?, ?, ?, ?)",
        (user_id, email, game_key, status)
    )
    conn.commit()
    conn.close()


def get_user_quests_count(user_id: int) -> int:
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM quest_logs WHERE user_id = ? AND status = 'COMPLETED'", (user_id,))
    row = cursor.fetchone()
    conn.close()
    return row[0] if row else 0


def save_master_token(user_id: int, email: str, master_token: str, android_id: str):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO master_tokens (user_id, email, master_token, android_id, updated_at)
        VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
        ON CONFLICT(user_id, email) DO UPDATE SET
            master_token=excluded.master_token,
            android_id=excluded.android_id,
            updated_at=CURRENT_TIMESTAMP
    """, (user_id, email, master_token, android_id))
    conn.commit()
    conn.close()


def get_master_token(user_id: int, email: str) -> Optional[Dict[str, str]]:
    conn = get_db_connection()
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute(
        "SELECT master_token, android_id FROM master_tokens WHERE user_id = ? AND email = ?",
        (user_id, email)
    )
    row = cursor.fetchone()
    conn.close()
    if row:
        return dict(row)
    return None


def get_user_by_query(query: str) -> Optional[Dict[str, Any]]:
    conn = get_db_connection()
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    q = str(query).strip().lstrip("@")
    if q.isdigit():
        cursor.execute("SELECT * FROM users WHERE user_id = ?", (int(q),))
    else:
        cursor.execute("SELECT * FROM users WHERE LOWER(username) = LOWER(?)", (q,))
    row = cursor.fetchone()
    conn.close()
    return dict(row) if row else None


def get_recent_users(limit: int = 12) -> List[Dict[str, Any]]:
    conn = get_db_connection()
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("SELECT user_id, username, balance, created_at, is_banned FROM users ORDER BY created_at DESC LIMIT ?", (limit,))
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_richest_users(limit: int = 12) -> List[Dict[str, Any]]:
    conn = get_db_connection()
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("SELECT user_id, username, balance, tokens_purchased, stars_spent FROM users ORDER BY balance DESC LIMIT ?", (limit,))
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_all_user_ids() -> List[int]:
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT user_id FROM users")
    ids = [r[0] for r in cursor.fetchall()]
    conn.close()
    return ids


def get_active_user_ids() -> List[int]:
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT user_id FROM users WHERE COALESCE(is_banned, 0) = 0")
    ids = [r[0] for r in cursor.fetchall()]
    conn.close()
    return ids


def get_admin_stats() -> Dict[str, Any]:
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*), SUM(balance), SUM(tokens_purchased), SUM(stars_spent), SUM(total_checkins) FROM users")
    row = cursor.fetchone()
    total_users = row[0] if row else 0
    total_balance = round(float(row[1]), 4) if row and row[1] else 0.0
    tokens_purchased = round(float(row[2]), 4) if row and row[2] else 0.0
    stars_spent = row[3] if row and row[3] else 0
    total_checkins = row[4] if row and row[4] else 0
    cursor.execute("SELECT COUNT(*) FROM users WHERE DATE(created_at) = DATE('now')")
    new_users_today = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM users WHERE COALESCE(is_banned, 0) = 1")
    banned_users = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM quest_logs WHERE status = 'COMPLETED'")
    completed_quests = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM quest_logs WHERE status != 'COMPLETED'")
    failed_quests = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM weekly_claim_logs WHERE status IN ('CLAIMED', 'APP_REQUIRED')")
    weekly_claims = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM saved_accounts")
    saved_accs = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM sponsored_channels WHERE channel_type = 'mandatory'")
    mandatory_channels = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM sponsored_channels WHERE channel_type = 'promo'")
    promo_channels = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM referrals WHERE rewarded = 1")
    total_referrals = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM promo_codes WHERE current_uses < max_uses")
    active_promos = cursor.fetchone()[0]
    conn.close()
    return {
        "total_users": total_users,
        "new_users_today": new_users_today,
        "banned_users": banned_users,
        "total_balance": _fmt_num(total_balance),
        "tokens_purchased": _fmt_num(tokens_purchased),
        "stars_spent": stars_spent,
        "total_checkins": total_checkins,
        "completed_quests": completed_quests,
        "failed_quests": failed_quests,
        "weekly_claims": weekly_claims,
        "saved_accs": saved_accs,
        "total_channels": mandatory_channels + promo_channels,
        "mandatory_channels": mandatory_channels,
        "promo_channels": promo_channels,
        "total_referrals": total_referrals,
        "active_promos": active_promos,
    }


def create_promo_code(code: str, reward_tokens: float, max_uses: int = 1) -> bool:
    code = code.strip().upper()
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("""
            INSERT INTO promo_codes (code, reward_tokens, max_uses, current_uses)
            VALUES (?, ?, ?, 0)
            ON CONFLICT(code) DO UPDATE SET
                reward_tokens = excluded.reward_tokens,
                max_uses = excluded.max_uses,
                current_uses = 0
        """, (code, round(float(reward_tokens), 4), max_uses))
        conn.commit()
        return True
    except Exception:
        return False
    finally:
        conn.close()


def get_all_promo_codes() -> List[Dict[str, Any]]:
    conn = get_db_connection()
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("SELECT code, reward_tokens, max_uses, current_uses, created_at FROM promo_codes ORDER BY created_at DESC")
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]


def delete_promo_code(code: str) -> bool:
    code = code.strip().upper()
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM promo_codes WHERE code = ?", (code,))
    deleted = cursor.rowcount > 0
    conn.commit()
    conn.close()
    return deleted


def redeem_promo_code(user_id: int, code: str) -> Tuple[bool, str, float]:
    if not get_setting_bool("promo_codes_enabled", True):
        return (False, "DISABLED", 0.0)
    code = code.strip().upper()
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT reward_tokens, max_uses, current_uses FROM promo_codes WHERE code = ?", (code,))
    promo = cursor.fetchone()
    if not promo:
        conn.close()
        return (False, "NOT_FOUND", 0.0)

    reward_tokens, max_uses, current_uses = round(float(promo[0]), 4), promo[1], promo[2]
    if current_uses >= max_uses:
        conn.close()
        return (False, "EXPIRED", 0.0)

    cursor.execute("SELECT id FROM promo_code_redemptions WHERE code = ? AND user_id = ?", (code, user_id))
    if cursor.fetchone():
        conn.close()
        return (False, "ALREADY_USED", 0.0)

    try:
        cursor.execute("INSERT INTO promo_code_redemptions (code, user_id) VALUES (?, ?)", (code, user_id))
        cursor.execute("UPDATE promo_codes SET current_uses = current_uses + 1 WHERE code = ?", (code,))
        cursor.execute("UPDATE users SET balance = ROUND(COALESCE(balance, 0.0) + ?, 4) WHERE user_id = ?", (reward_tokens, user_id))
        conn.commit()
        return (True, "SUCCESS", reward_tokens)
    except Exception:
        conn.rollback()
        return (False, "ERROR", 0.0)
    finally:
        conn.close()


def count_active_sessions(user_id: int) -> int:
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            "SELECT COUNT(DISTINCT LOWER(email)) FROM master_tokens WHERE user_id = ? AND master_token IS NOT NULL AND master_token != ''",
            (user_id,)
        )
        row = cursor.fetchone()
        return int(row[0]) if row and row[0] else 0
    except Exception:
        return 0
    finally:
        conn.close()


# =========================================================
# OFFERS, CATEGORIES & SERVICES STORE SYSTEM
# =========================================================

def create_store_category(name: str, description: str = "") -> int:
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            "INSERT INTO store_categories (name, description, is_active) VALUES (?, ?, 1)",
            (name.strip(), description.strip())
        )
        conn.commit()
        return cursor.lastrowid or 0
    finally:
        conn.close()


def get_store_categories(only_active: bool = True) -> List[Dict[str, Any]]:
    conn = get_db_connection()
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    try:
        if only_active:
            cursor.execute("SELECT * FROM store_categories WHERE is_active = 1 ORDER BY id ASC")
        else:
            cursor.execute("SELECT * FROM store_categories ORDER BY id ASC")
        return [dict(r) for r in cursor.fetchall()]
    finally:
        conn.close()


def get_store_category_by_id(cat_id: int) -> Optional[Dict[str, Any]]:
    conn = get_db_connection()
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT * FROM store_categories WHERE id = ?", (int(cat_id),))
        row = cursor.fetchone()
        return dict(row) if row else None
    finally:
        conn.close()


def toggle_store_category_active(cat_id: int) -> Optional[int]:
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT is_active FROM store_categories WHERE id = ?", (int(cat_id),))
        row = cursor.fetchone()
        if not row:
            return None
        new_val = 0 if row[0] else 1
        cursor.execute("UPDATE store_categories SET is_active = ? WHERE id = ?", (new_val, int(cat_id)))
        conn.commit()
        return new_val
    finally:
        conn.close()


def delete_store_category(cat_id: int, move_services_to_root: bool = True) -> bool:
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("BEGIN IMMEDIATE")
        if move_services_to_root:
            cursor.execute("UPDATE store_services SET category_id = 0 WHERE category_id = ?", (int(cat_id),))
        else:
            cursor.execute("DELETE FROM store_services WHERE category_id = ?", (int(cat_id),))
        cursor.execute("DELETE FROM store_categories WHERE id = ?", (int(cat_id),))
        ok = cursor.rowcount > 0
        conn.commit()
        return ok
    except Exception:
        conn.rollback()
        return False
    finally:
        conn.close()


def create_store_service(
    title: str,
    description: str,
    price_stars: int = 0,
    price_tokens: float = 0.0,
    category_id: int = 0,
    price_usdt: str = "",
    bundle_mode: int = 0,
) -> int:
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            """
            INSERT INTO store_services (
                category_id, title, description, price_stars, price_tokens, price_usdt, bundle_mode, is_active
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, 1)
            """,
            (
                int(category_id or 0),
                title.strip(),
                description.strip(),
                int(price_stars),
                round(float(price_tokens), 4),
                str(price_usdt or "").strip(),
                1 if int(bundle_mode) else 0,
            )
        )
        conn.commit()
        return cursor.lastrowid or 0
    finally:
        conn.close()


def get_store_services(only_active: bool = True, category_id: Optional[int] = None) -> List[Dict[str, Any]]:
    conn = get_db_connection()
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    try:
        clauses = []
        params: List[Any] = []
        if only_active:
            clauses.append("is_active = 1")
        if category_id is not None:
            clauses.append("COALESCE(category_id, 0) = ?")
            params.append(int(category_id))
        where_sql = (" WHERE " + " AND ".join(clauses)) if clauses else ""
        cursor.execute(f"SELECT * FROM store_services{where_sql} ORDER BY id DESC", params)
        return [dict(r) for r in cursor.fetchall()]
    finally:
        conn.close()


def get_store_service_by_id(service_id: int) -> Optional[Dict[str, Any]]:
    conn = get_db_connection()
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT * FROM store_services WHERE id = ?", (int(service_id),))
        row = cursor.fetchone()
        return dict(row) if row else None
    finally:
        conn.close()


def update_store_service_pricing(
    service_id: int,
    price_stars: int,
    price_tokens: float,
    price_usdt: Optional[str] = None,
    bundle_mode: Optional[int] = None,
) -> bool:
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cur_srv = get_store_service_by_id(int(service_id))
        if not cur_srv:
            return False
        new_usdt = str(cur_srv.get("price_usdt") or "").strip() if price_usdt is None else str(price_usdt).strip()
        new_bundle = int(cur_srv.get("bundle_mode") or 0) if bundle_mode is None else (1 if int(bundle_mode) else 0)
        cursor.execute(
            "UPDATE store_services SET price_stars = ?, price_tokens = ?, price_usdt = ?, bundle_mode = ? WHERE id = ?",
            (int(price_stars), round(float(price_tokens), 4), new_usdt, new_bundle, int(service_id))
        )
        conn.commit()
        return cursor.rowcount > 0
    finally:
        conn.close()


def toggle_store_service_bundle_mode(service_id: int) -> Optional[int]:
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT COALESCE(bundle_mode, 0) FROM store_services WHERE id = ?", (int(service_id),))
        row = cursor.fetchone()
        if not row:
            return None
        new_val = 0 if int(row[0]) else 1
        cursor.execute("UPDATE store_services SET bundle_mode = ? WHERE id = ?", (new_val, int(service_id)))
        conn.commit()
        return new_val
    finally:
        conn.close()


def toggle_store_service_active(service_id: int) -> Optional[int]:
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT is_active FROM store_services WHERE id = ?", (int(service_id),))
        row = cursor.fetchone()
        if not row:
            return None
        new_val = 0 if row[0] else 1
        cursor.execute("UPDATE store_services SET is_active = ? WHERE id = ?", (new_val, int(service_id)))
        conn.commit()
        return new_val
    finally:
        conn.close()


def delete_store_service(service_id: int) -> bool:
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("DELETE FROM store_services WHERE id = ?", (int(service_id),))
        conn.commit()
        return cursor.rowcount > 0
    finally:
        conn.close()


def purchase_service_with_tokens(
    user_id: int,
    service_id: int,
    override_tokens: Optional[float] = None,
    payment_method: str = "TOKENS",
    paid_label: Optional[str] = None,
) -> Tuple[bool, str, Optional[Dict[str, Any]]]:
    conn = get_db_connection()
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    try:
        cursor.execute("BEGIN IMMEDIATE")
        cursor.execute("SELECT * FROM store_services WHERE id = ? AND is_active = 1", (int(service_id),))
        srv = cursor.fetchone()
        if not srv:
            conn.commit()
            return (False, "NOT_FOUND", None)

        price_tok = round(float(srv["price_tokens"] or 0), 4) if override_tokens is None else round(float(override_tokens), 4)
        if price_tok <= 0:
            conn.commit()
            return (False, "NO_TOKEN_PRICE", None)

        cursor.execute("SELECT balance FROM users WHERE user_id = ?", (user_id,))
        u_row = cursor.fetchone()
        bal = round(float(u_row["balance"] or 0), 4) if u_row else 0.0
        if bal < price_tok:
            conn.commit()
            return (False, "INSUFFICIENT", None)

        new_bal = round(bal - price_tok, 4)
        cursor.execute("UPDATE users SET balance = ? WHERE user_id = ?", (new_bal, user_id))

        order_code = f"SRV-{int(datetime.now(timezone.utc).timestamp())}-{user_id % 10000}"
        cursor.execute(
            """
            INSERT INTO service_orders (order_code, user_id, service_id, service_title, payment_method, amount_paid)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (order_code, user_id, int(service_id), srv["title"], payment_method, price_tok)
        )
        conn.commit()
        return (True, "SUCCESS", {
            "order_code": order_code,
            "service_title": srv["title"],
            "amount_paid": price_tok,
            "paid_label": paid_label or f"{_fmt_num(price_tok)} توكن",
            "new_balance": new_bal,
        })
    except Exception:
        conn.rollback()
        return (False, "ERROR", None)
    finally:
        conn.close()


def record_service_star_order(
    user_id: int,
    service_id: int,
    service_title: str,
    stars_paid: int,
    extra_tokens_deducted: float = 0.0,
    payment_method: str = "STARS",
) -> str:
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("BEGIN IMMEDIATE")
        order_code = f"STR-{int(datetime.now(timezone.utc).timestamp())}-{user_id % 10000}"
        cursor.execute(
            """
            INSERT INTO service_orders (order_code, user_id, service_id, service_title, payment_method, amount_paid)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (order_code, user_id, int(service_id), service_title, payment_method, float(stars_paid))
        )
        if extra_tokens_deducted > 0:
            cursor.execute(
                "UPDATE users SET stars_spent = COALESCE(stars_spent, 0) + ?, balance = ROUND(MAX(0.0, COALESCE(balance, 0.0) - ?), 4) WHERE user_id = ?",
                (int(stars_paid), round(float(extra_tokens_deducted), 4), user_id)
            )
        else:
            cursor.execute(
                "UPDATE users SET stars_spent = COALESCE(stars_spent, 0) + ? WHERE user_id = ?",
                (int(stars_paid), user_id)
            )
        conn.commit()
        return order_code
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def record_service_usdt_order(user_id: int, service_id: int, service_title: str, usdt_price: str) -> str:
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        order_code = f"USDT-{int(datetime.now(timezone.utc).timestamp())}-{user_id % 10000}"
        numeric_amt = 0.0
        try:
            cleaned = "".join(ch for ch in str(usdt_price) if ch.isdigit() or ch == ".")
            if cleaned:
                numeric_amt = float(cleaned)
        except Exception:
            numeric_amt = 0.0
        cursor.execute(
            """
            INSERT INTO service_orders (order_code, user_id, service_id, service_title, payment_method, amount_paid)
            VALUES (?, ?, ?, ?, 'USDT', ?)
            """,
            (order_code, user_id, int(service_id), service_title, numeric_amt)
        )
        conn.commit()
        return order_code
    finally:
        conn.close()


def get_recent_service_orders(limit: int = 15) -> List[Dict[str, Any]]:
    conn = get_db_connection()
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    try:
        cursor.execute(
            """
            SELECT o.*, u.username
            FROM service_orders o
            LEFT JOIN users u ON u.user_id = o.user_id
            ORDER BY o.id DESC
            LIMIT ?
            """,
            (limit,)
        )
        return [dict(r) for r in cursor.fetchall()]
    finally:
        conn.close()
